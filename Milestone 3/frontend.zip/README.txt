## Software Engineering Project - Team 22

# Life Skills App for School-Aged Children

### Team Overview
	- Deepak Kumar Singh
	- Kumar Rishabh
	- Aarush Saxena
	- Rahul Sharma
	- Arya Chavan
	- Nikhil Sai Kasireddy
	- Gopu Vishal Reddy

## Project Structure

frontend/
├── SE-project			
    ├── public/                
    ├── src/
	│   ├── assets/        # Images/Icons
	│   ├── components/    # Reusable Vue components
	│   ├── layouts/   	# Role-based Sidebar Layouts
	│   ├── stores/    	# focusStore js component
	│   ├── views/    	# Main View Components
	│   ├── App.vue        # Root component
	│   └── main.js        # Main App Creation Point
	│   ├── api.js         # Vue Api config
	│   ├── router.js      # Vue Router config
	│   ├── store.js       # Vue Store config
    	├── package-lock.json  # Dependency manifest
    	└── package.json       # Dependency manifest


## Tech Stack

	- **Framework**: Vue.js 3
	- **Language**: JavaScript (ES6+)
	- **State Management**: Vuex / Pinia
	- **Routing**: Vue Router
	- **Cloud**: Cloud-hosted LLM (via LangChain)
	- **Node.js**: v20.11.0+
	- **npm**: v10.8.3+


## Setup Instructions

	1. Open your terminal/cmd and navigate to the 'frontend/SE-project' folder.
	
	2. Run ` npm install ` and it should install the necessary `node_modules` dependencies.
		```bash
		    npm install
	    	```

	3. Run the development server ` npm run dev ` to start the application.
		```bash
		    npm run dev
    		``` 

	4. Go to http://localhost:5173/ to view the app.


## Frontend Walkthrough

1. Once you go to the ` localhost:5173/ `, ` Login page ` will be the first view. From there you can go to the ` Registration ` Page.
	- At the login page you can login via any role by simply putting ur username or email.
	- At the registration page you can sign up by choosing your role either ` Student ` or ` Instructor ` or ` Parent `.

2. Once Login is done, you will be redirected to the Dashboard Page of your specific role.

## ⚠️ YOU CAN DIRECTLY GO TO RESPECTIVE USER PAGES BY FOLLOWING THE LINKS PROVIDED IN THE BELOW SECTION ROLES.

3. For ` Student ` role:
	- ⚠️ TO PREVIEW STUDENT UI, Kindly go to  ` http://localhost:5173/student/1/dashboard `.
	- There are 6 pages and a logout button in the sidebar.
	- Pages include Dashboard, Assignments, Badges, Resources, Calendar, Profile.
	- Focus mode functionality is also given for this role.
	- Chatbot feature is also used so the role can take help from it.

4. For ` Instructor ` role:
	- ⚠️ TO PREVIEW STUDENT UI, Kindly go to  ` http://localhost:5173/teacher/1/dashboard `.
	- There are 6 pages and a logout button in the sidebar.
	- Pages include Dashboard, My Students, Assignments, Resources, Comms Center, Profile
	- Teachers can have a direct conversation with the enrolled student's parents too.

5. For ` Parent ` role:
	- ⚠️ TO PREVIEW PARENT UI, Kindly go to  ` http://localhost:5173/parent `.
	- There are 3 pages and a logout button in the sidebar.
	- Pages include Dashboard, Messages, Comms Center.
	- Parent can view all their child's analytics.

6. For ` Admin ` role:
	- ⚠️ TO PREVIEW ADMIN UI, Kindly go to  ` http://localhost:5173/admin `.
	- App statistics are available on the dashboard
	- Admin has all the necessary CRUD functionalities to manage both roles.
	- Student-Student, Student-Instructor, Instructor-Student, Instructor-Instructor queries can also be managed by the admin.
	- Admin can announce or tag the users accordingly too.

7. Once the user logs out. The access_token and the session storage will be emptied.


That's it!
Thank you for previewing our frontend! :)
Our team is constantly working on improving the UI and the features part for each role! 
 