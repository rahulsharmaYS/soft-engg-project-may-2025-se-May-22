import { createRouter, createWebHistory } from 'vue-router';

// Layouts
import InstructorLayout from '@/layouts/InstructorLayout.vue';
import StudentLayout from '@/layouts/StudentLayout.vue';
import ParentLayout from '@/layouts/ParentLayout.vue';
import AdminLayout from './layouts/AdminLayout.vue';

// All Views & Components
import Dashboard from '@/views/Dashboard.vue';
import MySkills from '@/components/MySkills.vue';
import Resources from '@/components/Resources.vue';
import StudentCalendar from '@/components/StudentCalendar.vue';
import StudentMessages from '@/components/StudentMessages.vue';
import StudentProfile from '@/components/StudentProfile.vue';
import StudentAssignments from '@/components/StudentAssignments.vue';
import SubmitAssignment from '@/components/SubmitAssignment.vue';
import StudentTasks from '@/components/StudentTasks.vue';
import EditTask from '@/components/EditTask.vue';
import StudentBadges from '@/components/StudentBadges.vue';
import StudentNotifications from '@/components/StudentNotifications.vue';

import InstructorDashboard from '@/views/InstructorDashboard.vue';
import StudentManagement from '@/components/StudentManagement.vue';
import StudentDetail from '@/components/StudentDetail.vue';
import InstructorAssignments from '@/components/InstructorAssignments.vue';
import InstructorProfile from '@/components/InstructorProfile.vue';

import AdminDashboard from '@/views/AdminDashboard.vue';
import ParentDashboard from '@/views/ParentDashboard.vue';
import ParentsMessages from '@/components/ParentsMessages.vue';
import ParentProfile from '@/components/ParentProfile.vue';

import UserManagement from '@/components/UserManagement.vue';
import HelpCenter from '@/components/HelpCenter.vue';
import Annoucements from '@/components/Announcements.vue';

import Login from '@/views/Login.vue';
import Register from '@/views/Register.vue';
import CommsCenter from '@/components/CommsCenter.vue';


const routes = [
  // --- General & Other Role Routes ---
  { path: '/', redirect: '/login' },
  { path: '/login', name: 'Login', component: Login },
  { path: '/register', name: 'Register', component: Register },
  { path: '/admin', name: 'AdminDashboard', component: AdminDashboard },
  
  // --- STUDENT SECTION (Using StudentLayout) ---
 {
  path: '/student/:id',
  component: StudentLayout,
  children: [
    {  path: 'dashboard',  name: 'StudentDashboard',  component: Dashboard},
    {  path: 'assignments',  name: 'StudentAssignments',  component: StudentAssignments},
    {  path: 'assignments/:assignmentId/submit',  name: 'SubmitAssignment',  component: SubmitAssignment },
    {  path: 'tasks',  name: 'StudentTasks',  component: StudentTasks },
    {  path: 'tasks/:taskId/edit',  name: 'EditTask',  component: EditTask },
    {  path: 'calendar',  name: 'StudentCalendar',  component: StudentCalendar},
    { path: 'profile', name: 'StudentProfile', component: StudentProfile},
    { path: 'badges',  name: 'StudentBadges',  component: StudentBadges },
    { path: 'resources',  name: 'StudentResources',  component: Resources},
    {  path: 'messages',  name: 'StudentMessages',  component: StudentMessages},
    { path: 'notifications', name: 'StudentNotifications', component: StudentNotifications }
  ]
},

  // --- INSTRUCTOR SECTION (Using InstructorLayout) ---

  {
    path: '/teacher/:teacher_id',
    component: InstructorLayout,
    children: [
      { path: 'dashboard', name: 'InstructorDashboard', component: InstructorDashboard },
      { path: 'students', name: 'StudentManagement', component: StudentManagement },
      // { path: 'student/:id', name: 'StudentDetail', component: StudentDetail },
      { path: 'assignments', name: 'InstructorAssignments', component: InstructorAssignments },
      { path: 'resources', name: 'InstructorResources', component: Resources },
      { path: 'profile', name: 'InstructorProfile', component: InstructorProfile },
      { path: 'comms', name: 'InstructorComms', component: CommsCenter }
    ]
  },
  
  // --- PARENT SECTION (Using ParentLayout) ---
  {
    path: '/parent',
    component: ParentLayout,
    children: [
      { path: '', name: 'ParentDashboard', component: ParentDashboard },
      { path: 'messages', name: 'ParentsMessages', component: ParentsMessages },
      { path: 'comms', name: 'ParentComms', component: CommsCenter },
      { path: 'profile', name: 'ParentProfile', component: ParentProfile }
    ]
  },

  // --- ADMIN SECTION (Later work)---
  {
    path: '/admin',
    component: AdminLayout,
    children: [
      { path: '', name: 'AdminDashboard', component: AdminDashboard },
      { path: 'usermanagement', name: 'UserManagement', component: UserManagement },
      { path: 'helpcenter', name: 'HelpCenter', component: HelpCenter },
      { path: 'announcements', name: 'Announcements', component: Annoucements }
    ]
  }
];

export const router = createRouter({
  history: createWebHistory(),
  routes
});