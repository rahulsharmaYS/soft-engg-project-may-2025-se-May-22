import { reactive } from 'vue'

export const store = reactive({
  darkMode: false,
  toggleTheme() {
    this.darkMode = !this.darkMode
  }
})
