<template>
  <div>
    <div style="display: flex; justify-content: flex-end; align-items: center; padding: 1rem; position: relative;">
      <button @click="toggleDropdown" style="background: none; border: none; cursor: pointer; font-size: 1.5rem;">
        🔔
        <span v-if="notifications.length" style="color: red; font-weight: bold;">({{ notifications.length }})</span>
      </button>

      <div v-if="dropdownOpen" style="position: absolute; top: 3.2rem; right: 1rem; background: white; border: 1px solid #ddd; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); z-index: 50; width: 300px; padding: 10px;">
        <h4>Notifications</h4>
        <ul style="list-style: none; padding-left: 0; max-height: 250px; overflow-y: auto;">
          <li v-if="notifications.length === 0">No new notifications</li>
          <li v-for="(note, idx) in notifications" :key="idx" style="margin-bottom: 10px; border-bottom: 1px solid #eee; padding-bottom: 5px;">
            <strong>{{ formatTime(note.timestamp) }}</strong><br />
            {{ note.message }}
          </li>
        </ul>
      </div>
    </div>
    <Header :title="`Welcome Back, ${studentName}`" 


    subtitle="Here’s a quick glance at your progress" />

    <section class="grid">
      <section class="left">
        <h2>Knowledge base</h2>
        <div class="cards">
          <Card title="Vocabulary" icon="📘" color="#90b4ce" />
          <Card title="Phrasal verbs" icon="📕" color="#e57373" />
          <Card title="Grammar" icon="📗" color="#c9b037" />
        </div>

        <h2>Class Stats</h2>
        <div class="cards">
          <Card title="Today's Tasks" icon="📋" color="#4ade80" :value="studentStats.todaysTasksAndAssignments" />
          <Card title="Upcoming Assignments" icon="📝" color="#fbbf24" :value="studentStats.upcomingAssignments" />
          <Card title="Completed Assignments" icon="✅" color="#a78bfa" :value="studentStats.completedAssignments" />
        </div>

        <h2>Statistics</h2>
        <Chart />

        <h2>Focus Mode</h2>
        <div class="focus-mode">
          <input
            type="number"
            v-model.number="focusMinutes"
            placeholder="Minutes"
            min="1"
          />
          <button @click="startFocusMode">Enter Focus Mode</button>
        </div>
        <div v-if="focus.isFocusActive" class="focus-progress-bar">
  <div class="bar-container">
    <div class="bar-fill" :style="{ width: progressPercentage + '%' }">
      <span class="emoji">{{ progressEmoji }}</span>
    </div>
  </div>
  <p class="progress-message">{{ progressMessage }}</p>
</div>

      </section>

      <section class="right">
        <CalendarUpcoming />
        <TaskManagement />
      </section>
    </section>

    <ChatBox />

    <button
      v-if="focus.isFocusActive"
      @click="focus.cancelFocusMode"
      class="cancel-focus-btn"
    >
      ❌ Cancel Focus Mode
    </button>

    <div v-if="focus.isFocusActive" class="focus-notice">
      <p>🧘 Focus Mode — Time Left: <strong>{{ focus.formattedTime }}</strong></p>
    </div>
  </div>
</template>

<script setup>
import api from '../api';
import { ref, watch, computed, onUnmounted, onMounted } from 'vue';  
import { useFocusStore } from '../stores/focusStores';
import Header from '../components/Header.vue';
import Card from '../components/Card.vue';
import Chart from '../components/Chart.vue';
import ChatBox from '../components/ChatBox.vue';
import CalendarUpcoming from '../components/CalendarUpcoming.vue';

const dropdownOpen = ref(false)
const studentName = ref('');

function toggleDropdown() {
  dropdownOpen.value = !dropdownOpen.value
}

function formatTime(timestamp) {
  const date = new Date(timestamp)
  return date.toLocaleString('en-IN', {
    day: '2-digit',
    month: 'short',
    hour: '2-digit',
    minute: '2-digit',
  })
}

const focus = useFocusStore();
const focusMinutes = ref(25);
const elapsedSeconds = ref(0);
let interval = null;

const totalFocusSeconds = computed(() => focusMinutes.value * 60);

const progressPercentage = computed(() =>
  Math.min(100, Math.round((elapsedSeconds.value / totalFocusSeconds.value) * 100))
);

const progressEmoji = computed(() => {
  const pct = progressPercentage.value;
  if (pct < 25) return '🐢';
  if (pct < 50) return '🚶‍♂️';
  if (pct < 75) return '🏃';
  if (pct < 100) return '🚀';
  return '🎉';
});

const progressMessage = computed(() => {
  const pct = progressPercentage.value;
  if (pct < 25) return 'Let’s start slow...';
  if (pct < 50) return 'Great going!';
  if (pct < 75) return 'Almost there!';
  if (pct < 100) return 'Final push!';
  return 'You did it!';
});

watch(() => focus.isFocusActive, (newVal) => {
  if (newVal) {
    elapsedSeconds.value = 0;
    interval = setInterval(() => {
      elapsedSeconds.value += 1;
      if (elapsedSeconds.value >= totalFocusSeconds.value) {
        clearInterval(interval);
      }
    }, 1000);
  } else {
    clearInterval(interval);
    elapsedSeconds.value = 0;
  }
});

onUnmounted(() => {
  clearInterval(interval);
});

function startFocusMode() {
  focus.startFocusMode(focusMinutes.value);
}

const studentStats = ref({
  todaysTasksAndAssignments: 0,
  upcomingAssignments: 0,
  completedAssignments: 0,
});

const tasks = ref([]);
const assignments = ref([]);
const badges = ref([]);
const profile = ref({});
const calendarItems = ref([]);
const notifications = ref([]);
const resources = ref([]);

import { useRoute } from 'vue-router';
const route = useRoute();
const studentId = computed(() => route.params.id);

async function fetchTasks() {
  try {
    const res = await api.get(`student/${studentId.value}/calendar`);
    tasks.value = res.data;
  } catch (e) {
    console.error("Error fetching tasks:", e);
  }
}

async function fetchAssignments() {
  try {
    const res = await api.get(`student/${studentId.value}/assignments`);
    assignments.value = res.data;
  } catch (e) {
    console.error("Error fetching assignments:", e);
  }
}

async function fetchBadges() {
  try {
    const res = await api.get(`student/${studentId.value}/badges`);
    badges.value = res.data;
  } catch (e) {
    console.error("Error fetching badges:", e);
  }
}

async function fetchProfile() {
  try {
    const res = await api.get(`student/${studentId.value}/profile`);
    profile.value = res.data;
    studentName.value = res.data.full_name || 'Learner';
  } catch (e) {
    console.error("Error fetching profile:", e);
  }
}

async function fetchCalendar() {
  try {
    const res = await api.get(`student/${studentId.value}/calendar`);
    calendarItems.value = res.data;
  } catch (e) {
    console.error("Error fetching calendar:", e);
  }
}

async function fetchNotifications() {
  try {
    const res = await api.get(`student/${studentId.value}/notifications`);
    notifications.value = res.data;
  } catch (e) {
    console.error("Error fetching notifications:", e);
  }
}

async function fetchResources() {
  try {
    const res = await api.get(`student/${studentId.value}/resources`);
    resources.value = res.data;
  } catch (e) {
    console.error("Error fetching resources:", e);
  }
}


const todaysTasksAndAssignments = computed(() => {
  const today = new Date().toISOString().split('T')[0]; 

  const todayTasks = tasks.value.filter(task => task.created_at?.startsWith(today));

  const todayAssignments = assignments.value.filter(assignment => assignment.created_at?.startsWith(today));

  return todayTasks.length + todayAssignments.length;
});

const upcomingAssignments = computed(() => {
  const today = new Date();
  return assignments.value.filter(assignment => {
    if (!assignment.due_date) return false;
    return new Date(assignment.due_date) > today;
  }).length;
});

const completedAssignments = computed(() => {
  return assignments.value.filter(a => a.status === 'complete').length;
});

watch([todaysTasksAndAssignments, upcomingAssignments, completedAssignments], () => {
  studentStats.value.todaysTasksAndAssignments = todaysTasksAndAssignments.value;
  studentStats.value.upcomingAssignments = upcomingAssignments.value;
  studentStats.value.completedAssignments = completedAssignments.value;
});

onMounted(async () => {
  await Promise.all([
    fetchTasks(),
    fetchAssignments(),
    fetchBadges(),
    fetchProfile(),
    fetchCalendar(),
    fetchNotifications(),
    fetchResources()
  ]);
});
</script>


<style scoped>
.main {
  flex: 1;
  padding: 2rem;
  background: var(--bg);
  color: var(--text);
}
.grid {
  display: flex;
  gap: 2rem;
}
.left {
  flex: 2;
}
.right {
  flex: 1;
}
.cards {
  display: flex;
  gap: 1rem;
  margin-bottom: 2rem;
}
.focus-mode {
  display: flex;
  gap: 1rem;
  margin-top: 1rem;
}
.focus-mode input {
  padding: 0.5rem;
  border-radius: 0.5rem;
  border: 1px solid #ccc;
  width: 100px;
}
.focus-mode button {
  background-color: #4f46e5;
  color: white;
  padding: 0.5rem 1rem;
  border-radius: 0.5rem;
  cursor: pointer;
  border: none;
}
.cancel-focus-btn {
  position: fixed;
  top: 1rem;
  left: 1rem;
  z-index: 2000;
  background-color: #ef4444;
  color: white;
  border: none;
  padding: 0.5rem 1rem;
  border-radius: 0.5rem;
  cursor: pointer;
}

.focus-notice {
  position: fixed;
  bottom: 1rem;
  right: 1rem;
  background: rgba(0, 0, 0, 0.85);
  color: white;
  padding: 1rem 1.5rem;
  border-radius: 1rem;
  z-index: 1500;
}
.focus-progress-bar {
  position: fixed;
  bottom: 4rem;
  right: 1rem;
  left: 1rem;
  margin: 0 auto;
  max-width: 600px;
  background-color: #fef3c7;
  border: 2px solid #fde68a;
  padding: 1rem;
  border-radius: 1rem;
  z-index: 1600;
  text-align: center;
}

.bar-container {
  background-color: #fcd34d;
  height: 24px;
  border-radius: 999px;
  overflow: hidden;
  margin-bottom: 0.5rem;
  position: relative;
}

.bar-fill {
  background-color: #4ade80;
  height: 100%;
  width: 0;
  display: flex;
  align-items: center;
  justify-content: flex-end;
  border-radius: 999px;
  transition: width 1s linear;
  padding-right: 0.5rem;
  font-size: 20px;
}

.emoji {
  animation: bounce 1s infinite alternate;
}

.progress-message {
  font-weight: bold;
  color: #92400e;
  font-size: 1rem;
}

@keyframes bounce {
  from { transform: translateY(0); }
  to { transform: translateY(-5px); }
}
</style>