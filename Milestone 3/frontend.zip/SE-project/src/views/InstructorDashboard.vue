<template>
  <div>
    <!-- instructor name -->
    <Header 
      :title="`Welcome back, ${teacherName} 👋`"
      subtitle="Here’s a detailed look at your platform activity." 
    />

    <div class="stats-cards-grid">
      <MetricCard icon="🧑‍🎓" label="Total Students" :value="dashboardData.summary?.total_students || 0" />
      <MetricCard icon="🔥" label="Active Students" :value="dashboardData.summary?.active_students || 0" />
      <MetricCard icon="📚" label="Courses Taught" :value="dashboardData.summary?.courses_taught || 0" />
      <MetricCard icon="✅"
        label="Overall Completion"
        :value="`${dashboardData.summary?.overall_completion || 0}%`"
        :progress="dashboardData.summary?.overall_completion || 0"
      />
    </div>

    <div class="dashboard-grid">
      <div class="chart-card">
        <h3>Assignment Performance</h3>
        <p class="chart-subtitle">Average score (%) per assignment</p>
        <AssignmentPerformanceChart :teacherId="teacher_id" />
      </div>

      <div class="chart-card">
        <h3>Student Engagement</h3>
        <p class="chart-subtitle">Distribution of student activity levels</p>
        <StudentEngagementChart :teacherId="teacher_id" />
      </div>
      
      <!-- <div class="chart-card">
        <h3>Class Attendance Rate</h3>
        <AttendanceChart :teacherId="teacher_id" />
      </div> -->

      <div class="chart-card">
        <h3>Course Completion</h3>
        <CourseCompletionChart :teacherId="teacher_id" />
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import { useRoute } from 'vue-router';

import Header from '../components/Header.vue';
import MetricCard from '../components/MetricCard.vue';
import AttendanceChart from '../components/AttendanceChart.vue';
import CourseCompletionChart from '../components/CourseCompletionChart.vue';
import StudentEngagementChart from '../components/StudentEngagementChart.vue';
import AssignmentPerformanceChart from '../components/AssignmentPerformanceChart.vue';
import api from '@/api';

const route = useRoute();
const teacher_id = route.params.teacher_id;

const teacherName = ref('');
const dashboardData = ref({});

const error = ref(null);

onMounted(async () => {
  try {
    const response = await api.get(`/teacher/${teacher_id}/dashboard`);
    console.log('Dashboard data:', response.data);
    teacherName.value = response.data.teacher_name || 'Instructor';
    dashboardData.value = response.data;
  } catch (err) {
    console.error('Dashboard load error:', err);
    error.value = 'Failed to load dashboard. Please try again later.';
  }
});
</script>

<style scoped>
.stats-cards-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 1.5rem;
  margin-top: 2rem;
}

.dashboard-grid {
  margin-top: 2rem;
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
  gap: 1.5rem;
}

.chart-card {
  background-color: var(--card);
  padding: 1.5rem;
  border-radius: 12px;
  box-shadow: 0 4px 12px rgba(0,0,0,0.05);
  border: 1px solid var(--border);
  display: flex;
  flex-direction: column;
}

.chart-card h3 {
  margin-top: 0;
  margin-bottom: 0.25rem;
  font-weight: 600;
}

.chart-subtitle {
  font-size: 0.9rem;
  color: #888;
  margin-top: 0;
  margin-bottom: 1.5rem;
}
</style>