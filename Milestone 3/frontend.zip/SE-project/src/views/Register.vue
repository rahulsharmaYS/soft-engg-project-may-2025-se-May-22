<template>
  <div class="auth-page">
    <div class="auth-panel">
      <div class="form-wrapper">
        <div class="form-content">
          <h1 class="title">Create an Account</h1>
          <p class="subtitle">Get started on your journey with us.</p>
          
          <form @submit.prevent="handleRegister">
            <div class="select-group">
              <select v-model="role" id="role" required>
                <option value="student">Sign up as a Student</option>
                <option value="teacher">Sign up as an Teacher</option>
                <option value="parent">Sign up as a Parent</option>
              </select>
            </div>

            <div class="name-group">
              <div class="input-group">
                <input type="text" v-model="firstName" id="firstName" required>
                <label for="firstName">First Name</label>
                <span class="focus-bar"></span>
              </div>
              <div class="input-group">
                <input type="text" v-model="lastName" id="lastName" required>
                <label for="lastName">Last Name</label>
                <span class="focus-bar"></span>
              </div>
            </div>
            <div class="input-group">
              <input type="text" v-model="userid" id="userid" required>
              <label for="userid">User ID</label>
              <span class="focus-bar"></span>
            </div>
            <div class="input-group">
              <input type="email" v-model="email" id="email" required>
              <label for="email">Email Address</label>
              <span class="focus-bar"></span>
            </div>
            <div class="input-group">
              <input type="password" v-model="password" id="password" required>
              <label for="password">Password</label>
              <span class="focus-bar"></span>
            </div>
            
            <template v-if="role === 'student'">
              <div class="select-group">
                <label for="grade">Grade Level</label>
                <select v-model="grade" id="grade" required>
                    <option disabled value="">Select your grade...</option>
                    <option>3rd Grade</option>
                    <option>4th Grade</option>
                    <option>5th Grade</option>
                    <option>6th Grade</option>
                    <option>7th Grade</option>
                    <option>8th Grade</option>
                </select>
              </div>
              <div class="skills-group">
                <label class="skills-heading">What skills do you want to learn?</label>
                <div class="skills-options">
                    <div v-for="skill in availableSkills" :key="skill.id" class="skill-pill" :class="{ selected: selectedSkills.includes(skill.name) }" @click="toggleSkill(skill.name)">
                      {{ skill.name }}
                    </div>
                </div>
              </div>
            </template>

            <template v-if="role === 'teacher'">
              <div class="input-group">
                <input type="text" v-model="institution" id="institution" required>
                <label for="institution">School / Institution</label>
                <span class="focus-bar"></span>
              </div>
              <div class="skills-group">
                <label class="skills-heading">Which course(s) will you be teaching?</label>
                <div class="skills-options">
                    <div v-for="course in availableCourses" :key="course.id" class="skill-pill" :class="{ selected: selectedCourses.includes(course.name) }" @click="toggleCourse(course.name)">
                      {{ course.name }}
                    </div>
                </div>
              </div>
            </template>
            <template v-if="role === 'parent'">
              <div class="input-group">
                <input type="email" v-model="childEmail" id="childEmail" required>
                <label for="childEmail">Your Child's Email Address</label>
                <span class="focus-bar"></span>
              </div>
            </template>

            <button type="submit" class="auth-btn">Create Account</button>
          </form>
          
          <div class="auth-switch">
            <span>Already have an account? </span>
            <router-link to="/login">Sign In</router-link>
          </div>
        </div>
      </div>
      
      <div class="branding-wrapper">
        <div class="branding-content">
          <h1>Life Skills</h1>
          <p>Empowering the next generation.</p>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import api from '../api';
import { ref, reactive } from 'vue';
import { useRouter } from 'vue-router';

const router = useRouter();
const role = ref('student');
const firstName = ref('');
const lastName = ref('');
const userid = ref('');
const email = ref('');
const password = ref('');
const grade = ref('');
const selectedSkills = ref([]);
const availableSkills = reactive([
  { id: 'skill1', name: 'Time Management' }, { id: 'skill2', name: 'Communication' }, { id: 'skill3', name: 'Health' },
  { id: 'skill4', name: 'Decision Making' }, { id: 'skill5', name: 'Financial Literacy' }, { id: 'skill6', name: 'Problem Solving' },
]);
const institution = ref('');
const selectedCourses = ref([]);
const availableCourses = reactive([
  { id: 'course1', name: 'Time Management' }, { id: 'course2', name: 'Communication' }, { id: 'course3', name: 'Health' },
  { id: 'course4', name: 'Decision Making' }, { id: 'course5', name: 'Financial Literacy' }, { id: 'course6', name: 'Problem Solving' },
]);
const childEmail = ref('');

const toggleSkill = (skillName) => {
  const index = selectedSkills.value.indexOf(skillName);
  if (index > -1) selectedSkills.value.splice(index, 1);
  else selectedSkills.value.push(skillName);
};

const toggleCourse = (courseName) => {
  const index = selectedCourses.value.indexOf(courseName);
  if (index > -1) selectedCourses.value.splice(index, 1);
  else selectedCourses.value.push(courseName);
};

const handleRegister = async () => {
  const payload = {
    username: userid.value,
    password: password.value,
    role_name: role.value,
    email: email.value,
    full_name: `${firstName.value} ${lastName.value}`.trim(),
  };

  if (role.value === 'student') {
    payload.class_id = grade.value;
  } else if (role.value === 'teacher') {
    payload.class_id = institution.value;
  } else if (role.value === 'parent') {
    payload.child_email = childEmail.value;
  }

  try {
    const res = await api.post('/user/create_user', payload);
    console.log('User registered:', res.data);
    router.push('/login');
  } catch (err) {
    alert(err.response?.data?.detail || err.message || 'Registration failed');
  }
};
</script>


<style scoped>
.name-group { display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem; }
.auth-page { display: flex; justify-content: center; align-items: center; min-height: 100vh; background-color: var(--bg); padding: 1rem; animation: fadeIn 0.5s ease-out; }
@keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
.auth-panel { display: grid; grid-template-columns: 1fr 1fr; width: 100%; max-width: 1100px; background-color: var(--card); border-radius: 20px; box-shadow: 0 15px 40px rgba(0,0,0,0.12); overflow: hidden; }
.form-wrapper { display: flex; justify-content: center; align-items: center; padding: 2rem; overflow-y: auto; }
.form-content { width: 100%; max-width: 400px; }
.title { font-size: 2.2rem; font-weight: 700; color: var(--text); margin-bottom: 0.75rem; }
.subtitle { color: #888; margin-bottom: 2.5rem; font-size: 1.1rem; }
.input-group, .select-group { position: relative; margin-bottom: 2.5rem; } 
input, select { width: 100%; padding: 10px 0; font-size: 1rem; color: var(--text); border: none; border-bottom: 2px solid var(--border); background-color: transparent; transition: border-color 0.3s; }
input:focus { outline: none; border-color: var(--primary); }
.input-group > label { position: absolute; top: 10px; left: 0; font-size: 1rem; color: #aaa; pointer-events: none; transition: all 0.3s ease; }
input:focus + label, input:valid + label { top: -20px; font-size: 0.8rem; color: var(--primary); }
.focus-bar { position: absolute; bottom: 0; left: 0; width: 100%; height: 2px; background-color: var(--primary); transform: scaleX(0); transition: transform 0.3s ease; }
input:focus ~ .focus-bar { transform: scaleX(1); }


.select-group label { display: block; font-size: 0.8rem; color: #888; margin-bottom: 8px; }
.select-group select { padding: 10px; border: 1px solid var(--border); border-radius: 8px; }
.select-group select:focus { outline: none; border-color: var(--primary); box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.2); }

.auth-btn { width: 100%; padding: 1rem; border: none; border-radius: 10px; background-color: var(--primary); color: white; font-weight: 600; font-size: 1rem; cursor: pointer; margin-top: 1.5rem; transition: all 0.3s ease; }
.auth-btn:hover { background-color: #2563eb; box-shadow: 0 5px 15px rgba(59, 130, 246, 0.4); transform: translateY(-3px); }
.auth-switch { text-align: center; margin-top: 2rem; color: #888; }
.auth-switch a { color: var(--primary); font-weight: 600; text-decoration: none; }
.branding-wrapper { background: linear-gradient(-45deg, #3b82f6, #84cc16, #22c55e, #f97316); background-size: 400% 400%; animation: gradientBG 15s ease infinite; color: white; display: flex; justify-content: center; align-items: center; padding: 2rem; text-align: center; }
@keyframes gradientBG { 0% { background-position: 0% 50%; } 50% { background-position: 100% 50%; } 100% { background-position: 0% 50%; } }
.branding-content h1 { font-size: 3.5rem; font-weight: 700; text-shadow: 0 2px 4px rgba(0,0,0,0.2); }
.skills-group { margin-bottom: 2.5rem; }
.skills-heading { font-size: 0.8rem; color: #888; display: block; margin-bottom: 1rem; }
.skills-options { display: flex; flex-wrap: wrap; gap: 0.75rem; }
.skill-pill { padding: 8px 16px; border-radius: 20px; background-color: var(--bg); border: 1px solid var(--border); color: var(--text); font-size: 0.9rem; cursor: pointer; transition: all 0.2s ease; }
.skill-pill:hover { border-color: var(--primary); color: var(--primary); }
.skill-pill.selected { background-color: var(--primary); color: white; border-color: var(--primary); }
@media (max-width: 900px) { .auth-panel { grid-template-columns: 1fr; } .branding-wrapper { display: none; } .form-content { max-width: none; } }
@media (max-width: 500px) { .name-group { grid-template-columns: 1fr; gap: 0; } }
</style>