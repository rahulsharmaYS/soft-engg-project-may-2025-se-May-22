<template>
  <div class="admin-dashboard">
    <main class="main">
      <Header title="Admin Dashboard" subtitle="Platform-wide analytics and management" />
      
      <section class="metrics-row">
        <MetricCard icon="🧑‍🎓" value="5,000" label="Total Students" />
        <MetricCard icon="🧑‍🏫" value="250" label="Total Instructors" />
        <MetricCard icon="📚" value="12" label="Content Modules" />
        <MetricCard icon="🔥" value="1,245" label="Daily Active Users" />
      </section>

      <section class="main-content-grid">
        <UserGrowthChart />
        <CourseCompletionChart />
        <DemographicsChart />
        <RecentActivityTable />
      </section>

    </main>
  </div>
</template>

<script setup>
import Sidebar from '../components/Sidebar.vue'
import Header from '../components/Header.vue'
import MetricCard from '../components/MetricCard.vue'
import DemographicsChart from '../components/DemographicsChart.vue'
import RecentActivityTable from '../components/RecentActivityTable.vue'
import UserGrowthChart from '../components/UserGrowthChart.vue'
import CourseCompletionChart from '../components/CourseCompletionChart.vue'

// const adminNavLinks = [
//   { name: 'Dashboard', icon: '📊' },
//   { name: 'User Management', icon: '👥' },
//   { name: 'Help Center', icon: '❓' },
//   { name: 'Announcements', icon: '📢' },
//   { logout: true, name: 'Logout', icon: '🚪' }
// ]
</script>

<style scoped>
.admin-dashboard {
  display: flex;
  background-color: var(--bg);
}
.main {
  flex: 1;
  padding: 2rem;
}
.metrics-row {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
  gap: 1.5rem;
  margin-bottom: 2rem;
}
.main-content-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
  gap: 10.5rem;
}
</style>