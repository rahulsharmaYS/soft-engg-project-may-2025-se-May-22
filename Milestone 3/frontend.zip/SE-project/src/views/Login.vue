<template>
  <div class="auth-page">
    <div class="auth-panel">
      <div class="form-wrapper">
        <div class="form-content">
          <h1 class="title">Welcome Back</h1>
          <p class="subtitle">Enter your credentials to access your account.</p>
          
          <form @submit.prevent="handleLogin">
            <div class="input-group">
              <input type="text" v-model="username" id="username" required>
              <label for="username">User ID</label>
              <span class="focus-bar"></span>
            </div>

            <div class="input-group">
              <input type="password" v-model="password" id="password" required>
              <label for="password">Password</label>
              <span class="focus-bar"></span>
            </div>
            
            <button type="submit" class="auth-btn">Sign In</button>
          </form>
          
          <div class="auth-switch">
            <span>Don't have an account? </span>
            <router-link to="/register">Sign Up</router-link>
          </div>
        </div>
      </div>
      
      <div class="branding-wrapper">
        <div class="branding-content">
          <h1>Life Skills</h1>
          <p>Empowering the next generation.</p>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import api from '../api';
import { ref } from 'vue';
import { useRouter } from 'vue-router';

const username = ref('');
const password = ref('');
const router = useRouter();

const handleLogin = async () => {
  if (!username.value || !password.value) {
    alert('Please enter both username and password');
    return;
  }

  try {
    const form = new URLSearchParams();
    form.append('username', username.value);
    form.append('password', password.value);

    const response = await api.post('/user/login', form, {
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
    });

    console.log("FULL LOGIN RESPONSE:", response.data);

const access_token = response.data.access_token;
const user = response.data.user;

console.log("Extracted USER:", user);
console.log("Extracted USER ID:", user?.id);
    console.log("USER FROM LOGIN:", user);

    localStorage.setItem('token', access_token);

    if (user.role === 'student') {
      router.push(`/student/${user.id}/dashboard`);
    } else if (user.role === 'teacher') {
      router.push(`/teacher/${user.id}/dashboard`);
    } else if (user.role === 'parent') {
      router.push(`/parent/${user.id}/dashboard`);
    } else {
      alert('Unknown user role');
    }
  } catch (error) {
    console.error('Login failed:', error);
    alert('Login failed: ' + (error.response?.data?.detail || 'Server error'));
  }
};
</script>

<style scoped>
.auth-page { display: flex; justify-content: center; align-items: center; min-height: 100vh; background-color: var(--bg); padding: 1rem; animation: fadeIn 0.5s ease-out; }
@keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
.auth-panel { display: grid; grid-template-columns: 1fr 1fr; width: 100%; max-width: 1100px; background-color: var(--card); border-radius: 20px; box-shadow: 0 15px 40px rgba(0,0,0,0.12); overflow: hidden; }
.form-wrapper { display: flex; justify-content: center; align-items: center; padding: 2rem; }
.form-content { width: 100%; max-width: 400px; }
.title { font-size: 2.2rem; font-weight: 700; color: var(--text); margin-bottom: 0.75rem; }
.subtitle { color: #888; margin-bottom: 2.5rem; font-size: 1.1rem; }
.input-group { position: relative; margin-bottom: 2.5rem; }
input { width: 100%; padding: 10px 0; font-size: 1rem; color: var(--text); border: none; border-bottom: 2px solid var(--border); background-color: transparent; transition: border-color 0.3s; }
input:focus { outline: none; border-color: var(--primary); }
label { position: absolute; top: 10px; left: 0; font-size: 1rem; color: #aaa; pointer-events: none; transition: all 0.3s ease; }
input:focus + label, input:valid + label { top: -20px; font-size: 0.8rem; color: var(--primary); }
.focus-bar { position: absolute; bottom: 0; left: 0; width: 100%; height: 2px; background-color: var(--primary); transform: scaleX(0); transition: transform 0.3s ease; }
input:focus ~ .focus-bar { transform: scaleX(1); }
.auth-btn { width: 100%; padding: 1rem; border: none; border-radius: 10px; background-color: var(--primary); color: white; font-weight: 600; font-size: 1rem; cursor: pointer; margin-top: 1rem; transition: all 0.3s ease; }
.auth-btn:hover { background-color: #2563eb; box-shadow: 0 5px 15px rgba(59, 130, 246, 0.4); transform: translateY(-3px); }
.auth-switch { text-align: center; margin-top: 2rem; color: #888; }
.auth-switch a { color: var(--primary); font-weight: 600; text-decoration: none; }
.branding-wrapper { background: linear-gradient(-45deg, #3b82f6, #84cc16, #22c55e, #f97316); background-size: 400% 400%; animation: gradientBG 15s ease infinite; color: white; display: flex; justify-content: center; align-items: center; padding: 2rem; text-align: center; }
@keyframes gradientBG { 0% { background-position: 0% 50%; } 50% { background-position: 100% 50%; } 100% { background-position: 0% 50%; } }
.branding-content h1 { font-size: 3.5rem; font-weight: 700; text-shadow: 0 2px 4px rgba(0,0,0,0.2); }
@media (max-width: 900px) { .auth-panel { grid-template-columns: 1fr; } .branding-wrapper { display: none; } .form-content { max-width: none; } }
</style>