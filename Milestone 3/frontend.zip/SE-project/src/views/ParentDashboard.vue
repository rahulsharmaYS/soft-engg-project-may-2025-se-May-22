<template>
  <div>
    <Header title="Good afternoon, Parent 👋" subtitle="Here’s an overview of your child's learning journey" />

    <section class="profile-summary">
      <img
        class="child-photo"
        :src="childProfile.photo"
        alt="Child Profile"
      />
      <div class="child-info">
        <h2>{{ childProfile.name }}</h2>
        <p>Grade: {{ childProfile.grade }}</p>
        <p>School: {{ childProfile.school }}</p>
      </div>
    </section>

    <div class="tab-navigation">
      <button :class="{ active: activeTab === 'overview' }" @click="activeTab = 'overview'">Overview</button>
      <button :class="{ active: activeTab === 'charts' }" @click="activeTab = 'charts'">Charts & Progress</button>
      <button :class="{ active: activeTab === 'achievements' }" @click="activeTab = 'achievements'">Achievements</button>
    </div>

    <div class="tab-content">
      <div v-if="activeTab === 'overview'" class="tab-pane overview-grid">
        <div class="overview-left">
          <h3>Child Stats</h3>
          <div class="cards">
            <Card title="Today's Tasks" icon="📋" color="#4ade80" :value="childStats.todaysTasksAndAssignments" />
            <Card title="Upcoming Assignments" icon="📝" color="#3b82f6" :value="childStats.upcomingAssignments" suffix=" hrs this week" />
            <Card title="Completed Assignments" icon="✅" color="#f97316" :value="childStats.completedAssignments" />
          </div>
          <h3>Notifications</h3>
          <div class="notifications">
            <ul>
              <li v-for="note in notifications" :key="note.id">{{ note.text }}</li>
            </ul>
          </div>
        </div>
        <div class="overview-right">
          
          <CalendarUpcoming />
        </div>
      </div>

      <div v-if="activeTab === 'charts'" class="tab-pane">
        <h3>Progress Charts</h3>
        <div class="charts">
          <Chart title="Time Spent per Subject" type="doughnut" :data="timePerSubjectData" :height="250" />
          <Chart title="Score Comparison" type="bar" :data="scoreComparisonData" :height="250" />
        </div>
      </div>

      <div v-if="activeTab === 'achievements'" class="tab-pane">
        <h3>Achievements Earned</h3>
        <div class="achievements">
          <div v-for="achievement in achievements" :key="achievement.id" class="achievement-card" :title="achievement.description">
            <div class="icon">{{ achievement.icon }}</div>
            <div class="achievement-text">
              <h4>{{ achievement.title }}</h4>
              <p>{{ achievement.description }}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Header from '../components/Header.vue';
import Card from '../components/Card.vue';
import Chart from '../components/ParentChart.vue';
import CalendarUpcoming from '../components/CalendarUpcoming.vue';

const activeTab = ref('overview');

const childProfile = ref({
  name: 'Lil Aarush',
  grade: '5th Grade',
  school: 'Sunshine and Rainbow',
  // UPDATED: New, profile picture for the child
  photo: 'https://images.pexels.com/photos/4145146/pexels-photo-4145146.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
});

const childStats = ref({
  todaysTasksAndAssignments: 4,
  upcomingAssignments: 3,
  completedAssignments: 42,
});


const timePerSubjectData = ref({
  labels: ['Math', 'Science', 'History', 'English'],
  datasets: [{ data: [4, 2.5, 1, 1], backgroundColor: ['#3b82f6', '#10b981', '#f97316', '#ef4444'] }],
});

const scoreComparisonData = ref({
  labels: ['Math', 'Science', 'History', 'English'],
  datasets: [
    { label: "Your Child's Score", data: [88, 75, 92, 81], backgroundColor: '#a78bfa' },
    { label: 'Class Average', data: [76, 80, 85, 84], backgroundColor: '#d1d5db' },
  ],
});

const achievements = ref([
  { id: 1, icon: '🥇', title: 'Top Scorer', description: 'Highest test score in Math' },
  { id: 2, icon: '📚', title: 'Homework Hero', description: 'Completed all homework assignments' },
  { id: 3, icon: '🎯', title: 'Focus Master', description: 'Completed multiple focus sessions' },
]);

const notifications = ref([
  { id: 1, text: 'New assignment uploaded for History.' },
  { id: 2, text: 'Parent-teacher meeting scheduled for next Friday.' },
  { id: 3, text: 'Your child earned a new badge: Top Scorer.' },
]);
</script>

<style scoped>
.profile-summary { display: flex; align-items: center; gap: 1rem; margin-bottom: 2rem; background: var(--card); padding: 1rem 2rem; border-radius: 0.75rem; box-shadow: 0 1px 3px rgb(0 0 0 / 0.1); border: 1px solid var(--border); }
.child-photo { border-radius: 50%; width: 80px; height: 80px; object-fit: cover; border: 3px solid #4ade80; }
.child-info h2 { margin: 0; font-weight: 700; font-size: 1.5rem; }
.child-info p { margin: 0.2rem 0 0; color: #6b7280; }
.tab-navigation { display: flex; gap: 0.5rem; border-bottom: 2px solid var(--border); margin-bottom: 2rem; }
.tab-navigation button { padding: 0.75rem 1.5rem; border: none; background: none; font-weight: 600; font-size: 1rem; color: var(--text-light); cursor: pointer; border-bottom: 2px solid transparent; transform: translateY(2px); }
.tab-navigation button.active { color: var(--primary); border-bottom-color: var(--primary); }
.tab-pane { animation: fadeIn 0.5s ease; }
@keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
h3 { font-weight: 600; margin-top: 0; margin-bottom: 1.5rem; }
.overview-grid { display: grid; grid-template-columns: 2fr 1fr; gap: 2rem; }
.cards { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 1rem; margin-bottom: 2rem; }
.charts { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 1.5rem; }
.charts > * { background: var(--card); border-radius: 0.75rem; padding: 1rem; box-shadow: 0 1px 3px rgb(0 0 0 / 0.1); border: 1px solid var(--border); }
.achievements { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 1rem; }
.achievement-card { background: var(--card); border-radius: 0.75rem; padding: 1rem; display: flex; align-items: center; gap: 1rem; border: 1px solid var(--border); }
.achievement-card .icon { font-size: 2.5rem; }
.achievement-text h4 { margin: 0; font-weight: 600; }
.achievement-text p { margin: 0.25rem 0 0; font-size: 0.9rem; color: #6b7280; }
.notifications { background: var(--card); padding: 1.5rem; border-radius: 0.75rem; border: 1px solid var(--border); }
.notifications ul { list-style-type: disc; padding-left: 1.5rem; margin: 0; }
.notifications li { margin-bottom: 0.5rem; }
</style>