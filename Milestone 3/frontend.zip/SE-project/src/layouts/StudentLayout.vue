<template>
  <div class="page-container">
    <Sidebar :navLinks="studentNavLinks" />
    <main class="main-content">
      <router-view />
    </main>
  </div>
</template>

<script setup>
import { useRouter, useRoute } from 'vue-router';
import { computed } from 'vue';
import { store } from '../store'; // Import the global store for logout (stupid basic thing sorted)
import Sidebar from '../components/Sidebar.vue';

const router = useRouter();
const route = useRoute();

const studentId = computed(() => route.params.id || localStorage.getItem("student_id"));
const handleLogout = () => {
  localStorage.clear();

  store.darkMode = false;
  localStorage.setItem('darkMode', 'false');
  document.body.classList.remove('dark');
  router.push('/login');
};

const studentNavLinks = computed(() => [
  { name: 'Dashboard', icon: '🏠', onClick: () => router.push(`/student/${studentId.value}/dashboard`)},
  // { name: 'Tasks', icon: '📋', onClick: () => router.push(`/student/${studentId.value}/tasks`) },
  { name: 'Assignments', icon: '📝', onClick: () => router.push(`/student/${studentId.value}/assignments`)},
  { name: 'Badges', icon: '🏅', onClick: () => router.push(`/student/${studentId.value}/badges`) },
  { name: 'Resources', icon: '📚', onClick: () => router.push(`/student/${studentId.value}/resources`)},
  { name: 'Calendar', icon: '📆', onClick: () => router.push(`/student/${studentId.value}/calendar`)},
  // { name: 'Notifications', icon: '🔔', onClick: () => router.push(`/student/${studentId.value}/notifications`) },
  { name: 'Profile', icon: '👤', onClick: () => router.push(`/student/${studentId.value}/profile`) },
  { name: 'Logout', icon: '🚪', logout: true, onClick: handleLogout }
]);
</script>

<style scoped>
.page-container {
  display: flex;
  height: 100vh;
}
.main-content {
  flex: 1;
  padding: 2rem;
  background: var(--bg);
  color: var(--text);
  overflow-y: auto;
}
</style>