<template>
  <div class="page-container">
    <Sidebar :navLinks="adminNavLinks" />
    <main class="main-content">
      <router-view />
    </main>
  </div>
</template>

<script setup>
import { useRouter } from 'vue-router';
import Sidebar from '../components/Sidebar.vue';

const router = useRouter();

const adminNavLinks = [
    { name: 'Dashboard', icon: '🏠', onClick: () => router.push('/admin') },
    { name: 'User Management', icon: '👥', onClick: () => router.push('/admin/usermanagement') },
    { name: 'Help Center', icon: '❓', onClick: () => router.push('/admin/helpcenter') },
    { name: 'Announcements', icon: '📢', onClick: () => router.push('/admin/announcements') },
    { name: 'Logout', icon: '🚪', onClick: () => {router.push('/login');} }
];
</script>

<style scoped>
.page-container {
  display: flex;
  height: 100vh;
}
.main-content {
  flex: 1;
  padding: 2rem;
  background: var(--bg);
  color: var(--text);
  overflow-y: auto;
}
</style>