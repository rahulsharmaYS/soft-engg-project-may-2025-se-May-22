<template>
  <div class="page-container">
    <Sidebar :navLinks="instructorNavLinks" />
    <main class="main-content">
      <router-view />
    </main>
  </div>
</template>

<script setup>
import { useRouter, useRoute } from 'vue-router';
import { computed } from 'vue';
import { store } from '../store';
import Sidebar from '../components/Sidebar.vue';

const router = useRouter();
const route = useRoute();

const teacher_id = computed(() => route.params.teacher_id || localStorage.getItem("teacher_id"));
const handleLogout = () => {
  localStorage.clear();

  store.darkMode = false;
  localStorage.setItem('darkMode', 'false');
  document.body.classList.remove('dark');
  router.push('/login');
};

const instructorNavLinks = [
  { name: 'Dashboard', icon: '📊', onClick: () => router.push(`/teacher/${teacher_id.value}/dashboard`)},
  
  
  
  { name: 'My Students', icon: '🧑‍🎓', onClick: () => router.push(`/teacher/${teacher_id.value}/students`)},
  { name: 'Assignments', icon: '📝', onClick: () => router.push(`/teacher/${teacher_id.value}/assignments`)},
  { name: 'Resources', icon: '📚', onClick: () => router.push(`/teacher/${teacher_id.value}/resources`)},
  { name: 'Comms Center', icon: '📬', onClick: () => router.push(`/teacher/${teacher_id.value}/comms`)},
  { name: 'Profile', icon: '👤', onClick: () => router.push(`/teacher/${teacher_id.value}/profile`)},
  { name: 'Logout', icon: '🚪', logout: true, onClick: handleLogout }
];
</script>

<style scoped>
.page-container {
  display: flex;
  height: 100vh;
}
.main-content {
  flex: 1;
  padding: 2rem;
  background: var(--bg);
  color: var(--text);
  overflow-y: auto;
}
</style>