<template>
  <aside class="sidebar" @mouseenter="expand = true" @mouseleave="expand = false">
    <ul>
      <li
        v-for="link in navLinks"
        :key="link.name"
        @click="link.onClick && link.onClick()"
      >
        <span>{{ link.icon }}</span>
        <span v-if="expand">{{ link.name }}</span>
      </li>
    </ul>
  </aside>
</template>

<script setup>
import { ref } from 'vue';

defineProps({
  navLinks: {
    type: Array,
    required: true,
  },
});

const expand = ref(false);
</script>

<style scoped>
.sidebar {
  background: var(--card);
  color: var(--text);
  padding: 1rem 0.5rem;
  width: 60px;
  transition: width 0.2s ease;
  overflow: hidden;
  /* height: 100vh; */
}
.sidebar:hover {
  width: 180px;
}
ul {
  list-style: none;
  padding: 0;
  margin: 0;
}
li {
  display: flex;
  align-items: center;
  gap: 1rem;
  padding: 1rem;
  font-weight: 500;
  cursor: pointer;
}
li:hover {
  background-color: var(--bg);
}
</style>