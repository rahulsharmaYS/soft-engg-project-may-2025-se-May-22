<template>
  <div class="p-4">
    <h2 class="text-2xl font-bold mb-4">🏕️ All Badges</h2>
    <div class="flex space-x-4 overflow-x-auto pb-4">
      <div
        v-for="badge in allBadges"
        :key="badge.id"
        class="min-w-[120px] flex-shrink-0 flex flex-col items-center text-center bg-white shadow p-3 rounded-xl"
      >
        <div
          class="w-12 h-12 rounded-full overflow-hidden border border-yellow-400 bg-white flex items-center justify-center mb-2"
        >
          <img
            :src="badge.image"
            alt="badge"
            class="w-full h-full object-cover"
          />
        </div>

        <div class="font-semibold text-sm">{{ badge.name }}</div>
        <div class="text-xs text-gray-500 mt-1">{{ badge.description }}</div>
      </div>
    </div>

    <h2 class="text-xl font-bold mb-4 mt-6">🎖️ Your Badges</h2>
    <ul>
      <li
        v-for="(badge, index) in userBadges"
        :key="index"
        class="p-3 bg-green-100 rounded mb-2 flex items-center space-x-2"
      >
        <span class="text-xl">🏅</span>
        <span>{{ badge }}</span>
      </li>
    </ul>

    <div v-if="userBadges.length === 0" class="text-gray-500 mt-2">
      No badges earned yet.
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import api from '../api'
import { useRoute } from 'vue-router'

const route = useRoute()
const studentId = route.params.id

const userBadges = ref([])

const allBadges = ref([

  {
    id: 2,
    name: 'Nature Explorer',
    image: new URL('@/assets/badges/nature.jpg', import.meta.url).href,
    description: 'Join 3 nature walks',
  },
  
])

onMounted(async () => {
  try {
    const res = await api.get(`/student/${studentId}/badges`)
    userBadges.value = res.data
  } catch (err) {
    console.error('Failed to fetch badges:', err)
  }
})
</script>


