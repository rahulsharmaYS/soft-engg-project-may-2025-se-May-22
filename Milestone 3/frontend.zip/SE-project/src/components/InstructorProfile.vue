<template>
  <div>
    <Header title="My Profile" subtitle="Manage your account details and preferences." />
    
    <div class="profile-grid">
      <div class="profile-card">
        <h3>Profile Details</h3>
        <div class="details-content" v-if="user">
          <img src="https://i.pravatar.cc/150?img=5" alt="Instructor Avatar" class="profile-avatar">
          <div class="info">
            <p><strong>Name:</strong> {{ user.name }}</p>
            <p><strong>Email:</strong> {{ user.email }}</p>
            <p><strong>Subjects:</strong> {{ user.subjects.join(', ') }}</p>
            <p><strong>Role:</strong> <span class="role-tag">{{ user.role }}</span></p>
          </div>
        </div>
        <div v-else>
          <p>Loading profile...</p>
        </div>
      </div>

      <div class="profile-card">
        <h3>Settings & Actions</h3>
        <div class="actions-group">
          <button class="action-btn edit-btn" @click="openEditModal">Edit Profile</button>
          <button class="action-btn password-btn">Change Password</button>
          <button @click="logout" class="action-btn logout-btn">Logout</button>
        </div>
      </div>
    </div>

    <div v-if="showModal" class="modal-overlay">
      <div class="modal-content">
        <h3>Edit Profile</h3>
        <label>
          Full Name:
          <input v-model="editForm.full_name" type="text" />
        </label>
        <label>
          Email:
          <input v-model="editForm.email" type="email" />
        </label>
        <div class="modal-actions">
          <button @click="submitEdit" class="save-btn">Save</button>
          <button @click="showModal = false" class="cancel-btn">Cancel</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import axios from 'axios';
import { ref, onMounted } from 'vue';
import { useRoute, useRouter } from 'vue-router';
import Header from './Header.vue';
import api from '@/api';

const route = useRoute();
const router = useRouter();
const teacherId = route.params.teacher_id;

const user = ref(null);
const showModal = ref(false);
const editForm = ref({ full_name: '', email: '' });
const fetchProfile = async () => {
  try {
    const response = await api.get(`/teacher/${teacherId}/profile`);
    if (response.status === 200) {
      user.value = response.data;
    }
  } catch (error) {
    console.error('Failed to fetch profile', error);
  }
};

const openEditModal = () => {
  if (user.value) {
    editForm.value.full_name = user.value.name;
    editForm.value.email = user.value.email;
    showModal.value = true;
  }
};

const submitEdit = async () => {
  try {
    await api.put(`/teacher/${teacherId}/editprofile`, {
      full_name: editForm.value.full_name,
      email: editForm.value.email,
    });
    user.value.name = editForm.value.full_name;
    user.value.email = editForm.value.email;
    showModal.value = false;
    alert('Profile updated successfully');
  } catch (error) {
    console.error('Failed to update profile', error.response?.data || error);
    alert('Failed to update profile');
  }
};

const logout = () => {
  router.push('/login');
};

onMounted(() => {
  fetchProfile();
});
</script>

<style scoped>
.profile-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
  gap: 2rem;
  margin-top: 2rem;
}

.profile-card {
  background-color: var(--card);
  padding: 1.5rem 2rem;
  border-radius: 12px;
  box-shadow: 0 4px 12px rgba(0,0,0,0.05);
}

.details-content {
  display: flex;
  align-items: center;
  gap: 1.5rem;
}

.profile-avatar {
  width: 90px;
  height: 90px;
  border-radius: 50%;
}

.info p {
  margin-bottom: 0.5rem;
}

.role-tag {
  background-color: var(--primary);
  color: white;
  padding: 4px 10px;
  border-radius: 20px;
  font-size: 0.8rem;
}

.actions-group {
  margin-top: 1.5rem;
  display: flex;
  flex-direction: column;
  gap: 1rem;
}

.action-btn {
  width: 100%;
  padding: 0.8rem;
  border: 1px solid var(--border);
  border-radius: 8px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.2s;
  text-align: left;
  background-color: var(--bg);
  color: var(--text);
}
.action-btn.logout-btn {
  border-color: #ef4444;
  color: #ef4444;
}
.action-btn:hover {
  border-color: var(--primary);
  color: var(--primary);
}
.action-btn.logout-btn:hover {
  background-color: #ef4444;
  border-color: #ef4444;
  color: white;
}

/* Modal Styles */
.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0,0,0,0.6); 
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 99;
}

.modal-content {
  background: var(--card); 
  padding: 2rem;
  border-radius: 10px;
  width: 400px;
  box-shadow: var(--shadow);
  color: var(--text); 
}

.modal-content h3 {
  margin-bottom: 1rem;
}

.modal-content label {
  display: block;
  margin-bottom: 1rem;
  font-weight: 500;
  color: var(--text); 
}

.modal-content input {
  width: 100%;
  padding: 0.6rem;
  border-radius: 6px;
  border: 1px solid var(--border); 
  margin-top: 0.3rem;
  background-color: var(--bg); 
  color: var(--text); 
}

.modal-actions {
  display: flex;
  justify-content: flex-end;
  gap: 1rem;
  margin-top: 1.5rem;
}

.save-btn {
  background: var(--primary);
  color: white;
  padding: 0.6rem 1rem;
  border: none;
  border-radius: 6px;
  cursor: pointer;
}
.cancel-btn {
  background: var(--secondary);
  color: var(--text); 
  padding: 0.6rem 1rem;
  border: none;
  border-radius: 6px;
  cursor: pointer;
}
</style>