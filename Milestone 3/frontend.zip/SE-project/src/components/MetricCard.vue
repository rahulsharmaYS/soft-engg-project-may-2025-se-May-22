<template>
  <div class="metric-card">
    <div class="icon">{{ icon }}</div>
    <div class="content">
      <div class="value">{{ value }}</div>
      <div class="label">{{ label }}</div>
    </div>
  </div>
</template>

<script setup>
defineProps(['icon', 'value', 'label'])
</script>

<style scoped>
.metric-card {
  display: flex;
  align-items: center;
  gap: 1rem;
  background-color: var(--card);
  padding: 1.5rem;
  border-radius: var(--card-radius);
  box-shadow: var(--shadow);
  flex-grow: 1;
}
.icon { font-size: 2rem; }
.value { font-size: 1.75rem; font-weight: 600; }
.label { color: grey; }
</style>