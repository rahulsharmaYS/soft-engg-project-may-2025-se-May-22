<template>
  <div class="activity-container">
    <h3>Recent Activity</h3>
    <table>
      <thead>
        <tr>
          <th>User</th>
          <th>Action</th>
          <th>Timestamp</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="item in activities" :key="item.id">
          <td>{{ item.user }}</td>
          <td>{{ item.action }}</td>
          <td>{{ item.time }}</td>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<script setup>
const activities = [
  { id: 1, user: 'Admin', action: 'Updated "Time Management" module', time: '2 min ago' },
  { id: 2, user: 'instructor@school.com', action: 'Graded 5 student assignments', time: '15 min ago' },
  { id: 3, user: 'parent_of_student123', action: 'Viewed progress report', time: '28 min ago' },
  { id: 4, user: 'student_xyz', action: 'Completed a "Communication" lesson', time: '45 min ago' },
];
</script>

<style scoped>
.activity-container {
  background: var(--card);
  padding: 1rem;
  border-radius: var(--card-radius);
  box-shadow: var(--shadow);
  flex-grow: 1;
}
table {
  width: 100%;
  border-collapse: collapse;
}
th, td {
  padding: 0.75rem;
  text-align: left;
  border-bottom: 1px solid var(--border);
}
th { font-weight: 600; }
</style>