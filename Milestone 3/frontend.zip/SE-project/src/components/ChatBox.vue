<template>
  <div>
    <div class="chat-icon" @click="open = true">💬</div>

    <div v-if="open" class="modal-overlay" @click.self="open = false">
      <div
        class="chat-modal"
        ref="modal"
        @mousedown="initDrag"
        :style="{ width: width + 'px', height: height + 'px', top: top + 'px', left: left + 'px' }"
      >
        <div class="chat-header">
          <h4>LifeSkills - AI ChatBot</h4>
          <button @click="open = false" class="close-btn">✖️</button>
        </div>

        <div class="chat-messages" ref="chatScroll">
          <div
            v-for="(msg, index) in conversation"
            :key="index"
            :class="['message', msg.sender]"
          >
          <span class="sender-label">{{ msg.sender === 'student' ? 'Student' : 'Bot' }}:</span>
            <p>{{ msg.text }}</p>
          </div>
        </div>

        <textarea
          v-model="input"
          rows="2"
          placeholder="Ask anything..."
          @keydown.enter.prevent="sendMessage"
        />
        <button @click="sendMessage">Send</button>

        <div class="resize-handle" @mousedown.stop.prevent="initResize"></div>
      </div>
    </div>
  </div>
</template>

<script setup>
//  import { c } from 'vite/dist/node/moduleRunnerTransport.d-DJ_mE5sf'

import { ref, nextTick, onMounted, onBeforeUnmount } from 'vue'

const open = ref(false)
const input = ref('')
const chatScroll = ref(null)
const modal = ref(null)

const conversation = ref([
  { sender: 'student', text: "Hi, can you help me prepare for my upcoming math test?" },
  { sender: 'bot', text: "Of course! Let's review some key math concepts and practice a few problems together." },
  { sender: 'student', text: "That sounds great. Can we also go over some tips for staying focused while studying?" },
  { sender: 'bot', text: "Absolutely! Taking short breaks, setting clear goals, and practicing regularly can really help you stay focused." },
  { sender: 'student', text: "Thanks! Also, I'm struggling a bit with algebra. Any advice?" },
  { sender: 'bot', text: "For algebra, try to break down each problem into smaller steps and practice solving equations daily. Would you like a sample problem to try?" },
  { sender: 'student', text: "Yes, please! That would be helpful." },
  { sender: 'bot', text: "Here's one: Solve for x in the equation 2x + 5 = 13." }
])
const width = ref(350)
const height = ref(400)
const top = ref(100)
const left = ref(100)

let isDragging = false
let dragStartX = 0
let dragStartY = 0
let modalStartTop = 0
let modalStartLeft = 0

let isResizing = false
let resizeStartX = 0
let resizeStartY = 0
let startWidth = 0
let startHeight = 0

function toggleOpen() {
  open.value = !open.value
}

function sendMessage() {
  if (!input.value.trim()) return
  conversation.value.push({ sender: 'student', text: input.value.trim() })

  setTimeout(() => {
    const reply = getBotReply(input.value)
    conversation.value.push({ sender: 'bot', text: reply })

    nextTick(() => {
      if (chatScroll.value) {
        chatScroll.value.scrollTop = chatScroll.value.scrollHeight
      }
    })
  }, 1000)

  input.value = ''
  nextTick(() => {
    if (chatScroll.value) chatScroll.value.scrollTop = chatScroll.value.scrollHeight
  })
}

function getBotReply(userText) {
  const replies = [
    "I'll make a note for the teacher to encourage more presentation time.",
    "Yes, regular reading aloud at home will support their fluency.",
    "Absolutely! They've shown improvement since last month.",
    "We recommend a few group tasks to build stronger peer collaboration.",
    "That's a valid concern. They might need individual attention in those sessions.",
  ]
  return replies[Math.floor(Math.random() * replies.length)]
}

function initDrag(e) {
  if (e.target.classList.contains('resize-handle')) return
  isDragging = true
  dragStartX = e.clientX
  dragStartY = e.clientY
  modalStartTop = top.value
  modalStartLeft = left.value

  window.addEventListener('mousemove', onDrag)
  window.addEventListener('mouseup', stopDrag)
}
function onDrag(e) {
  if (!isDragging) return
  top.value = modalStartTop + (e.clientY - dragStartY)
  left.value = modalStartLeft + (e.clientX - dragStartX)

  const maxLeft = window.innerWidth - width.value
  const maxTop = window.innerHeight - height.value
  if (left.value < 0) left.value = 0
  if (top.value < 0) top.value = 0
  if (left.value > maxLeft) left.value = maxLeft
  if (top.value > maxTop) top.value = maxTop
}
function stopDrag() {
  isDragging = false
  window.removeEventListener('mousemove', onDrag)
  window.removeEventListener('mouseup', stopDrag)
}

function initResize(e) {
  isResizing = true
  resizeStartX = e.clientX
  resizeStartY = e.clientY
  startWidth = width.value
  startHeight = height.value

  window.addEventListener('mousemove', onResize)
  window.addEventListener('mouseup', stopResize)
}
function onResize(e) {
  if (!isResizing) return
  const newWidth = startWidth + (e.clientX - resizeStartX)
  const newHeight = startHeight + (e.clientY - resizeStartY)

  width.value = Math.min(Math.max(newWidth, 300), window.innerWidth - left.value - 20)
  height.value = Math.min(Math.max(newHeight, 300), window.innerHeight - top.value - 20)
}
function stopResize() {
  isResizing = false
  window.removeEventListener('mousemove', onResize)
  window.removeEventListener('mouseup', stopResize)
}

onMounted(() => {
  if (chatScroll.value) chatScroll.value.scrollTop = chatScroll.value.scrollHeight
})
</script>

<style scoped>
.chat-icon {
  position: fixed;
  bottom: 20px;
  right: 20px;
  font-size: 2.2rem;
  background: #3b82f6;
  color: white;
  padding: 0.75rem;
  border-radius: 50%;
  cursor: pointer;
  box-shadow: var(--shadow);
  z-index: 4000;
}

.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100vw;
  height: 100vh;
  background: rgba(0, 0, 0, 0.3);
  z-index: 4100;
  display: flex;
  align-items: flex-start;
  justify-content: flex-start;
}

.chat-modal {
  position: absolute;
  background: var(--card);
  border-radius: 1rem;
  box-shadow: var(--shadow);
  display: flex;
  flex-direction: column;
  padding: 1rem;
  user-select: none;
  cursor: move;
}

.chat-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 0.5rem;
  cursor: grab;
}

.close-btn {
  background: transparent;
  border: none;
  font-size: 1.2rem;
  cursor: pointer;
}

.chat-messages {
  flex: 1;
  overflow-y: auto;
  padding: 0.5rem 0;
  margin-bottom: 0.5rem;
  user-select: text;
  scrollbar-width: thin;
  scrollbar-color: #888 transparent;
}

.chat-messages::-webkit-scrollbar {
  width: 6px;
}

.chat-messages::-webkit-scrollbar-thumb {
  background-color: #888;
  border-radius: 3px;
}

.message {
  max-width: 90%;
  padding: 0.6rem 0.8rem;
  margin-bottom: 0.5rem;
  border-radius: 0.75rem;
  font-size: 0.9rem;
  line-height: 1.4;
  user-select: text;
}

.message.parent {
  align-self: flex-end;
  background: #4f46e5;
  color: white;
  border-bottom-right-radius: 0;
}

.message.bot {
  align-self: flex-start;
  background: #e5e7eb;
  color: #111827;
  border-bottom-left-radius: 0;
}

textarea {
  resize: none;
  width: 100%;
  padding: 0.4rem;
  border-radius: 0.5rem;
  border: 1px solid #ccc;
  font-size: 0.9rem;
  user-select: text;
}

button {
  background: #3b82f6;
  color: white;
  border: none;
  margin-top: 0.5rem;
  padding: 0.4rem 0.75rem;
  border-radius: 0.5rem;
  cursor: pointer;
}

.resize-handle {
  position: absolute;
  width: 15px;
  height: 15px;
  background: transparent;
  border-right: 3px solid #888;
  border-bottom: 3px solid #888;
  right: 10px;
  bottom: 10px;
  cursor: se-resize;
  user-select: none;
}
.sender-label {
  font-size: 0.85em;
  font-weight: bold;
  color: #6366f1;
  display: block;
  margin-bottom: 0.2em;
}
</style>
