<template>
  <div>
    <h2>Notifications</h2>
    <ul>
      <li v-for="(notification, index) in notifications" :key="index">
        {{ notification.message }} — {{ notification.timestamp }}
      </li>
    </ul>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import api from '../api'
import { useRoute } from 'vue-router'

const route = useRoute()
const studentId = route.params.id
const notifications = ref([])

onMounted(async () => {
  try {
    const res = await api.get(`/student/${studentId}/notifications`)
    notifications.value = res.data
  } catch (err) {
    console.error('Failed to load notifications:', err)
  }
})
</script>
