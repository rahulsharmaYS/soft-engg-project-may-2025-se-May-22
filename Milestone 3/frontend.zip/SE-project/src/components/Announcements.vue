<template>
  <div class="announcements">
    <main class="main">
      <Header title="Announcements" subtitle="Broadcast messages to platform users" />

      <section class="new-announcement">
        <h2>Create Announcement</h2>
        <input v-model="newPost.subject" placeholder="Subject" class="input" />

        <textarea
          v-model="newPost.body"
          placeholder="Write your announcement..."
          class="textarea"
        ></textarea>

        <div class="controls-row">
          <label>
            Send to:
            <select v-model="newPost.role">
              <option value="all">All Users</option>
              <option value="student">Students Only</option>
              <option value="instructor">Instructors Only</option>
            </select>
          </label>

          <label>
            Tag Users:
            <input
              v-model="newTag"
              @keyup.enter="addTag"
              placeholder="Type user ID or name & press Enter"
              class="input"
            />
          </label>
        </div>

        <div class="tags">
          <span v-for="(tag, i) in newPost.tags" :key="i" class="tag">
            {{ tag }}
            <button @click="removeTag(i)">✖</button>
          </span>
        </div>

        <div class="attachment">
          <label>
            Attach File:
            <input type="file" @change="handleFileUpload" />
          </label>
          <span v-if="newPost.attachmentName">📎 {{ newPost.attachmentName }}</span>
        </div>

        <button @click="postAnnouncement" class="submit-btn">Post Announcement</button>
      </section>

      <section class="announcement-list">
        <h2>Previous Announcements</h2>
        <div v-for="post in posts" :key="post.id" class="post-card">
          <div class="post-header">
            <h3>{{ post.subject }}</h3>
            <span class="target">To: {{ formatRole(post.role) }}</span>
            <span v-if="post.tags.length" class="tags-inline">
              Tags: <span v-for="t in post.tags" :key="t" class="tag-inline">{{ t }}</span>
            </span>
          </div>
          <p class="post-body">{{ post.body }}</p>
          <div class="post-footer">
            <span>{{ post.timestamp }}</span>
            <span v-if="post.attachmentName">📎 {{ post.attachmentName }}</span>
          </div>
        </div>
      </section>
    </main>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import Sidebar from '../components/Sidebar.vue'
import Header from '../components/Header.vue'

const adminNavLinks = [
  { name: 'Dashboard', icon: '📊' },
  { name: 'User Management', icon: '👥' },
  { name: 'Help Center', icon: '❓' },
  { name: 'Announcements', icon: '📢' },
  { logout: true, name: 'Logout', icon: '🚪' }
]

const newPost = ref({
  subject: '',
  body: '',
  role: 'all',
  tags: [],
  attachment: null,
  attachmentName: ''
})

const newTag = ref('')

function addTag() {
  if (newTag.value.trim()) {
    newPost.value.tags.push(newTag.value.trim())
    newTag.value = ''
  }
}

function removeTag(index) {
  newPost.value.tags.splice(index, 1)
}

function handleFileUpload(event) {
  const file = event.target.files[0]
  if (file) {
    newPost.value.attachment = file
    newPost.value.attachmentName = file.name
  }
}

const posts = ref([
  {
    id: 1,
    subject: 'System Maintenance Tonight',
    body: 'The platform will undergo maintenance from 12:00 AM to 2:00 AM.',
    role: 'all',
    tags: [],
    timestamp: 'June 10, 2025',
    attachmentName: ''
  },
  {
    id: 2,
    subject: 'New Module Released',
    body: 'Instructors, please check the new content module added to your dashboard.',
    role: 'instructor',
    tags: ['Dr. Smith'],
    timestamp: 'June 12, 2025',
    attachmentName: 'ModuleOutline.pdf'
  }
])

function postAnnouncement() {
  if (!newPost.value.subject || !newPost.value.body) {
    alert('Subject and body are required.')
    return
  }

  posts.value.unshift({
    id: Date.now(),
    subject: newPost.value.subject,
    body: newPost.value.body,
    role: newPost.value.role,
    tags: [...newPost.value.tags],
    attachmentName: newPost.value.attachmentName,
    timestamp: new Date().toLocaleDateString('en-US', {
      month: 'long',
      day: 'numeric',
      year: 'numeric'
    })
  })

  newPost.value = {
    subject: '',
    body: '',
    role: 'all',
    tags: [],
    attachment: null,
    attachmentName: ''
  }
}

function formatRole(role) {
  if (role === 'student') return 'Students'
  if (role === 'instructor') return 'Instructors'
  return 'All Users'
}
</script>

<style scoped>
.announcements {
  display: flex;
  background-color: var(--bg); 
}
.main {
  flex: 1;
  padding: 2rem;
  color: var(--text);
}

.new-announcement {
  background: var(--card);
  padding: 1.5rem;
  border-radius: 8px;
  margin-bottom: 2rem;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.05);
}
.input,
.textarea,
select {
  width: 100%;
  margin-top: 0.5rem;
  padding: 0.6rem;
  border-radius: 4px;
  border: 1px solid var(--border);
  font-size: 1rem;
  margin-bottom: 1rem;
  background-color: var(--card);
  color: var(--text);
}
.controls-row {
  display: flex;
  gap: 1rem;
  flex-wrap: wrap;
}
.tags {
  display: flex;
  flex-wrap: wrap;
  gap: 0.5rem;
  margin-bottom: 1rem;
}
.tag {
  background: var(--secondary);
  padding: 4px 10px;
  border-radius: 12px;
  display: inline-flex;
  align-items: center;
  color: var(--text);
}
.tag button {
  background: none;
  border: none;
  margin-left: 4px;
  cursor: pointer;
  color: var(--text);
}
.attachment {
  margin-bottom: 1rem;
  color: var(--text);
}
.submit-btn {
  background: var(--primary);
  color: white;
  border: none;
  padding: 0.7rem 1.5rem;
  border-radius: 4px;
  cursor: pointer;
}

.announcement-list h2 {
  margin-bottom: 1rem;
}
.post-card {
  background: var(--card);
  padding: 1.2rem;
  border-radius: 6px;
  margin-bottom: 1.5rem;
  box-shadow: 0 0 5px rgba(0, 0, 0, 0.04);
  color: var(--text);
}
.post-header {
  display: flex;
  flex-direction: column;
  gap: 4px;
  margin-bottom: 0.5rem;
}
.post-header .target {
  font-size: 0.85rem;
  color: var(--text);
}
.tags-inline {
  font-size: 0.85rem;
  color: var(--text);
}
.tag-inline {
  background: var(--secondary);
  padding: 2px 8px;
  margin-left: 4px;
  border-radius: 10px;
  color: var(--text);
}
.post-body {
  margin-bottom: 0.5rem;
  color: var(--text);
}
.post-footer {
  font-size: 0.8rem;
  color: var(--text);
  display: flex;
  justify-content: space-between;
}

</style>