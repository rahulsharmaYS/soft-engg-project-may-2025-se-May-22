<template>
  <div>
    <h2>Submit Assignment Page</h2>
    <p>This is a placeholder component.</p>
  </div>
</template>

<script setup>
</script>

<style scoped>
h2 {
  color: #2c3e50;
}
</style>
