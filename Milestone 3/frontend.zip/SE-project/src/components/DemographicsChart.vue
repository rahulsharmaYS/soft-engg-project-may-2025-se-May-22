<template>
  <div class="chart-container" ref="chartContainer">
    <h3>Student Demographics</h3>
    <canvas id="demographicsChart"></canvas>
  </div>
</template>

<script setup>
import { onMounted, watch, nextTick, ref } from 'vue';
import Chart from 'chart.js/auto';
import { store } from '../store.js';

let demographicsChart = null;
const chartContainer = ref(null);

const createChart = () => {
  if (demographicsChart) demographicsChart.destroy();
  if (!chartContainer.value) return;

  const textColor = getComputedStyle(chartContainer.value).getPropertyValue('--text').trim();
  demographicsChart = new Chart(document.getElementById('demographicsChart'), {
    type: 'doughnut',
    data: {
      labels: ['8-10 years', '11-12 years', '13-14 years'],
      datasets: [{
        label: 'Student Count',
        data: [1250, 2300, 1450],
        backgroundColor: ['#3b82f6', '#84cc16', '#f97316']
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          position: 'top',
          labels: {
            color: textColor
          }
        }
      }
    }
  });
};

onMounted(async () => {
  await nextTick();
  createChart();
});
watch(() => store.darkMode, async () => {
  await nextTick();
  createChart();
});
</script>

<style scoped>
.chart-container {
  background: var(--card);
  padding: 1rem;
  border-radius: var(--card-radius);
  box-shadow: var(--shadow);
  width: 100%;
  height: 400px;
}
.chart-container canvas {
  width: 95% !important;
  height: 85% !important;
}
</style>