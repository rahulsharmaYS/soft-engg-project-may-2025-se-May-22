
<!-- 
 

NO PURPOSE FOR THIS FILE 💀


-->


<template>
  <div class="chart-container" ref="chartContainer">
    <canvas ref="attendanceCanvas"></canvas>
  </div>
</template>

<script setup>
import { ref, onMounted, watch, nextTick } from 'vue';
import Chart from 'chart.js/auto';
import axios from 'axios';
import { store } from '../store.js';

const attendanceCanvas = ref(null);
const chartContainer = ref(null);
let attendanceChart = null;

const fetchAttendanceData = async () => {
  try {
    const teacherId = store.teacherId;
    const res = await axios.get(`/api/teachers/${teacherId}/dashboard`);
    return res.data.attendance_data || [0, 0, 0, 0];
  } catch (error) {
    console.error('Failed to fetch attendance data:', error);
    return [0, 0, 0, 0];
  }
};

const createChart = async () => {
  if (attendanceChart) attendanceChart.destroy();
  if (!chartContainer.value || !attendanceCanvas.value) return;

  const attendanceData = await fetchAttendanceData();

  const textColor = getComputedStyle(chartContainer.value).getPropertyValue('--text').trim();
  const gridColor = store.isDarkMode ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.1)';

  attendanceChart = new Chart(attendanceCanvas.value, {
    type: 'line',
    data: {
      labels: ['Week 1', 'Week 2', 'Week 3', 'Week 4'],
      datasets: [{
        label: 'Attendance (%)',
        data: attendanceData,
        borderColor: '#3b82f6',
        backgroundColor: 'rgba(59, 130, 246, 0.2)',
        tension: 0.4,
        fill: true,
        pointRadius: 5,
        pointHoverRadius: 7,
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { labels: { color: textColor } },
        tooltip: {
          callbacks: {
            label: context => `Attendance: ${context.parsed.y}%`
          }
        }
      },
      scales: {
        x: {
          ticks: { color: textColor },
          grid: { color: gridColor }
        },
        y: {
          ticks: {
            color: textColor,
            callback: value => `${value}%`
          },
          grid: { color: gridColor },
          beginAtZero: true,
          max: 100,
        }
      }
    }
  });
};

onMounted(async () => {
  await nextTick();
  createChart();
});

watch(() => store.isDarkMode, async () => {
  await nextTick();
  createChart();
});
</script>

<style scoped>
.chart-container {
  background: var(--card);
  padding: 1rem;
  border-radius: var(--card-radius);
  box-shadow: var(--shadow);
  height: 300px;
  width: 100%;
}
</style>
