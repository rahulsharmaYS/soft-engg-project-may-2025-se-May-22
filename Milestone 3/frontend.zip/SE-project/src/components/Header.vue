<template>
  <header class="header">
    <div class="header-content">
      <h1>{{ title }}</h1>
      <p>{{ subtitle }}</p>
    </div>
    <div class="controls">
      <label class="switch">
        <input type="checkbox" v-model="$store.darkMode" @change="$store.toggleDarkMode()" />
        <span class="slider" />
      </label>
    </div>
  </header>
</template>

<script setup>
import { store as $store } from '../store.js'

defineProps({ title: String, subtitle: String })
</script>

<style scoped>

.header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 2rem;
  color: var(--text);
}



h1 {
  margin: 0;
  font-weight: 700;
}

p {
  margin: 0;
  opacity: 0.8; 
}

.controls {
  display: flex;
  align-items: center;
}

.switch {
  position: relative;
  display: inline-block;
  width: 52px;
  height: 28px;
}

.switch input {
  opacity: 0;
  width: 0;
  height: 0;
}

.slider {
  position: absolute;
  inset: 0;
  cursor: pointer;
  background-color: var(--secondary);
  border-radius: 34px;
  transition: background-color 0.4s;
}

.slider:before {
  position: absolute;
  content: '🌞';
  height: 24px;
  width: 24px;
  left: 2px;
  bottom: 2px;
  display: flex;
  align-items: center;
  justify-content: center;
  background-color: var(--card);
  border-radius: 50%;
  font-size: 14px;
  transition: transform 0.4s, content 0.4s;
}

input:checked + .slider {
  background-color: var(--primary);
}

input:checked + .slider:before {
  transform: translateX(24px);
  content: '🌙';
}

@media (max-width: 768px) {
  .header {
    flex-direction: column;
    text-align: center;
    padding: 1rem;
  }

  .controls {
    margin-top: 1rem;
    justify-content: center;
  }
}
</style>