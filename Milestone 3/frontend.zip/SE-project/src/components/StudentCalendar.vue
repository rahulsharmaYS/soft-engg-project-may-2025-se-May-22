<template>
  <div>
    <Header title="My Calendar" subtitle="Stay organized and never miss a task!" />

    <div class="main-content-wrapper">
      <div class="calendar-header">
        <button @click="prevMonth">‹</button>
        <h3>{{ currentMonthName }} {{ currentYear }}</h3>
        <button @click="nextMonth">›</button>
      </div>

      <div class="calendar-controls">
        <input type="text" v-model="newReminder" placeholder="Add new reminder..." />
        <input type="date" v-model="reminderDate" />
        <button @click="addReminder">Set Reminder</button>
      </div>

      <section class="calendar-month-view">
        <div class="calendar-grid-header">
          <div v-for="day in weekDays" :key="day" class="day-name">{{ day }}</div>
        </div>

        <div class="calendar-grid-body">
          <div
            v-for="day in calendarDays"
            :key="day.date"
            class="calendar-cell"
            :class="{ 'not-current-month': !day.isCurrentMonth }"
            @click="openTaskModal(day.date)"
          >
            <div class="cell-date">{{ day.date.getDate() }}</div>

            <div class="event-list">
              <div
                v-for="event in eventsOnDate(day.date)"
                :key="event.id"
                class="event-pill"
                :class="event.type"
              >
                {{ event.title }}
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>

    <div v-if="showTaskModal" class="modal-overlay" @click.self="closeTaskModal">
      <div class="modal-content"> <div class="modal-header">
          <h3>📝 Tasks on {{ formatDate(selectedDate) }}</h3>
          <button class="close-btn" @click="closeTaskModal">×</button> </div>

        <div class="modal-body">
          <form @submit.prevent="createTask" class="task-form">
            <input v-model="newTask.title" placeholder="Task title" required />
            <input v-model="newTask.description" placeholder="Description" />
            <input type="datetime-local" v-model="newTask.due_date" required />
            <button type="submit">➕ Add Task</button>
          </form>

          <hr />

          <div class="task-section" v-if="tasksOnDate.length">
            <h4>📌 Your Tasks</h4>
            <div v-for="(task, index) in tasksOnDate" :key="task.id" class="task-card" :class="task.status">
              <div class="task-info">
                <template v-if="task.editing">
                  <input v-model="task.title" />
                  <input v-model="task.description" />
                  <input type="datetime-local" v-model="task.due_date" />
                </template>
                <template v-else>
                  <h5>{{ task.title }}</h5>
                  <p>{{ task.description }}</p>
                  <span class="task-date">🕒 {{ formatDateTime(task.due_date) }}</span>
                </template>
              </div>

              <div class="task-actions">
                <span class="status-pill" :class="task.status">{{ task.status }}</span>
                <button @click="toggleTask(index)">
                  {{ task.status === 'complete' ? 'Undo' : 'Done' }}
                </button>
                <button @click="toggleEdit(index)">
                  {{ task.editing ? 'Save' : 'Edit' }}
                </button>
                <button @click="deleteTask(task.id)">🗑</button>
              </div>
            </div>
          </div>
          <p v-else style="margin-top: 1rem; color: var(--text); opacity: 0.7;">No tasks for this day.</p>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import Header from '../components/Header.vue'
import api from '../api'
import { useRoute } from 'vue-router'

const route = useRoute()
const userId = route.params.id

// data thign
const assignments = ref([])
const reminders = ref([])
const newReminder = ref('')
const reminderDate = ref('')
const today = new Date()
const currentYear = ref(today.getFullYear())
const currentMonth = ref(today.getMonth())
const weekDays = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']
const tasks = ref([])
const showTaskModal = ref(false)
const selectedDate = ref(null)
const newTask = ref({
  title: '',
  description: '',
  due_date: ''
})

// calendar utilities
const getMonthDays = (year, month) => {
  const first = new Date(year, month, 1)
  const last = new Date(year, month + 1, 0)
  const days = []
  const startOffset = first.getDay()
  const total = last.getDate()
  const slots = Math.ceil((startOffset + total) / 7) * 7
  for (let i = 0; i < slots; i++) {
    const day = new Date(year, month, i - startOffset + 1)
    days.push({ date: day, isCurrentMonth: day.getMonth() === month })
  }
  return days
}

const calendarDays = computed(() => getMonthDays(currentYear.value, currentMonth.value))
const currentMonthName = computed(() =>
  new Date(currentYear.value, currentMonth.value).toLocaleString('default', { month: 'long' })
)
const allEvents = computed(() => [...assignments.value, ...reminders.value, ...tasks.value])
const tasksOnDate = computed(() =>
  tasks.value.filter(t => new Date(t.due_date).toDateString() === selectedDate.value.toDateString())
)
const eventsOnDate = date =>
  allEvents.value.filter(e => new Date(e.date || e.due_date).toDateString() === date.toDateString())

const prevMonth = () => {
  currentMonth.value = currentMonth.value === 0 ? 11 : currentMonth.value - 1
  if (currentMonth.value === 11) currentYear.value--
}
const nextMonth = () => {
  currentMonth.value = currentMonth.value === 11 ? 0 : currentMonth.value + 1
  if (currentMonth.value === 0) currentYear.value++
}


const openTaskModal = date => {
  selectedDate.value = date
  showTaskModal.value = true
  let newDate = new Date(date);
  newDate.setDate(newDate.getDate() + 1); // add 1 day
  newTask.value.due_date = newDate.toISOString().slice(0, 16);
  document.body.style.overflow = 'hidden'; // solved body scroll when modal is open
  fetchTasks()
}
const closeTaskModal = () => {
  showTaskModal.value = false
  document.body.style.overflow = '' // restore body scroll
}

onMounted(() => {
  fetchTasks()
})

async function fetchTasks() {
  try {
    const res = await api.get(`/student/${userId}/calendar`)
    tasks.value = res.data.map(t => ({
      ...t,
      editing: false,
      due_date: t.due_date?.slice(0, 16) || ''
    }))
  } catch (err) {
    console.error(err)
  }
}

async function createTask() {
  try {
    await api.post(`/student/${userId}/calendar`, {
      title: newTask.value.title,
      description: newTask.value.description,
      due_date: newTask.value.due_date
    })
    await fetchTasks()
    newTask.value = { title: '', description: '', due_date: selectedDate.value.toISOString().slice(0, 16) }
  } catch (err) {
    console.error(err)
  }
}

async function toggleTask(index) {
  const task = tasksOnDate.value[index]
  const newStatus = task.status === 'complete' ? 'pending' : 'complete'
  try {
    await api.put(`/student/${userId}/calendar/${task.id}`, {
      ...task,
      status: newStatus
    })
    fetchTasks()
  } catch (err) {
    console.error(err)
  }
}

async function toggleEdit(index) {
  const task = tasksOnDate.value[index]
  if (task.editing) {
    try {
      await api.put(`/student/${userId}/calendar/${task.id}`, task)
    } catch (err) {
      console.error(err)
    }
  }
  task.editing = !task.editing
}

async function deleteTask(id) {
  try {
    await api.delete(`/student/${userId}/calendar/${id}`)
    fetchTasks()
  } catch (err) {
    console.error(err)
  }
}

function addReminder() {
  if (newReminder.value && reminderDate.value) {
    reminders.value.push({
      id: Date.now(),
      title: newReminder.value,
      date: reminderDate.value,
      type: 'reminder'
    })
    newReminder.value = ''
    reminderDate.value = ''
  }
}

function formatDate(date) {
  return date.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })
}

function formatDateTime(dateStr) {
  const date = new Date(dateStr)
  return date.toLocaleString('en-IN', {
    day: '2-digit', month: 'short', year: 'numeric',
    hour: '2-digit', minute: '2-digit', hour12: true
  })
}
</script>

<style scoped>
.main-content-wrapper {
  margin-top: 2rem;
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
}
.calendar-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.calendar-controls {
  display: flex;
  gap: 1rem;
  flex-wrap: wrap;
  align-items: center;
}
.calendar-controls input,
.calendar-controls button {
  padding: 0.5rem;
  font-size: 1rem;
  border-radius: 0.5rem;
}
.calendar-controls input {
  border: 1px solid var(--border);
  background-color: var(--card);
  color: var(--text);
}
.calendar-controls button {
  background: var(--primary);
  color: white;
  border: none;
  cursor: pointer;
}
.calendar-month-view {
  display: flex;
  flex-direction: column;
  background-color: var(--card);
  border: 1px solid var(--border);
  border-radius: 12px;
  overflow: hidden;
}
.calendar-grid-header,
.calendar-grid-body {
  display: grid;
  grid-template-columns: repeat(7, 1fr);
}
.day-name {
  text-align: center;
  font-weight: bold;
  padding: 0.75rem 0.5rem;
  background: var(--bg);
}
.calendar-cell {
  border-right: 1px solid var(--border);
  border-bottom: 1px solid var(--border);
  padding: 0.5rem;
  min-height: 120px;
  display: flex;
  flex-direction: column;
  gap: 0.25rem;
}
.calendar-cell:nth-child(7n) {
  border-right: none;
}
.not-current-month {
  background: var(--bg);
  color: var(--text);
  opacity: 0.6;
}
.cell-date {
  font-size: 0.85rem;
  font-weight: bold;
  color: var(--text);
}
.event-list {
  display: flex;
  flex-direction: column;
  gap: 0.25rem;
  margin-top: 0.25rem;
}
.event-pill {
  font-size: 0.75rem;
  padding: 0.2rem 0.4rem;
  border-radius: 6px;
  border: 1px solid var(--border); 
  color: var(--text);
  background-color: var(--bg);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.event-pill.assignment {
  background-color: #f97316;
  color: white;
}
.event-pill.reminder {
  background-color: #10b981;
  color: white;
}
.modal-overlay {
  position: fixed;
  top: 0; left: 0;
  width: 100vw; height: 100vh;
  background: rgba(0,0,0,0.6);
  backdrop-filter: blur(3px);
  display: flex; justify-content: center; align-items: center;
  z-index: 1000;
}

.modal-content {
  background: var(--card); 
  padding: 2rem; 
  border-radius: 10px; 
  width: 90%;
  max-width: 600px;
  max-height: 90vh;
  overflow-y: auto;
  box-shadow: var(--shadow);
  color: var(--text);
}

.modal-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 1rem;
  color: var(--text);
}

.modal-header .close-btn {
  font-size: 1.5rem;
  background: transparent;
  border: none;
  cursor: pointer;
  color: var(--text);
}

.task-form {
  display: flex;
  flex-direction: column;
  gap: 0.8rem;
}

.task-form input {
  padding: 0.75rem;
  border-radius: 8px;
  border: 1px solid var(--border);
  background-color: var(--bg);
  color: var(--text);
}
.task-form input:focus {
  border-color: var(--primary);
  outline: none;
  box-shadow: 0 0 0 3px rgba(var(--primary-rgb, 79, 70, 229), 0.25);
}

.task-form button {
  margin-top: 0.5rem;
  background: var(--primary);
  color: white;
  padding: 0.75rem;
  border: none;
  border-radius: 8px; 
  cursor: pointer;
  font-weight: 600;
  transition: all 0.2s ease;
  box-shadow: 0 2px 8px rgba(0,0,0,0.05);
}
.task-form button:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(0,0,0,0.1);
  opacity: 0.95;
}


.task-section {
  margin-top: 1.5rem;
}

.task-section h4 { 
  font-size: 1.1rem;
  font-weight: 600;
  color: var(--text);
  margin-bottom: 0.8rem;
}

.task-card {
  background: var(--bg); 
  border: 1px solid var(--border);
  padding: 1rem; 
  border-radius: 0.75rem; 
  margin-top: 0.8rem; 
  box-shadow: 0 1px 5px rgba(0,0,0,0.03);
  color: var(--text); 
}

.task-info h5 { 
  font-size: 1rem;
  font-weight: 600;
  margin-bottom: 0.2rem;
}
.task-info p { 
  font-size: 0.9rem;
  color: var(--text);
  opacity: 0.8;
  margin-bottom: 0.4rem;
}


.task-actions {
  display: flex;
  gap: 0.6rem; 
  margin-top: 0.8rem; 
  flex-wrap: wrap;
}

.task-actions button { 
  padding: 0.4rem 0.8rem;
  font-size: 0.85rem;
  border-radius: 6px;
  border: 1px solid var(--border);
  background-color: var(--bg);
  color: var(--text);
  cursor: pointer;
  transition: all 0.2s ease;
}
.task-actions button:hover {
  background-color: var(--primary);
  color: white;
  border-color: var(--primary);
}


.task-date {
  font-size: 0.8rem; 
  color: var(--text); 
  opacity: 0.7; 
}

.status-pill {
  padding: 0.25rem 0.6rem; 
  font-size: 0.75rem;
  border-radius: 0.5rem;
  background: var(--secondary); 
  color: var(--text);
  text-transform: capitalize;
  font-weight: 600;
}

.status-pill.complete {
  background-color: #10b981; 
  color: white;
}

.status-pill.pending {
  background-color: #facc15; 
  color: black;
}

hr {
  border: none;
  border-top: 1px solid var(--border); 
  margin: 1.5rem 0; 
}

@media (max-width: 768px) {
  .modal-content {
    padding: 1.5rem;
    max-width: 90%;
  }
  .task-form input, .task-form button {
    padding: 0.6rem;
  }
  .task-card {
    padding: 0.8rem;
  }
  .task-actions button {
    padding: 0.3rem 0.6rem;
    font-size: 0.8rem;
  }
}
</style>