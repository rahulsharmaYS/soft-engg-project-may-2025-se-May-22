<template>
  <div class="help-center">
    <main class="main">
      <Header title="Help Center" subtitle="Support tickets from users" />

      <div class="controls">
        <input
          type="text"
          v-model="searchQuery"
          @input="filterTickets"
          placeholder="Search tickets by subject or user"
          class="search-input"
        />
      </div>

      <div class="ticket-list">
        <div
          v-for="ticket in filteredTickets"
          :key="ticket.id"
          class="ticket"
          :class="{ expanded: expandedTicketId === ticket.id }"
        >
          <div class="ticket-summary" @click="toggleExpand(ticket.id)">
            <div class="info">
              <span class="type-label">{{ roleCode(ticket.fromRole) }}-{{ roleCode(ticket.toRole) }}</span>
              <span class="subject">{{ ticket.subject }}</span>
              <span class="status" :class="ticket.status">{{ ticket.status }}</span>
            </div>
            <div class="meta">
              <span class="time">{{ ticket.time }}</span>
            </div>
          </div>

          <div v-if="expandedTicketId === ticket.id" class="ticket-details">
            <p><strong>From:</strong> {{ ticket.fromName }} ({{ ticket.fromRole }})
              <button @click.stop="viewProfile(ticket.fromUser)" class="btn small">View Profile</button>
              <button @click.stop="banUser(ticket.fromUser)" class="btn danger small">Ban</button>
              <button @click.stop="messageUser(ticket.fromUser)" class="btn small">Message</button>
            </p>
            <p><strong>To:</strong> {{ ticket.toName }} ({{ ticket.toRole }})
              <button @click.stop="viewProfile(ticket.toUser)" class="btn small">View Profile</button>
              <button @click.stop="banUser(ticket.toUser)" class="btn danger small">Ban</button>
              <button @click.stop="messageUser(ticket.toUser)" class="btn small">Message</button>
            </p>
            <p><strong>Email:</strong> {{ ticket.email }}</p>
            <p><strong>Message:</strong></p>
            <p class="message">{{ ticket.message }}</p>
          </div>
        </div>
      </div>

      <div v-if="selectedUser" class="modal-overlay" @click.self="selectedUser = null">
        <div class="modal">
          <div class="modal-header">
            <h3>User Profile</h3>
            <button class="close-btn" @click="selectedUser = null">✖</button>
          </div>
          <div class="modal-body">
            <img :src="selectedUser.profilePic" class="modal-pic" />
            <p><strong>ID:</strong> {{ selectedUser.id }}</p>
            <p><strong>Name:</strong> {{ selectedUser.name }}</p>
            <p><strong>Email:</strong> {{ selectedUser.email }}</p>
            <p><strong>Role:</strong> {{ selectedUser.role }}</p>
            <p><strong>Status:</strong> {{ selectedUser.banned ? 'Banned' : 'Active' }}</p>
          </div>
        </div>
      </div>
    </main>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import Header from '../components/Header.vue'

const expandedTicketId = ref(null)
const selectedUser = ref(null)
const searchQuery = ref('')
const filteredTickets = ref([])

function toggleExpand(id) {
  expandedTicketId.value = expandedTicketId.value === id ? null : id
}

function viewProfile(user) {
  selectedUser.value = user
}

function banUser(user) {
  user.banned = true
  alert(`${user.name} has been banned.`)
}

function messageUser(user) {
  alert(`Opening message box to ${user.name} (mock only)`)
}

function roleCode(role) {
  return role === 'student' ? 'S' : 'I'
}

// Dummy Users for nowwww
const user1 = { id: 'U001', name: 'Alice Johnson', email: 'alice@student.com', role: 'student', banned: false, profilePic: 'https://i.pravatar.cc/100?img=1' }
const user2 = { id: 'U002', name: 'Professor Smith', email: 'smith@instructor.com', role: 'instructor', banned: false, profilePic: 'https://i.pravatar.cc/100?img=2' }
const user3 = { id: 'U003', name: 'Eva Green', email: 'eva@student.com', role: 'student', banned: false, profilePic: 'https://i.pravatar.cc/100?img=3' }
const user4 = { id: 'U004', name: 'Dr. Raj', email: 'raj@instructor.com', role: 'instructor', banned: false, profilePic: 'https://i.pravatar.cc/100?img=4' }

const tickets = ref([
  {
    id: 'T001',
    fromName: user1.name,
    fromRole: user1.role,
    toName: user2.name,
    toRole: user2.role,
    email: user1.email,
    subject: 'Issue with assignment submission',
    message: 'I tried submitting the assignment but it failed. Please help!',
    status: 'open',
    time: '2 hours ago',
    fromUser: user1,
    toUser: user2
  },
  {
    id: 'T002',
    fromName: user2.name,
    fromRole: user2.role,
    toName: user1.name,
    toRole: user1.role,
    email: user2.email,
    subject: 'Suspected plagiarism',
    message: 'A student submitted work that looks like someone else’s.',
    status: 'open',
    time: '1 day ago',
    fromUser: user2,
    toUser: user1
  },
  {
    id: 'T003',
    fromName: user3.name,
    fromRole: user3.role,
    toName: user1.name,
    toRole: user1.role,
    email: user3.email,
    subject: 'Group project issue',
    message: 'My teammate is not contributing to the group project.',
    status: 'closed',
    time: '3 days ago',
    fromUser: user3,
    toUser: user1
  },
  {
    id: 'T004',
    fromName: user2.name,
    fromRole: user2.role,
    toName: user4.name,
    toRole: user4.role,
    email: user2.email,
    subject: 'Schedule coordination',
    message: 'Can we align our lectures? Students are struggling to attend both.',
    status: 'open',
    time: '5 days ago',
    fromUser: user2,
    toUser: user4
  }
])

filteredTickets.value = tickets.value

function filterTickets() {
  const query = searchQuery.value.toLowerCase()
  filteredTickets.value = tickets.value.filter(ticket =>
    ticket.subject.toLowerCase().includes(query) ||
    ticket.fromName.toLowerCase().includes(query) ||
    ticket.toName.toLowerCase().includes(query)
  )
}
</script>

<style scoped>
.help-center {
  display: flex;
  background-color: var(--bg); 
}
.main {
  flex: 1;
  padding: 2rem;
  color: var(--text); 
}
.controls {
  display: flex;
  justify-content: flex-end;
  margin-bottom: 1rem;
}
.search-input {
  padding: 0.5rem 1rem;
  border: 1px solid var(--border); 
  border-radius: 6px;
  width: 300px;
  font-size: 1rem;
  background-color: var(--card);
  color: var(--text);
}

.ticket-list {
  display: flex;
  flex-direction: column;
  gap: 1rem;
}
.ticket {
  background: var(--card); 
  border-radius: 6px;
  box-shadow: 0 0 5px rgba(0, 0, 0, 0.08);
  cursor: pointer;
  padding: 1rem;
  transition: 0.2s ease;
  color: var(--text);
}
.ticket-summary {
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.ticket .type-label {
  font-weight: bold;
  margin-right: 1rem;
  background: var(--secondary);
  padding: 2px 6px;
  border-radius: 4px;
  color: var(--text);
}
.ticket .subject {
  flex-grow: 1;
  font-size: 1rem;
}
.ticket .status {
  font-size: 0.8rem;
  padding: 2px 8px;
  border-radius: 12px;
  text-transform: uppercase;
}
.ticket .status.open {
  background-color: var(--primary);
  color: white;
}
.ticket .status.closed {
  background-color: var(--secondary);
  color: var(--text);
}
.ticket-details {
  margin-top: 1rem;
  border-top: 1px solid var(--border); 
  padding-top: 1rem;
  font-size: 0.95rem;
  color: var(--text);
}
.ticket-details .message {
  background: var(--bg);
  padding: 0.75rem;
  border-radius: 5px;
  margin-top: 0.5rem;
  white-space: pre-wrap;
  color: var(--text);
}
.meta {
  font-size: 0.8rem;
  color: var(--text);
}
.btn {
  margin-left: 0.5rem;
  padding: 0.2rem 0.6rem;
  font-size: 0.75rem;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  background: var(--primary);
  color: white;
  transition: background-color 0.3s;
}
.btn.small {
  font-size: 0.75rem;
}
.btn.danger {
  background: var(--secondary);
  color: var(--text);
}
.btn:hover {
  background-color: var(--button);
}
.btn.danger:hover {
  background-color: var(--primary);
}

.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.5);
  z-index: 1000;
  display: flex;
  align-items: center;
  justify-content: center;
}
.modal {
  background: var(--card);
  padding: 2rem;
  border-radius: 8px;
  width: 90%;
  max-width: 400px;
  animation: fadeIn 0.3s ease;
  box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
  color: var(--text);
}
.modal-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.close-btn {
  background: transparent;
  border: none;
  font-size: 1.2rem;
  cursor: pointer;
  color: var(--text);
}
.modal-body {
  text-align: center;
}
.modal-pic {
  width: 80px;
  height: 80px;
  border-radius: 50%;
  margin-bottom: 1rem;
}
@keyframes fadeIn {
  from {
    opacity: 0;
    transform: scale(0.96);
  }
  to {
    opacity: 1;
    transform: scale(1);
  }
}

</style>