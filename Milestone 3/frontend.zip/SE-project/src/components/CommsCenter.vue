<template>
  <div>
    <Header :title="isInstructorView ? 'Instructor Comms Center' : 'Parent Comms Center'" subtitle="Direct and secure messaging" />
    <div class="comms-center-layout">
      <aside class="conversation-list">
        <header class="list-header">
          <h2>Chats</h2>
        </header>
        <ul class="chat-items">
          <li
            v-for="convo in displayedConversations"
            :key="convo.id"
            @click="selectConversation(convo.id)"
            :class="{ active: activeConversation && activeConversation.id === convo.id }"
            class="chat-item"
          >
            <img :src="getParticipant(convo).avatar" alt="Avatar" class="avatar" />
            <div class="chat-info">
              <span class="chat-name">{{ getParticipant(convo).name }}</span>
              <span class="chat-subtitle" v-if="isInstructorView && getParticipant(convo).role === 'parent'">
                Parent of {{ getParticipant(convo).childName }}
              </span>
              <span class="chat-subtitle" v-else-if="!isInstructorView && getParticipant(convo).role === 'instructor'">
                {{ getParticipant(convo).subject }}
              </span>
            </div>
          </li>
        </ul>
      </aside>

      <main class="chat-window">
        <template v-if="activeConversation">
          <header class="chat-header">
            <div class="participant-info">
              <img :src="getParticipant(activeConversation).avatar" alt="Avatar" class="avatar" />
              <div class="chat-info">
                <span class="chat-name header-name">{{ getParticipant(activeConversation).name }}</span>
                <span class="chat-subtitle" v-if="isInstructorView && getParticipant(activeConversation).role === 'parent'">
                  Parent of {{ getParticipant(activeConversation).childName }}
                </span>
                <span class="chat-subtitle" v-else-if="!isInstructorView && getParticipant(activeConversation).role === 'instructor'">
                  {{ getParticipant(activeConversation).subject }}
                </span>
              </div>
            </div>
            <button v-if="isInstructorView" @click="viewChildDetails" class="view-details-btn">
              View Child Details
            </button>
          </header>
          <div class="message-area">
            <div
              v-for="message in activeConversation.messages"
              :key="message.timestamp"
              class="message-bubble"
              :class="{ sent: message.senderId === currentUser.id, received: message.senderId !== currentUser.id }"
            >
              <p>{{ message.text }}</p>
            </div>
          </div>
          <footer class="message-input-area">
            <input v-model="newMessageText" @keyup.enter="sendMessage" type="text" placeholder="Type a message..." />
            <button @click="sendMessage">Send</button>
          </footer>
        </template>
        <template v-else>
          <div class="no-chat-selected"><p>Select a chat to start messaging</p></div>
        </template>
      </main>
    </div>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue';
import { useRoute } from 'vue-router';
import Header from './Header.vue';

const route = useRoute();

const users = ref({
  1: { id: 1, name: 'Mrs. Davis', role: 'instructor', subject: 'Mathematics', avatar: 'https://avatar.iran.liara.run/public/girl?username=Davis' },
  2: { id: 2, name: 'Mr. Smith', role: 'instructor', subject: 'History', avatar: 'https://avatar.iran.liara.run/public/boy?username=Smith' },
  3: { id: 3, name: 'Anjali Sharma', role: 'parent', childName: 'Nikhil', avatar: 'https://avatar.iran.liara.run/public/job/mother/female' },
  4: { id: 4, name: 'Vikram Reddy', role: 'parent', childName: 'Arya', avatar: 'https://avatar.iran.liara.run/public/job/father/male' },
});

const instructorConversations = ref([
  { id: 'conv_p1', participants: [1, 3], messages: [{ senderId: 3, text: "Hi, I'd like to discuss Nikhil's progress.", timestamp: new Date() }] },
  { id: 'conv_p2', participants: [1, 4], messages: [{ senderId: 4, text: "Hello, when is the history project due for Arya?", timestamp: new Date() }] },
]);

const parentConversations = ref([
  { id: 'conv_i1', participants: [3, 1], messages: [{ senderId: 3, text: "Hi, I'd like to discuss Nikhil's progress.", timestamp: new Date() }] },
  { id: 'conv_i2', participants: [3, 2], messages: [{ senderId: 3, text: "Hello Mr. Smith!", timestamp: new Date() }] },
]);

const isInstructorView = computed(() => route.path.startsWith('/instructor'));
const currentUser = computed(() => isInstructorView.value ? users.value[1] : users.value[3]);
const displayedConversations = computed(() => isInstructorView.value ? instructorConversations.value : parentConversations.value);

const selectedConversationId = ref(null);
const newMessageText = ref('');

const activeConversation = computed(() => {
  if (!selectedConversationId.value) return null;
  return displayedConversations.value.find(c => c.id === selectedConversationId.value);
});

function selectConversation(id) {
  selectedConversationId.value = id;
}

function getParticipant(convo) {
  const participantId = convo.participants.find(pId => pId !== currentUser.value.id);
  return users.value[participantId] || {};
}

function getLastMessage(convo) {
  return convo.messages[convo.messages.length - 1] || { text: 'No messages yet' };
}

function sendMessage() {
  if (!newMessageText.value.trim() || !activeConversation.value) return;
  activeConversation.value.messages.push({
    senderId: currentUser.value.id,
    text: newMessageText.value,
    timestamp: new Date()
  });
  newMessageText.value = '';
}

function viewChildDetails() {
  const participant = getParticipant(activeConversation.value);
  alert(`Viewing details for ${participant.childName}.`);
}

if (displayedConversations.value.length > 0) {
  selectConversation(displayedConversations.value[0].id);
}
</script>

<style scoped>
.comms-center-layout { display: flex; height: calc(100vh - 10rem); background-color: var(--card); border-radius: 12px; overflow: hidden; border: 1px solid var(--border); margin-top: 2rem; }
.conversation-list { width: 320px; border-right: 1px solid var(--border); display: flex; flex-direction: column; }
.list-header { padding: 1rem; border-bottom: 1px solid var(--border); }
.list-header h2 { margin: 0; font-weight: 600; }
.chat-items { list-style: none; padding: 0; margin: 0; overflow-y: auto; flex-grow: 1; }
.chat-item { display: flex; align-items: center; gap: 1rem; padding: 1rem; cursor: pointer; border-bottom: 1px solid var(--border); }
.chat-item:hover { background-color: var(--bg); }
.chat-item.active { background-color: var(--primary-light); }
.avatar { width: 50px; height: 50px; border-radius: 50%; background-color: #eee; }
.chat-info { display: flex; flex-direction: column; overflow: hidden; line-height: 1.3; }
.chat-name { font-weight: 600; }
.header-name { font-size: 1.2rem; }
.chat-subtitle { font-size: 0.8rem; color: #666; }
.last-message { font-size: 0.9rem; color: #888; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.chat-window { flex-grow: 1; display: flex; flex-direction: column; }
.chat-header { display: flex; align-items: center; justify-content: space-between; padding: 1rem; border-bottom: 1px solid var(--border); background-color: var(--bg); }
.participant-info { display: flex; align-items: center; gap: 1rem; }
.view-details-btn {
  padding: 0.5rem 1rem;
  border: 1px solid var(--border);
  background-color: var(--bg);
  color: var(--text);
  border-radius: 8px;
  cursor: pointer;
  font-weight: 500;
}
.message-area { flex-grow: 1; padding: 1.5rem; overflow-y: auto; display: flex; flex-direction: column; gap: 1rem; }
.message-bubble { max-width: 60%; padding: 0.75rem 1rem; border-radius: 18px; }
.message-bubble p { margin: 0; }
.message-bubble.sent { background-color: var(--primary); color: white; border-bottom-right-radius: 4px; align-self: flex-end; }
.message-bubble.received { background-color: var(--bg); border: 1px solid var(--border); border-bottom-left-radius: 4px; align-self: flex-start; }
.message-input-area { display: flex; padding: 1rem; gap: 1rem; border-top: 1px solid var(--border); }
.message-input-area input { flex-grow: 1; padding: 0.75rem; border-radius: 20px; border: 1px solid var(--border); background-color: var(--card); color: var(--text); }
.message-input-area button { padding: 0.75rem 1.5rem; border: none; background-color: var(--primary); color: white; border-radius: 20px; cursor: pointer; font-weight: 600; }
.no-chat-selected { display: flex; align-items: center; justify-content: center; height: 100%; color: #888; }
</style>