<template>
  <div>
    <Header title="Messages & Reports" subtitle="Stay updated on your child’s academic journey" />

    <div class="main-content-wrapper">
      <div class="message-filters">
        <button :class="{ active: selectedTab === 'all' }" @click="selectedTab = 'all'">All</button>
        <button :class="{ active: selectedTab === 'notifications' }" @click="selectedTab = 'notifications'">Notifications</button>
        <button :class="{ active: selectedTab === 'reports' }" @click="selectedTab = 'reports'">Reports</button>
      </div>

      <div class="messages-list">
        <div
          v-for="message in filteredMessages"
          :key="message.id"
          class="message-card"
          :class="message.type"
        >
          <h4>{{ message.title }}</h4>
          <p>{{ message.body }}</p>
          <small>{{ formatDate(message.date) }}</small>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import Header from '../components/Header.vue'
import { ref, computed } from 'vue'

const selectedTab = ref('all')

const messages = ref([
  { id: 1, title: 'Monthly Report Available', body: 'Your child’s May performance report is ready.', date: '2025-06-01', type: 'report' },
  { id: 2, title: 'Parent Meeting Reminder', body: 'Virtual PTM scheduled for June 15th at 6 PM.', date: '2025-06-10', type: 'notification' },
  { id: 3, title: 'New Assignment Notification', body: 'English project submitted successfully.', date: '2025-06-09', type: 'notification' },
  { id: 4, title: 'April Report Available', body: 'April monthly report now accessible.', date: '2025-05-02', type: 'report' },
])

const filteredMessages = computed(() => {
  if (selectedTab.value === 'all') return messages.value
  return messages.value.filter(msg => msg.type === selectedTab.value)
})

function formatDate(dateStr) {
  const options = { year: 'numeric', month: 'short', day: 'numeric' }
  return new Date(dateStr).toLocaleDateString(undefined, options)
}
</script>

<style scoped>
.main-content-wrapper {
  margin-top: 2rem;
  display: flex;
  flex-direction: column;
  gap: 2rem;
}
.message-filters {
  display: flex;
  gap: 1rem;
}
.message-filters button {
  padding: 0.5rem 1rem;
  background: var(--bg);
  border: 1px solid var(--border);
  color: var(--text);
  border-radius: 0.5rem;
  cursor: pointer;
  font-weight: 500;
}
.message-filters button.active {
  background: var(--primary);
  color: white;
  border-color: var(--primary);
}
.messages-list {
  display: flex;
  flex-direction: column;
  gap: 1.25rem;
}
.message-card {
  padding: 1rem;
  border-radius: 0.75rem;
  background-color: var(--card);
  box-shadow: var(--shadow);
  border-left: 5px solid transparent;
  transition: 0.3s ease;
}
.message-card.notification {
  border-left-color: var(--primary);
}
.message-card.report {
  border-left-color: #10b981;
}
.message-card h4 {
  margin-bottom: 0.5rem;
  font-size: 1.1rem;
}
.message-card p {
  margin-bottom: 0.5rem;
}
.message-card small {
  color: gray;
  font-size: 0.85rem;
}
</style>