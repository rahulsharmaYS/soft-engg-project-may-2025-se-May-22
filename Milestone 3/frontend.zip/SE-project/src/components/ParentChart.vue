<template>
  <div class="chart" :style="{ height: height + 'px' }" ref="chartContainer">
    <h3 v-if="title" class="chart-title">{{ title }}</h3>
    <canvas ref="canvas"></canvas>
  </div>
</template>

<script setup>
import { onMounted, onBeforeUnmount, watch, ref } from 'vue'
import Chart from 'chart.js/auto'
import { store } from '../store.js'

const props = defineProps({
  data: {
    type: Object,
    required: true
  },
  title: {
    type: String,
    default: ''
  },
  height: {
    type: Number,
    default: 350
  },
  type: {
    type: String,
    default: 'line'
  }
})

const chartContainer = ref(null)
const canvas = ref(null)
let chartInstance = null

const createChart = () => {
  if (chartInstance) {
    chartInstance.destroy()
    chartInstance = null
  }
  if (!canvas.value) return

  const textColor = getComputedStyle(chartContainer.value).getPropertyValue('--text').trim()
  const isDark = store.darkMode

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: { labels: { color: textColor, font: { size: 12 } } },
      title: {
        display: false
      }
    },
    scales: {}
  }

  if (props.type === 'line' || props.type === 'bar') {
    options.scales = {
      x: {
        ticks: { color: textColor, font: { size: 12 } },
        grid: { color: isDark ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.1)' }
      },
      y: {
        ticks: { color: textColor, font: { size: 12 } },
        grid: { color: isDark ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.1)' }
      }
    }
  }

  chartInstance = new Chart(canvas.value.getContext('2d'), {
    type: props.type,
    data: props.data,
    options
  })
}

onMounted(() => {
  createChart()
})

watch(() => [props.data, props.type, store.darkMode], () => {
  createChart()
})

onBeforeUnmount(() => {
  if (chartInstance) {
    chartInstance.destroy()
    chartInstance = null
  }
})
</script>

<style scoped>
.chart {
  width: 100%;
  max-width: 700px;
  margin-top: 1rem;
  padding: 1rem;
  border-radius: var(--card-radius);
  background-color: var(--card);
  box-shadow: var(--shadow);
  transition: background 0.3s ease;
  display: flex;
  flex-direction: column;
  align-items: center;
}

.chart-title {
  margin: 0 0 0.5rem 0;
  font-weight: 600;
  color: var(--text);
  user-select: none;
}
</style>
