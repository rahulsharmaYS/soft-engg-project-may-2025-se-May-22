<template>
  <div class="panel">
    <div class="icon">{{ icon }}</div>
    <h3>{{ title }}</h3>
    <p>{{ description }}</p>
  </div>
</template>

<script setup>
defineProps(['title', 'icon', 'description'])
</script>

<style scoped>
.panel {
  background: var(--card);
    color: var(--text);
  padding: 1rem;
  width: 220px;
  border-radius: var(--card-radius);
  box-shadow: var(--shadow);
}
.icon {
  font-size: 2rem;
}
</style>
