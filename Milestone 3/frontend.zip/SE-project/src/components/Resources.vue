<template>
  <div>
    <Header title="Resources Hub" subtitle="Explore curated materials for learning and teaching" />

    <div class="resources-grid">
      <div v-if="isInstructorView" class="add-resource-card resource-card">
        <h3 class="card-title">Add New Resource</h3>
        <p class="card-subtitle">For Instructor Use Only</p>
        <form @submit.prevent="addResource" class="add-resource-form">
          <div class="input-group">
            <label>Resource Title</label>
            <input type="text" v-model="newResource.title" required />
          </div>
          <div class="input-group">
            <label>Description</label>
            <input type="text" v-model="newResource.description" required />
          </div>
          <div class="input-group">
            <label>URL</label>
            <input type="url" v-model="newResource.url" required />
          </div>
          <div class="select-group">
            <label for="resourceCategory">Category</label>
            <select v-model="newResource.category" id="resourceCategory" required>
              <option value="student">Student Resource</option>
              <option value="instructor">Instructor Tool</option>
            </select>
          </div>
          <button type="submit" class="add-btn">Add Resource</button>
        </form>
      </div>

      <div class="resource-card">
        <h3 class="card-title">Student Resources</h3>
        <div v-for="resource in studentResources" :key="resource.id" class="resource-item">
          <div class="resource-info">
            <h4>{{ resource.title }}</h4>
            <p>{{ resource.description }}</p>
          </div>
          <a :href="resource.url" target="_blank" class="resource-link">View</a>
        </div>
      </div>

      <div v-if="isInstructorView" class="resource-card">
        <h3 class="card-title">Instructor Tools</h3>
        <div v-for="tool in instructorTools" :key="tool.id" class="resource-item">
          <div class="resource-info">
            <h4>{{ tool.title }}</h4>
            <p>{{ tool.description }}</p>
          </div>
          <a :href="tool.url" target="_blank" class="resource-link">Visit</a>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, computed } from 'vue';
import { useRoute } from 'vue-router';
import Header from './Header.vue';
import api from '@/api';

const route = useRoute();
const teacherId = route.params.teacher_id;



const isInstructorView = computed(() => route.path.startsWith('/teacher'));

const studentResources = ref([]);
const instructorTools = ref([]);
const newResource = ref({ title: '', description: '', url: '', category: 'student' });

async function fetchResources() {
  if (isInstructorView.value) {
    const resS = await api.get(`/teacher/${teacherId}/resources?category=student`);
    const resI = await api.get(`/teacher/${teacherId}/resources?category=instructor`);
    studentResources.value = resS.data;
    instructorTools.value = resI.data;
  } else {
    const resS = await api.get(`/teacher/${teacherId}/resources?category=student`);
    studentResources.value = resS.data;
  }
}

async function addResource() {
  const payload = { ...newResource.value };
  try {
    const response = await api.post(`/teacher/${teacherId}/resources`, payload);
    const resource = response.data.resource;
    if (resource.category === 'student') studentResources.value.unshift(resource);
    else instructorTools.value.unshift(resource);
    newResource.value = { title: '', description: '', url: '', category: 'student' };
  } catch (err) {
    console.error('Failed to add resource:', err);
    alert('Oops, could not add!');
  }
}

onMounted(fetchResources);
</script>


<style scoped>
.resources-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(350px, 1fr)); gap: 2rem; margin-top: 2rem; }
.resource-card { background-color: var(--card); padding: 1.5rem; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.05); border: 1px solid var(--border); }
.card-title { font-size: 1.5rem; font-weight: 600; color: var(--text); margin-bottom: 0.5rem; }
.card-subtitle { font-size: 0.9rem; color: #888; margin-bottom: 1.5rem; }
.resource-item { display: flex; justify-content: space-between; align-items: center; padding: 1rem 0; border-bottom: 1px solid var(--border); }
.resource-item:last-child { border-bottom: none; }
.resource-info h4 { font-weight: 500; color: var(--text); margin-bottom: 0.25rem; }
.resource-info p { font-size: 0.9rem; color: #888; }
.resource-link { padding: 6px 14px; border-radius: 6px; background-color: var(--primary); color: white; text-decoration: none; font-size: 0.9rem; font-weight: 500; transition: background-color 0.2s; }
.resource-link:hover { background-color: #2563eb; }
.add-resource-form { margin-top: 1rem; }
.input-group, .select-group { margin-bottom: 1.5rem; }
.input-group label, .select-group label { display: block; font-size: 0.9rem; color: #888; margin-bottom: 8px; }
.input-group input, .select-group select {
  width: 100%;
  padding: 10px;
  font-size: 1rem;
  color: var(--text);
  border: 1px solid var(--border);
  border-radius: 8px;
  background-color: var(--bg);
  transition: border-color 0.3s;
  box-sizing: border-box;
}
.input-group input:focus, .select-group select:focus {
  outline: none;
  border-color: var(--primary);
}
.add-btn { width: 100%; padding: 0.8rem; border: none; border-radius: 10px; background-color: var(--primary); color: white; font-weight: 600; font-size: 1rem; cursor: pointer; transition: all 0.3s ease; }
.add-btn:hover { background-color: #2563eb; transform: translateY(-2px); }
</style>