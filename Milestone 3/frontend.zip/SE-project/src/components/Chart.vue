<template>
  <div class="chart" ref="chartContainer">
    <canvas id="lineChart"></canvas>
  </div>
</template>

<script setup>
import { onMounted, watch, nextTick, ref } from 'vue';
import Chart from 'chart.js/auto';
import { store } from '../store.js';

let lineChart = null;
const chartContainer = ref(null);

const createChart = () => {
  if (lineChart) lineChart.destroy();
  if (!chartContainer.value) return;

  const textColor = getComputedStyle(chartContainer.value).getPropertyValue('--text').trim();
  lineChart = new Chart(document.getElementById('lineChart'), {
    type: 'line',
    data: {
      labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
      datasets: [
        { label: 'Average grade', data: [2, 2.5, 3, 2.8, 3.2, 3.5, 3.8, 4, 3.7, 4.2, 4.4, 4.6], borderColor: '#3b82f6', tension: 0.4 },
        { label: 'Exams', data: [1.5, 2, 2.5, 3, 3.5, 4, 4.2, 4.5, 4.6, 4.8, 5, 5.2], borderColor: '#22c55e', tension: 0.4 }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: { legend: { labels: { color: textColor, font: { size: 12 } } } },
      scales: {
        x: { ticks: { color: textColor, font: { size: 12 } }, grid: { color: store.darkMode ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.1)' } },
        y: { ticks: { color: textColor, font: { size: 12 } }, grid: { color: store.darkMode ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.1)' } }
      }
    }
  });
};

onMounted(async () => {
  await nextTick();
  createChart();
});
watch(() => store.darkMode, async () => {
  await nextTick();
  createChart();
});
</script>

<style scoped>
.chart {
  width: 100%;
  max-width: 700px;
  height: 350px;
  margin-top: 1rem;
  padding: 1rem;
  border-radius: var(--card-radius);
  background-color: var(--card);
  box-shadow: var(--shadow);
  transition: background 0.3s ease;
}
</style>