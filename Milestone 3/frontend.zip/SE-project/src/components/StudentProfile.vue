<template>
  <div>
    <Header title="My Profile" subtitle="Your personal hub for achievements and account details." />

    <div class="profile-grid">
      <div class="profile-card profile-details-card">
        <h3>Profile Details</h3>
        <div class="details-content" v-if="student.name">
          <img :src="student.avatar" alt="Student Avatar" class="profile-avatar">
          <div class="info">
            <p><strong>Name:</strong> {{ student.name }}</p>
            <p><strong>Email:</strong> {{ student.email }}</p>
            <p><strong>Grade:</strong> {{ student.grade }}</p>
            <p><strong>Member Since:</strong> {{ student.memberSince }}</p>
            <p><strong>Role:</strong> <span class="role-tag">Student</span></p>
          </div>
        </div>
        <div v-else>
          <p>Loading profile...</p>
        </div>
      </div>

      <div class="profile-card">
        <h3>Settings & Actions</h3>
        <div class="actions-group">
          <button class="action-btn primary-btn" @click="openEditModal">Edit Profile</button>
          <button class="action-btn password-btn">Change Password</button> <button @click="logout" class="action-btn danger-btn">Logout</button>
        </div>
      </div>

      <div class="profile-card">
        <h3>Achievements</h3>
        <ul class="achievement-list">
          <li v-for="badge in student.badges" :key="badge">
            <span class="badge-icon">🏅</span>
            <span>{{ badge }}</span>
          </li>
        </ul>
      </div>

      </div>

    <div v-if="showModal" class="modal-overlay" @click.self="showModal = false">
      <div class="modal-content">
        <h3>Edit Profile</h3>
        <label>
          Full Name:
          <input v-model="editForm.full_name" type="text" />
        </label>
        <label>
          Email:
          <input v-model="editForm.email" type="email" />
        </label>
        <label>
          Avatar URL:
          <input v-model="editForm.avatar" type="text" />
        </label>
        <div class="modal-actions">
          <button @click="submitEdit" class="save-btn">Save</button>
          <button @click="showModal = false" class="cancel-btn">Cancel</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, watch, computed, onMounted } from 'vue';
import { useRouter, useRoute } from 'vue-router';
import api from '../api';
import Header from './Header.vue';

const router = useRouter();
const route = useRoute();

const studentId = computed(() => route.params.id);

const student = ref({
  name: '',
  email: '',
  grade: '',
  memberSince: '',
  avatar: '',
  topSkills: [],
  badges: [] 
});

const showModal = ref(false);
const editForm = ref({
  full_name: '',
  email: '',
  avatar: ''
});

const logout = () => {
  router.push('/login');
};

const openEditModal = () => {
  if (student.value) {
    editForm.value.full_name = student.value.name;
    editForm.value.email = student.value.email;
    editForm.value.avatar = student.value.avatar;
    showModal.value = true;
  }
};

const cancelEdit = () => {
  showModal.value = false;
};

const submitEdit = async () => {
  try {
    await api.put(`/student/${studentId.value}/profile`, {
      full_name: editForm.value.full_name,
      email: editForm.value.email,
      avatar: editForm.value.avatar
    });
    student.value.name = editForm.value.full_name;
    student.value.email = editForm.value.email;
    student.value.avatar = editForm.value.avatar;
    showModal.value = false;
    alert('Profile updated successfully');
  } catch (err) {
    console.error("Failed to update profile", err.response?.data || err);
    alert('Failed to update profile');
  }
};

async function loadProfile(id) {
  try {
    const res = await api.get(`/student/${id}/profile`);
    const data = res.data;
    student.value.name = data.full_name;
    student.value.email = data.email;
    student.value.grade = `Class ${data.class.standard} - ${data.class.division}`;
    student.value.memberSince = new Date(data.created_at).toLocaleString('default', { month: 'long', year: 'numeric' });
    student.value.avatar = `https://avatar.iran.liara.run/public/boy?username=${data.username}`;

    const badgeRes = await api.get(`/student/${id}/badges`);
    student.value.badges = badgeRes.data;
  } catch (err) {
    console.error("Failed to load student profile", err);
  }
}

onMounted(() => {
  if (studentId.value) loadProfile(studentId.value);
});

watch(studentId, (newId) => {
  if (newId) loadProfile(newId);
});
</script>

<style scoped>
body {
  font-family: 'Inter', 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
}

.profile-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); 
  gap: 1.5rem; 
  margin-top: 1.5rem; 
  align-items: stretch;
}

.profile-card {
  background-color: var(--card);
  padding: 1.5rem;
  border-radius: 12px; 
  box-shadow: 0 4px 15px rgba(0, 0, 0, 0.08);
  border: 1px solid var(--border);
  transition: transform 0.2s ease, box-shadow 0.2s ease; 
  height: 100%;
}

.profile-card:hover {
  transform: translateY(-3px); 
  box-shadow: 0 8px 20px rgba(0, 0, 0, 0.12);
}

h3 {
  font-size: 1.25rem;
  font-weight: 700;
  color: var(--primary);
  margin-bottom: 1rem; 
  border-bottom: 2px solid var(--border);
  padding-bottom: 0.75rem; 
  letter-spacing: 0;
}

.profile-details-card .details-content {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 0.8rem;
  text-align: center;
}

.profile-avatar {
  width: 100px; 
  height: 100px;
  border-radius: 50%;
  border: 4px solid var(--primary); 
  object-fit: cover;
  box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
  transition: transform 0.2s ease;
}
.profile-avatar:hover {
  transform: scale(1.01); 
}

.details-content .info h2 { 
  font-size: 1.8rem; 
  font-weight: 700;
  margin: 0;
  color: var(--text);
  letter-spacing: -0.01em;
  line-height: 1.2;
}
.details-content .info p {
  margin: 0.4rem 0;
  font-size: 0.95rem;
  color: var(--text);
  opacity: 0.7;
}

.details-content .info p strong {
  font-weight: 600;
  color: var(--text);
  margin-right: 0.3em;
}

.role-tag {
  background-color: var(--primary);
  color: white;
  padding: 4px 10px;
  border-radius: 20px;
  font-size: 0.8rem;
  font-weight: 600;
  display: inline-block;
  margin-top: 0.4rem;
}

.about-details {
  margin-top: 1rem;
  padding-top: 1rem;
  border-top: 1px solid var(--border);
}
.about-details div {
  padding: 0.6rem 0;
  font-size: 0.95rem;
  border-bottom: 1px dashed var(--border);
  color: var(--text);
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.about-details div:last-child {
  border-bottom: none;
}
.about-details strong {
  color: var(--text);
  font-weight: 600;
  flex-shrink: 0;
  margin-right: 0.8rem;
}
.about-details span {
  text-align: right;
  flex-grow: 1;
  color: var(--primary);
  font-weight: 500;
}

.edit-form {
  margin-top: 1.5rem;
  padding-top: 1rem;
  border-top: 1px solid var(--border);
}
.edit-form label {
  display: block;
  margin-bottom: 0.8rem;
  font-weight: 500;
  color: var(--text);
  font-size: 0.95rem;
}
.profile-input {
  width: calc(100% - 16px);
  padding: 0.6rem 8px;
  border: 1px solid var(--border);
  border-radius: 6px;
  background-color: var(--bg);
  color: var(--text);
  font-size: 0.95rem;
  margin-top: 0.3rem;
  transition: border-color 0.2s ease, box-shadow 0.2s ease;
}
.profile-input:focus {
  border-color: var(--primary);
  outline: none;
  box-shadow: 0 0 0 2px rgba(var(--primary-rgb, 79, 70, 229), 0.25);
}
.actions-group.inline-actions {
  flex-direction: row;
  justify-content: flex-end;
  gap: 0.5rem;
  margin-top: 1.2rem;
}
.actions-group.inline-actions .action-btn {
  width: auto;
  flex-grow: 0;
  padding: 0.6rem 1.2rem;
}

.achievement-list {
  list-style: none;
  padding: 0;
  display: flex;
  flex-direction: column;
  gap: 0.6rem;
}
.achievement-list li {
  background: var(--bg);
  color: var(--text);
  padding: 0.7rem 1rem;
  border-radius: 8px;
  font-weight: 500;
  display: flex;
  align-items: center;
  gap: 0.7rem;
  border: 1px solid var(--border);
  box-shadow: 0 1px 5px rgba(0,0,0,0.02);
  transition: transform 0.15s ease, box-shadow 0.15s ease;
}
.achievement-list li:hover {
  transform: translateX(4px);
  box-shadow: 0 3px 10px rgba(0,0,0,0.06);
}
.badge-icon {
  font-size: 1.3rem;
  line-height: 1;
}

.actions-group {
  display: flex;
  flex-direction: column;
  gap: 0.8rem;
  margin-top: 1rem;
}
.action-btn {
  width: 100%;
  padding: 0.8rem;
  border: none;
  border-radius: 8px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.2s ease;
  text-align: center;
  box-shadow: 0 2px 8px rgba(0,0,0,0.05); 
}

.action-btn.primary-btn {
  background-color: var(--primary);
  color: white;
}

.action-btn.secondary-btn {
  background-color: var(--secondary);
  color: var(--text);
}

.action-btn.danger-btn {
  background-color: #ef4444;
  color: white;
}

.action-btn:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(0,0,0,0.1);
  opacity: 1;
}

.action-btn.primary-btn:hover {
  background-color: var(--primary);
}
.action-btn.secondary-btn:hover {
  background-color: var(--bg);
  color: var(--primary);
}
.action-btn.danger-btn:hover {
  background-color: #dc2626;
}

.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0,0,0,0.4);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
}

.modal-content {
  background: var(--card);
  padding: 1.5rem;
  border-radius: 10px;
  width: 90%;
  max-width: 380px; 
  box-shadow: 0 6px 18px rgba(0,0,0,0.15);
  color: var(--text);
}

.modal-content h3 {
  font-size: 1.2rem; 
  font-weight: 700;
  color: var(--primary);
  margin-bottom: 1rem;
  border-bottom: 1px solid var(--border);
  padding-bottom: 0.7rem;
}

.modal-content label {
  display: block;
  margin-bottom: 0.7rem;
  font-weight: 500;
  font-size: 0.9rem;
}

.modal-content input {
  width: calc(100% - 14px);
  padding: 0.6rem 7px;
  border-radius: 5px;
  border: 1px solid var(--border);
  background-color: var(--bg);
  color: var(--text);
  font-size: 0.9rem;
  margin-top: 0.3rem;
  transition: border-color 0.2s ease, box-shadow 0.2s ease;
}

.modal-content input:focus {
  border-color: var(--primary);
  outline: none;
  box-shadow: 0 0 0 2px rgba(var(--primary-rgb, 79, 70, 229), 0.2);
}

.modal-actions {
  display: flex;
  justify-content: flex-end;
  gap: 0.6rem;
  margin-top: 1.2rem;
}

.save-btn, .cancel-btn {
  padding: 0.6rem 1.2rem;
  border: none;
  border-radius: 6px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.2s ease;
  box-shadow: 0 1px 5px rgba(0,0,0,0.05);
}
.save-btn {
  background: var(--primary);
  color: white;
}
.cancel-btn {
  background: var(--secondary);
  color: var(--text);
}
.save-btn:hover { background-color: var(--primary); transform: translateY(-1px); box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
.cancel-btn:hover { background-color: var(--bg); color: var(--primary); transform: translateY(-1px); box-shadow: 0 2px 8px rgba(0,0,0,0.1); }

@media (max-width: 1024px) {
  .profile-grid {
    grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
    gap: 1.2rem;
  }
}

@media (max-width: 768px) {
  .profile-grid {
    grid-template-columns: 1fr;
    gap: 1rem;
  }
  .profile-banner {
    padding: 1.2rem;
    gap: 0.8rem;
  }
  .profile-avatar {
    width: 80px;
    height: 80px;
  }
  .profile-banner-info h2 {
    font-size: 1.6rem;
  }
  .profile-email {
    font-size: 0.85rem;
  }
  .profile-card {
    padding: 1rem;
  }
  h3 {
    font-size: 1.1rem;
    margin-bottom: 0.8rem;
    padding-bottom: 0.5rem;
  }
  .about-details div {
    font-size: 0.85rem;
    padding: 0.5rem 0;
  }
  .achievement-list li {
    padding: 0.6rem 0.8rem;
    font-size: 0.8rem;
  }
  .badge-icon {
    font-size: 1.2rem;
  }
  .skills-list {
    gap: 0.8rem;
  }
  .skill-item span {
    font-size: 0.85rem;
  }
  .progress-bar {
    height: 5px;
  }
  .action-btn {
    padding: 0.7rem;
    font-size: 0.85rem;
  }
  .modal-content {
    padding: 1rem;
  }
}

@media (max-width: 480px) {
  .profile-grid {
    gap: 0.8rem;
  }
  .profile-banner {
    padding: 1rem 0.6rem;
    gap: 0.6rem;
  }
  .profile-avatar {
    width: 70px;
    height: 70px;
  }
  .profile-banner-info h2 {
    font-size: 1.4rem;
  }
  .profile-email {
    font-size: 0.75rem;
  }
  .profile-card {
    padding: 0.8rem;
  }
  h3 {
    font-size: 0.95rem;
    margin-bottom: 0.6rem;
    padding-bottom: 0.3rem;
  }
  .about-details div {
    font-size: 0.75rem;
    padding: 0.4rem 0;
  }
  .achievement-list li {
    padding: 0.5rem 0.7rem;
    font-size: 0.75rem;
  }
  .badge-icon {
    font-size: 1rem;
  }
  .skills-list {
    gap: 0.6rem;
  }
  .skill-item span {
    font-size: 0.8rem;
  }
  .progress-bar {
    height: 4px;
  }
  .action-btn {
    padding: 0.5rem;
    font-size: 0.75rem;
  }
  .modal-content {
    padding: 0.8rem;
  }
  .modal-content h3 {
    font-size: 1rem;
  }
  .modal-content input {
    font-size: 0.75rem;
    padding: 0.5rem 5px;
  }
  .save-btn, .cancel-btn {
    padding: 0.6rem 1rem;
    font-size: 0.75rem;
  }
}
</style>