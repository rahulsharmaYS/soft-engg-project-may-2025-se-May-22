<template>
  <div class="container">
    <Header title="Assignments" subtitle="Create and manage assignments dynamically" />
    
    <div class="main-grid">
      <div class="card">
        <h3>{{ isEditing ? 'Edit Assignment' : 'New Assignment' }}</h3>
        <form @submit.prevent="saveAssignment">
          <div class="form-group"><label>Skill</label><input v-model="draft.skill" /></div>
          <div class="form-group"><label>Topic</label><input v-model="draft.topic" /></div>
          <div class="form-group">
            <label>Type</label>
            <select v-model="draft.type">
              <option disabled value="">Select type</option>
              <option value="objective">Objective</option>
              <option value="subjective">Subjective</option>
            </select>
          </div>
          <div v-if="draft.type" class="form-group">
            <label>Time Limit (HH:MM)</label>
            <input type="time" v-model="draft.timeLimit" />
          </div>
          <div class="form-group"><label>Description</label><textarea v-model="draft.description" /></div>
          <div class="form-group"><label>Due Date</label><input type="date" v-model="draft.dueDate" /></div>
          <button type="submit">{{ isEditing ? 'Update' : 'Assign' }}</button>
        </form>
      </div>

      <div class="card" v-if="draft.type">
        <h3>Manage Questions ({{ draft.type.toUpperCase() }})</h3>
        <form @submit.prevent="addOrUpdateQuestion">
          <div class="form-group"><label>Question</label><textarea v-model="qForm.text" /></div>

          <template v-if="draft.type === 'objective'">
            <div class="form-group" v-for="(opt, i) in qForm.options" :key="i">
              <label>Option {{ i + 1 }}</label>
              <input v-model="qForm.options[i]" />
            </div>
            <div class="form-group">
              <label>Correct Option</label>
              <select v-model="qForm.correctOption">
                <option disabled value="">Select correct</option>
                <option v-for="(opt, idx) in qForm.options" :value="idx" :key="idx">Option {{ idx + 1 }}</option>
              </select>
            </div>
          </template>

          <template v-else>
            <div class="form-group">
              <label>Word Limit</label>
              <input type="number" v-model="qForm.wordLimit" />
            </div>
          </template>

          <button type="submit">{{ isEditingQuestion ? 'Update' : 'Add' }} Question</button>
        </form>

        <ul class="question-list" v-if="draft.questions.length">
          <li v-for="(q, index) in draft.questions" :key="index">
            {{ index + 1 }}. {{ q.text }}
            <span v-if="draft.type === 'objective'">(Correct: Option {{ q.correctOption + 1 }})</span>
            <span v-else>(Limit: {{ q.wordLimit }} words)</span>
            <button class="small-btn" @click="editQuestion(index)">Edit</button>
            <button class="small-btn danger" @click="deleteQuestion(index)">Delete</button>
          </li>
        </ul>
      </div>
    </div>

    <div class="card">
      <h3>All Assignments</h3>

      <div class="filters">
        <input v-model="searchQuery" placeholder="Search by title or subject..." />
        <select v-model="filterType">
          <option value="">All Types</option>
          <option value="objective">Objective</option>
          <option value="subjective">Subjective</option>
        </select>
      </div>

      <div v-if="filteredAssignments.length === 0" class="empty">No matching assignments.</div>

      <div v-for="assignment in filteredAssignments" :key="assignment.id" class="assignment-entry">
        <div class="header-row">
          <strong>{{ assignment.title }}</strong>
          <span class="badge">{{ assignment.type }}</span>
          <span class="badge secondary">{{ assignment.subject }}</span>
          <button class="small-btn" @click="editAssignment(assignment)">Edit</button>
        </div>
        <p>{{ assignment.description }}</p>
        <div class="meta">
          Due: {{ formatDate(assignment.dueDate) }} | Time: {{ assignment.timeLimit }}
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue'
import Header from './Header.vue'

const assignments = ref([])

const draft = ref({
  id: null,
  title: '',
  subject: '',
  type: '',
  timeLimit: '',
  description: '',
  dueDate: '',
  questions: [],
})

const qForm = ref({
  text: '',
  options: ['', '', '', ''],
  correctOption: '',
  wordLimit: '',
})

const isEditing = ref(false)
const isEditingQuestion = ref(false)
let editingQIndex = -1

function saveAssignment() {
  if (!draft.value.title || !draft.value.subject || !draft.value.type || !draft.value.dueDate) {
    alert('Fill all required fields.')
    return
  }

  if (isEditing.value) {
    const i = assignments.value.findIndex(a => a.id === draft.value.id)
    if (i !== -1) assignments.value[i] = { ...draft.value }
    isEditing.value = false
  } else {
    draft.value.id = Date.now()
    assignments.value.unshift({ ...draft.value })
  }

  resetDraft()
}

function addOrUpdateQuestion() {
  const q = qForm.value
  if (!q.text) return alert('Question required.')

  if (draft.value.type === 'objective') {
    if (q.options.some(o => !o) || q.correctOption === '') return alert('Complete all options.')
  } else if (!q.wordLimit) return alert('Specify word limit.')

  if (isEditingQuestion.value) {
    draft.value.questions[editingQIndex] = { ...q }
    isEditingQuestion.value = false
  } else {
    draft.value.questions.push({ ...q })
  }

  resetQForm()
}

function editQuestion(index) {
  const q = draft.value.questions[index]
  qForm.value = JSON.parse(JSON.stringify(q))
  editingQIndex = index
  isEditingQuestion.value = true
}

function deleteQuestion(index) {
  draft.value.questions.splice(index, 1)
}

function editAssignment(assignment) {
  draft.value = JSON.parse(JSON.stringify(assignment))
  isEditing.value = true
}

function resetDraft() {
  draft.value = {
    id: null,
    title: '',
    subject: '',
    type: '',
    timeLimit: '',
    description: '',
    dueDate: '',
    questions: [],
  }
  resetQForm()
}

function resetQForm() {
  qForm.value = {
    text: '',
    options: ['', '', '', ''],
    correctOption: '',
    wordLimit: '',
  }
  editingQIndex = -1
  isEditingQuestion.value = false
}

function formatDate(date) {
  return new Date(date).toLocaleDateString()
}

// search & filter logic here
const searchQuery = ref('')
const filterType = ref('')

const filteredAssignments = computed(() =>
  assignments.value.filter(a =>
    (!filterType.value || a.type === filterType.value) &&
    (a.title.toLowerCase().includes(searchQuery.value.toLowerCase()) ||
     a.subject.toLowerCase().includes(searchQuery.value.toLowerCase()))
  )
)
</script>

<style scoped>
.container {
  font-family: 'Inter', 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
  background-color: var(--bg);
  color: var(--text);
  min-height: 100vh;
  padding-bottom: 4rem;
  transition: background-color 0.3s ease, color 0.3s ease;
}

.page-title {
  font-weight: 700;
  font-size: 1.8rem;
  margin-bottom: 1.2rem;
  color: var(--text);
}

.main-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); 
  gap: 1.5rem; 
  margin-bottom: 1.5rem; 
}

.card {
  background-color: var(--card);
  color: var(--text);
  padding: 1.5rem;
  border-radius: 12px;
  box-shadow: 0 4px 12px rgba(0,0,0,0.06);
  border: 1px solid var(--border);
  transition: background 0.3s, box-shadow 0.3s;
}

.card h3 {
  font-size: 1.25rem;
  font-weight: 700;
  margin-top: 0;
  margin-bottom: 1rem;
  color: var(--primary);
}

.form-group {
  margin-bottom: 1rem;
}
label {
  display: block;
  font-size: 0.9rem;
  margin-bottom: 0.4rem;
  color: var(--text);
}
input, textarea, select {
  width: 100%;
  max-width: 400px; 
  padding: 0.4rem 0.8rem;
  border-radius: 8px;
  border: 1px solid var(--border);
  font-size: 0.95rem;
  box-sizing: border-box;
  background-color: var(--bg);
  color: var(--text);
  transition: border-color 0.2s ease, box-shadow 0.2s ease;
}
input:focus, textarea:focus, select:focus {
  outline: none;
  border-color: var(--primary);
  box-shadow: 0 0 0 3px rgba(var(--primary-rgb, 79, 70, 229), 0.2);
}
textarea {
  resize: vertical;
  min-height: 50px;
}

button[type="submit"] {
  background: var(--primary);
  color: white;
  padding: 0.6rem 1.2rem;
  border-radius: 8px;
  border: none;
  font-weight: 600;
  cursor: pointer;
  margin-top: 1rem;
  transition: background 0.2s, transform 0.2s, box-shadow 0.2s;
  box-shadow: 0 3px 8px rgba(0,0,0,0.1);
}
button[type="submit"]:hover {
  background: var(--primary);
  transform: translateY(-2px);
  box-shadow: 0 5px 12px rgba(0,0,0,0.15);
}

.small-btn {
  background: var(--secondary);
  color: var(--text);
  font-size: 0.75rem;
  padding: 0.25rem 0.5rem;
  margin-left: 0.5rem;
  border-radius: 4px;
  cursor: pointer;
  border: none;
  transition: background 0.2s, color 0.2s;
}
.small-btn.danger {
  background: #ef4444;
  color: white;
}
.small-btn:hover {
  background: var(--bg);
  color: var(--primary);
}
.small-btn.danger:hover {
  background: #dc2626;
  color: white;
}

.header-row {
  display: flex;
  align-items: center;
  gap: 0.8rem;
  flex-wrap: wrap;
  margin-bottom: 0.5rem;
}
.header-row strong {
  font-size: 1.1rem;
  font-weight: 700;
  color: var(--text);
}
.badge {
  padding: 0.2rem 0.5rem;
  background: var(--secondary);
  color: var(--text);
  font-size: 0.7rem;
  border-radius: 4px;
  text-transform: uppercase;
  font-weight: 600;
}
.badge.secondary {
  background: var(--bg);
  color: var(--primary);
}
.meta {
  font-size: 0.8rem;
  color: var(--text);
  opacity: 0.7;
  margin-top: 0.4rem;
}
.empty {
  text-align: center;
  padding: 1rem;
  color: var(--text);
  opacity: 0.6;
}
.filters {
  display: flex;
  gap: 0.8rem;
  margin-bottom: 1rem;
  flex-wrap: wrap;
}
.filters input, .filters select {
  flex-grow: 1;
  min-width: 150px;
  padding: 0.5rem 0.8rem;
  border-radius: 8px;
  border: 1px solid var(--border);
  font-size: 0.95rem;
  box-sizing: border-box;
  background-color: var(--bg);
  color: var(--text);
}

.assignment-card {
  background-color: var(--card);
  border: 1px solid var(--border);
  border-radius: 10px;
  box-shadow: 0 3px 10px rgba(0, 0, 0, 0.05);
  display: flex;
  flex-direction: row;
  align-items: center;
  padding: 1rem;
  transition: box-shadow 0.2s ease, border-color 0.2s ease;
}

.assignment-card:hover {
  box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
  border-color: var(--primary);
}

.assignment-title {
  font-size: 1.1rem;
  font-weight: 700;
  color: var(--text);
}

.assignment-type {
  font-weight: 600;
  font-size: 0.85rem;
  color: var(--text);
  opacity: 0.7;
  margin: 0.2rem 0 0.6rem 0;
}

.assignment-info {
  font-size: 0.8rem;
  color: var(--text);
  opacity: 0.8;
  display: flex;
  gap: 0.8rem;
  flex-wrap: wrap;
}

.attempt-btn {
  background-color: var(--primary);
  border: none;
  color: white;
  font-weight: 600;
  padding: 0.6rem 1.1rem;
  border-radius: 8px;
  cursor: pointer;
  user-select: none;
  transition: background-color 0.2s ease, box-shadow 0.2s ease, transform 0.2s ease;
  box-shadow: 0 3px 8px rgba(0, 0, 0, 0.1);
}

.attempt-btn:hover:not(:disabled) {
  transform: translateY(-1px);
  box-shadow: 0 5px 12px rgba(0, 0, 0, 0.15);
}

.attempt-section {
  margin-top: 2rem;
  background-color: var(--card);
  border-radius: 12px;
  padding: 1.5rem 1.8rem;
  border: 1px solid var(--border);
  box-shadow: 0 4px 15px rgba(0, 0, 0, 0.08);
  color: var(--text);
}

.attempt-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 1rem;
  font-weight: 700;
  font-size: 1.2rem;
  color: var(--text);
}

.timer {
  background-color: var(--primary);
  color: white;
  font-weight: 700;
  padding: 0.2rem 0.6rem;
  border-radius: 8px;
  user-select: none;
  font-family: monospace;
  font-size: 0.85rem;
}

.questions-nav {
  display: flex;
  flex-wrap: wrap;
  gap: 0.4rem;
  margin-bottom: 0.8rem;
}

.questions-nav button {
  border: 1px solid var(--border);
  background-color: var(--bg);
  padding: 0.3rem 0.6rem;
  border-radius: 6px;
  font-weight: 600;
  cursor: pointer;
  color: var(--text);
  transition: background-color 0.2s ease, color 0.2s ease, border-color 0.2s ease;
  user-select: none;
}

.questions-nav button:hover,
.questions-nav button.active {
  background-color: var(--primary);
  color: white;
  border-color: var(--primary);
}

.question-display {
  background-color: var(--bg);
  padding: 1.2rem;
  border-radius: 10px;
  border: 1px solid var(--border);
  margin-bottom: 1.2rem;
  box-shadow: inset 0 0 5px rgba(0,0,0,0.04);
  color: var(--text);
}

.question-text {
  font-weight: 600;
  font-size: 1rem;
  margin-bottom: 0.8rem;
}

.options {
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
}

.option-label {
  gap: 0.4rem;
  font-size: 0.95rem;
  color: var(--text);
}

.option-label input[type='radio'] {
  background-color: var(--bg);
  border: 1px solid var(--border);
}

textarea {
  width: 100%;
  max-width: 400px;
  padding: 0.5rem 0.8rem;
  border-radius: 8px;
  border: 1px solid var(--border);
  font-size: 0.95rem;
  box-sizing: border-box;
  background-color: var(--bg);
  color: var(--text);
  resize: vertical;
  min-height: 50px;
  transition: border-color 0.2s ease, background-color 0.2s ease, color 0.2s ease;
}
textarea:focus {
  outline: none;
  border-color: var(--primary);
  box-shadow: 0 0 0 3px rgba(var(--primary-rgb, 79, 70, 229), 0.2);
}

.word-count {
  font-size: 0.75rem;
  color: var(--text);
  opacity: 0.7;
  margin-top: 0.4rem;
  font-weight: 500;
  text-align: right;
}

.attempt-actions {
  display: flex;
  gap: 0.6rem;
  flex-wrap: wrap;
  justify-content: flex-end;
  margin-top: 0.8rem;
}

.attempt-actions button {
  background-color: var(--primary);
  border: none;
  color: white;
  font-weight: 600;
  padding: 0.6rem 1.1rem;
  border-radius: 8px;
  cursor: pointer;
  transition: background-color 0.2s ease, box-shadow 0.2s ease, transform 0.2s ease;
  box-shadow: 0 3px 8px rgba(0, 0, 0, 0.08);
  user-select: none;
}

.attempt-actions button:hover:not(:disabled) {
  background-color: var(--primary);
  transform: translateY(-1px);
  box-shadow: 0 5px 12px rgba(0, 0, 0, 0.12);
}

.secondary-btn {
  box-shadow: 0 2px 6px rgba(0,0,0,0.04);
}

.secondary-btn:hover {
  background-color: var(--bg);
}

.submit-btn {
  box-shadow: 0 3px 8px rgba(239, 68, 68, 0.15);
}

.submit-btn:hover {
  box-shadow: 0 5px 12px rgba(220, 38, 38, 0.25);
}

.review-section {
  margin-top: 1.5rem;
  background-color: var(--card);
  border-radius: 12px;
  padding: 1.2rem 1.5rem;
  border: 1px solid var(--border);
  max-height: 280px;
  overflow-y: auto;
  color: var(--text);
  box-shadow: 0 3px 12px rgba(0,0,0,0.06);
}

.review-section h3 {
  margin-bottom: 0.8rem;
  font-size: 1.1rem;
}

.review-section li {
  margin-bottom: 0.6rem;
  line-height: 1.4;
  font-size: 0.9rem;
}

.review-section::-webkit-scrollbar {
  width: 6px;
}
.review-section::-webkit-scrollbar-thumb {
  background-color: var(--secondary);
  border-radius: 6px;
}
.review-section::-webkit-scrollbar-thumb:hover {
  background-color: var(--primary);
}

hr {
  margin: 1rem 0;
}

@media (max-width: 600px) {
  .container {
    padding: 0 0.8rem;
  }
  .page-title {
    font-size: 1.5rem;
    margin-bottom: 1rem;
  }
  .main-grid {
    gap: 1rem;
  }
  .card {
    padding: 1rem;
  }
  .card h3 {
    font-size: 1.1rem;
    margin-bottom: 0.8rem;
  }
  input, textarea, select {
    padding: 0.4rem 0.6rem;
    font-size: 0.9rem;
  }
  textarea {
    min-height: 50px;
  }
  button[type="submit"] {
    padding: 0.6rem 1.2rem;
    font-size: 0.9rem;
  }
  .assignment-card {
    padding: 0.8rem;
  }
  .attempt-btn {
    padding: 0.5rem 1rem;
    font-size: 0.9rem;
  }
  .attempt-section {
    padding: 1rem 1.2rem;
  }
  .attempt-header {
    font-size: 1.1rem;
    margin-bottom: 0.8rem;
  }
  .timer {
    padding: 0.2rem 0.5rem;
    font-size: 0.8rem;
  }
  .questions-nav button {
    padding: 0.25rem 0.5rem;
    font-size: 0.85rem;
  }
  .question-display {
    padding: 1rem;
  }
  .question-text {
    font-size: 0.95rem;
  }
  .attempt-actions button {
    padding: 0.5rem 1rem;
  }
  .review-section {
    padding: 1rem 1.2rem;
  }
  .review-section h3 {
    font-size: 1rem;
  }
  .review-section li {
    font-size: 0.85rem;
  }
}
</style>