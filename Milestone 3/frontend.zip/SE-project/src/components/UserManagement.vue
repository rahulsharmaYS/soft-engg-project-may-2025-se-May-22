<template>
  <div class="user-management">
    <main class="main">
      <Header title="User Management" subtitle="Manage users, view profiles, and control access" />

      <div class="controls">
        <input
          v-model="searchQuery"
          placeholder="Search by email or user ID"
          class="search-input"
        />
        <select v-model="roleFilter" class="filter-select">
          <option value="">All Roles</option>
          <option value="student">Student</option>
          <option value="teacher">Teacher</option>
        </select>
      </div>

      <table class="user-table">
        <thead>
          <tr>
            <th>Profile</th>
            <th>User ID</th>
            <th>Email</th>
            <th>Role</th>
            <th>Status</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="user in filteredUsers" :key="user.id">
            <td>
              <img
                :src="user.profilePic"
                class="profile-pic"
                @click="openProfile(user)"
                title="Click to view profile"
              />
            </td>
            <td>{{ user.id }}</td>
            <td>{{ user.email }}</td>
            <td>{{ user.role }}</td>
            <td>{{ user.banned ? 'Banned' : 'Active' }}</td>
            <td>
              <button @click="toggleBan(user)" class="action-btn">
                {{ user.banned ? 'Unban' : 'Ban' }}
              </button>
              <button @click="tempBan(user)" class="action-btn warning">Temp Ban</button>
            </td>
          </tr>
        </tbody>
      </table>

      <div v-if="selectedUser" class="modal-overlay" @click.self="closeModal">
        <div class="modal">
          <div class="modal-header">
            <h3>User Profile</h3>
            <button class="close-btn" @click="closeModal">✖</button>
          </div>
          <div class="modal-body">
            <img :src="selectedUser.profilePic" class="modal-pic" />
            <p><strong>ID:</strong> {{ selectedUser.id }}</p>
            <p><strong>Email:</strong> {{ selectedUser.email }}</p>
            <p><strong>Role:</strong> {{ selectedUser.role }}</p>
            <p><strong>Status:</strong> {{ selectedUser.banned ? 'Banned' : 'Active' }}</p>
            <p><strong>Joined:</strong> {{ selectedUser.joined }}</p>
            <p><strong>Last Activity:</strong> {{ selectedUser.activity }}</p>
          </div>
        </div>
      </div>
    </main>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue'
import Sidebar from '../components/Sidebar.vue'
import Header from '../components/Header.vue'

const adminNavLinks = [
  { name: 'Dashboard', icon: '📊' },
  { name: 'User Management', icon: '👥' },
  { name: 'Help Center', icon: '❓' },
  { name: 'Announcements', icon: '📢' },
  { logout: true, name: 'Logout', icon: '🚪' }
]

const searchQuery = ref('')
const roleFilter = ref('')
const selectedUser = ref(null)

const users = ref([
  {
    id: 'U001',
    email: 'alice@example.com',
    role: 'student',
    banned: false,
    profilePic: 'https://i.pravatar.cc/100?img=1',
    joined: '2024-01-15',
    activity: 'Active 2 hours ago'
  },
  {
    id: 'U002',
    email: 'bob@example.com',
    role: 'teacher',
    banned: false,
    profilePic: 'https://i.pravatar.cc/100?img=2',
    joined: '2023-10-10',
    activity: 'Active yesterday'
  },
  {
    id: 'U003',
    email: 'carla@example.com',
    role: 'student',
    banned: true,
    profilePic: 'https://i.pravatar.cc/100?img=3',
    joined: '2024-02-01',
    activity: 'Banned'
  }
])

const filteredUsers = computed(() =>
  users.value.filter(user => {
    const query = searchQuery.value.toLowerCase()
    const matchesQuery =
      user.email.toLowerCase().includes(query) || user.id.toLowerCase().includes(query)
    const matchesRole = roleFilter.value ? user.role === roleFilter.value : true
    return matchesQuery && matchesRole
  })
)

function toggleBan(user) {
  user.banned = !user.banned
}

function tempBan(user) {
  user.banned = true
  setTimeout(() => {
    user.banned = false
  }, 10000) // 10 seconds temp ban for demo
}

function openProfile(user) {
  selectedUser.value = user
}

function closeModal() {
  selectedUser.value = null
}
</script>

<style scoped>
.user-management {
  display: flex;
  background-color: var(--bg);
}
.main {
  flex: 1;
  padding: 2rem;
}
.controls {
  display: flex;
  gap: 1rem;
  margin-bottom: 1.5rem;
}
.search-input,
.filter-select {
  padding: 0.5rem;
  font-size: 1rem;
  width: 200px;
  background-color: var(--card);
  color: var(--text);
  border: 1px solid var(--border); 
}
.user-table {
  width: 100%;
  border-collapse: collapse;
  background: var(--card);
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.05);
}
.user-table th,
.user-table td {
  padding: 0.75rem;
  text-align: left;
  border-bottom: 1px solid var(--border); 
  color: var(--text);
}
.profile-pic {
  width: 40px;
  height: 40px;
  border-radius: 50%;
  cursor: pointer;
}
.action-btn {
  margin-right: 0.5rem;
  padding: 0.4rem 0.7rem;
  font-size: 0.85rem;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  background-color: var(--primary); 
  color: white; 
}
.action-btn.warning {
  background-color: var(--secondary);
  color: var(--text); 
}

.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.5);
  z-index: 1000;
  display: flex;
  align-items: center;
  justify-content: center;
}
.modal {
  background: var(--card);
  padding: 2rem;
  border-radius: 8px;
  width: 90%;
  max-width: 400px;
  animation: fadeIn 0.3s ease;
  box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
  color: var(--text); 
}
.modal-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 1rem;
}
.close-btn {
  background: transparent;
  border: none;
  font-size: 1.2rem;
  cursor: pointer;
  color: var(--text); 
}
.modal-body {
  text-align: center;
}
.modal-pic {
  width: 80px;
  height: 80px;
  border-radius: 50%;
  margin-bottom: 1rem;
}
@keyframes fadeIn {
  from {
    opacity: 0;
    transform: scale(0.96);
  }
  to {
    opacity: 1;
    transform: scale(1);
  }
}
</style>