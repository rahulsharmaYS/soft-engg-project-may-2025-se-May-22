<template>
  <div :class="['student-assignments-page', { dark: store.darkMode }]">
    <Header />

    <section class="assignments-overview container">
      <h1 class="page-title">Assignments Overview</h1>

      <div class="assignments-grid">
        <div
          v-for="assignment in assignments"
          :key="assignment.id"
          class="assignment-card"
        >
          <div
            class="type-segment"
            :class="assignment.type.toLowerCase()"
            aria-label="Assignment type"
          ></div>

          <div class="assignment-content">
            <h2 class="assignment-title">{{ assignment.title }}</h2>
            <div class="assignment-type">{{ assignment.type }}</div>
            <div class="assignment-info">
              <div><strong>Due:</strong> {{ formatDate(assignment.dueDate) }}</div>
              <div><strong>Time Limit:</strong> {{ assignment.timeLimit }}</div>
            </div>
          </div>

          <button
            class="attempt-btn"
            @click="attemptAssignment(assignment.id)"
            :disabled="activeAssignment && activeAssignment.id === assignment.id"
          >
            {{ activeAssignment && activeAssignment.id === assignment.id
              ? 'Attempting...'
              : 'Attempt Paper' }}
          </button>
        </div>
      </div>
    </section>

    <section v-if="activeAssignment" class="attempt-section container">
      <div class="attempt-header">
        <h2>Attempting: {{ activeAssignment.title }}</h2>
        <div class="timer">⏳ {{ formattedTimeLeft }}</div>
      </div>

      <nav class="questions-nav">
        <button
          v-for="(q, i) in questions"
          :key="q.id"
          :class="{ active: currentQuestionIndex === i }"
          @mouseenter="hoveredQuestion = i"
          @mouseleave="hoveredQuestion = null"
          @click="goToQuestion(i)"
          :title="'Go to question ' + (i + 1)"
        >
          Q{{ i + 1 }}
        </button>
      </nav>

      <div class="question-display">
        <h3>Question {{ currentQuestionIndex + 1 }}</h3>
        <p class="question-text">{{ currentQuestion.question }}</p>

        <template v-if="activeAssignment.type === 'Objective'">
          <div class="options">
            <label
              v-for="(option, idx) in currentQuestion.options"
              :key="idx"
              class="option-label"
            >
              <input
                type="radio"
                :name="'q_' + currentQuestion.id"
                :value="option"
                v-model="answers[currentQuestion.id]"
              />
              {{ option }}
            </label>
          </div>
        </template>

        <template v-else>
          <textarea
            v-model="answers[currentQuestion.id]"
            :maxlength="currentQuestion.wordLimit * 6"
            placeholder="Type your answer here..."
            @input="limitWordCount(currentQuestion.id)"
            rows="6"
          ></textarea>
          <div class="word-count">
            {{ wordCount(answers[currentQuestion.id]) }} / {{ currentQuestion.wordLimit }} words
          </div>
        </template>
      </div>

      <div class="attempt-actions">
        <button @click="prevQuestion" :disabled="currentQuestionIndex === 0">
          ← Previous
        </button>
        <button
          @click="nextQuestion"
          :disabled="currentQuestionIndex === questions.length - 1"
        >
          Next →
        </button>
        <button @click="saveAnswer" class="secondary-btn">Save Answer</button>
        <button @click="reviewAnswers" class="secondary-btn">Review Answers</button>
        <button class="submit-btn" @click="submitAssignment">Submit</button>
      </div>

      <div v-if="isReviewing" class="review-section">
        <h3>Review Your Answers</h3>
        <ul>
          <li v-for="(q, i) in questions" :key="'review-' + q.id">
            <strong>Q{{ i + 1 }}:</strong> {{ q.question }}<br />
            <em>Your answer:</em>
            <span v-if="answers[q.id]">{{ answers[q.id] }}</span>
            <span v-else class="no-answer">No answer provided</span>
          </li>
        </ul>
        <button @click="isReviewing = false" class="secondary-btn">Close Review</button>
      </div>
    </section>
  </div>
</template>

<script setup>
import Header from './Header.vue'
import { ref, computed, onUnmounted } from 'vue'
import { store } from '../store.js'

const assignments = ref([
  {
    id: 1,
    title: 'Math Quiz 1',
    type: 'Objective',
    dueDate: '2025-06-30',
    timeLimit: '00:15',
  },
  {
    id: 2,
    title: 'English Essay',
    type: 'Subjective',
    dueDate: '2025-07-05',
    timeLimit: '01:00',
  },
])

const questionBank = {
  1: [
    {
      id: 'q1',
      question: 'What is 2 + 2?',
      options: ['3', '4', '5', '6'],
      wordLimit: null,
    },
    {
      id: 'q2',
      question: 'Which number is prime?',
      options: ['4', '6', '7', '9'],
      wordLimit: null,
    },
  ],
  2: [
    {
      id: 'q1',
      question: 'Write an essay on the importance of reading books.',
      options: null,
      wordLimit: 150,
    },
    {
      id: 'q2',
      question: 'Describe your favorite childhood memory.',
      options: null,
      wordLimit: 100,
    },
  ],
}

const activeAssignment = ref(null)
const questions = ref([])
const currentQuestionIndex = ref(0)
const hoveredQuestion = ref(null)
const answers = ref({})
const isReviewing = ref(false)

const timerSeconds = ref(0)
let timerInterval = null

function attemptAssignment(id) {
  activeAssignment.value = assignments.value.find((a) => a.id === id)
  questions.value = questionBank[id] || []
  currentQuestionIndex.value = 0
  isReviewing.value = false
  answers.value = {}

  const [h, m] = activeAssignment.value.timeLimit.split(':').map(Number)
  timerSeconds.value = h * 3600 + m * 60

  if (timerInterval) clearInterval(timerInterval)
  timerInterval = setInterval(() => {
    if (timerSeconds.value > 0) {
      timerSeconds.value--
    } else {
      clearInterval(timerInterval)
      alert('Time is up! Submitting your assignment.')
      submitAssignment()
    }
  }, 1000)
}

function formatDate(dateStr) {
  if (!dateStr) return 'N/A'
  return new Date(dateStr).toLocaleDateString()
}

const formattedTimeLeft = computed(() => {
  const min = Math.floor(timerSeconds.value / 60)
  const sec = timerSeconds.value % 60
  return `${min.toString().padStart(2, '0')}:${sec.toString().padStart(2, '0')}`
})

function goToQuestion(index) {
  currentQuestionIndex.value = index
}

function nextQuestion() {
  if (currentQuestionIndex.value < questions.value.length - 1)
    currentQuestionIndex.value++
}

function prevQuestion() {
  if (currentQuestionIndex.value > 0) currentQuestionIndex.value--
}

function saveAnswer() {
  alert('Answer saved!')
}

function reviewAnswers() {
  isReviewing.value = true
}

function submitAssignment() {
  clearInterval(timerInterval)
  alert('Assignment submitted! Good luck.')
  activeAssignment.value = null
  questions.value = []
  answers.value = {}
  currentQuestionIndex.value = 0
  isReviewing.value = false
}

function wordCount(text) {
  if (!text) return 0
  return text.trim().split(/\s+/).length
}

function limitWordCount(qId) {
  const text = answers.value[qId] || ''
  const limit = questions.value.find((q) => q.id === qId)?.wordLimit || 0
  if (wordCount(text) > limit) {
    answers.value[qId] = text.trim().split(/\s+/).slice(0, limit).join(' ')
  }
}

onUnmounted(() => {
  if (timerInterval) clearInterval(timerInterval)
})

const currentQuestion = computed(() => questions.value[currentQuestionIndex.value] || {})

</script>

<style scoped>
:root {
  --bg: #f9fafb;
  --text-primary: #111827;
  --text-secondary: #374151;
  --primary: #4f46e5;
  --primary-hover: #4338ca;
  --objective-color: #3b82f6;
  --subjective-color: #10b981;
  --btn-bg: var(--primary);
  --btn-hover: var(--primary-hover);
  --border: #e5e7eb;
  --card-bg: #fff;
  --shadow: rgba(0, 0, 0, 0.05);
  --secondary-btn-bg: #6b7280;
  --secondary-btn-hover: #4b5563;
  --danger: #ef4444;
  --danger-hover: #dc2626;
  --input-bg: #fff;
  --input-border: #d1d5db;
  --input-text: var(--text-primary);
  --mode-toggle-bg: #4f46e5;
  --mode-toggle-hover: #4338ca;
  --scrollbar-thumb: #cbd5e1;
  --scrollbar-thumb-hover: #a1aebf;
}

.dark {
  --bg: #111827;
  --text-primary: #f3f4f6;
  --text-secondary: #d1d5db;
  --primary: #818cf8;
  --primary-hover: #6366f1;
  --objective-color: #60a5fa;
  --subjective-color: #34d399;
  --btn-bg: var(--primary);
  --btn-hover: var(--primary-hover);
  --border: #374151;
  --card-bg: #1f2937;
  --shadow: rgba(0, 0, 0, 0.3);
  --secondary-btn-bg: #6b7280;
  --secondary-btn-hover: #4b5563;
  --danger: #f87171;
  --danger-hover: #ef4444;
  --input-bg: #374151;
  --input-border: #4b5563;
  --input-text: var(--text-primary);
  --mode-toggle-bg: #818cf8;
  --mode-toggle-hover: #6366f1;
  --scrollbar-thumb: #4b5563;
  --scrollbar-thumb-hover: #6b7280;
}

.student-assignments-page {
  font-family: 'Inter', 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
  background-color: var(--bg);
  color: var(--text-primary);
  min-height: 100vh;
  padding-bottom: 4rem;
  transition: background-color 0.3s ease, color 0.3s ease;
}

.container {
  max-width: 900px;
  margin: 2rem auto;
  padding: 0 1rem;
}

.page-title {
  font-weight: 800;
  font-size: 2rem;
  margin-bottom: 1.5rem;
  color: var(--text-primary);
}

.mode-toggle-container {
  display: flex;
  justify-content: flex-end;
  margin: 1rem 2rem 0 0;
}

.mode-toggle-btn {
  background-color: var(--mode-toggle-bg);
  border: none;
  padding: 0.5rem 1rem;
  border-radius: 12px;
  color: white;
  font-weight: 600;
  cursor: pointer;
  transition: background-color 0.3s ease;
  user-select: none;
}

.mode-toggle-btn:hover {
  background-color: var(--mode-toggle-hover);
}

.assignments-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
  gap: 1.4rem;
}

.assignment-card {
  background-color: var(--card-bg);
  border: 1px solid var(--border);
  border-radius: 12px;
  box-shadow: 0 4px 10px var(--shadow);
  display: flex;
  flex-direction: row;
  align-items: center;
  padding: 1rem;
  transition: box-shadow 0.3s ease, border-color 0.3s ease;
}

.assignment-card:hover {
  box-shadow: 0 6px 18px var(--shadow);
  border-color: var(--primary);
}

.type-segment {
  width: 8px;
  height: 100%;
  border-radius: 8px 0 0 8px;
  margin-right: 1rem;
}

.type-segment.objective {
  background-color: var(--objective-color);
}

.type-segment.subjective {
  background-color: var(--subjective-color);
}

.assignment-content {
  flex-grow: 1;
}

.assignment-title {
  margin: 0;
  font-weight: 700;
  font-size: 1.2rem;
  color: var(--text-primary);
}

.assignment-type {
  font-weight: 600;
  font-size: 0.9rem;
  color: var(--text-secondary);
  margin: 0.2rem 0 0.8rem 0;
}

.assignment-info {
  font-size: 0.85rem;
  color: var(--text-secondary);
  display: flex;
  gap: 1.4rem;
  flex-wrap: wrap;
}

.attempt-btn {
  background-color: var(--btn-bg);
  border: none;
  font-weight: 700;
  padding: 0.65rem 1.2rem;
  border-radius: 12px;
  cursor: pointer;
  user-select: none;
  transition: background-color 0.3s ease, box-shadow 0.3s ease;
  box-shadow: 0 5px 12px rgb(79 70 229 / 0.5);
}

.attempt-btn:hover:not(:disabled) {
  background-color: var(--btn-hover);
  box-shadow: 0 7px 18px rgb(67 56 202 / 0.7);
}

.attempt-btn:disabled {
  opacity: 0.5;
  cursor: not-allowed;
  box-shadow: none;
}

.attempt-section {
  margin-top: 3rem;
  background-color: var(--card-bg);
  border-radius: 16px;
  padding: 1.6rem 2rem;
  border: 1px solid var(--border);
  box-shadow: 0 5px 20px var(--shadow);
  color: var(--text-primary);
}

.attempt-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 1.6rem;
  font-weight: 700;
  font-size: 1.4rem;
}

.timer {
  background-color: var(--objective-color);
  font-weight: 700;
  padding: 0.3rem 0.9rem;
  border-radius: 10px;
  user-select: none;
  font-family: monospace;
}

.questions-nav {
  display: flex;
  flex-wrap: wrap;
  gap: 0.6rem;
  margin-bottom: 1.2rem;
}

.questions-nav button {
  border: 1px solid var(--border);
  background-color: transparent;
  padding: 0.5rem 0.8rem;
  border-radius: 8px;
  font-weight: 600;
  cursor: pointer;
  color: var(--text-primary);
  transition: background-color 0.3s ease, color 0.3s ease;
  user-select: none;
}

.questions-nav button:hover,
.questions-nav button.active {
  background-color: var(--btn-bg);
  border-color: var(--btn-bg);
}

.question-display {
  background-color: var(--bg);
  padding: 1.4rem 1.6rem;
  border-radius: 12px;
  border: 1px solid var(--border);
  margin-bottom: 1.6rem;
  box-shadow: inset 0 0 8px var(--shadow);
  color: var(--text-primary);
}

.question-text {
  font-weight: 600;
  font-size: 1.1rem;
  margin-bottom: 1.2rem;
}

.options {
  display: flex;
  flex-direction: column;
  gap: 0.75rem;
}

.option-label {
  cursor: pointer;
  font-weight: 500;
  user-select: none;
  display: flex;
  align-items: center;
  gap: 0.6rem;
  color: var(--text-primary);
}

.option-label input[type='radio'] {
  cursor: pointer;
}

textarea {
  width: 100%;
  resize: vertical;
  padding: 0.7rem 1rem;
  border: 1px solid var(--input-border);
  border-radius: 12px;
  font-size: 1rem;
  font-family: inherit;
  color: var(--input-text);
  font-weight: 400;
  background-color: var(--input-bg);
  min-height: 130px;
  transition: border-color 0.3s ease, background-color 0.3s ease, color 0.3s ease;
}

textarea:focus {
  outline: none;
  border-color: var(--primary);
  box-shadow: 0 0 6px var(--primary);
}

.word-count {
  font-size: 0.85rem;
  color: var(--text-secondary);
  margin-top: 0.5rem;
  font-weight: 600;
  text-align: right;
}

.attempt-actions {
  display: flex;
  gap: 1rem;
  flex-wrap: wrap;
  justify-content: flex-end;
  margin-top: 0.8rem;
}

.attempt-actions button {
  background-color: var(--btn-bg);
  border: none;
  font-weight: 700;
  padding: 0.7rem 1.4rem;
  border-radius: 14px;
  cursor: pointer;
  transition: background-color 0.3s ease, box-shadow 0.3s ease;
  box-shadow: 0 6px 16px rgb(79 70 229 / 0.45);
  user-select: none;
}

.attempt-actions button:hover:not(:disabled) {
  background-color: var(--btn-hover);
  box-shadow: 0 8px 26px rgb(67 56 202 / 0.7);
}

.attempt-actions button:disabled {
  opacity: 0.5;
  cursor: not-allowed;
  box-shadow: none;
}

.secondary-btn {
  background-color: var(--secondary-btn-bg);
  box-shadow: none;
  color: var(--text-primary);
}

.secondary-btn:hover {
  background-color: var(--secondary-btn-hover);
}

.submit-btn {
  background-color: var(--danger);
  box-shadow: 0 6px 14px rgb(239 68 68 / 0.5);
}

.submit-btn:hover {
  background-color: var(--danger-hover);
  box-shadow: 0 8px 26px rgb(220 38 38 / 0.7);
}

.review-section {
  margin-top: 2rem;
  background-color: var(--card-bg);
  border-radius: 16px;
  padding: 1.8rem 2.2rem;
  border: 1px solid var(--border);
  max-height: 320px;
  overflow-y: auto;
  color: var(--text-primary);
  box-shadow: 0 4px 16px var(--shadow);
}

.review-section h3 {
  margin-bottom: 1.2rem;
  font-weight: 700;
  font-size: 1.3rem;
}

.review-section ul {
  list-style-type: none;
  padding: 0;
  margin: 0;
}

.review-section li {
  margin-bottom: 1.4rem;
  line-height: 1.5;
  font-weight: 500;
  color: var(--text-secondary);
}

.no-answer {
  font-style: italic;
  color: var(--danger);
}

.review-section::-webkit-scrollbar {
  width: 8px;
}
.review-section::-webkit-scrollbar-thumb {
  background-color: var(--scrollbar-thumb);
  border-radius: 8px;
}
.review-section::-webkit-scrollbar-thumb:hover {
  background-color: var(--scrollbar-thumb-hover);
}

@media (max-width: 600px) {
  .assignments-grid {
    grid-template-columns: 1fr;
  }

  .attempt-header {
    flex-direction: column;
    align-items: flex-start;
    gap: 0.8rem;
  }

  .attempt-actions {
    justify-content: center;
  }
}
</style>
