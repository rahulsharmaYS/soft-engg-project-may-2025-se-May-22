<template>
  <div>
    <Header title="My Students" subtitle="Manage your students and view their progress." />
    <div class="table-container">
      <table>
        <thead>
          <tr>
            <th>Student Name</th>
            <th>ID</th>
            <th>Status</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="student in students" :key="student.id">
            <td>
              <div class="student-info">
                <img :src="student.avatar" alt="Avatar" class="avatar" />
                <span>{{ student.name }}</span>
              </div>
            </td>
            <td>{{ student.id }}</td>
            <td><span :class="['status-pill', getStatusClass(student.status)]">{{ student.status }}</span></td>
            <td class="actions">
              <button @click="viewStudent(student.id)" class="action-btn view">View</button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import { useRouter } from 'vue-router';
import Header from './Header.vue';

const router = useRouter();
const students = ref([
  { id: '#1001', name: 'Rahul Sharma', avatar: 'https://i.pravatar.cc/40?img=1', status: 'Active' },
  { id: '#1002', name: 'Arya Chavan', avatar: 'https://i.pravatar.cc/40?img=2', status: 'Active' },
  { id: '#1003', name: 'Aarush Saxena', avatar: 'https://i.pravatar.cc/40?img=3', status: 'Inactive' },
  { id: '#1004', name: 'Gopu Vishal Reddy', avatar: 'https://i.pravatar.cc/40?img=4', status: 'Blocked' },
]);
const viewStudent = (studentId) => {
  router.push(`/instructor/student/${studentId.replace('#', '')}`);
};
const getStatusClass = (status) => {
  if (status === 'Active') return 'status-active';
  if (status === 'Inactive') return 'status-inactive';
  return 'status-blocked';
};
</script>

<style scoped>
.table-container { background-color: var(--card); border-radius: 12px; padding: 1rem; margin-top: 2rem; }
table { width: 100%; border-collapse: collapse; color: var(--text); }
th, td { padding: 1rem; text-align: left; border-bottom: 1px solid var(--border); }
.student-info { display: flex; align-items: center; gap: 1rem; }
.avatar { width: 40px; height: 40px; border-radius: 50%; }
.status-pill { padding: 4px 12px; border-radius: 20px; font-weight: 500; }
.status-active { background-color: #dcfce7; color: #166534; }
.status-inactive { background-color: #fee2e2; color: #991b1b; }
.status-blocked { background-color: #e5e7eb; color: #374151; }
.actions { display: flex; gap: 0.5rem; }
.action-btn { padding: 6px 12px; border: 1px solid var(--border); border-radius: 6px; cursor: pointer; }
</style>