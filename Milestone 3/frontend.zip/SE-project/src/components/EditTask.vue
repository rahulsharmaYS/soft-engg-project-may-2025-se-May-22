<template>
  <div>
    <h2>Edit Task</h2>
    <p>This is a placeholder for the EditTask component.</p>
  </div>
</template>

<script setup>
// will add logic to fetch task by ID and update it laterrrrr
</script>

<style scoped>
h2 {
  color: #2c3e50;
}
</style>
