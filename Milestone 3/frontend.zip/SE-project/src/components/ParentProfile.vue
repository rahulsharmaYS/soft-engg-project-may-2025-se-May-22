<template>
  <div>
    <Header title="Parent Profile" subtitle="Your central hub for account and child information." />

    <div class="profile-content-grid">
      <div class="main-column">
        <div class="profile-card">
          <h3>Your Information</h3>
          <div class="parent-info">
            <img :src="parent.avatar" alt="Parent Avatar" class="profile-avatar">
            <div class="info-text">
              <h4>{{ parent.name }}</h4>
              <p>{{ parent.email }}</p>
            </div>
          </div>
        </div>

        <div class="profile-card">
          <h3>Account Actions</h3>
          <div class="actions-group">
            <button class="action-btn">
              <span class="icon">✏️</span>
              <span>Edit Profile</span>
            </button>
            
            <button @click="logout" class="action-btn logout-btn">
              <span class="icon">🚪</span>
              <span>Logout</span>
            </button>
          </div>
        </div>
      </div>

      <div class="side-column">
        <div class="profile-card">
          <h3>Child's Details</h3>
          <div class="child-info">
            <img :src="parent.child.avatar" alt="Child Avatar" class="profile-avatar-small">
            <div class="info-text">
              <h4>{{ parent.child.name }}</h4>
              <p>Grade: {{ parent.child.grade }}</p>
            </div>
          </div>
        </div>
        
        </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import { useRouter } from 'vue-router';
import Header from './Header.vue';

const router = useRouter();

const parent = ref({
  name: 'Anjali Sharma',
  email: 'anjali.sharma@example.com',
  avatar: 'https://avatar.iran.liara.run/public/job/mother/female',
  child: {
    name: 'Nikhil',
    grade: '8th Grade',
    avatar: 'https://avatar.iran.liara.run/public/boy?username=Nikhil'
  },
});

const logout = () => {
  router.push('/login');
};
</script>

<style scoped>
.profile-content-grid {
  margin-top: 2rem;
  display: flex;
  flex-wrap: wrap;
  gap: 2rem;
  align-items: flex-start;
}

.main-column {
  flex: 2;
  min-width: 350px;
  display: flex;
  flex-direction: column;
  gap: 2rem;
}

.side-column {
  flex: 1;
  min-width: 300px;
}

.profile-card {
  background-color: var(--card);
  padding: 1.5rem 2rem;
  border-radius: 12px;
  box-shadow: 0 4px 12px rgba(0,0,0,0.05);
  border: 1px solid var(--border);
}

h3 {
  margin-top: 0;
  margin-bottom: 1.5rem;
  font-weight: 600;
}

.parent-info, .child-info {
  display: flex;
  align-items: center;
  gap: 1.5rem;
}

.profile-avatar {
  width: 70px;
  height: 70px;
  border-radius: 50%;
}

.profile-avatar-small {
  width: 50px;
  height: 50px;
  border-radius: 50%;
}

.info-text h4 {
  margin: 0;
  font-weight: 600;
}

.info-text p {
  margin: 0.25rem 0 0;
  color: #888;
}

.actions-group {
  display: grid;
  grid-template-columns: 1fr;
  gap: 1rem;
}

.action-btn {
  display: flex;
  align-items: center;
  gap: 0.75rem;
  width: 100%;
  padding: 0.8rem 1rem;
  border: 1px solid var(--border);
  border-radius: 8px;
  font-weight: 600;
  font-size: 1rem;
  cursor: pointer;
  transition: all 0.2s;
  background-color: var(--bg);
  color: var(--text);
}
.action-btn .icon {
  font-size: 1.2rem;
}
.action-btn.logout-btn { border-color: #ef4444; color: #ef4444; }
.action-btn:hover { border-color: var(--primary); color: var(--primary); }
.action-btn.logout-btn:hover { background-color: #ef4444; color: white; }
</style>