<template>
  <div class="chart-container" ref="chartContainer">
    <h3>User Growth (Last 8 Weeks)</h3>
    <canvas id="userGrowthChart"></canvas>
  </div>
</template>

<script setup>
import { onMounted, watch, nextTick, ref } from 'vue';
import Chart from 'chart.js/auto';
import { store } from '../store.js';

let userGrowthChart = null;
const chartContainer = ref(null);

const createChart = () => {
  if (userGrowthChart) userGrowthChart.destroy();
  if (!chartContainer.value) return;

  const textColor = getComputedStyle(chartContainer.value).getPropertyValue('--text').trim();
  userGrowthChart = new Chart(document.getElementById('userGrowthChart'), {
    type: 'line',
    data: {
      labels: ['Week 1', 'Week 2', 'Week 3', 'Week 4', 'Week 5', 'Week 6', 'Week 7', 'Week 8'],
      datasets: [
        { label: 'New Students', data: [15, 25, 40, 30, 50, 75, 60, 90], borderColor: '#3b82f6', tension: 0.4, fill: true, backgroundColor: 'rgba(59, 130, 246, 0.1)' },
        { label: 'New Instructors', data: [2, 5, 3, 6, 8, 5, 7, 10], borderColor: '#84cc16', tension: 0.4, fill: true, backgroundColor: 'rgba(132, 204, 22, 0.1)' }
      ]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { labels: { color: textColor } } },
        scales: {
            x: { ticks: { color: textColor }, grid: { color: store.darkMode ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.1)' } },
            y: { ticks: { color: textColor }, grid: { color: store.darkMode ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.1)' } }
        }
    }
  });
};

onMounted(async () => {
  await nextTick();
  createChart();
});
watch(() => store.darkMode, async () => {
  await nextTick();
  createChart();
});
</script>

<style scoped>
.chart-container {
  background: var(--card);
  padding: 1rem;
  border-radius: var(--card-radius);
  box-shadow: var(--shadow);
  width: 100%;
  height: 400px;
}
.chart-container canvas {
  width: 100% !important;
  height: 85% !important;
}
</style>