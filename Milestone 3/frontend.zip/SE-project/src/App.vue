<template>
  <div :class="['app', $store.darkMode ? 'dark' : 'light']">
    <router-view />
  </div>
</template>

<script setup>
import { store as $store } from './store.js'
</script>

<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap');
body {
  margin: 0;
  font-family: 'Inter', sans-serif;
}
</style>
