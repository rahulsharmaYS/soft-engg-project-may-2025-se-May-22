import { defineStore } from 'pinia'
import { ref, computed } from 'vue'

export const useFocusStore = defineStore('focus', () => {
  const isFocusActive = ref(false)
  const remainingSeconds = ref(0)
  let focusTimer = null

  function startFocusMode(minutes) {
    if (minutes < 1) return alert('Enter valid focus time')

    isFocusActive.value = true
    remainingSeconds.value = minutes * 60

    document.addEventListener('visibilitychange', blockTabSwitching)

    focusTimer = setInterval(() => {
      remainingSeconds.value--
      if (remainingSeconds.value <= 0) {
        cancelFocusMode()
        alert('Focus session complete! 🎉')
      }
    }, 1000)
  }

  function cancelFocusMode() {
    isFocusActive.value = false
    clearInterval(focusTimer)
    document.removeEventListener('visibilitychange', blockTabSwitching)
  }

  function blockTabSwitching() {
    if (document.hidden && isFocusActive.value) {
      alert('⚠️ Stay focused! Don’t switch tabs during Focus Mode.')
      document.title = 'Return to Focus Mode!'
    } else {
      document.title = 'Student Dashboard'
    }
  }

  const formattedTime = computed(() => {
    const mins = String(Math.floor(remainingSeconds.value / 60)).padStart(2, '0')
    const secs = String(remainingSeconds.value % 60).padStart(2, '0')
    return `${mins}:${secs}`
  })

  return {
    isFocusActive,
    remainingSeconds,
    formattedTime,
    startFocusMode,
    cancelFocusMode,
  }
})



// task_management related code for students
