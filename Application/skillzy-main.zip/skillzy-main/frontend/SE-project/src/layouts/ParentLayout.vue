<template>
  <div class="page-container">
    <Sidebar :navLinks="parentNavLinks" />
    <main class="main-content">
      <router-view v-if="parentId" :key="$route.fullPath" />
    </main>
  </div>
</template>

<script setup>
import { useRouter, useRoute } from 'vue-router';
import Sidebar from '../components/Sidebar.vue';
import { computed } from 'vue'; 

const router = useRouter();
const route = useRoute();
const parentId = computed(() => route.params.parentId);

const parentNavLinks = [
  { name: 'Dashboard', icon: '🏠', onClick: () => router.push(`/parent/${parentId.value}/dashboard`) },
//   { name: 'My Child', icon: '🧒', onClick: () => {} },
  { name: 'Messages', icon: '✉️', onClick: () => router.push(`/parent/${parentId.value}/messages`) },
  { name: 'Comms Center', icon: '📬', onClick: () => router.push(`/parent/${parentId.value}/comms`) },
  // REMOVED LINE 24 
  // { name: 'AI Assistance', icon: '🤖', onClick: () => router.push(`/parent/${parentId.value}/ai-assistance`) },
  { name: 'Health', icon: '💊', onClick: () => router.push(`/parent/${parentId.value}/health`) },
  { name: 'Profile', icon: '👤', onClick: () => router.push(`/parent/${parentId.value}/profile`) },
];
</script>

<style scoped>
.page-container {
  display: flex;
  height: 100vh;
}
.main-content {
  flex: 1;
  padding: 2rem;
  background: var(--bg);
  color: var(--text);
  overflow-y: auto;
}
</style>