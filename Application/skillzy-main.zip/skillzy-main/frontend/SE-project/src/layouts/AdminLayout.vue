<template>
  <div class="layout-container">
    <div class="sidebar-container">
      <Sidebar :navLinks="adminNavLinks">
        <template #header>
          <div class="admin-subtitle">
            Admin Portal <span class="cap"></span>
          </div>
        </template>
      </Sidebar>
    </div>
    <main class="content-area">
      <router-view />
    </main>
  </div>
</template>

<script setup>
import { useRouter } from 'vue-router';
import Sidebar from '../components/Sidebar.vue';

const router = useRouter();

const adminNavLinks = [
  // { name: 'Dashboard', icon: '🏠', onClick: () => router.push('/admin/dashboard') },
  { name: 'User Management', icon: '👥', onClick: () => router.push('/admin/usermanagement') },
  { name: 'Help Center', icon: '❓', onClick: () => router.push('/admin/helpcenter') },
  { name: 'Announcements', icon: '📢', onClick: () => router.push('/admin/announcements') },
];
</script>


<style scoped>
.layout-container {
  display: flex;
  height: 100vh;
  background: #1A1A1A; /* Dark neutral background as a fallback */
}

.sidebar-container {
  background: var(--sidebar-bg, #fff);
  box-shadow: 2px 0 16px 0 rgba(44, 62, 80, 0.08);
  z-index: 20;
  position: relative;
}

.content-area {
  flex: 1;
  padding: 0; /* Remove padding to let pages handle it */
  overflow-y: auto;
  position: relative; /* For z-index stacking */
}

.admin-subtitle {
  margin: 0.2rem 0 0 0;
  font-size: 1rem;
  color: #a445ff;
  font-weight: 700;
  letter-spacing: 0.5px;
  display: flex;
  align-items: center;
  gap: 0.3rem;
}

.cap {
  font-size: 1.2rem;
}
</style>