<template>
  <div class="page-container">
    <div class="sidebar-container">
      <Sidebar :navLinks="instructorNavLinks" class="special">
        <template #header>
          <div class="instructor-subtitle">
            Teacher Portal <span class="cap">🎓</span>
          </div>
        </template>
      </Sidebar>
    </div>
    <main class="main-content">
      <div class="main-content-inner">
        <router-view />
      </div>
    </main>
  </div>
</template>

<script setup>
import { useRouter, useRoute } from 'vue-router';
import { computed } from 'vue';
import { store } from '../store'; // Import the global store for logout
import Sidebar from '../components/Sidebar.vue';

const router = useRouter();
const route = useRoute();

const teacher_id = computed(() => route.params.teacher_id || localStorage.getItem("teacher_id"));
const handleLogout = () => {
  localStorage.clear();

  store.darkMode = false;
  localStorage.setItem('darkMode', 'false');
  document.body.classList.remove('dark');
  router.push('/login');
};

const instructorNavLinks = [
  { name: 'Dashboard', icon: '📊', onClick: () => router.push(`/teacher/${teacher_id.value}/dashboard`)},
  { name: 'My Students', icon: '🧑‍🎓', onClick: () => router.push(`/teacher/${teacher_id.value}/students`)},
  { name: 'Assignments', icon: '📝', onClick: () => router.push(`/teacher/${teacher_id.value}/assignments`)},
  { name: 'Evaluation', icon: '🛡️', onClick: () => router.push(`/teacher/${teacher_id.value}/evaluation`)},
  { name: 'Resources', icon: '📚', onClick: () => router.push(`/teacher/${teacher_id.value}/resources`)},
  { name: 'AI Assistance', icon: '🤖', onClick: () => router.push(`/teacher/${teacher_id.value}/ai-assistance`)},
  { name: 'Comms Center', icon: '📬', onClick: () => router.push(`/teacher/${teacher_id.value}/comms`)},
  { name: 'Profile', icon: '👤', onClick: () => router.push(`/teacher/${teacher_id.value}/profile`)},
];
</script>

<style scoped>
.page-container {
  display: flex;
  min-height: 100vh;
  background: linear-gradient(135deg, #B12BE2, #1F6CF3);
  overflow-x: hidden;
}

.sidebar-container {
  background: var(--sidebar-bg, #fff);
  box-shadow: 2px 0 16px 0 rgba(44, 62, 80, 0.08);
  z-index: 20;
  position: fixed;
  left: 0;
  top: 0;
  height: 100vh;
  width: 72px;
  transition: width 0.2s cubic-bezier(.4,0,.2,1);
}

/* Expand sidebar width on hover (match Sidebar.vue) */
.sidebar-container:hover {
  width: 240px;
}

.instructor-subtitle {
  margin: 0.2rem 0 0 0;
  font-size: 1rem;
  color: #a445ff;
  font-weight: 700;
  letter-spacing: 0.5px;
  display: flex;
  align-items: center;
  gap: 0.3rem;
}
.cap {
  font-size: 1.2rem;
}
.main-content {
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: stretch;
  background: transparent;
  color: var(--text);
  overflow-y: auto;
  min-width: 0;
  min-height: 100vh;
  box-sizing: border-box;
  margin-left: 72px;
  transition: margin-left 0.2s cubic-bezier(.4,0,.2,1);
}

/* Match expanded sidebar width on hover */
.sidebar-container:hover ~ .main-content {
  margin-left: 240px;
}
.main-content-inner {
  max-width: 1400px;
  margin: 0 auto;
  width: 100%;
  background: transparent;
  /* Optional: add a subtle shadow or border for separation */
  /* box-shadow: 0 2px 16px rgba(0,0,0,0.04); */
  /* border-radius: 16px; */
}
@media (max-width: 1200px) {
  .main-content-inner {
    max-width: 1000px;
  }
  .main-content {
    padding: 1.5rem 1rem 1.5rem 1rem;
  }
}
@media (max-width: 900px) {
  .main-content {
    padding: 1rem 0.5rem 1rem 0.5rem;
  }
  .main-content-inner {
    max-width: 100%;
    padding: 0;
  }
}
@media (max-width: 600px) {
  .main-content {
    padding: 0.5rem 0.2rem 0.5rem 0.2rem;
  }
}
</style>