// src/store.js
import { reactive } from 'vue'

// Function to initialize store from localStorage
const initializeStore = () => {
  const savedUser = localStorage.getItem('user');
  const savedToken = localStorage.getItem('token');
  
  console.log('🔄 INITIALIZING STORE FROM LOCALSTORAGE:', {
    savedUser: savedUser ? 'Found' : 'Not found',
    savedToken: savedToken ? 'Found' : 'Not found'
  });
  
  return {
    darkMode: false,
    user: savedUser ? JSON.parse(savedUser) : null,
    userId: savedUser ? JSON.parse(savedUser).id : null,
    token: savedToken || null,
    isAuthenticated: !!(savedUser && savedToken),
    
    toggleTheme() {
      this.darkMode = !this.darkMode
    },
    
    // Method to clear user data (for logout)
    clearUser() {
      this.user = null;
      this.userId = null;
      this.token = null;
      this.isAuthenticated = false;
      localStorage.removeItem('user');
      localStorage.removeItem('token');
    }
  };
};

// Create reactive store with initialized data
export const store = reactive(initializeStore());

// Log the initialized store state
console.log('✅ STORE INITIALIZED:', {
  user: store.user,
  userId: store.userId,
  token: store.token,
  isAuthenticated: store.isAuthenticated
});