<template>
  <div class="page-wrapper">
          <div class="hero-header">
<div style="
  padding: 25px; 
  border: 2px solid whitesmoke; 
  backdrop-filter: blur(20px); 
  background-color: rgba(255, 255, 255, 0.2); 
  border-radius: 10px;
  display: flex; 
  align-items: center; 
  justify-content: center; 
  min-height: 50px; /* prevents jumpiness */
">
<h1 style="margin: 0; line-height: 1; color: #fff;">
  Welcome to
  <span style="color: #66fcf1; 
               text-shadow: 1px 1px 6px rgba(0, 0, 50, 0.4); 
               font-family: 'Algerian', serif;" 
        class="animate__animated animate__pulse animate__infinite">
    Skillzy
  </span>
</h1>

</div>

        <p>Your journey to knowledge starts here</p>
      </div>
      <div class="hero-subtitle-1">
        <h3 style="color: wheat;">Lets Learn Together! 🌟</h3>
      </div>
      <div class="hero-subtitle-2">
        <p>Empowering young minds with essential life skills through interactive learning, AI-powered assistance, and fun activities for ages 8–14.</p>
      </div>
    <!-- Top Section -->
    <div class="hero-section">
<div class="character-list">
  <div class="character">
  <img
    src="@/assets/tom.png"
    alt="Tom"
    class="animate__animated animate__bounce animate__infinite animate__slow"
    style="animation-delay: 1s;"
  />
  <p>Tom - Time Master!</p>
</div>
<div class="character">
  <img
    src="@/assets/doremon.png"
    alt="Doraemon"
    class="animate__animated animate__bounce animate__infinite animate__slow"
    style="animation-delay: 2s;"
  />
  <p>Doraemon - Joyful Learner!</p>
</div>
<div class="character">
  <img
    src="@/assets/mickey.png"
    alt="Mickey"
    class="animate__animated animate__bounce animate__infinite animate__slow"
    style="animation-delay: 3s;"
  />
  <p>Mickey - Fun Guide!</p>
</div>
</div>

<div class="ready-box">
  <lottie-player
    src="https://assets5.lottiefiles.com/packages/lf20_qp1q7mct.json"
    background="transparent"
    speed="1"
    style="width: 160px; height: 160px; margin: auto;"
    loop
    autoplay
  ></lottie-player>

  <!-- Add this new section -->
  <div class="learning-ready-section">
    <h2 class="ready-title">✨ Ready to Start Learning? ✨</h2>
    
    <p class="ready-description">
      Join thousands of young learners who are building essential life skills and having fun
      ⭐ while doing it! Choose your path below to begin your adventure.
    </p>
    
    <div class="action-buttons">
      <router-link to="/login" class="action-btn login-btn">
        <span class="btn-icon">🔓</span>
        <div class="btn-content">
          <h3>Login</h3>
          <p>Already have an account?</p>
        </div>
      </router-link>
      
      <router-link to="/register" class="action-btn register-btn">
        <span class="btn-icon">📝</span>
        <div class="btn-content">
          <h3>Register</h3>
          <p>Start your journey today!</p>
        </div>
      </router-link>
    </div>
    
    <div class="safety-note">
      <span class="safety-icon">🛡️</span>
      <p>Safe, secure, and privacy-focused platform designed specifically for children</p>
    </div>
  </div>
</div>

  <DotLottieVue style="height: 100px; width: 100px; position: relative; bottom: -40px; top: -140px; right: 300px;" autoplay loop src="https://lottie.host/79fd18d1-9070-465e-a1b0-e2f50ca46b9b/6Ps47WGPwb.lottie" />

<div class="character-list-right">

  <div class="character-right">
    <h3>Welcome to Your Learning Adventure! 🚀</h3>
    <p>
      Skillzy is designed specifically for children aged 8-14 to develop essential life skills that will help them succeed in school and beyond. Our interactive platform combines fun activities, engaging content, and AI-powered assistance to make learning both effective and enjoyable.
    </p>
  </div>
</div>

    </div>
  <div class="wave-animation">
    <span class="animate__animated animate__swing animate__infinite" style="animation-delay: 0s; animation-duration: 2s;">🎯</span>
    <span class="animate__animated animate__swing animate__infinite" style="animation-delay: 0.2s; animation-duration: 2s;">📚</span>
    <span class="animate__animated animate__swing animate__infinite" style="animation-delay: 0.4s; animation-duration: 2s;">🎨</span>
    <span class="animate__animated animate__swing animate__infinite" style="animation-delay: 0.6s; animation-duration: 2s;">🧠</span>
    <span class="animate__animated animate__swing animate__infinite" style="animation-delay: 0.8s; animation-duration: 2s;">💬</span>
    <span class="animate__animated animate__swing animate__infinite" style="animation-delay: 1s; animation-duration: 2s;">⭐</span>
    <span class="animate__animated animate__swing animate__infinite" style="animation-delay: 1.2s; animation-duration: 2s;">🚀</span>
    <span class="animate__animated animate__swing animate__infinite" style="animation-delay: 1.4s; animation-duration: 2s;">🌈</span>
  </div>

    <!-- Mid Highlights -->
    <div class="features-section">
      <h3 class="section-title">✨ Why Choose Learning Hub? ✨</h3>
      <div class="features">
        <div class="feature-item">
          <i class="icon">🏆</i>
          <p>Award-Winning Platform</p>
        </div>
        <div class="feature-item">
          <i class="icon">👩‍🎓</i>
          <p>10,000+ Happy Students</p>
        </div>
        <div class="feature-item">
          <i class="icon">⚡</i>
          <p>AI-Powered Learning</p>
        </div>
        <div class="feature-item">
          <i class="icon">💙</i>
          <p>Made with Love</p>
        </div>
      </div>
    </div>

    <!-- Footer -->
    <footer class="footer">
      <div class="footer-content">
        <div class="footer-left">
          <h3>Skillzy</h3>
          <p>
            Empowering young minds with essential life skills through interactive
            learning, AI-powered assistance, and fun activities for ages 8–14.
          </p>
          <div class="social-icons">
          <a href="https://www.facebook.com/iitmadrasbsdegree/about/" target="_blank"><img src="https://cdn-icons-png.flaticon.com/512/733/733547.png" alt="Facebook" class="social-icon" /></a>
          <a href="https://github.com/rahulsharmaYS/soft-engg-project-may-2025-se-May-22" target="_blank"><img src="https://cdn-icons-png.flaticon.com/512/733/733609.png" alt="GitHub" class="social-icon" /></a>
          <a href="https://study.iitm.ac.in/ds/" target="_blank"><img src="https://cdn-icons-png.flaticon.com/512/2702/2702602.png" alt="Google" class="social-icon" /></a>
          <a href="https://www.instagram.com/iitmadras_bs/" target="_blank"><img src="https://cdn-icons-png.flaticon.com/512/733/733558.png" alt="Instagram" class="social-icon" /></a>
          </div>

        </div>

        <div class="footer-links">
          <h4>Quick Links</h4>
          <ul>
            <li><router-link to="/about">About Us</router-link></li>
            <li><router-link to="/features">Features</router-link></li>
            <li><router-link to="/privacy">Privacy Policy</router-link></li>
            <li><router-link to="/terms">Terms of Service</router-link></li>
          </ul>
        </div>

        <div class="footer-contact">
          <h4>Contact Us</h4>
          <p>Dummy Email: <u>team22@seproject.com</u></p>
          <p>Phone: <u>+91 123456789000</u></p>
          <p>Address: <u>IIT Madras, SoftWare Engineering Course</u></p>
        </div>
      </div>
      <div class="footer-bottom">
        © 2025 Skillzy. Made with ❤️ for young learners.
          <!-- highlight that all the quick links pages are dummy and only made for project use -->
          <div class="highlight-message">
            <span class="highlight" style="color: yellow; font-size: large; font-style: oblique; margin-top: 50px;">
                Quick Links are for demo purposes for our SE project only!
            </span>
          </div>
      </div>
    </footer>
  
  </div>
</template>

<script setup>


import api from '../api';
import { ref } from 'vue';
import { useRouter } from 'vue-router';
import { store } from '../store.js';
import 'animate.css';
import { DotLottieVue } from '@lottiefiles/dotlottie-vue';

const username = ref('');
const password = ref('');
const loading = ref(false);
const error = ref('');
const success = ref('');
const router = useRouter();

const handleLogin = async () => {
  if (!username.value || !password.value) {
    error.value = 'Please enter both username and password';
    return;
  }

  try {
    loading.value = true;
    error.value = '';
    success.value = '';

    const form = new URLSearchParams();
    form.append('username', username.value);
    form.append('password', password.value);

    const response = await api.post('/user/login', form, {
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
    });

    const access_token = response.data.access_token;
    const user = response.data.user;

    if (!access_token || !user) {
      throw new Error('Invalid response: missing token or user data');
    }

    localStorage.setItem('token', access_token);
    localStorage.setItem('user', JSON.stringify(user));

    store.user = user;
    store.userId = user.id;
    store.token = access_token;
    store.isAuthenticated = true;

    if (api.defaults) {
      api.defaults.headers.common['Authorization'] = `Bearer ${access_token}`;
    }

    success.value = 'Login successful! Redirecting...';

    setTimeout(() => {
      if (user.role === 'student') {
        router.push(`/student/${user.id}/dashboard`);
      } else if (user.role === 'teacher') {
        router.push(`/teacher/${user.id}/dashboard`);
      } else if (user.role === 'parent') {
        router.push(`/parent/${user.id}/dashboard`);
      } else if (user.role === 'admin') {
        router.push('/admin/dashboard');
      } else {
        router.push('/dashboard');
      }
    }, 1000);
  } catch (err) {
    if (err.response) {
      const status = err.response.status;
      const msg =
        err.response.data?.detail ||
        err.response.data?.message ||
        'Login failed';
      error.value =
        status === 401
          ? 'Invalid username or password.'
          : status === 422
          ? 'Invalid format.'
          : status >= 500
          ? 'Server error.'
          : msg;
    } else {
      error.value = err.message || 'An error occurred.';
    }
  } finally {
    loading.value = false;
  }
};

</script>


<style scoped>


.page-wrapper {
  position: relative;
  min-height: 100vh;
  display: flex;
  flex-direction: column;
  z-index: 1;
  overflow: hidden;
}

.page-wrapper::before {
  content: "⭐";
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100vh;
  /* background: url(../assets/abcd.jpg) no-repeat center center fixed; */
  /* background: linear-gradient(135deg, #7e4ff9 0%, #b176fa 50%, #a0c4ff 100%); */
  /* background: linear-gradient(to bottom right, #8a4fff, #b084ff, #a3cfff); */
  background: radial-gradient(circle at top left, #6a1bff 0%, #b13eff 40%, #3a83ff 80%);

  /* background: ; */
  background-size: cover;
  filter: blur(1px); /* Adjust blur level */
  z-index: -1;
}

.page-wrapper::after {
  content: '⭐';
  position: absolute;
  top: 20%;
  right: 15%;
  font-size: 1.2rem;
  animation: float 3s ease-in-out infinite reverse;
}

@keyframes float {
  0%, 100% { transform: translateY(0px); }
  50% { transform: translateY(-20px); }
}

.social-icons {
  display: flex;
  justify-content: center;
  gap: 10px;
  margin-top: 30px;
}
.social-icon {
  width: 30px;
  height: 30px;
  transition: transform 0.3s;
  cursor: pointer;
}

.social-icon:hover {
  transform: scale(1.1);
}

/* Hero/Login Section */
.hero-header {
  text-align: center;
  color: white;
  padding: 1rem 1rem;
  margin: auto;
    }

.hero-header h1 {
  font-size: 3.5rem;
  margin-bottom: 0.5rem;
  animation: pulse 2s infinite;
  animation-delay: 0.5s;
  animation-duration: 1.5s;
  font-weight: bold;
  text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
  color: #fff;

}
.hero-header p {
  font-size: 1.2rem;
  margin-bottom: 0.5rem;
}
.hero-subtitle-1 {
  text-align: center;
  color: white;
  font-size: 1.1rem;
  margin-bottom: 0.5rem;
}
.hero-subtitle-2 {
  text-align: center;
  color: white;
  font-size: 1.1rem;
  margin-bottom: 0.5rem;
}

.hero-section {
  flex: 1;
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 2rem 1rem;
  position: relative;
}

.wave-animation {
      display: flex;
      justify-content: center;
      gap: 10px;
      margin-top: 30px;
      font-size: 1.5rem;
    }

.login-box {
  background: #fff;
  padding: 2rem;
  border-radius: 1.5rem;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
  width: 100%;
  max-width: 400px;
  text-align: center;
}

.login-box h2 {
  font-size: 1.8rem;
  color: #6a00f4;
  margin-bottom: 0.5rem;
}

.subtitle {
  font-size: 0.95rem;
  color: #444;
  margin-bottom: 1.5rem;
}

.input {
  width: 90%;
  padding: 0.75rem 1rem;
  border-radius: 1rem;
  border: 1px solid #ccc;
  margin-bottom: 1rem;
  font-size: 1rem;
}

.button {
  background: #9b5de5;
  color: white;
  border: none;
  padding: 0.75rem;
  font-size: 1rem;
  width: 100%;
  border-radius: 1rem;
  cursor: pointer;
  transition: background 0.3s;
}
.button:hover {
  background: #7c3aed;
}
.button:disabled {
  opacity: 0.7;
}

.message {
  margin-top: 1rem;
  font-size: 0.9rem;
}
.message.success {
  color: green;
}
.message.error {
  color: red;
}

.bottom-note {
  margin-top: 1rem;
  font-size: 0.9rem;
}
.bottom-note a {
  color: #9b5de5;
  font-weight: bold;
}

/* Feature Section */
.features-section {
  color: white;
  text-align: center;
  padding: 2rem 1rem;
  background: rgba(255, 255, 255, 0.027);
  backdrop-filter: blur(10px);
  border-radius: 1.5rem;
  border-top: 1px solid rgba(255, 255, 255, 0.3);
  border-bottom: 1px solid rgba(255, 255, 255, 0.3);
  border-left: 1px solid rgba(255, 255, 255, 0.3);
  border-right: 1px solid rgba(255, 255, 255, 0.3);
  margin: 2rem auto;
  max-width: 90rem;
  display: flex;
  flex-direction: column;
  position: relative;
  align-items: center;
  justify-content: center;
}
.section-title {
  font-size: 1.5rem;
  margin-bottom: 1rem;
}
.features {
  display: flex;
  justify-content: center;
  flex-wrap: wrap;
  gap: 2rem;
}
.feature-item {
  width: 140px;
  background: transparent;
  border-radius: 1rem;
  /* border shadow */
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
  padding: 1rem;
  border-radius: 1rem solid rgba(255, 255, 255, 0.4);
}
.icon {
  font-size: 2rem;
  margin-bottom: 0.5rem;
}

/* Footer */
.footer {
  background: #7400b8;
  color: white;
  padding: 2rem 1rem 1rem;
  margin-top: auto;
}
.footer-content {
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
  gap: 2rem;
}
.footer-left,
.footer-links,
.footer-contact {
  flex: 1;
  min-width: 200px;
}
.footer h4 {
  margin-bottom: 1rem;
}
.footer-links ul {
  list-style: none;
  padding: 0;
}
.footer-links li {
  margin-bottom: 0.5rem;
}
.footer-links a {
  color: white;
  text-decoration: none;
}
.footer-links a:hover {
  text-decoration: underline;
}
.social-icons a {
  font-size: 1.5rem;
  margin-right: 0.5rem;
  color: white;
}
.footer-bottom {
  margin-top: 2rem;
  text-align: center;
  font-size: 0.85rem;
  border-top: 1px solid rgba(255, 255, 255, 0.2);
  padding-top: 1rem;
}
.ready-box {
  background: rgba(255, 255, 255, 0.1);
  backdrop-filter: blur(20px);
  border: 1px solid rgba(255, 255, 255, 0.2);
  border-radius: 25px;
  padding: 2.5rem 2rem;
  box-shadow: 0 15px 35px rgba(0, 0, 0, 0.1);
  max-width: 600px;
  margin: 0 auto;
  text-align: center;
}

.learning-ready-section {
  margin-top: 2rem;
}

.ready-title {
  font-size: 2rem;
  color: rgba(255, 255, 255, 0.95);
  margin-bottom: 1rem;
  font-weight: 600;
  text-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
}

.ready-description {
  color: rgba(255, 255, 255, 0.9);
  font-size: 1.1rem;
  line-height: 1.6;
  margin-bottom: 2rem;
  padding: 0 1rem;
}

.action-buttons {
  display: flex;
  gap: 1.5rem;
  justify-content: center;
  margin-bottom: 2rem;
  flex-wrap: wrap;
}

.action-btn {
  display: flex;
  align-items: center;
  gap: 1rem;
  background: rgba(255, 255, 255, 0.15);
  backdrop-filter: blur(10px);
  border: 1px solid rgba(255, 255, 255, 0.3);
  border-radius: 15px;
  padding: 1.2rem 1.5rem;
  text-decoration: none;
  color: white;
  transition: all 0.3s ease;
  min-width: 200px;
  position: relative;
  overflow: hidden;
}

.action-btn::before {
  content: '';
  position: absolute;
  top: 0;
  left: -100%;
  width: 100%;
  height: 100%;
  background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.1), transparent);
  transition: left 0.5s ease;
}

.action-btn:hover::before {
  left: 100%;
}

.action-btn:hover {
  transform: translateY(-3px);
  box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
  background: rgba(255, 255, 255, 0.2);
}

.login-btn {
  background: linear-gradient(135deg, rgba(17, 85, 194, 0.9), rgba(37, 99, 235, 0.2));
}

.register-btn {
  background: linear-gradient(135deg, rgba(198, 29, 29, 0.9), rgba(220, 38, 38, 0.2));
}

.btn-icon {
  font-size: 2rem;
  display: flex;
  align-items: center;
  justify-content: center;
}

.btn-content {
  text-align: left;
}

.btn-content h3 {
  margin: 0;
  font-size: 1.2rem;
  font-weight: 600;
}

.btn-content p {
  margin: 0.2rem 0 0 0;
  font-size: 0.9rem;
  opacity: 0.9;
}

.safety-note {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 0.8rem;
  background: rgba(34, 197, 94, 0.1);
  border: 1px solid rgba(34, 197, 94, 0.3);
  border-radius: 10px;
  padding: 1rem;
  color: rgba(255, 255, 255, 0.9);
  font-size: 0.9rem;
}

.safety-icon {
  font-size: 1.5rem;
}

/* Responsive adjustments */
@media (max-width: 768px) {
  .action-buttons {
    flex-direction: column;
    align-items: center;
  }
  
  .action-btn {
    min-width: 250px;
  }
  
  .ready-title {
    font-size: 1.6rem;
  }
  
  .ready-description {
    font-size: 1rem;
  }
}

.character-list {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  margin-right: 2rem;
  gap: 2rem;
}

.character {
  text-align: center;
  background: rgba(255, 255, 255, 0.1);
  border-radius: 15px;
  padding: 1rem;
  width: 160px;
  box-shadow: 0 6px 15px rgba(0, 0, 0, 0.1);
  backdrop-filter: blur(10px);
}

.character img {
  width: 100px;
  height: 100px;
  object-fit: contain;
  margin-bottom: 0.5rem;
}

.character p {
  color: white;
  font-weight: bold;
  font-size: 0.95rem;
}

/* Responsive for small devices */
@media (max-width: 768px) {
  .hero-section {
    flex-direction: column;
  }

  .character-list {
    flex-direction: row;
    justify-content: center;
    margin-right: 0;
    margin-bottom: 2rem;
    gap: 1rem;
  }

  .character {
    width: 100px;
    padding: 0.5rem;
  }

  .character img {
    width: 60px;
    height: 60px;
  }

  .character p {
    font-size: 0.75rem;
  }
}
.character-list {
  position: absolute;
  top: 50%;
  left: 5%; /* 👈 Move closer to center (you can try 8%, 10%, etc. if needed) */
  transform: translateY(-50%);
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
  z-index: 2;
}

.character {
  background: rgba(255, 255, 255, 0.15);
  backdrop-filter: blur(8px);
  border-radius: 15px;
  padding: 1rem;
  text-align: center;
  width: 160px;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
  color: white;
  font-weight: bold;
  font-size: 0.95rem;
}


.star {
  position: absolute;
  pointer-events: none;
  z-index: -1;
  color: #ffd700;
  font-size: 1rem;
  animation: twinkle 2s infinite ease-in-out;
  opacity: 0.8;
}

@keyframes twinkle {
  0%, 100% { opacity: 0.8; transform: scale(1); }
  50% { opacity: 0.2; transform: scale(1.2); }
}

body::after {
  content: "";
  position: fixed;
  bottom: 0;
  left: 0;
  height: 5px;
  width: 100%;
  background: red;
  z-index: 9999;
}

.character-list-right {
  position: absolute;
  top: 50%;
  right: 5%; /* 👈 Move closer to center (you can try 8%, 10%, etc. if needed) */
  transform: translateY(-50%);
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
  z-index: 2;
}

.character-right {
  background: rgba(255, 255, 255, 0.15);
  backdrop-filter: blur(8px);
  border-radius: 15px;
  padding: 1rem;
  text-align: center;
  width: 260px;
  /* height: 300px; */
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
  color: white;
  font-weight: bold;
  font-size: 0.95rem;
}

</style>
