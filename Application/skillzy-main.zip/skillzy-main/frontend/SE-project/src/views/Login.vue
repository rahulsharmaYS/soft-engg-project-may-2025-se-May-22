<template>
  <div class="page-wrapper">
    <div class="hero-header">
      <h1 class="animate__animated animate__pulse animate__infinite">Welcome to Skillzy</h1>
      <p>Your journey to knowledge starts here</p>
    </div>
    <div class="hero-subtitle-1">
      <h3 style="color: wheat;">Lets Learn Together! 🌟</h3>
    </div>
    <div class="hero-subtitle-2">
      <p>Empowering young minds with essential life skills through interactive learning, AI-powered assistance, and fun activities for ages 8–14.</p>
    </div>

<!-- <div id="girl-animation" style="width: 150px; height: 150px;"></div> -->

    <!-- Updated Hero Section with Split Layout -->
    <div class="hero-section">
      <!-- Left Side - Login Box -->
      <div class="login-container">
        <div class="back-button">
          <router-link to="/" class="back-link">
            ← Back to Home
          </router-link>
        </div>

        <div class="login-box">
          <!-- Happy Sun Emoji -->

          <!-- <div class="sun-emoji"> -->
            <DotLottieVue style="height: 75px; width: 75px; position: relative; bottom: -20px; right: 5px;" autoplay loop src="https://lottie.host/af860a20-a4ff-44b6-a4cc-a2b1d991ff90/u2P9qVTGxN.lottie" />
            <!-- <div>
              
            </div> -->
            <!-- </div> -->
          
          <h2 style="position: relative; left: 20px; bottom: 50px;">Welcome Back! 😊</h2>
          <p class="subtitle">Enter your credentials to access your account</p>

          <form @submit.prevent="handleLogin" class="form">
                        <p class="message success" v-if="success">{{ success }}</p>
            <p class="message error" v-if="error">{{ error }}</p>
            <div class="input-group">
              <label class="input-label">Username</label>
              <input
                type="text"
                v-model="username"
                placeholder="Enter your username"
                class="input"
              />
            </div>

            <div class="input-group">
              <label class="input-label">Password</label>
              <input
                type="password"
                v-model="password"
                placeholder="•••"
                class="input"
              />
            </div>

            <button type="submit" class="signin-button" :disabled="loading">
              <span v-if="loading">Signing in...</span>
              <span v-else>Sign In ✨</span>
            </button>


          </form>

          <div class="signup-link">
            Don't have an account? 
            <router-link to="/register" class="signup-text">Sign Up</router-link>
          </div>
        </div>
      </div>

      <!-- Right Side - Life Skills Card -->
<div class="life-skills-container">
  <div class="life-skills-card">
    <!-- Position Lottie animation to overlap above the card -->
    <DotLottieVue 
      class="lottie-overlay" 
      style="height: 70px; width: 70px; background: transparent;" 
      autoplay 
      loop 
      src="https://lottie.host/a02b7f5a-1688-42d1-ab5c-2e0b069b1daa/Fjm5E8bq9L.lottie" 
    />
    
          <div class="card-header">
            <div class="avatars">
              <div class="avatar blue">
                  <img
                    src="@/assets/doremon.png"
                    alt="Doraemon"
                    class="animate__animated animate__bounce animate__infinite animate__slow"
                    style="animation-delay: 0.5s; width: 50px; height: 50px;"
                  />
              </div>
              <div class="avatar black">
                <img
                  src="@/assets/mickey.png"
                  alt="Mickey"
                  class="animate__animated animate__bounce animate__infinite animate__slow"
                  style="animation-delay: 2s; width: 50px; height: 50px;"
                />
              </div>
              <div class="avatar orange">
                <img
                  src="@/assets/tom.png"
                  alt="Tom"
                  class="animate__animated animate__bounce animate__infinite animate__slow"
                  style="animation-delay: 3.5s; width: 50px; height: 50px;"
                />
              </div>
            </div>
            <div class="star-badge">⭐</div>
          </div>
          <h2 class="card-title">Life Skills</h2>
          <p class="card-subtitle">Empowering the next generation</p>

          <div class="skills-grid">
            <div class="skill-card fun-learning">
              <div class="skill-icon">🎯</div>
              <span>Fun Learning</span>
            </div>
            <div class="skill-card skill-building">
              <div class="skill-icon">🏗️</div>
              <span>Skill Building</span>
            </div>
            <div class="skill-card achievement">
              <div class="skill-icon">🏆</div>
              <span>Achievement</span>
            </div>
            <div class="skill-card growth">
              <div class="skill-icon">📈</div>
              <span>Growth</span>
            </div>
          </div>

          <div class="decorative-elements">
            <span class="deco-star">⭐</span>
            <span class="deco-mushroom">🍄</span>
            <span class="deco-flag">🏳️</span>
          </div>
        </div>
      </div>
    </div>

    <!-- Mid Highlights -->
    <div class="features-section">
      <h3 class="section-title">✨ Why Choose Learning Hub? ✨</h3>
      <div class="features">
        <div class="feature-item">
          <i class="icon">🏆</i>
          <p>Award-Winning Platform</p>
        </div>
        <div class="feature-item">
          <i class="icon">👩‍🎓</i>
          <p>10,000+ Happy Students</p>
        </div>
        <div class="feature-item">
          <i class="icon">⚡</i>
          <p>AI-Powered Learning</p>
        </div>
        <div class="feature-item">
          <i class="icon">❤️</i>
          <p>Made with Love</p>
        </div>
      </div>
    </div>

    <!-- Footer -->
    <footer class="footer">
      <div class="footer-content">
        <div class="footer-left">
          <h3>Skillzy</h3>
          <p>
            Empowering young minds with essential life skills through interactive
            learning, AI-powered assistance, and fun activities for ages 8–14.
          </p>
          <div class="social-icons">
          <a href="https://www.facebook.com/iitmadrasbsdegree/about/" target="_blank"><img src="https://cdn-icons-png.flaticon.com/512/733/733547.png" alt="Facebook" class="social-icon" /></a>
          <a href="https://github.com/rahulsharmaYS/soft-engg-project-may-2025-se-May-22" target="_blank"><img src="https://cdn-icons-png.flaticon.com/512/733/733609.png" alt="GitHub" class="social-icon" /></a>
          <a href="https://study.iitm.ac.in/ds/" target="_blank"><img src="https://cdn-icons-png.flaticon.com/512/2702/2702602.png" alt="Google" class="social-icon" /></a>
          <a href="https://www.instagram.com/iitmadras_bs/" target="_blank"><img src="https://cdn-icons-png.flaticon.com/512/733/733558.png" alt="Instagram" class="social-icon" /></a>
          </div>
        </div>

        <div class="footer-links">
          <h4>Quick Links</h4>
          <ul>
            <li><router-link to="/about">About Us</router-link></li>
            <li><router-link to="/features">Features</router-link></li>
            <li><router-link to="/privacy">Privacy Policy</router-link></li>
            <li><router-link to="/terms">Terms of Service</router-link></li>
          </ul>
        </div>

        <div class="footer-contact">
          <h4>Contact Us</h4>
          <p>Dummy Email: <u>team22@seproject.com</u></p>
          <p>Phone: <u>+91 9560594522</u></p>
          <p>Address: <u>IIT Madras, SoftWare Engineering Course</u></p>
        </div>
      </div>
      <div class="footer-bottom">
        © 2025 Skillzy. Made with ❤️ for young learners.
      </div>
    </footer>
  </div>
</template>

<script setup>
import api from '../api';
import { ref } from 'vue';
import { useRouter } from 'vue-router';
import { store } from '../store.js';
import 'animate.css';
import { DotLottieVue } from '@lottiefiles/dotlottie-vue';

const username = ref('');
const password = ref('');
const loading = ref(false);
const error = ref('');
const success = ref('');
const router = useRouter();

const handleLogin = async () => {
  if (!username.value || !password.value) {
    error.value = 'Please enter both username and password';
    return;
  }

  try {
    loading.value = true;
    error.value = '';
    success.value = '';

    const form = new URLSearchParams();
    form.append('username', username.value);
    form.append('password', password.value);

    const response = await api.post('/user/login', form, {
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
    });

    const access_token = response.data.access_token;
    const user = response.data.user;

    if (!access_token || !user) {
      throw new Error('Invalid response: missing token or user data');
    }

    localStorage.setItem('token', access_token);
    localStorage.setItem('user', JSON.stringify(user));

    store.user = user;
    store.userId = user.id;
    store.token = access_token;
    store.isAuthenticated = true;

    if (api.defaults) {
      api.defaults.headers.common['Authorization'] = `Bearer ${access_token}`;
    }

    success.value = 'Login successful! Redirecting...';

    setTimeout(() => {
      if (user.role === 'student') {
        router.push(`/student/${user.id}/dashboard`);
      } else if (user.role === 'teacher') {
        router.push(`/teacher/${user.id}/dashboard`);
      } else if (user.role === 'parent') {
        router.push(`/parent/${user.id}/dashboard`);
      } else if (user.role === 'admin') {
        router.push('/admin/usermanagement');
      } else {
        router.push('/dashboard');
      }
    }, 1000);
  } catch (err) {
    if (err.response) {
      const status = err.response.status;
      const msg =
        err.response.data?.detail ||
        err.response.data?.message ||
        'Login failed';
      error.value =
        status === 401
          ? 'Invalid username or password.'
          : status === 422
          ? 'Invalid format.'
          : status >= 500
          ? 'Server error.'
          : msg;
    } else {
      error.value = err.message || 'An error occurred.';
    }
  } finally {
    loading.value = false;
  }
};

lottie.loadAnimation({
  container: document.getElementById('girl-animation'),
  renderer: 'svg',
  loop: true,
  autoplay: true,
  path: 'hhttps://lottie.host/ac7d02a7-8531-4a4f-b56e-8e705fecf113/EEQb5iDLJY.lottie',
  rendererSettings: {
    preserveAspectRatio: 'xMidYMid meet',
    clearCanvas: true,
    progressiveLoad: true,
    hideOnTransparent: true,
  },
});

</script>

<style scoped>


.social-icons {
  display: flex;
  justify-content: center;
  gap: 10px;
  margin-top: 30px;
}
.social-icon {
  width: 30px;
  height: 30px;
  transition: transform 0.3s;
  cursor: pointer;
}

.social-icon:hover {
  transform: scale(1.1);
}

.message {
  margin-top: 1rem;
  font-size: 0.9rem;
}
.message.success {
  color: green;
}
.message.error {
  color: red;
}

.bottom-note {
  margin-top: 1rem;
  font-size: 0.9rem;
}
.bottom-note a {
  color: #9b5de5;
  font-weight: bold;
}

/* Feature Section */
.features-section {
  text-align: center;
  padding: 2rem 1rem;
  background: rgba(255, 255, 255, 0.027);
  backdrop-filter: blur(10px);
  border-radius: 1.5rem;
  border-top: 1px solid rgba(255, 255, 255, 0.3);
  border-bottom: 1px solid rgba(255, 255, 255, 0.3);
  border-left: 1px solid rgba(255, 255, 255, 0.3);
  border-right: 1px solid rgba(255, 255, 255, 0.3);
  margin: 2rem auto;
  max-width: 90rem;
  display: flex;
  flex-direction: column;
  position: relative;
  align-items: center;
  justify-content: center;
  color: whitesmoke;
}
.section-title {
  font-size: 1.5rem;
  margin-bottom: 1rem;
}
.features {
  display: flex;
  justify-content: center;
  flex-wrap: wrap;
  gap: 2rem;
}
.feature-item {
  width: 140px;
  background: transparent;
  border-radius: 1rem;
  /* border shadow */
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
  padding: 1rem;
  border-radius: 1rem solid rgba(255, 255, 255, 0.4);
}
.icon {
  font-size: 2rem;
  margin-bottom: 0.5rem;
}

/* Footer */
.footer {
  background: #7400b8;
  color: white;
  padding: 2rem 1rem 1rem;
}
.footer-content {
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
  gap: 2rem;
}
.footer-left,
.footer-links,
.footer-contact {
  flex: 1;
  min-width: 200px;
}
.footer h4 {
  margin-bottom: 1rem;
}
.footer-links ul {
  list-style: none;
  padding: 0;
}
.footer-links li {
  margin-bottom: 0.5rem;
}
.footer-links a {
  color: white;
  text-decoration: none;
}
.footer-links a:hover {
  text-decoration: underline;
}
.social-icons a {
  font-size: 1.5rem;
  margin-right: 0.5rem;
  color: white;
}
.footer-bottom {
  margin-top: 2rem;
  text-align: center;
  font-size: 0.85rem;
  border-top: 1px solid rgba(255, 255, 255, 0.2);
  padding-top: 1rem;
}

/* .page-wrapper {
  background: linear-gradient(135deg, #8b5cf6, #ec4899);
  min-height: 100vh;
  display: flex;
  flex-direction: column;
  position: relative;
} */

.page-wrapper {
  position: relative;
  min-height: 100vh;
  display: flex;
  flex-direction: column;
  /* background: url(../assets/abcd.jpg) no-repeat center center fixed; */
  background: linear-gradient(135deg, #2978f8, #8c24ee, #db217e);

  /* backdrop-filter: blur(10px); */
  background-size: cover;
  overflow-x: hidden;
}

/* Add floating stars */
.page-wrapper::before {
  content: '⭐';
  position: absolute;
  top: 10%;
  left: 10%;
  font-size: 1.5rem;
  animation: float 3s ease-in-out infinite;
}

.page-wrapper::after {
  content: '⭐';
  position: absolute;
  top: 20%;
  right: 15%;
  font-size: 1.2rem;
  animation: float 3s ease-in-out infinite reverse;
}

@keyframes float {
  0%, 100% { transform: translateY(0px); }
  50% { transform: translateY(-20px); }
}

@keyframes floatAnimation {
  0%, 100% { transform: translateX(-50%) translateY(0px); }
  50% { transform: translateX(-50%) translateY(-10px); }
}

/* Hero Section - Split Layout */
.hero-section {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 3rem;
  padding: 2rem 1rem;
  flex: 1;
  max-width: 1200px;
  margin: 0 auto;
}

/* Left Side - Login Container */
.login-container {
  flex: 1;
  max-width: 450px;
  min-width: 350px;
}

.back-button {
  margin-bottom: 1rem;
}

.back-link {
  color: rgba(255, 255, 255, 0.9);
  text-decoration: none;
  font-size: 1rem;
  display: inline-flex;
  align-items: center;
  gap: 0.5rem;
  transition: all 0.3s ease;
}

.back-link:hover {
  color: white;
  transform: translateX(-5px);
}

.login-box {
  background: rgba(255, 255, 255, 0.1);
  backdrop-filter: blur(20px);
  border: 1px solid rgba(255, 255, 255, 0.2);
  border-radius: 25px;
  padding: 1.5rem 1.5rem;
  box-shadow: 0 15px 35px rgba(0, 0, 0, 0.1);
  text-align: center;
  position: relative;
}

/* .sun-emoji {
  font-size: 4rem;
  margin-bottom: 1rem;
  display: block;
  filter: drop-shadow(0 4px 8px rgba(0, 0, 0, 0.1));
} */

.login-box h2 {
  font-size: 2rem;
  color: white;
  margin-bottom: 0.5rem;
  font-weight: 600;
}

.subtitle {
  color: rgba(255, 255, 255, 0.8);
  margin-bottom: 1rem;
  font-size: 1rem;
}

.form {
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
  text-align: left;
}

.input-group {
  position: relative;
}

.input-label {
  display: block;
  color: rgba(255, 255, 255, 0.9);
  font-size: 0.9rem;
  margin-bottom: 0.5rem;
  font-weight: 500;
}

.input {
  width: 100%;
  padding: 1rem 3rem 1rem 1.2rem;
  border-radius: 15px;
  border: 1px solid rgba(255, 255, 255, 0.2);
  background: rgba(255, 255, 255, 0.1);
  backdrop-filter: blur(10px);
  font-size: 1rem;
  color: white;
  transition: all 0.3s ease;
  box-sizing: border-box;
}

.input::placeholder {
  color: rgba(255, 255, 255, 0.41);
}

.input:focus {
  outline: none;
  border-color: rgba(255, 255, 255, 0.4);
  background: rgba(255, 255, 255, 0.15);
  box-shadow: 0 0 20px rgba(255, 255, 255, 0.1);
}

.input-icon {
  position: absolute;
  right: 1rem;
  top: 2.5rem;
  transform: translateY(-50%);
  color: rgba(255, 255, 255, 0.6);
  cursor: pointer;
  font-size: 1.2rem;
}

.signin-button {
  background: linear-gradient(135deg, #3b82f6, #1d4ed8);
  color: white;
  border: none;
  padding: 1rem 2rem;
  font-size: 1.1rem;
  font-weight: 600;
  border-radius: 15px;
  cursor: pointer;
  transition: all 0.3s ease;
  margin-top: 1rem;
  box-shadow: 0 8px 25px rgba(59, 130, 246, 0.3);
}

.signin-button:hover {
  transform: translateY(-2px);
  box-shadow: 0 12px 35px rgba(59, 130, 246, 0.4);
}

.signin-button:disabled {
  opacity: 0.6;
  cursor: not-allowed;
  transform: none;
}

.signup-link {
  margin-top: 1.5rem;
  color: rgba(255, 255, 255, 0.8);
  font-size: 0.9rem;
}

.signup-text {
  color: #fbbf24;
  font-weight: 600;
  text-decoration: none;
}

.signup-text:hover {
  text-decoration: underline;
}

/* Right Side - Life Skills Card */
.life-skills-container {
  flex: 1;
  max-width: 450px;
  min-width: 350px;
  position: relative;
}

.life-skills-card {
  background: linear-gradient(135deg, #10b981, #059669);
  border-radius: 25px;
  padding: 2.5rem 1.5rem;
  color: white;
  position: relative;
  overflow: hidden;
  box-shadow: 0 20px 40px rgba(16, 185, 129, 0.3);
}

.lottie-overlay {
  position: absolute;
  top: 5px;
  right: 10px;
  /* left: 0;*/
  z-index: 1;
  opacity: 0.8;
  filter: drop-shadow(0 4px 8px rgba(0, 0, 0, 0.1));
  /*width: 100%;
  height: 100%; */
  pointer-events: none;
}
.lottie-overlay.top-left {
  top: -50px;
  left: -50px;
}
.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 2rem;
}

.avatars {
  display: flex;
  gap: 0.5rem;
}

.avatar {
  width: 50px;
  height: 50px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 1.5rem;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}

.avatar.blue { background: #3b82f6; }
.avatar.black { background: #1f2937; }
.avatar.orange { background: #f97316; }

.star-badge {
  background: #fbbf24;
  width: 40px;
  height: 40px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 1.2rem;
  box-shadow: 0 4px 12px rgba(251, 191, 36, 0.3);
}

.card-title {
  font-size: 3rem;
  font-weight: bold;
  margin-bottom: 0.5rem;
  text-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.card-subtitle {
  font-size: 1.2rem;
  opacity: 0.9;
  margin-bottom: 2rem;
}

.skills-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 1rem;
  margin-bottom: 2rem;
}

.skill-card {
  background: rgba(255, 255, 255, 0.2);
  backdrop-filter: blur(10px);
  border-radius: 15px;
  padding: 1.5rem 1rem;
  text-align: center;
  transition: all 0.3s ease;
  border: 1px solid rgba(255, 255, 255, 0.1);
}

.skill-card:hover {
  transform: translateY(-5px);
  background: rgba(255, 255, 255, 0.3);
}

.skill-icon {
  font-size: 2rem;
  margin-bottom: 0.5rem;
  display: block;
}

.decorative-elements {
  position: absolute;
  bottom: 1rem;
  right: 1rem;
  display: flex;
  gap: 0.5rem;
}

.decorative-elements span {
  font-size: 1.5rem;
  opacity: 0.7;
}

/* Message Styles */
.message {
  margin-top: 1rem;
  padding: 0.75rem;
  border-radius: 10px;
  font-size: 0.9rem;
  text-align: center;
}

.message.success {
  background: rgba(34, 197, 94, 0.2);
  border: 1px solid rgba(34, 197, 94, 0.3);
  color: #22c55e;
}

.message.error {
  background: rgba(239, 68, 68, 0.2);
  border: 1px solid rgba(239, 68, 68, 0.3);
  color: white;
}

/* Responsive Design */
@media (max-width: 1200px) {
  
  .hero-section {
    gap: 1.5rem;
    padding: 1rem 0.5rem;
  }
  
  .login-container,
  .life-skills-container {
    max-width: 400px;
    min-width: 300px;
  }
}
@media (max-width: 768px) {
    .lottie-overlay {
    height: 200px !important;
    width: 200px !important;
    top: -30px;
    right: -30px;
  }
  .hero-section {
    flex-direction: column;
    gap: 2rem;
    padding: 1rem;
  }
  
  .login-container,
  .life-skills-container {
    width: 100%;
    max-width: 500px;
    min-width: auto;
  }
  
  .login-box,
  .life-skills-card {
    padding: 1.5rem 1rem;
  }
  
  .card-title {
    font-size: 2.5rem;
  }
  
  .skills-grid {
    grid-template-columns: 1fr;
    gap: 0.8rem;
  }
  
  .skill-card {
    padding: 1rem 0.8rem;
  }
}

@media (max-width: 480px) {
    .lottie-overlay {
    height: 200px !important;
    width: 200px !important;
    top: -30px;
    right: -30px;
  }
  .hero-section {
    padding: 0.5rem;
  }
  
  .login-box,
  .life-skills-card {
    padding: 1rem;
    border-radius: 20px;
  }
  
  .hero-header h1 {
    font-size: 2.5rem;
  }
  
  .card-title {
    font-size: 2rem;
  }
}

/* Keep your existing styles for other sections */
.hero-header {
  text-align: center;
  color: white;
  padding: 1rem;
}

.hero-header h1 {
  font-size: 3.5rem;
  margin-bottom: 0.5rem;
  font-weight: bold;
  text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
  color: #fff;
}

.hero-header p {
  font-size: 1.2rem;
  margin-bottom: 0rem;
}

.hero-subtitle-1,
.hero-subtitle-2 {
  text-align: center;
  color: white;
  font-size: 1rem;
  margin-bottom: 0rem;
}

/* Keep your existing wave animation and other styles */
.wave-animation {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  pointer-events: none;
  z-index: 1;
  display: flex;
  align-items: center;
  justify-content: space-around;
  flex-wrap: wrap;
  padding: 2rem;
}

.wave-animation span {
  font-size: 2rem;
  opacity: 0.7;
}


</style>
