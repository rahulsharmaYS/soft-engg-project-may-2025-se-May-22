<template>
  <div class="dashboard-container">
    <main class="main">
      <Header title="Admin Dashboard" subtitle="Overview of platform metrics" />

      <div class="content-wrapper">
        <section class="overview-metrics-grid">
          <MetricCard icon="👥" :value="totalUsers" label="Total Users" subLabel="Platform-wide" iconBg="linear-gradient(135deg, #6a11cb 0%, #2575fc 100%)" />
          <MetricCard icon="🔥" :value="totalActiveUsers" label="Active Users" subLabel="Currently online" iconBg="linear-gradient(135deg, #a020f0 0%, #f72585 100%)" />
          <MetricCard icon="🚫" :value="totalBlockedUsers" label="Blocked Users" subLabel="Temporarily Inactive"  iconBg="linear-gradient(135deg, #FF6B6B 0%, #FFD166 100%)" />
          <MetricCard icon="👑" :value="totalAdmins" label="Admins" subLabel="System Staff" iconBg="linear-gradient(135deg, #4ef013 0%, #00bc40 100%)"/>
        </section>

        <section class="recent-activity-card">
          <h3>Recent Activity</h3>
          <div class="activity-list">
            <div v-for="activity in activities" :key="activity.id" class="activity-item">
              <span class="activity-icon">{{ activity.icon }}</span>
              <div class="activity-details">
                <span class="activity-description">{{ activity.description }}</span>
                <span class="activity-time">{{ activity.time }}</span>
              </div>
            </div>
          </div>
        </section>
      </div>
    </main>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import Header from '../components/Header.vue'
import MetricCard from '../components/MetricCard.vue'
import api from '../api'

const totalUsers = ref(0)
const totalActiveUsers = ref(0)
const totalBlockedUsers = ref(0)
const totalAdmins = ref(0)

const activities = ref([
  { id: 1, icon: '📝', description: 'User Alice Johnson created a new account', time: '10 mins ago' },
  { id: 2, icon: '🚪', description: 'User Bob Smith logged out', time: '25 mins ago' },
  { id: 3, icon: '📧', description: 'Announcement sent to all students', time: '1 hour ago' },
  { id: 4, icon: '🔧', description: 'System update deployed', time: '2 hours ago' },
])

onMounted(async () => {
  try {
    const response = await api.get('/admin/dashboard')
    totalUsers.value = response.data.total_users
    totalActiveUsers.value = response.data.active_users
    totalBlockedUsers.value = response.data.blocked_users
    totalAdmins.value = response.data.admin_count
  } catch (error) {
    console.error('Failed to load dashboard data:', error)
  }
})
</script>

<style scoped>
.dashboard-container {
  /* No background, let .main handle it */
}

.main {
  flex: 1;
  padding: 2rem; /* Control padding here */
  color: var(--text);
  background: linear-gradient(135deg, #2d6df6, #a436f1);
  width: 100%;
  min-height: calc(100vh - 2rem); /* Adjust for top padding only, assuming sidebar handles height */
  box-sizing: border-box;
  position: relative;
  z-index: 1; 
}

.content-wrapper {
  max-width: 1200px; /* Constrain the overall width */
  margin: 0 auto; /* Center the content */
  width: 100%; /* Ensure it takes full width up to max-width */
}

.overview-metrics-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
  gap: 1.5rem;
  margin-bottom: 2rem;
  background: transparent;
  padding: 1 rem;
  border-radius: 12px;
}

.recent-activity-card {
  background-color: var(--card);
  padding: 1.5rem 2rem;
  border-radius: 15px;
  box-shadow: var(--shadow);
  border: 1px solid var(--border);
  max-width: 100%; /* Ensure it doesn't exceed the content wrapper */
  margin-top: 2rem; /* Add spacing from the metrics grid */
}

.recent-activity-card h3 {
  margin-top: 0;
  margin-bottom: 1.5rem;
  font-size: 1.5rem;
  font-weight: 600;
  color: var(--text);
}

.activity-list {
  display: flex;
  flex-direction: column;
  gap: 1rem;
}

.activity-item {
  display: flex;
  align-items: center;
  gap: 1rem;
}

.activity-icon {
  font-size: 1.2rem;
  color: var(--primary);
}

.activity-details {
  display: flex;
  flex-direction: column;
}

.activity-description {
  font-size: 1rem;
  color: var(--text);
}

.activity-time {
  font-size: 0.85rem;
  color: var(--text-secondary);
}

@media (max-width: 600px) {
  .main {
    padding: 1rem;
  }
  .content-wrapper {
    padding: 0 1rem; /* Add padding for smaller screens */
  }
  .overview-metrics-grid {
    grid-template-columns: 1fr;
    padding: 1rem;
  }
  .recent-activity-card {
    padding: 1rem;
  }
  .recent-activity-card h3 {
    font-size: 1.25rem;
  }
  .activity-description {
    font-size: 0.9rem;
  }
  .activity-time {
    font-size: 0.75rem;
  }
}
</style>