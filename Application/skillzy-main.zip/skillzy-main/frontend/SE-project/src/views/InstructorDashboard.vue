.dark-mode .announcement-modal {
  background: #23233a !important;
  color: #f3f3f3 !important;
  border: 1px solid #444 !important;
}
.dark-mode .announcement-modal h3 {
  color: #f3f3f3 !important;
  font-weight: 700;
}
.dark-mode .announcement-modal-date {
  color: #bdbdbd !important;
}
.dark-mode .announcement-modal-body {
  color: #f3f3f3 !important;
}
.dark-mode .close-modal-btn {
  background: #444 !important;
  color: #fff !important;
  border: 1px solid #888 !important;
}
.dark-mode .close-modal-btn:hover {
  background: #222 !important;
}

.dark-mode .announcement-modal h3 {
  color: #f3f3f3 !important;
}
<template>
  <div class="instructor-dashboard-page">
    <!-- <Header 
      :title="`Welcome Back, ${teacherName} 👋 ⭐ ✨`"
      subtitle="Ready to inspire young minds today? Your students are excited to learn!" 
    /> -->
    <header style="color: whitesmoke;">
      <h1>Welcome Back, {{ teacherName }} 👋 ⭐ ✨</h1>
      <p>Ready to inspire young minds today? Your students are excited to learn!</p>
    </header>
    <div v-if="error" class="error-message">
      {{ error }}
      <button @click="retryFetch" class="retry-button">Retry</button>
    </div>
    <div v-else-if="loading" class="loading-message">
      Loading dashboard data...
    </div>
    <div v-else>
      <div class="stats-cards-grid">
        <MetricCard
          icon="👥"
          label="Total Students"
          :value="dashboardData.summary?.total_students || 0"
          valueSuffix=" ⭐"
          iconBg="linear-gradient(135deg, #6a11cb 0%, #2575fc 100%)"
        />
        <MetricCard
          icon="📈"
          label="Active Students"
          :value="dashboardData.summary?.active_students || 0"
          valueSuffix=" ⭐"
          iconBg="linear-gradient(135deg, #4ef013 0%, #00bc40 100%)"
        />
        <MetricCard
          icon="📝"
          label="Assignments Created"
          :value="dashboardData.summary?.assignments_created ?? 12"
          valueSuffix=" ⭐"
          iconBg="linear-gradient(135deg, #FF6B6B 0%, #FFD166 100%)"
        />
        <MetricCard
          icon="📦"
          label="Resources Provided"
          :value="dashboardData.summary?.resources_provided ?? 8"
          valueSuffix=" ⭐"
          iconBg="linear-gradient(135deg, #a020f0 0%, #f72585 100%)"
        />
      </div>

      <div class="dashboard-content-grid">
        <div class="chart-card">
          <h3>Student Engagement <span class="chart-header-emoji">🎉</span></h3>
          <p class="chart-subtitle">Distribution of student activity levels</p>
          <div class="engagement-summary">
            <div class="engagement-item">
              <span class="color-dot highly-active"></span> Highly Active
              <span class="student-count">{{ engagementCounts.highlyActive }} students</span>
            </div>
            <div class="engagement-item">
              <span class="color-dot moderately-active"></span> Moderately Active
              <span class="student-count">{{ engagementCounts.moderatelyActive }} students</span>
            </div>
            <div class="engagement-item">
              <span class="color-dot low-activity"></span> Low Activity
              <span class="student-count">{{ engagementCounts.lowActivity }} students</span>
            </div>
            <div class="engagement-item">
              <span class="color-dot inactive"></span> Inactive
              <span class="student-count">{{ engagementCounts.inactive }} students</span>
            </div>
            <p class="engagement-feedback">
              Great job! {{ Math.round(engagementPercentage) }}% of your students are actively engaged!
            </p>
          </div>
        </div>
        
        <div class="chart-card">
          <h3>Course Completion <span class="chart-header-emoji">🥳</span></h3>
          <p class="chart-subtitle">Overall course completion rate</p>
          <div class="completion-list">
            <div class="completion-item">
              <span>All Courses</span>
              <span>{{ dashboardData.summary?.course_completion_percentage || 0 }}%</span>
            </div>
          </div>
          <p class="average-completion">Overall completion rate: {{ dashboardData.summary?.course_completion_percentage || 0 }}%</p>
        </div>

        <div class="chart-card announcements-card">
          <h3>Announcements <span class="chart-header-emoji">🎺</span></h3>
          <div class="announcements-scroll">
            <div class="announcement-message" v-for="(msg, idx) in announcements" :key="idx" @click="openAnnouncementModal(msg)" style="cursor:pointer;">
              <div class="announcement-title">{{ msg.title }}</div>
              <div class="announcement-body">
                <span v-if="msg.body.length > 120">{{ msg.body.slice(0, 120) }}... <span class="read-more">Read more</span></span>
                <span v-else>{{ msg.body }}</span>
              </div>
              <div class="announcement-date">{{ msg.date }}</div>
            </div>
            <div v-if="showAnnouncementModal" class="announcement-modal-overlay" @click.self="closeAnnouncementModal">
              <div class="announcement-modal">
                
                <div class="announcement-modal-date">{{ selectedAnnouncement?.date }}</div>
                <div class="announcement-modal-body">{{ selectedAnnouncement?.body }}</div>
                <button @click="closeAnnouncementModal" class="close-modal-btn">Close</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- Report Section -->
    
      
    <br>
    
    </br>
    <Report />
      
    
  </div>
</template>

<script setup>
import Report from '../components/Report.vue';
const showAnnouncementModal = ref(false);
const selectedAnnouncement = ref(null);
import { ref, onMounted, computed, watchEffect } from 'vue';
import { useRoute } from 'vue-router';
import Header from '../components/Header.vue';
import MetricCard from '../components/MetricCard.vue';
import api from '@/api';
import { Space } from 'lucide-vue-next';



// Format date to IST with date and time (hh:mm) using manual offset
function formatISTDate(dateStr) {
  if (!dateStr) return '';
  const date = new Date(dateStr);
  if (isNaN(date)) return dateStr;
  // Manually add IST offset (5.5 hours)
  const utc = date.getTime() + (date.getTimezoneOffset() * 60000);
  const istDate = new Date(utc + (5.5 * 60 * 60 * 1000));
  const y = istDate.getFullYear();
  const m = String(istDate.getMonth() + 1).padStart(2, '0');
  const d = String(istDate.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

const announcements = computed(() => {
  return (dashboardData.value.notifications || []).map(a => ({
    ...a,
    date: formatISTDate(a.date)
  }));
});

const route = useRoute();
const teacher_id = route.params.teacher_id;
const teacherName = ref('');
const dashboardData = ref({});
const error = ref(null);
const loading = ref(false);

const fetchDashboardData = async () => {
  loading.value = true;
  error.value = null;
  try {
    const response = await api.get(`/teacher/${teacher_id}/dashboard`);
    teacherName.value = response.data.teacher_name;
    dashboardData.value = response.data;
  } catch (err) {
    console.error('Dashboard load error:', err);
    error.value = err.response?.data?.detail || 'Failed to load dashboard. Please try again later.';
  } finally {
    loading.value = false;
  }
};

const retryFetch = () => {
  fetchDashboardData();
};

onMounted(fetchDashboardData);

const engagementCounts = computed(() => {
  // Use backend engagementCounts if available, else fallback to zeros
  return dashboardData.value.engagementCounts || {
    highlyActive: 0,
    moderatelyActive: 0,
    lowActivity: 0,
    inactive: 0,
  };
});

const engagementPercentage = computed(() => {
  const counts = engagementCounts.value;
  const totalStudents = counts.highlyActive + counts.moderatelyActive + counts.lowActivity + counts.inactive;
  const activeCount = counts.highlyActive + counts.moderatelyActive;
  return totalStudents > 0 ? (activeCount / totalStudents) * 100 : 0;
});

const isDarkMode = ref(false);
watchEffect(() => {
  isDarkMode.value = document.documentElement.classList.contains('dark-mode') || document.body.classList.contains('dark-mode');
});

function openAnnouncementModal(msg) {
  selectedAnnouncement.value = msg;
  showAnnouncementModal.value = true;
}
function closeAnnouncementModal() {
  showAnnouncementModal.value = false;
  selectedAnnouncement.value = null;
}
</script>

<style scoped>

.report-container {
  background: var(--bg-card);
  backdrop-filter: blur(20px);
  border: 1px solid var(--border);
  border-radius: 20px;
  padding: 2rem;
  margin-top: 2rem;
}

.announcement-message {
  max-width: 100%;
  min-height: 60px;
  width: 100%;
  display: flex;
  flex-direction: column;
  justify-content: center;
  white-space: pre-line;
  overflow: hidden;
  text-overflow: ellipsis;
  background: var(--card);
  border-radius: 8px;
  margin-bottom: 0;
  padding: 1rem;
  box-shadow: 0 2px 8px rgba(0,0,0,0.04);
  cursor: pointer;
  transition: box-shadow 0.2s;
}
.announcement-message:hover {
  box-shadow: 0 4px 16px rgba(0,0,0,0.10);
}
.announcement-body {
  max-height: 3.5em;
  overflow: hidden;
  text-overflow: ellipsis;
  word-break: break-word;
}
.read-more {
  color: #1F6CF3;
  font-weight: 500;
  font-size: 0.95em;
}
.announcement-modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100vw;
  height: 100vh;
  background: rgba(0,0,0,0.25);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
}
.announcement-modal {
  border-radius: 12px;
  padding: 2rem;
  max-width: 400px;
  width: 90vw;
  box-shadow: 0 8px 32px rgba(0,0,0,0.18);
  position: relative;
  background: #fff;
  color: #23233a;
  border: 1px solid #e0e0e0;
}

.announcement-modal-date {
  color: #888;
  font-size: 0.95em;
  margin-bottom: 1rem;
}
.announcement-modal-body {
  white-space: pre-line;
  margin-bottom: 1.5rem;
  word-break: break-word;
  max-width: 100%;
  overflow-wrap: break-word;
}
.close-modal-btn {
  background: #1F6CF3;
  color: #fff;
  border: none;
  border-radius: 6px;
  padding: 0.5rem 1.2rem;
  font-size: 1rem;
  cursor: pointer;
  transition: background 0.2s;
}
.close-modal-btn:hover {
  background: #163e8a;
}

.instructor-dashboard-page {
  /* No background here; it should be transparent to show the layout's gradient */
  padding: 2rem;
}
.error-message {
  background-color: #f8d7da;
  color: #721c24;
  padding: 1rem;
  border-radius: 8px;
  margin: 1rem 0;
  text-align: center;
}

.retry-button {
  margin-left: 1rem;
  padding: 0.5rem 1rem;
  background-color: #dc3545;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

.retry-button:hover {
  background-color: #c82333;
}

.loading-message {
  text-align: center;
  padding: 2rem;
  color: var(--text-secondary);
  font-style: italic;
}

.stats-cards-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 1.5rem;
  margin-top: 2rem;
}

.dashboard-content-grid {
  margin-top: 2rem;
  
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 1.5rem;
}

.chart-card {
  background-color: var(--card);
  padding: 1.5rem;
  border-radius: 12px;
  box-shadow: var(--shadow);
  border: 1px solid var(--border);
  display: flex;
  flex-direction: column;
}

.announcements-card {
  max-height: 320px;
  display: flex;
  flex-direction: column;
}
.announcements-scroll {
  max-height: 400px;
  overflow-y: auto;
  overflow-x: hidden;
  display: flex;
  flex-direction: column;
  gap: 1rem;
}
.announcement-message {
  max-width: 100%;
  min-height: 60px;
  width: 100%;
  display: flex;
  flex-direction: column;
  justify-content: center;
  white-space: pre-line;
  overflow: hidden;
  text-overflow: ellipsis;
  background: var(--card);
  border-radius: 8px;
  margin-bottom: 0;
  padding: 1rem;
  box-shadow: 0 2px 8px rgba(0,0,0,0.04);
  cursor: pointer;
  transition: box-shadow 0.2s;
  word-break: break-word;
  overflow-wrap: break-word;
}
.announcement-title {
  font-weight: 600;
  color: var(--primary);
  margin-bottom: 0.2rem;
}
.announcement-body {
  color: var(--text);
  font-size: 0.97rem;
  margin-bottom: 0.2rem;
}
.announcement-date {
  color: var(--text-secondary);
  font-size: 0.8rem;
  text-align: left;
  margin-top: 0.2rem;
}

.chart-card h3 {
  margin-top: 0;
  margin-bottom: 0.25rem;
  font-weight: 600;
  color: var(--text);
  display: flex;
  align-items: center;
  gap: 0.5rem;
}

.chart-header-emoji {
  font-size: 1.2rem;
}

.chart-subtitle {
  font-size: 0.9rem;
  color: var(--text-secondary);
  margin-top: 0;
  margin-bottom: 1.5rem;
}

.engagement-summary {
  display: flex;
  flex-direction: column;
  gap: 0.8rem;
}

.engagement-item {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  font-size: 0.95rem;
  color: var(--text);
}

.color-dot {
  width: 10px;
  height: 10px;
  border-radius: 50%;
  flex-shrink: 0;
}

.color-dot.highly-active { background-color: #4CAF50; }
.color-dot.moderately-active { background-color: #2196F3; }
.color-dot.low-activity { background-color: #FFC107; }
.color-dot.inactive { background-color: #F44336; }

.student-count {
  margin-left: auto;
  font-weight: 500;
  color: var(--text-secondary);
}

.engagement-feedback {
  margin-top: 1rem;
  font-style: italic;
  font-size: 0.9rem;
  color: var(--text-secondary);
  padding-top: 0.8rem;
  border-top: 1px dashed var(--border);
}

.completion-list {
  display: flex;
  flex-direction: column;
  gap: 0.8rem;
}

.completion-item {
  display: flex;
  justify-content: space-between;
  font-size: 0.95rem;
  color: var(--text);
}

.completion-item span:first-child {
  font-weight: 500;
}

.average-completion {
  margin-top: 1rem;
  font-size: 0.9rem;
  font-weight: 600;
  color: var(--primary);
  padding-top: 0.8rem;
  border-top: 1px dashed var(--border);
}

.no-data-message {
  font-style: italic;
  color: var(--text-secondary);
  text-align: center;
  padding: 20px 0;
}

@media (max-width: 768px) {
  .stats-cards-grid {
    grid-template-columns: 1fr;
  }
  .dashboard-content-grid {
    grid-template-columns: 1fr;
  }
  .chart-card {
    padding: 1rem;
  }
}
</style>

<style>
.announcement-modal {
  background: #fff;
  border: 1px solid #e0e0e0;
}
.dark-mode .announcement-modal {
  background: #23233a !important;
  color: #f3f3f3 !important;
  border: 1px solid #444 !important;
}
.dark-mode .announcement-modal h3 {
  color: #f3f3f3 !important;
}
.dark-mode .announcement-modal-date {
  color: #bdbdbd !important;
}
.dark-mode .announcement-modal-body {
  color: #f3f3f3 !important;
}
.dark-mode .close-modal-btn {
  background: #444 !important;
  color: #fff !important;
  border: 1px solid #888 !important;
}
.dark-mode .close-modal-btn:hover {
  background: #222 !important;
}
</style>