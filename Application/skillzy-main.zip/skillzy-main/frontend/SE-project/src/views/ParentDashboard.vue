<template>
  <div class="parent-dashboard">

<header v-if="parentProfile?.user">
  <!-- <pre>{{ parentProfile.user.full_name }}</pre> -->
  <h1>Good to see you!, {{ parentProfile.user.full_name }} 👋</h1>
  <p>Here's an overview of your child's learning journey</p>
</header>

    <div class="dashboard-container">

      <!-- Enhanced Profile Summary -->
      <section class="profile-summary">
        <div class="profile-background"></div>
        <div class="profile-content">
          <div class="child-info" v-if="childProfile.user">
            <h2>{{ childProfile.user.full_name }}</h2>
            <div class="child-details">
              <span class="detail-item">
                <i class="icon">🎓</i>
                <strong>Email:</strong> {{ childProfile.user.email }}
              </span>
              <span class="detail-item">
                <i class="icon">📚</i>
                <strong>Status:</strong> {{ childProfile.user.user_status }}
              </span>
            </div>
            
            <!-- report section -->
          </div>
          <div class="report-section">
            <Report />
          </div>
        </div>
      </section>

      <!-- Enhanced Tab Navigation -->
      <div class="tab-navigation">
        <button v-for="tab in tabs" :key="tab.id" :class="{ active: activeTab === tab.id }" @click="activeTab = tab.id">
          <i class="tab-icon">{{ tab.icon }}</i>
          {{ tab.name }}
        </button>
      </div>

      <!-- Tab Content -->
      <div class="tab-content">
        <!-- Overview Tab -->
        <div v-if="activeTab === 'overview'" class="tab-pane overview-grid">
          <div class="overview-left">
            <!-- Enhanced Stats Cards -->
            <div class="section-header">
              <h3><i class="icon">📊</i> Child Statistics</h3>
            </div>
            <div class="stats-grid">
              <div class="stat-card tasks">
                <div class="stat-icon">📋</div>
                <div class="stat-content">
                  <h4>Today's Tasks</h4>
                  <span class="stat-value">{{ childStats.today_tasks_count || 0 }}</span>
                  <span class="stat-subtitle">Active tasks</span>
                </div>
              </div>

              <div class="stat-card assignments">
                <div class="stat-icon">📝</div>
                <div class="stat-content">
                  <h4>Upcoming Assignments</h4>
                  <span class="stat-value">{{ childStats.upcoming_assignment_count || 0 }}</span>
                  <span class="stat-subtitle">Due this week</span>
                </div>
              </div>

              <div class="stat-card completed">
                <div class="stat-icon">✅</div>
                <div class="stat-content">
                  <h4>Completed</h4>
                  <span class="stat-value">{{ childStats.completed_assignment_count || 0 }}</span>
                  <span class="stat-subtitle">This month</span>
                </div>
              </div>
            </div>

            <!-- Enhanced Notifications -->
            <div class="section-header">
              <h3><i class="icon">🔔</i> Recent Notifications</h3>
            </div>
            <div class="notifications-container">
              <div v-if="notifications.length" class="notifications-list">
                <div v-for="note in notifications.slice(0, 5)" :key="note.id" class="notification-item">
                  <div class="notification-icon">📢</div>
                  <div class="notification-content">
                    <p>{{ note.message }}</p>
                    <small>{{ note.time || '2 hours ago' }}</small>
                  </div>
                </div>
              </div>
              <div v-else class="no-notifications">
                <i class="icon">✨</i>
                <p>No new notifications</p>
              </div>
            </div>
          </div>

          <div class="overview-right">
            <!-- Enhanced Calendar with Expandable Section -->
            <div class="calendar-section">
              <div class="section-header">
                <h3 style="color: black;"><i class="icon">📅</i> Your Child's Tasks</h3>
                  <button
                    v-if="allTasks.length > 3"
                    @click="toggleExpandedTasks"
                    class="expand-btn"
                    :class="{ expanded: showAllTasks }"
                  >
                    {{ showAllTasks ? 'Show Less' : 'See More' }}
                    <i class="arrow">{{ showAllTasks ? '▲' : '▼' }}</i>
                  </button>
              </div>

<div class="tasks-container" :class="{ expanded: showAllTasks }">
  <template v-if="tasks && tasks.length">
    <div class="task-item" v-for="task in displayedTasks" :key="task.id">
      <div class="task-date">
        <span class="day">{{ task.day }}</span>
        <span class="month">{{ task.month }}</span>
      </div>
      <div class="task-content">
        <h4>{{ task.title }}</h4>
        <p>{{ task.subject }}</p>
        <span class="task-time">{{ task.time }}</span>
      </div>
      <div class="task-priority" :class="task.priority">
        {{ task.priority }}
      </div>
    </div>
  </template>

  <div v-else class="no-tasks-message">
    <i class="icon">📭</i>
    <p>No upcoming tasks</p>
  </div>
</div>

            </div>

          </div>
        </div>

        <!-- Charts Tab -->
        <Chart v-if="activeTab === 'charts'" :assignments="childStats.assignments" />

        <!-- Enhanced Achievements Tab -->
        <div v-if="activeTab === 'achievements'" class="tab-pane achievements-section">
          <div class="section-header">
            <h3><i class="icon">🏆</i> Achievements & Milestones <i class="icon">🏆</i> </h3>
          </div>

          <div class="achievements-stats">
            <div class="achievement-stat">
              <span class="stat-number">{{ achievements.length }}</span>
              <span class="stat-label">Total Achievements</span>
            </div>
          </div>

          <div v-if="achievements.length > 0" class="achievements-grid">
            <div v-for="achievement in achievements" :key="achievement.id" class="achievement-card"
              :class="achievement.category">
              <div class="achievement-header">
                <div class="achievement-icon">{{ achievement.icon }}</div>
                <!-- <div class="achievement-badge" v-if="achievement.recent">New!</div> -->
              </div>
              <div class="achievement-content">
                <h4>{{ achievement.title }}</h4>
                <p>{{ achievement.description }}</p>
                <div class="achievement-meta">
                  <span class="achievement-date">{{ achievement.date || 'Unknown Date' }}</span>
                  <!-- <span class="achievement-category">{{ achievement.category || 'lol' }}</span> -->
                </div>
              </div>
              <div class="achievement-glow"></div>
            </div>
          </div>
          <div v-else class="no-achievements-message">
            <i class="icon">📭</i>
            <p>No achievements found yet! Kindly check again later.</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
// import Header from '../components/Header.vue';
import Report from '../components/Report.vue';
import Chart from '../components/Chart.vue';
import api from '../api';
import { ref, computed, onMounted } from 'vue';
import dayjs from 'dayjs'

const activeTab = ref('overview');
const showAllTasks = ref(false);
var childProfile = ref({});
var childStats = ref({ assignments: [] })
var parentProfile = ref({});
var tasks = ref({});

// Dynamic Time Per Subject Chart Data
const timePerSubjectData = computed(() => {
  if (!childStats.value.timePerSubject) {
    return {
      labels: [],
      datasets: [],
    };
  }

  const labels = Object.keys(childStats.value.timePerSubject);
  const data = Object.values(childStats.value.timePerSubject);
  const backgroundColors = ['#3b82f6', '#10b981', '#f97316', '#ef4444'];

  return {
    labels,
    datasets: [
      {
        data,
        backgroundColor: backgroundColors.slice(0, labels.length),
      },
    ],
  };
});

// Dynamic Score Comparison Chart Data
const scoreComparisonData = computed(() => {
  if (!childStats.value.scores || !childStats.value.classAverageScores) {
    return {
      labels: [],
      datasets: [],
    };
  }

  const labels = Object.keys(childStats.value.scores);
  const childScores = labels.map(subject => childStats.value.scores[subject]);
  const classScores = labels.map(subject => childStats.value.classAverageScores[subject]);

  return {
    labels,
    datasets: [
      {
        label: "Your Child's Score",
        data: childScores,
        backgroundColor: '#a78bfa',
      },
      {
        label: 'Class Average',
        data: classScores,
        backgroundColor: '#d1d5db',
      },
    ],
  };
});
const achievements = ref([]);

const notifications = ref({});

import { useRoute } from 'vue-router';
const route = useRoute();

async function fetchParentProfile() {
  try {
    const parentId = computed(() => route.params.parentId);
    const res = await api.get(`parent/${parentId.value}/profile`);
    parentProfile.value = res.data;
    console.log("Parent Profile:", parentProfile);
  } catch (e) {
    console.error("Error fetching profile:", e);
  }
}

async function fetchChildProfile() {
  try {
    const parentId = computed(() => route.params.parentId);
    const res = await api.get(`parent/${parentId.value}/child/profile`);
    childProfile.value = res.data;
    console.log("Child Profile:", res);
  } catch (e) {
    console.error("Error fetching profile:", e);
  }
}

async function fetchChildStats() {
  try {
    const parentId = computed(() => route.params.parentId);
    const res = await api.get(`parent/child_stats/${parentId.value}`);
    childStats.value = res.data;
    console.log("Child Stats:", childStats);
  } catch (e) {
    console.error("Error fetching profile:", e);
  }
}

async function fetchParentNotifications() {
  try {
    const parentId = computed(() => route.params.parentId);
    const res = await api.get(`parent/notifications/${parentId.value}`);
    const allNotifications = res.data;
    const now = new Date();
    const oneDayAgo = new Date(now.getTime() - 24 * 60 * 60 * 1000);

    notifications.value = allNotifications.filter(notification => {
      const notificationTime = new Date(notification.timestamp);
      return notificationTime >= oneDayAgo;
    });
    console.log("Recent Notifications (last 24 hrs):", notifications.value);
  } catch (e) {
    console.error("Error fetching notifications:", e);
  }
}

async function fetchChildAchievements() {
  try {
    const parentId = route.params.parentId
    const res = await api.get(`parent/achievements/${parentId}`)

    achievements.value = res.data.map(item => {
      return {
        id: item.id,
        icon: pickIcon(item.badge_type),           // custom helper for emoji/icon
        title: item.badge_type,                    // using badge type as title
        description: `${item.badge_points} points`,// could be improved if API returns desc
        category: mapCategory(item.badge_type),    // 'academic' | 'behavioral' | ...
        recent: false,                             // or logic to set true if within 30 days
        date: new Date().toISOString().split('T')[0]  // dummy date until API provides actual
      }
    })
  } catch (e) {
    console.error("Error fetching achievements:", e)
  }
}

// Example icon picker
function pickIcon(type) {
  if (!type) return '🏅'
  const lower = type.toLowerCase()
  if (lower.includes('academic')) return '🎓'
  if (lower.includes('star')) return '⭐'
  return '🏅'
}

// Example category mapper
function mapCategory(type) {
  const lower = type.toLowerCase()
  if (lower.includes('academic')) return 'academic'
  if (lower.includes('behavior')) return 'behavioral'
  if (lower.includes('special')) return 'special'
  return 'academic' // default
}

async function fetchChildTasks() {
  try {
    const parentId = route.params.parentId
    const res = await api.get(`/parent/tasks/${parentId}`) // your endpoint here
    console.log("Fetched Tasks:", res.data);
    const mappedTasks = res.data.map(t => {
      const due = dayjs(t.due_date);
      return {
        id: t.id,
        day: due.format('DD'),
        month: due.format('MMM'),
        title: t.title,
        subject: t.description || 'N/A',
        time: due.format('h:mm A'),
        priority: mapStatusToPriority(t.status)
      };
    });

    tasks.value = mappedTasks;
    allTasks.value = mappedTasks; // ✅ required for toggle to work

  } catch (err) {
    console.error('Error fetching tasks:', err)
  }
}

// Helper to translate API status to your priority class
function mapStatusToPriority(status) {
  switch (status) {
    case 'overdue':
      return 'high'
    case 'pending':
      return 'medium'
    case 'complete':
      return 'low'
    default:
      return 'low'
  }
}


onMounted(async () => {
  await Promise.all([
    fetchParentProfile(),
    fetchChildProfile(),
    fetchChildStats(),
    fetchParentNotifications(),
    fetchChildAchievements(),
    fetchChildTasks()
  ]);
});

const tabs = ref([
  { id: 'overview', name: 'Overview', icon: '📊' },
  { id: 'charts', name: 'Your Child\'s Analytics', icon: '📈' },
  { id: 'achievements', name: 'Achievements', icon: '🏆' }
]);

// Sample tasks data
const allTasks = ref([]);

const displayedTasks = computed(() => {
  return showAllTasks.value ? allTasks.value : allTasks.value.slice(0, 3);
});

const toggleExpandedTasks = () => {
  if (allTasks.value.length > 3) {
    showAllTasks.value = !showAllTasks.value;
  }
};
</script>

<style scoped>
.report-section {
  margin-top: 2rem;
}

.parent-dashboard {
  min-height: 100vh;
  /* background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); */
  background: linear-gradient(135deg, #B12BE2, #1F6CF3);
  padding: 2rem;
  color: whitesmoke;
}

.dashboard-container {
  max-width: 1400px;
  margin: 0 auto;
  padding: 0 1rem;
}

/* Enhanced Profile Summary */
.profile-summary {
  position: relative;
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(10px);
  border-radius: 20px;
  margin: 2rem 0;
  overflow: hidden;
  box-shadow: 0 10px 40px rgba(0, 0, 0, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.2);
}

.profile-background {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  height: 100px;
  background: linear-gradient(135deg, #667eea, #764ba2);
  opacity: 0.00000000000001;
}

.profile-content {
  position: relative;
  display: flex;
  align-items: center;
  gap: 2rem;
  padding: 2rem;
  flex-wrap: wrap;
}

.child-avatar-container {
  position: relative;
}

.child-photo {
  width: 100px;
  height: 100px;
  border-radius: 50%;
  object-fit: cover;
  border: 4px solid #667eea;
  box-shadow: 0 8px 25px rgba(102, 126, 234, 0.3);
  transition: transform 0.3s ease;
}

.child-photo:hover {
  transform: scale(1.05);
}

.online-indicator {
  position: absolute;
  bottom: 8px;
  right: 8px;
  width: 20px;
  height: 20px;
  background: #10b981;
  border-radius: 50%;
  border: 3px solid white;
  box-shadow: 0 2px 8px rgba(16, 185, 129, 0.3);
}

.child-info {
  flex: 1;
  min-width: 300px;
}

.child-info h2 {
  margin: 0 0 1rem 0;
  font-size: 2rem;
  font-weight: 700;
  color: #1f2937;
}

.child-details {
  display: flex;
  flex-wrap: wrap;
  gap: 1.5rem;
}

.detail-item {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  color: #6b7280;
  font-weight: 500;
}

.detail-item .icon {
  font-size: 1.2rem;
}

.profile-actions {
  display: flex;
  gap: 1rem;
  flex-wrap: wrap;
}

.action-btn {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.75rem 1.5rem;
  border: none;
  border-radius: 12px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s ease;
}

.action-btn.primary {
  background: linear-gradient(135deg, #667eea, #764ba2);
  color: white;
}

.action-btn.secondary {
  background: rgba(102, 126, 234, 0.1);
  color: #667eea;
  border: 2px solid #667eea;
}

.action-btn:hover {
  transform: translateY(-2px);
  box-shadow: 0 8px 25px rgba(102, 126, 234, 0.3);
}

/* Enhanced Tab Navigation */
.tab-navigation {
  display: flex;
  gap: 0.5rem;
  background: rgba(255, 255, 255, 0.1);
  backdrop-filter: blur(10px);
  border-radius: 16px;
  padding: 0.5rem;
  margin-bottom: 2rem;
}

.tab-navigation button {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  flex: 1;
  padding: 1rem 1.5rem;
  border: none;
  background: transparent;
  color: rgba(255, 255, 255, 0.7);
  font-weight: 600;
  border-radius: 12px;
  cursor: pointer;
  transition: all 0.3s ease;
}

.tab-navigation button.active {
  background: white;
  color: #1f2937;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
}

.tab-icon {
  font-size: 1.2rem;
}

/* Enhanced Overview Grid */
.overview-grid {
  display: grid;
  grid-template-columns: 2fr 1fr;
  gap: 2rem;
}

.section-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 1.5rem;
}

.section-header h3 {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  margin: 0;
  color: white;
  font-size: 1.3rem;
  font-weight: 700;
}

/* Enhanced Stats Grid */
.stats-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 1.5rem;
  margin-bottom: 2rem;
}

.stat-card {
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(10px);
  border-radius: 16px;
  padding: 1.5rem;
  display: flex;
  align-items: center;
  gap: 1rem;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.2);
  transition: transform 0.3s ease;
}

.stat-card:hover {
  transform: translateY(-5px);
}

.stat-icon {
  font-size: 2.5rem;
  padding: 1rem;
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
}

.stat-card.tasks .stat-icon {
  background: rgba(59, 130, 246, 0.1);
}

.stat-card.assignments .stat-icon {
  background: rgba(249, 115, 22, 0.1);
}

.stat-card.completed .stat-icon {
  background: rgba(16, 185, 129, 0.1);
}

.stat-card.grade .stat-icon {
  background: rgba(139, 92, 246, 0.1);
}

.stat-content h4 {
  margin: 0 0 0.5rem 0;
  color: #374151;
  font-size: 0.9rem;
  font-weight: 600;
}

.stat-value {
  display: block;
  font-size: 2rem;
  font-weight: 700;
  color: #1f2937;
  margin-bottom: 0.25rem;
}

.stat-subtitle {
  font-size: 0.8rem;
  color: #6b7280;
}

/* Enhanced Notifications */
.notifications-container {
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(10px);
  border-radius: 16px;
  padding: 1.5rem;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.2);
}

.mark-read-btn {
  background: rgba(102, 126, 234, 0.1);
  color: #667eea;
  border: 1px solid #667eea;
  padding: 0.5rem 1rem;
  border-radius: 8px;
  cursor: pointer;
  font-size: 0.8rem;
  transition: all 0.3s ease;
}

.notification-item {
  display: flex;
  align-items: flex-start;
  gap: 1rem;
  padding: 1rem 0;
  border-bottom: 1px solid #e5e7eb;
}

.notification-item:last-child {
  border-bottom: none;
}

.notification-icon {
  font-size: 1.5rem;
  padding: 0.5rem;
  background: rgba(102, 126, 234, 0.1);
  border-radius: 8px;
}

.notification-content p {
  margin: 0 0 0.25rem 0;
  color: #374151;
}

.notification-content small {
  color: #6b7280;
}

/* Enhanced Calendar Section */
.calendar-section {
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(10px);
  border-radius: 16px;
  padding: 1.5rem;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.2);
}

.expand-btn {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  background: #667eea;
  color: white;
  border: none;
  padding: 0.5rem 1rem;
  border-radius: 8px;
  cursor: pointer;
  font-size: 0.9rem;
  transition: all 0.3s ease;
}

.expand-btn:hover {
  background: #5a67d8;
}

.arrow {
  transition: transform 0.3s ease;
}

.expand-btn.expanded .arrow {
  transform: rotate(180deg);
}

.tasks-container {
  max-height: 300px;
  overflow: hidden;
  transition: max-height 0.3s ease;
}

.tasks-container.expanded {
  max-height: 600px;
}

.task-item {
  display: flex;
  align-items: center;
  gap: 1rem;
  padding: 1rem;
  margin-bottom: 1rem;
  background: #f8fafc;
  border-radius: 12px;
  border-left: 4px solid #667eea;
  transition: transform 0.3s ease;
}

.task-item:hover {
  transform: translateX(5px);
}

.task-date {
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 0.5rem;
  background: white;
  border-radius: 8px;
  min-width: 60px;
}

.task-date .day {
  font-size: 1.5rem;
  font-weight: 700;
  color: #1f2937;
}

.task-date .month {
  font-size: 0.8rem;
  color: #6b7280;
}

.task-content {
  flex: 1;
}

.task-content h4 {
  margin: 0 0 0.25rem 0;
  color: #1f2937;
  font-weight: 600;
}

.task-content p {
  margin: 0 0 0.25rem 0;
  color: #6b7280;
  font-size: 0.9rem;
}

.task-time {
  font-size: 0.8rem;
  color: #9ca3af;
}

.task-priority {
  padding: 0.25rem 0.75rem;
  border-radius: 12px;
  font-size: 0.8rem;
  font-weight: 600;
}

.task-priority.high {
  background: #fef2f2;
  color: #dc2626;
}

.task-priority.medium {
  background: #fffbeb;
  color: #d97706;
}

.task-priority.low {
  background: #f0fdf4;
  color: #16a34a;
}

/* Enhanced Charts Section */
.charts-section {
  color: white;
}

.chart-filters {
  display: flex;
  gap: 0.5rem;
}

.filter-btn {
  background: rgba(255, 255, 255, 0.1);
  color: rgba(255, 255, 255, 0.8);
  border: 1px solid rgba(255, 255, 255, 0.2);
  padding: 0.5rem 1rem;
  border-radius: 8px;
  cursor: pointer;
  transition: all 0.3s ease;
}

.filter-btn.active,
.filter-btn:hover {
  background: white;
  color: #1f2937;
}

.charts-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
  gap: 2rem;
}

.chart-container {
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(10px);
  border-radius: 16px;
  padding: 1.5rem;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.2);
  position: relative;

}

.chart-container h4 {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  margin: 0 0 1rem 0;
  color: #1f2937;
  font-weight: 600;
}

/* Enhanced Achievements Section */
.achievements-section {
  color: white;
}

.achievement-filters {
  display: flex;
  gap: 0.5rem;
}

.achievements-stats {
  display: flex;
  justify-content: center;
  gap: 2rem;
  margin: 2rem 0;
  padding: 1.5rem;
  background: rgba(255, 255, 255, 0.1);
  border-radius: 16px;
  backdrop-filter: blur(10px);
}

.achievement-stat {
  text-align: center;
}

.stat-number {
  display: block;
  font-size: 2.5rem;
  font-weight: 700;
  color: white;
}

.stat-label {
  font-size: 0.9rem;
  color: rgba(255, 255, 255, 0.8);
}

.achievements-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 2rem;
  margin-bottom: 2rem;
}

.achievement-card {
  position: relative;
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(10px);
  border-radius: 20px;
  padding: 2rem;
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.2);
  transition: transform 0.3s ease;
  overflow: hidden;
}

.achievement-card:hover {
  transform: translateY(-10px);
}

.achievement-card.academic {
  border-left: 6px solid #3b82f6;
}

.achievement-card.behavioral {
  border-left: 6px solid #10b981;
}

.achievement-card.special {
  border-left: 6px solid #8b5cf6;
}

.achievement-header {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  margin-bottom: 1rem;
}

.achievement-icon {
  font-size: 3rem;
  padding: 1rem;
  background: linear-gradient(135deg, #f8fafc, #e2e8f0);
  border-radius: 16px;
  display: flex;
  align-items: center;
  justify-content: center;
}

.achievement-badge {
  background: linear-gradient(135deg, #ef4444, #dc2626);
  color: white;
  padding: 0.25rem 0.75rem;
  border-radius: 12px;
  font-size: 0.8rem;
  font-weight: 600;
  animation: pulse 2s infinite;
}

@keyframes pulse {

  0%,
  100% {
    opacity: 1;
  }

  50% {
    opacity: 0.7;
  }
}

.achievement-content h4 {
  margin: 0 0 0.5rem 0;
  color: #1f2937;
  font-size: 1.3rem;
  font-weight: 700;
}

.achievement-content p {
  margin: 0 0 1rem 0;
  color: #6b7280;
  line-height: 1.5;
}

.achievement-meta {
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-size: 0.8rem;
}

.achievement-date {
  color: #9ca3af;
}

.achievement-category {
  background: rgba(102, 126, 234, 0.1);
  color: #667eea;
  padding: 0.25rem 0.75rem;
  border-radius: 12px;
  font-weight: 600;
}

.achievement-glow {
  position: absolute;
  top: -50%;
  left: -50%;
  width: 200%;
  height: 200%;
  background: radial-gradient(circle, rgba(102, 126, 234, 0.1) 0%, transparent 70%);
  opacity: 0;
  transition: opacity 0.3s ease;
}

.achievement-card:hover .achievement-glow {
  opacity: 1;
}

/* Next Achievements */
.next-achievements {
  background: rgba(255, 255, 255, 0.1);
  backdrop-filter: blur(10px);
  border-radius: 16px;
  padding: 2rem;
  border: 1px solid rgba(255, 255, 255, 0.2);
}

.next-achievements h4 {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  margin: 0 0 1.5rem 0;
  color: white;
  font-weight: 700;
}

.milestone-list {
  display: flex;
  flex-direction: column;
  gap: 1rem;
}

.milestone-item {
  display: flex;
  align-items: center;
  gap: 1rem;
  padding: 1rem;
  background: rgba(255, 255, 255, 0.1);
  border-radius: 12px;
}

.milestone-icon {
  font-size: 2rem;
  padding: 0.75rem;
  background: rgba(255, 255, 255, 0.2);
  border-radius: 12px;
}

.milestone-content {
  flex: 1;
}

.milestone-content h5 {
  margin: 0 0 0.5rem 0;
  color: white;
  font-weight: 600;
}

.progress-bar {
  width: 100%;
  height: 8px;
  background: rgba(255, 255, 255, 0.2);
  border-radius: 4px;
  overflow: hidden;
  margin-bottom: 0.25rem;
}

.progress-fill {
  height: 100%;
  background: linear-gradient(90deg, #10b981, #34d399);
  border-radius: 4px;
  transition: width 0.3s ease;
}

.milestone-content small {
  color: rgba(255, 255, 255, 0.8);
  font-size: 0.8rem;
}

.no-notifications {
  text-align: center;
  padding: 2rem;
  color: #6b7280;
}

.no-notifications .icon {
  font-size: 3rem;
  margin-bottom: 1rem;
  display: block;
}

/* Responsive Design */
@media (max-width: 1024px) {
  .overview-grid {
    grid-template-columns: 1fr;
  }

  .charts-grid {
    grid-template-columns: 1fr;
  }

  .stats-grid {
    grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
  }
}

@media (max-width: 768px) {
  .profile-content {
    flex-direction: column;
    text-align: center;
    gap: 1.5rem;
  }

  .child-details {
    justify-content: center;
  }

  .tab-navigation {
    flex-direction: column;
  }

  .achievements-stats {
    flex-direction: column;
    gap: 1rem;
  }

  .chart-filters,
  .achievement-filters {
    flex-wrap: wrap;
  }

  .dashboard-container {
    padding: 0 0.5rem;
  }
}

.tab-pane {
  animation: fadeIn 0.5s ease;
}

@keyframes fadeIn {
  from {
    opacity: 0;
    transform: translateY(20px);
  }

  to {
    opacity: 1;
    transform: translateY(0);
  }
}
</style>