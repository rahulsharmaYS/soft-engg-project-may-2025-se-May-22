<template>
  <div class="page-wrapper">
    <div class="hero-header">
      <h1 class="animate__animated animate__pulse animate__infinite">Join Skillzy Today!</h1>
      <p>Start your learning adventure with us</p>
    </div>
    <div class="hero-subtitle-1">
      <h3 style="color: wheat;">Create Your Account! 🌟</h3>
    </div>
    <div class="hero-subtitle-2">
      <p>Join thousands of young learners building essential life skills through interactive learning and fun activities.</p>
    </div>
    <div class="floating-shapes">
      <div class="shape shape-1"></div>
      <div class="shape shape-2"></div>
      <div class="shape shape-3"></div>
    </div>
    
    <!-- Updated Hero Section with Split Layout -->
    <div class="hero-section">
      <!-- Left Side - Registration Form -->
      <div class="register-container">
        <div class="back-button">
          <router-link to="/" class="back-link">
            ← Back to Home
          </router-link>
        </div>

        <div class="register-box">
          <div class="lottie-header-container">
            <DotLottieVue 
              class="lottie-left" 
              autoplay 
              loop 
              src="https://lottie.host/3d456750-bf97-4ce2-8f65-9e67c5424688/4eAOy23nuj.lottie" 
            />
            
            <h2>Create an Account 🎉</h2>
            
            <DotLottieVue 
              class="lottie-right" 
              autoplay 
              loop 
              src="https://lottie.host/a02b7f5a-1688-42d1-ab5c-2e0b069b1daa/Fjm5E8bq9L.lottie" 
            />
          </div>

          <p class="subtitle">Get started on your journey with us</p>

          <form @submit.prevent="handleRegister" class="form">
            <!-- Account Type Selection -->
            <div class="sticky-register-wrapper">
              <p class="message success" v-if="success">{{ success }} ✅</p>
              <p class="message error" v-if="error">{{ error }} ❌</p>
            </div>
            <div class="input-group">
              <label class="input-label">👤 Account Type</label>
              <select v-model="role" class="select-input" @change="resetForm">
                <option value="student">Sign up as a Student</option>
                <option value="teacher">Sign up as a Teacher</option>
                <option value="parent">Sign up as a Parent</option>
              </select>
            </div>

            <!-- Name Fields -->
            <div class="name-group">
              <div class="input-group">
                <label class="input-label">First Name</label>
                <input
                  type="text"
                  v-model="firstName"
                  placeholder="Enter your first name"
                  class="input"
                  required
                />
              </div>
              <div class="input-group">
                <label class="input-label">Last Name</label>
                <input
                  type="text"
                  v-model="lastName"
                  placeholder="Enter your last name"
                  class="input"
                  required
                />
              </div>
            </div>

            <!-- User ID -->
            <div class="input-group">
              <label class="input-label">🆔 User ID</label>
              <input
                type="text"
                v-model="userid"
                placeholder="Enter your user ID"
                class="input"
                required
              />
            </div>

            <!-- Email -->
            <div class="input-group">
              <label class="input-label">📧 Email Address</label>
              <input
                type="email"
                v-model="email"
                placeholder="Enter your email address"
                class="input"
                required
              />
            </div>

            <!-- Password -->
            <div class="input-group">
              <label class="input-label">🔒 Password</label>
              <input
                type="password"
                v-model="password"
                placeholder="Atleast 8 characters, 1 uppercase letter, 1 lowercase letter, 1 number"
                class="input"
                required
              />
              <p v-if="passwordError" class="message error">{{ passwordError }} ❌</p>
            </div>


            <!-- Student Specific Fields -->
            <template v-if="role === 'student'">
              <!-- Grade Level -->
              <div class="input-group">
                <label class="input-label">📚 Grade Level</label>
                <select v-model="grade" class="select-input" required @change="onGradeChange">
                  <option disabled value="">Select your grade...</option>
                  <option value="3">3rd Grade</option>
                  <option value="4">4th Grade</option>
                  <option value="5">5th Grade</option>
                  <option value="6">6th Grade</option>
                  <option value="7">7th Grade</option>
                  <option value="8">8th Grade</option>
                </select>
              </div>

              <template v-if="showSkillsSelection">
                <p class="skills-info">Select the skills you want to learn:</p>

                <div class="skills-group">
                  <label class="skills-heading">🎯 Which skills do you want to learn?</label>
                  <div class="skills-options">
                    <div 
                      v-for="skill in availableSkills" 
                      :key="skill.id" 
                      class="skill-pill" 
                      :class="{ selected: selectedSkills.some(c => c.id === skill.id) }" 
                      @click="toggleSkill(skill)"
                    >
                      {{ skill.name }}
                    </div>
                  </div>
                </div>
              </template>

              <div v-if="showSkillsSelection && selectedSkills.length === 0" class="no-skills-warning">
                <p class="warning-text">Please select at least one skill to proceed.</p>
              </div>

              <!-- Teacher Selection - Only show after skills are selected -->    
              <div v-if="showSkillsSelection && selectedSkills.length > 0" class="teacher-selection-section">
                <h3 class="teacher-heading">👨‍🏫 Choose Your Teachers</h3>
                <p class="teacher-subheading">Select teachers for your chosen skills</p>
                
                <!-- Search and Filter Controls -->
                <div class="teacher-filters">
                  <div class="search-container">
                    <div class="search-input-wrapper">
                      <span class="search-icon">🔍</span>
                      <input
                        type="text"
                        v-model="searchQuery"
                        placeholder="Search teachers by name..."
                        class="search-input"
                      />
                    </div>
                  </div>
                  
                  <div class="filter-controls">
                    <div class="filter-group">
                      <label class="filter-label">Experience</label>
                      <select v-model="experienceFilter" class="filter-select">
                        <option value="">All Experience</option>
                        <option value="new">New (0-1 years)</option>
                        <option value="mid">Mid (2-5 years)</option>
                        <option value="experienced">Experienced (6-10 years)</option>
                        <option value="senior">Senior (11-15 years)</option>
                        <option value="expert">Expert (16+ years)</option>
                      </select>
                    </div>
                    
                    <!-- <div class="filter-group">
                      <label class="filter-label">Rating</label>
                      <select v-model="ratingFilter" class="filter-select">
                        <option value="">All Ratings</option>
                        <option value="high">Excellent (4.5+)</option>
                        <option value="good">Good (4.0+)</option>
                      </select>
                    </div> -->
                    
                    <button type="button" class="reset-filters-btn" @click="resetFilters">
                      Clear Filters
                    </button>
                  </div>
                </div>
                
                <div v-for="skill in selectedSkills" :key="skill.id" class="skill-teachers">
                  <h4 class="skill-name">{{ skill.name }} Teachers</h4>
                  
                  <div class="teachers-grid">
                    <div 
                      v-for="teacher in getFilteredTeachersForSkill(skill.id)" 
                      :key="teacher.id" 
                      class="teacher-card"
                      :class="{ selected: selectedTeachers.some(t => t.id === teacher.id) }"
                      @click="toggleTeacherSelection(teacher)"
                    >
                      <!-- <div class="teacher-avatar">
                        <img :src="teacher.profilePic" :alt="teacher.name" />
                      </div> -->
                      <div class="teacher-info">
                        <p class="teacher-name"><strong>Instructor Name: </strong>{{ teacher.full_name }}</p>
                        <p class="teacher-exp"><strong>Experience: </strong>{{ teacher.experience }} years exp</p>
                        <!-- <div class="teacher-rating">
                          <span v-for="n in 5" :key="n" class="star" :class="{ filled: n <= Math.floor(teacher.rating) }">⭐</span>
                          <span class="rating-text">({{ teacher.rating }})</span>
                        </div>
                        <p class="teacher-skills">{{ teacher.subject?.name || '' }}</p> -->
                      </div>
                      <div class="selection-indicator">
                        <span v-if="selectedTeachers.some(t => t.id === teacher.id)" class="selected-icon">✓</span>
                      </div>
                    </div>
                  </div>
                  
                  <!-- No teachers found message -->
                  <div v-if="getFilteredTeachersForSkill(skill.id).length === 0" class="no-teachers-found">
                    <p>No teachers found matching your criteria for {{ skill.name }}.</p>
                    <button type="button" class="clear-search-btn" @click="resetFilters">
                      Clear filters to see all teachers
                    </button>
                  </div>
                  
                  <!-- Pagination -->
                  <div v-if="getTotalPagesForSkill(skill.id) > 1" class="pagination">
                    <button 
                      type="button"
                      class="pagination-btn"
                      :disabled="currentPage === 1"
                      @click="currentPage = Math.max(1, currentPage - 1)"
                    >
                      ← Previous
                    </button>
                    
                    <span class="pagination-info">
                      Page {{ currentPage }} of {{ getTotalPagesForSkill(skill.id) }}
                    </span>
                    
                    <button 
                      type="button"
                      class="pagination-btn"
                      :disabled="currentPage === getTotalPagesForSkill(skill.id)"
                      @click="currentPage = Math.min(getTotalPagesForSkill(skill.id), currentPage + 1)"
                    >
                      Next →
                    </button>
                  </div>
                </div>
                
                <!-- Selected Teachers Summary -->
                <div v-if="selectedTeachers.length > 0" class="selected-teachers-summary">
                  <h4 class="summary-title">Selected Teachers ({{ selectedTeachers.length }})</h4>
                  <div class="selected-teachers-list">
                    <div 
                      v-for="teacher in selectedTeachers" 
                      :key="teacher.id"
                      class="selected-teacher-chip"
                    >
                      <!-- <img :src="teacher.profilePic" :alt="teacher.name" class="chip-avatar" /> -->
                      <span class="chip-name">{{ teacher.name }}</span>
                      <button 
                        type="button" 
                        class="remove-teacher-btn"
                        @click="removeTeacher(teacher.id)"
                      >
                        ×
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </template>

            <!-- Teacher Specific Fields -->
            <template v-if="role === 'teacher'">
              <!-- Experience Field -->
              <div class="input-group">
                <label class="input-label">💼 Years of Experience</label>
                <select v-model="experience" class="select-input" required>
                  <option disabled value="">Select your experience...</option>
                  <option value="0-1">0-1 years</option>
                  <option value="2-5">2-5 years</option>
                  <option value="6-10">6-10 years</option>
                  <option value="11-15">11-15 years</option>
                  <option value="16+">16+ years</option>
                </select>
              </div>

              <!-- Phone Number -->
              <div class="input-group">
                <label class="input-label">📞 Phone Number</label>
                <input
                  type="tel"
                  v-model="phone"
                  placeholder="Enter your phone number"
                  class="input"
                  required
                />
              </div>

              <!-- Grade Level -->
              <div class="input-group">
                <label class="input-label">🏫 Grade Level You Teach</label>
                <select v-model="institution" class="select-input" required>
                  <option disabled value="">Select grade level...</option>
                  <option value="3">3rd Grade</option>
                  <option value="4">4th Grade</option>
                  <option value="5">5th Grade</option>
                  <option value="6">6th Grade</option>
                  <option value="7">7th Grade</option>
                  <option value="8">8th Grade</option>
                </select>
              </div>

              <!-- Skills Selection -->
              <div class="skills-group">
                <label class="skills-heading">📖 Which course will you be teaching?</label>
                <!-- limit of 1 selection -->
                <div class="skills-options">
                  <div 
                    v-for="skill in availableSkills" 
                    :key="skill.id" 
                    class="skill-pill" 
                    :class="{ selected: selectedSkills.some(c => c.id === skill.id) }" 
                    @click="toggleSkill(skill)" 
                  >
                    {{ skill.name }}
                  </div>
                </div>
              </div>

              <!-- Teaching Philosophy -->
              <div class="input-group">
                <label class="input-label">📝 Teaching Philosophy (Optional)</label>
                <textarea
                  v-model="teachingPhilosophy"
                  placeholder="Describe your teaching approach..."
                  class="textarea-input"
                  rows="3"
                ></textarea>
              </div>
            </template>

            <!-- Parent Specific Fields -->
            <template v-if="role === 'parent'">
              <div class="input-group">
                <label class="input-label">👶 Your Child's Email</label>
                <input
                  type="email"
                  v-model="childEmail"
                  placeholder="Enter your child's email"
                  class="input"
                  required
                />
              </div>
              <!-- parent's own phone number -->
              <div class="input-group">
                <label class="input-label">📞 Your Phone Number</label>
                <input
                  type="tel"
                  v-model="parentPhone"
                  placeholder="Enter your phone number"
                  class="input"
                  required
                />
              </div>

              <!-- child's relation mother father sister guardian -->
              <div class="input-group">
                <label class="input-label">👶 Your Child's Relation to You</label>
                <select v-model="childRelation" class="select-input" required>
                  <option disabled value="">Select relation...</option>
                  <option value="mother">Mother</option>
                  <option value="father">Father</option>
                  <option value="sister">Sister</option>
                  <option value="guardian">Guardian</option>
                </select>
              </div>
            </template>

            <div class="sticky-register-wrapper">
            <button type="submit" class="register-button" :disabled="loading || !canSubmit">
              <span v-if="loading">Creating Account...</span>
              <span v-else>Create Account ✨</span>
            </button>

            </div>

          </form>

          <div class="signin-link">
            Already have an account? 
            <router-link to="/login" class="signin-text">Sign In</router-link>
          </div>
        </div>
      </div>
    </div>

    <!-- Features Section -->
    <div class="features-section">
      <h3 class="section-title">✨ Why Choose Learning Hub? ✨</h3>
      <div class="features">
        <div class="feature-item">
          <i class="icon">🏆</i>
          <p>Award-Winning Platform</p>
        </div>
        <div class="feature-item">
          <i class="icon">👩‍🎓</i>
          <p>10,000+ Happy Students</p>
        </div>
        <div class="feature-item">
          <i class="icon">⚡</i>
          <p>AI-Powered Learning</p>
        </div>
        <div class="feature-item">
          <i class="icon">❤️</i>
          <p>Made with Love</p>
        </div>
      </div>
    </div>

    <!-- Footer -->
    <footer class="footer">
      <div class="footer-content">
        <div class="footer-left">
          <h3>Skillzy</h3>
          <p>
            Empowering young minds with essential life skills through interactive
            learning, AI-powered assistance, and fun activities for ages 8–14.
          </p>
          <div class="social-icons">
            <a href="https://www.facebook.com/iitmadrasbsdegree/about/" target="_blank">
              <img src="https://cdn-icons-png.flaticon.com/512/733/733547.png" alt="Facebook" class="social-icon" />
            </a>
            <a href="https://github.com/rahulsharmaYS/soft-engg-project-may-2025-se-May-22" target="_blank">
              <img src="https://cdn-icons-png.flaticon.com/512/733/733609.png" alt="GitHub" class="social-icon" />
            </a>
            <a href="https://study.iitm.ac.in/ds/" target="_blank">
              <img src="https://cdn-icons-png.flaticon.com/512/2702/2702602.png" alt="Google" class="social-icon" />
            </a>
            <a href="https://www.instagram.com/iitmadras_bs/" target="_blank">
              <img src="https://cdn-icons-png.flaticon.com/512/733/733558.png" alt="Instagram" class="social-icon" />
            </a>
          </div>
        </div>

        <div class="footer-links">
          <h4>Quick Links</h4>
          <ul>
            <li><router-link to="/about">About Us</router-link></li>
            <li><router-link to="/features">Features</router-link></li>
            <li><router-link to="/privacy">Privacy Policy</router-link></li>
            <li><router-link to="/terms">Terms of Service</router-link></li>
          </ul>
        </div>

        <div class="footer-contact">
          <h4>Contact Us</h4>
          <p>Dummy Email: <u>team22@seproject.com</u></p>
          <p>Phone: <u>+91 9560594522</u></p>
          <p>Address: <u>IIT Madras, SoftWare Engineering Course</u></p>
        </div>
      </div>
      <div class="footer-bottom">
        © 2025 Skillzy. Made with ❤️ for young learners.
      </div>
    </footer>
  </div>
</template>

<script setup>
import api from '../api';
import { ref, reactive, computed } from 'vue';
import { useRouter } from 'vue-router';
import 'animate.css';
import { DotLottieVue } from '@lottiefiles/dotlottie-vue';
import { watch } from 'vue';


const router = useRouter();
const role = ref('student');
const firstName = ref('');
const lastName = ref('');
const userid = ref('');
const email = ref('');
const password = ref('');
const grade = ref('');
const selectedSkills = ref([]);
const selectedTeachers = ref([]);
const loading = ref(false);
const error = ref('');
const success = ref('');
const passwordError = ref('');



const validatePassword = (value) => {
  const rules = [
    { regex: /.{8,}/, message: 'At least 8 characters' },
    { regex: /[A-Z]/, message: 'At least one uppercase letter' },
    { regex: /[a-z]/, message: 'At least one lowercase letter' },
    { regex: /\d/, message: 'At least one number' },
    { regex: /[^A-Za-z0-9]/, message: 'At least one special character' }
  ];

  const failedRule = rules.find(rule => !rule.regex.test(value));
  passwordError.value = failedRule ? failedRule.message : '';
};

watch(password, (newVal) => {
  validatePassword(newVal);
});

// Teacher specific fields
const experience = ref('');
const teachingPhilosophy = ref('');
const availableTeachers = ref([]);
const loadingTeachers = ref(false);

// Parent specific fields
const childEmail = ref('');
const institution = ref('');

// Search and filtering
const searchQuery = ref('');
const experienceFilter = ref('');
const ratingFilter = ref('');
const currentPage = ref(1);
const teachersPerPage = ref(6);

const availableSkills = reactive([
  { id: '1', name: 'Time Management' }, 
  { id: '2', name: 'Communication' }, 
  { id: '3', name: 'Health' },
  { id: '7', name: 'Emotion Theory'},
  { id: '4', name: 'Decision Making' }, 
  { id: '5', name: 'Financial Literacy' }, 
  { id: '6', name: 'Problem Solving' },
]);

// Computed properties for progressive form display
const showSkillsSelection = computed(() => {
  return role.value === 'student' && grade.value !== '';
});

const showTeacherSelection = computed(() => {
  return role.value === 'student' && selectedSkills.value.length > 0;
});
const canSubmit = computed(() => {
  const basicFields =
    firstName.value &&
    lastName.value &&
    userid.value &&
    email.value &&
    password.value &&
    !passwordError.value;

  if (role.value === 'student') {
    return (
      basicFields &&
      grade.value &&
      selectedSkills.value.length > 0 &&
      availableTeachers.value.length > 0 && // 👈 ensure teachers are shown
      selectedTeachers.value.length > 0     // 👈 ensure at least one teacher is selected
    );
  } else if (role.value === 'teacher') {
    return (
      basicFields &&
      experience.value &&
      institution.value &&
      selectedSkills.value.length > 0
    );
  } else if (role.value === 'parent') {
    return basicFields && childEmail.value;
  }

  return basicFields;
});


// Methods
const resetForm = () => {
  grade.value = '';
  selectedSkills.value = [];
  selectedTeachers.value = [];
  experience.value = '';
  institution.value = '';
  teachingPhilosophy.value = '';
  childEmail.value = '';
};

const onGradeChange = () => {
  selectedSkills.value = [];
  selectedTeachers.value = [];
  availableTeachers.value = []; // Clear available teachers when grade changes
};

const fetchTeachersForSkills = async () => {
  if (selectedSkills.value.length === 0) {
    availableTeachers.value = [];
    return;
  }

  try {
    loadingTeachers.value = true;
    const skillIds = selectedSkills.value.map(skill => skill.id).join(',');

    const response = await api.get(`/user/teachers/by-subjects`, {
      params: {
        subject_ids: skillIds,
        class_id: grade.value // 👈 filter by class/grade
      }
    });

    if (response.data && response.data.teachers) {
      availableTeachers.value = response.data.teachers
        .filter(t => String(t.class_id) === String(grade.value))
        .map(teacher => ({
          id: teacher.id,
          name: teacher.name,
          full_name: teacher.full_name || teacher.name,
          experience: teacher.experience,
          subject_id: teacher.subject_id,
          subject_name: teacher.subject_name,
          email: teacher.email,
          phone: teacher.phone,
          class_id: teacher.class_id,
          // profilePic: `https://randomuser.me/api/portraits/${Math.random() > 0.5 ? 'women' : 'men'}/${teacher.id}.jpg`,
          rating: (4.5 + Math.random() * 0.5).toFixed(1)
        }));
    } else {
      availableTeachers.value = [];
    }

  } catch (error) {
    console.error('Error fetching teachers:', error);
    error.value = `Failed to load teachers: ${error.response?.data?.detail || error.message}`;
    availableTeachers.value = [];
  } finally {
    loadingTeachers.value = false;
  }
};


const toggleSkill = async (skill) => {
  const index = selectedSkills.value.findIndex((c) => c.id === skill.id);
  if (index > -1) {
    selectedSkills.value.splice(index, 1);
    // Remove teachers that only teach this subject
    selectedTeachers.value = selectedTeachers.value.filter(teacher => 
      selectedSkills.value.some(selectedSkill => teacher.subject_id == selectedSkill.id)
    );
  } else {
    selectedSkills.value.push(skill);
  }
  
  // Fetch updated teachers list
  await fetchTeachersForSkills();
};

const toggleTeacherSelection = (teacher) => {
  const index = selectedTeachers.value.findIndex(t => t.id === teacher.id);
  if (index > -1) {
    selectedTeachers.value.splice(index, 1);
  } else {
    // Check if student has selected the subject this teacher teaches
    const teacherSubjectSelected = selectedSkills.value.some(skill => skill.id == teacher.subject_id);
    if (teacherSubjectSelected) {
      selectedTeachers.value.push(teacher);
    } else {
      error.value = `Cannot select teacher for ${teacher.subject_name} as this subject is not selected`;
      setTimeout(() => {
        error.value = '';
      }, 3000);
    }
  }
};

const removeTeacher = (teacherId) => {
  selectedTeachers.value = selectedTeachers.value.filter(t => t.id !== teacherId);
};

const getTeachersForSkill = (skillId) => {
  if (!availableTeachers.value || !Array.isArray(availableTeachers.value)) {
    return [];
  }
  return availableTeachers.value.filter(teacher => 
    teacher.subject_id == skillId
  );
};

// Computed property for filtered teachers (for search and filter functionality)
const filteredTeachersForSelectedSkills = computed(() => {
  if (!availableTeachers.value || !Array.isArray(availableTeachers.value)) {
    return [];
  }
  
  return availableTeachers.value.filter(teacher => {
    const matchesSearch = teacher.name && teacher.name.toLowerCase().includes(searchQuery.value.toLowerCase());
    const teacherExp = parseInt(teacher.experience) || 0;
    const matchesExperience = !experienceFilter.value || 
      (experienceFilter.value === 'new' && teacherExp <= 2) ||
      (experienceFilter.value === 'experienced' && teacherExp >= 3 && teacherExp <= 10) ||
      (experienceFilter.value === 'expert' && teacherExp > 10);
    const teacherRating = parseFloat(teacher.rating) || 4.0;
    const matchesRating = !ratingFilter.value ||
      (ratingFilter.value === 'high' && teacherRating >= 4.5) ||
      (ratingFilter.value === 'good' && teacherRating >= 4.0 && teacherRating < 4.5);
    
    return matchesSearch && matchesExperience && matchesRating;
  });
});

// Updated method to use filtered teachers
const getFilteredTeachersForSkill = (skillId) => {
  if (!filteredTeachersForSelectedSkills.value || !Array.isArray(filteredTeachersForSelectedSkills.value)) {
    return [];
  }
  
  const teachersForSkill = filteredTeachersForSelectedSkills.value.filter(teacher => 
    teacher.subject_id == skillId
  );
  const startIndex = (currentPage.value - 1) * teachersPerPage.value;
  const endIndex = startIndex + teachersPerPage.value;
  return teachersForSkill.slice(startIndex, endIndex);
};

const getTotalPagesForSkill = (skillId) => {
  if (!filteredTeachersForSelectedSkills.value || !Array.isArray(filteredTeachersForSelectedSkills.value)) {
    return 0;
  }
  
  const teachersForSkill = filteredTeachersForSelectedSkills.value.filter(teacher => 
    teacher.subject_id == skillId
  );
  return Math.ceil(teachersForSkill.length / teachersPerPage.value);
};

const resetFilters = () => {
  searchQuery.value = '';
  experienceFilter.value = '';
  ratingFilter.value = '';
  currentPage.value = 1;
};

const handleRegister = async () => {
  if (!firstName.value || !lastName.value || !userid.value || !email.value || !password.value) {
    error.value = 'Please fill in all required fields';
    return;
  }

  try {
    loading.value = true;
    error.value = '';
    success.value = '';

    const payload = {
      username: userid.value,
      password: password.value,
      role_name: role.value,
      email: email.value,
      full_name: `${firstName.value} ${lastName.value}`.trim(),
    };

    if (role.value === 'student') {
      payload.class_id = parseInt(grade.value);
      payload.selected_skills = selectedSkills.value.map(s => s.id);
      payload.selected_teachers = selectedTeachers.value.map(t => t.id);
      
      if (payload.selected_skills.length === 0) {
        error.value = 'Please select at least one skill';
        loading.value = false;
        return;
      }
      
      if (payload.selected_teachers.length === 0) {
        error.value = 'Please select at least one teacher';
        loading.value = false;
        return;
      }
      
    } else if (role.value === 'teacher') {
      payload.class_id = institution.value;
      payload.subject_id = selectedSkills.value.length > 0 ? selectedSkills.value[0].id : null;
      payload.experience = experience.value;
      payload.teaching_philosophy = teachingPhilosophy.value;
      payload.skills_to_teach = selectedSkills.value.map(s => s.id);
      
    } else if (role.value === 'parent') {
      payload.child_email = childEmail.value;
    }

    const res = await api.post('/user/create_user', payload);
    console.log('User registered:', res.data);
    
    success.value = 'Account created successfully! Redirecting to login...';
    
    setTimeout(() => {
      router.push('/login');
    }, 2000);

  } catch (err) {
    error.value = err.response?.data?.detail || err.message || 'Registration failed';
  } finally {
    loading.value = false;
  }
};
</script>

<style scoped>
.signin-link {
  text-align: center;
  color: #fff;
  margin-top: 1rem;
  font-size: 1rem;
}
.signin-text {
  color: whitesmoke;
  text-decoration: none;
  font-weight: bold;
  margin-left: 0.5rem;

}

.register-box {
  /* background: rgba(255, 255, 255, 0.1);
   */
  background: rgba(55, 54, 54, 0.412);
  color: white;
  backdrop-filter: blur(20px);
  border: 1px solid rgba(255, 255, 255, 0.2);
  border-radius: 25px;
  padding: 2rem;
  margin-top: 1rem;
}
.sigin-link {
  margin-top: 1rem;
  text-align: center;
  color: #fff;
}
.register-button {
  
  background: #7400b8;
  color: white;
  padding: 0.75rem 1.5rem;
  border: none;
  border-radius: 25px;
  font-size: 1rem;
  cursor: pointer;
  transition: background-color 0.3s ease;
}

.features-section {
  color: white;
  text-align: center;
  padding: 2rem 1rem;
  background: rgba(255, 255, 255, 0.027);
  backdrop-filter: blur(10px);
  border-radius: 1.5rem;
  border-top: 1px solid rgba(255, 255, 255, 0.3);
  border-bottom: 1px solid rgba(255, 255, 255, 0.3);
  border-left: 1px solid rgba(255, 255, 255, 0.3);
  border-right: 1px solid rgba(255, 255, 255, 0.3);
  margin: 2rem auto;
  max-width: 90rem;
  display: flex;
  flex-direction: column;
  position: relative;
  align-items: center;
  justify-content: center;
}
.section-title {
  font-size: 1.5rem;
  margin-bottom: 1rem;
}
.features {
  display: flex;
  justify-content: center;
  flex-wrap: wrap;
  gap: 2rem;
}
.feature-item {
  width: 140px;
  background: transparent;
  border-radius: 1rem;
  /* border shadow */
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
  padding: 1rem;
  border-radius: 1rem solid rgba(255, 255, 255, 0.4);
}
.icon {
  font-size: 2rem;
  margin-bottom: 0.5rem;
}

.footer {
  background: #7400b8;
  color: white;
  padding: 2rem 1rem 1rem;
}
.footer-content {
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
  gap: 2rem;
}
.footer-left,
.footer-links,
.footer-contact {
  flex: 1;
  min-width: 200px;
}
.footer h4 {
  margin-bottom: 1rem;
}
.footer-links ul {
  list-style: none;
  padding: 0;
}
.footer-links li {
  margin-bottom: 0.5rem;
}
.footer-links a {
  color: white;
  text-decoration: none;
}
.footer-links a:hover {
  text-decoration: underline;
}
.social-icons a {
  font-size: 1.5rem;
  margin-right: 0.5rem;
  color: white;
}
.footer-bottom {
  margin-top: 2rem;
  text-align: center;
  font-size: 0.85rem;
  border-top: 1px solid rgba(255, 255, 255, 0.2);
  padding-top: 1rem;
}

.social-icons {
  display: flex;
  justify-content: center;
  gap: 10px;
  margin-top: 30px;
}
.social-icon {
  width: 30px;
  height: 30px;
  transition: transform 0.3s;
  cursor: pointer;
}

.social-icon:hover {
  transform: scale(1.1);
}

.page-wrapper {
  position: relative;
  min-height: 100vh;
  display: flex;
  flex-direction: column;
  background: linear-gradient(135deg, #0f7659 0%, #059669 50%, #0be59d 100%);
  background-size: cover;
  overflow-x: hidden;
}

/* Header Styles */
.hero-header {
  text-align: center;
  color: white;
  padding: 1rem;
}

.hero-header h1 {
  font-size: 3.5rem;
  margin-bottom: 0.5rem;
  font-weight: bold;
  text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
  color: #fff;
}

.hero-header p {
  font-size: 1.2rem;
  margin-bottom: 0.5rem;
}

.hero-subtitle-1,
.hero-subtitle-2 {
  text-align: center;
  color: white;
  font-size: 1.1rem;
  margin-bottom: 0.5rem;
}

/* Hero Section - Split Layout */
.hero-section {
  display: flex;
  align-items: flex-start;
  justify-content: center;
  gap: 2rem;
  padding: 1rem;
  flex: 1;
  max-width: 1400px;
  margin: 0 auto;
  width: 100%;
}

/* Left Side - Registration Container */
.register-container {
  flex: 1;
  max-width: 800px;
  min-width: 350px;
  min-height: 800px;
}

.back-button {
  margin-bottom: 1rem;
}

.back-link {
  color: rgba(255, 255, 255, 0.9);
  text-decoration: none;
  font-size: 1rem;
  display: inline-flex;
  align-items: center;
  gap: 0.5rem;
  transition: all 0.3s ease;
}

.back-link:hover {
  color: white;
  transform: translateX(-5px);
}

.register-box {
  /* background: rgba(255, 255, 255, 0.1); */
  backdrop-filter: blur(20px);
  border: 1px solid rgba(255, 255, 255, 0.2);
  border-radius: 25px;
  padding: 2rem 1.5rem;
  box-shadow: 0 15px 35px rgba(0, 0, 0, 0.1);
  text-align: center;
  position: relative;
  width: 100%;
  box-sizing: border-box;
  max-height: 90vh;
  overflow-y: auto;
}

.character-emoji {
  font-size: 4rem;
  margin-bottom: 1rem;
  display: block;
  filter: drop-shadow(0 4px 8px rgba(0, 0, 0, 0.1));
}

.register-box h2 {
  font-size: 2rem;
  color: white;
  margin-bottom: 0.5rem;
  font-weight: 600;
}

.subtitle {
  color: rgba(255, 255, 255, 0.8);
  margin-bottom: 2rem;
  font-size: 1rem;
}

.form {
  display: flex;
  flex-direction: column;
  gap: 1.2rem;
  text-align: left;
}

.name-group {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 1rem;
}

.input-group {
  position: relative;
}

.input-label {
  display: block;
  color: rgba(255, 255, 255, 0.9);
  font-size: 0.9rem;
  margin-bottom: 0.5rem;
  font-weight: 500;
}

.input, .select-input, .textarea-input {
  width: 100%;
  padding: 1rem 1.2rem;
  border-radius: 15px;
  border: 1px solid rgba(255, 255, 255, 0.2);
  background: rgba(255, 255, 255, 0.1);
  backdrop-filter: blur(10px);
  font-size: 1rem;
  color: white;
  transition: all 0.3s ease;
  box-sizing: border-box;
  font-family: inherit;
}

.textarea-input {
  resize: vertical;
  min-height: 80px;
}

.input::placeholder, .textarea-input::placeholder {
  color: rgba(255, 255, 255, 0.393);
}

.input:focus, .select-input:focus, .textarea-input:focus {
  outline: none;
  border-color: rgba(255, 255, 255, 0.4);
  background: rgba(255, 255, 255, 0.15);
  box-shadow: 0 0 20px rgba(255, 255, 255, 0.1);
}

.select-input option {
  background: #4c1d95;
  color: white;
}

/* Skills Selection */
.skills-group {
  margin-bottom: 1.5rem;
}

.skills-heading {
  display: block;
  color: rgba(255, 255, 255, 0.9);
  font-size: 0.9rem;
  margin-bottom: 1rem;
  font-weight: 500;
}

.skills-options {
  display: flex;
  flex-wrap: wrap;
  gap: 0.8rem;
}

.skill-pill {
  padding: 0.6rem 1rem;
  border-radius: 20px;
  background: rgba(255, 255, 255, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.2);
  color: rgba(255, 255, 255, 0.9);
  font-size: 0.85rem;
  cursor: pointer;
  transition: all 0.3s ease;
  backdrop-filter: blur(10px);
}

.skill-pill:hover {
  background: rgba(255, 255, 255, 0.2);
  border-color: rgba(255, 255, 255, 0.4);
  transform: translateY(-2px);
}

.skill-pill.selected {
  background: linear-gradient(135deg, #3b82f6, #1d4ed8);
  border-color: #3b82f6;
  color: white;
  box-shadow: 0 4px 12px rgba(59, 130, 246, 0.3);
}

/* Teacher Selection Section */
.teacher-selection-section {
  margin-top: 2rem;
  padding-top: 2rem;
  border-top: 1px solid rgba(255, 255, 255, 0.2);
}

.teacher-heading {
  color: white;
  font-size: 1.4rem;
  margin-bottom: 0.5rem;
  text-align: center;
}

.teacher-subheading {
  color: rgba(255, 255, 255, 0.8);
  font-size: 0.95rem;
  margin-bottom: 2rem;
  text-align: center;
}

.skill-teachers {
  margin-bottom: 2rem;
}

.skill-name {
  color: #fbbf24;
  font-size: 1.1rem;
  margin-bottom: 1rem;
  text-align: left;
}

.teachers-grid {
  display: grid;
  grid-template-columns: 1fr;
  gap: 1rem;
}

.teacher-card {
  background: rgba(255, 255, 255, 0.1);
  backdrop-filter: blur(10px);
  border: 1px solid rgba(255, 255, 255, 0.2);
  border-radius: 15px;
  padding: 1rem;
  display: flex;
  align-items: center;
  gap: 1rem;
  transition: all 0.3s ease;
  cursor: pointer;
  position: relative;
}

.selection-indicator {
  position: absolute;
  top: 1rem;
  right: 1rem;
  width: 25px;
  height: 25px;
  border-radius: 50%;
  background: rgba(34, 197, 94, 0.9);
  display: flex;
  align-items: center;
  justify-content: center;
  opacity: 0;
  transition: all 0.3s ease;
}

.teacher-card.selected .selection-indicator {
  opacity: 1;
}

.selected-icon {
  color: white;
  font-weight: bold;
  font-size: 0.9rem;
}

.teacher-rating {
  display: flex;
  align-items: center;
  gap: 0.2rem;
  margin: 0.3rem 0;
}

.star {
  font-size: 0.7rem;
  opacity: 0.3;
  transition: all 0.2s ease;
}

.star.filled {
  opacity: 1;
}

.rating-text {
  color: rgba(255, 255, 255, 0.7);
  font-size: 0.75rem;
  margin-left: 0.3rem;
}

/* Teacher Filters */
.teacher-filters {
  background: rgba(255, 255, 255, 0.1);
  backdrop-filter: blur(10px);
  border: 1px solid rgba(255, 255, 255, 0.2);
  border-radius: 15px;
  padding: 1.5rem;
  margin-bottom: 2rem;
}

.search-container {
  margin-bottom: 1rem;
}

.search-input-wrapper {
  position: relative;
  display: flex;
  align-items: center;
}

.search-icon {
  position: absolute;
  left: 1rem;
  z-index: 1;
  color: rgba(255, 255, 255, 0.6);
  font-size: 1rem;
}

.search-input {
  width: 100%;
  padding: 1rem 1rem 1rem 2.5rem;
  border-radius: 12px;
  border: 1px solid rgba(255, 255, 255, 0.2);
  background: rgba(255, 255, 255, 0.1);
  backdrop-filter: blur(10px);
  font-size: 1rem;
  color: white;
  transition: all 0.3s ease;
  box-sizing: border-box;
}

.search-input::placeholder {
  color: rgba(255, 255, 255, 0.6);
}

.search-input:focus {
  outline: none;
  border-color: rgba(255, 255, 255, 0.4);
  background: rgba(255, 255, 255, 0.15);
}

.filter-controls {
  display: flex;
  flex-wrap: wrap;
  gap: 1rem;
  align-items: end;
}

.filter-group {
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
  min-width: 150px;
}

.filter-label {
  color: rgba(255, 255, 255, 0.9);
  font-size: 0.85rem;
  font-weight: 500;
}

.filter-select {
  padding: 0.75rem;
  border-radius: 10px;
  border: 1px solid rgba(255, 255, 255, 0.2);
  background: rgba(255, 255, 255, 0.1);
  backdrop-filter: blur(10px);
  color: white;
  font-size: 0.9rem;
  transition: all 0.3s ease;
}

.filter-select:focus {
  outline: none;
  border-color: rgba(255, 255, 255, 0.4);
  background: rgba(255, 255, 255, 0.15);
}

.filter-select option {
  background: #4c1d95;
  color: white;
}

.reset-filters-btn {
  padding: 0.75rem 1.5rem;
  border-radius: 10px;
  border: 1px solid rgba(255, 255, 255, 0.3);
  background: rgba(255, 255, 255, 0.1);
  color: rgba(255, 255, 255, 0.9);
  font-size: 0.9rem;
  cursor: pointer;
  transition: all 0.3s ease;
  height: fit-content;
}

.reset-filters-btn:hover {
  background: rgba(255, 255, 255, 0.2);
  border-color: rgba(255, 255, 255, 0.4);
}

/* No Teachers Found */
.no-teachers-found {
  text-align: center;
  padding: 2rem;
  color: rgba(255, 255, 255, 0.8);
  background: rgba(255, 255, 255, 0.05);
  border-radius: 12px;
  border: 1px dashed rgba(255, 255, 255, 0.2);
}

.clear-search-btn {
  margin-top: 1rem;
  padding: 0.6rem 1.2rem;
  border-radius: 8px;
  border: 1px solid rgba(255, 255, 255, 0.3);
  background: rgba(255, 255, 255, 0.1);
  color: white;
  font-size: 0.85rem;
  cursor: pointer;
  transition: all 0.3s ease;
}

.clear-search-btn:hover {
  background: rgba(255, 255, 255, 0.2);
}

/* Pagination */
.pagination {
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 1rem;
  margin-top: 1.5rem;
  padding-top: 1rem;
  border-top: 1px solid rgba(255, 255, 255, 0.2);
}

.pagination-btn {
  padding: 0.6rem 1.2rem;
  border-radius: 8px;
  border: 1px solid rgba(255, 255, 255, 0.3);
  background: rgba(255, 255, 255, 0.1);
  color: white;
  font-size: 0.85rem;
  cursor: pointer;
  transition: all 0.3s ease;
}

.pagination-btn:hover:not(:disabled) {
  background: rgba(255, 255, 255, 0.2);
  transform: translateY(-1px);
}

.pagination-btn:disabled {
  opacity: 0.4;
  cursor: not-allowed;
}

.pagination-info {
  color: rgba(255, 255, 255, 0.8);
  font-size: 0.85rem;
  padding: 0.6rem 1rem;
}

/* Selected Teachers Summary */
.selected-teachers-summary {
  background: rgba(34, 197, 94, 0.1);
  border: 1px solid rgba(34, 197, 94, 0.3);
  border-radius: 15px;
  padding: 1.5rem;
  margin-top: 2rem;
}

.summary-title {
  color: #22c55e;
  font-size: 1.1rem;
  margin-bottom: 1rem;
  text-align: center;
}

.selected-teachers-list {
  display: flex;
  flex-wrap: wrap;
  gap: 0.8rem;
}

.selected-teacher-chip {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  background: rgba(255, 255, 255, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.2);
  border-radius: 20px;
  padding: 0.5rem 0.8rem;
  transition: all 0.3s ease;
}

.chip-avatar {
  width: 24px;
  height: 24px;
  border-radius: 50%;
  object-fit: cover;
}

.chip-name {
  color: white;
  font-size: 0.85rem;
  font-weight: 500;
}

.remove-teacher-btn {
  background: rgba(239, 68, 68, 0.8);
  border: none;
  border-radius: 50%;
  width: 20px;
  height: 20px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
  font-size: 0.8rem;
  cursor: pointer;
  transition: all 0.3s ease;
}

.remove-teacher-btn:hover {
  background: rgba(239, 68, 68, 1);
  transform: scale(1.1);
}

/* Responsive Design */
@media (max-width: 1200px) {
  .hero-section {
    gap: 1.5rem;
    padding: 1rem 0.5rem;
  }
  
  .register-container,
  .life-skills-container {
    max-width: 400px;
    min-width: 300px;
  }
}

@media (max-width: 768px) {
  .hero-section {
    flex-direction: column;
    gap: 2rem;
    padding: 1rem;
  }
  
  .register-container,
  .life-skills-container {
    width: 100%;
    max-width: 500px;
    min-width: auto;
  }
  
  .register-box,
  .life-skills-card {
    padding: 1.5rem 1rem;
  }
  
  .name-group {
    grid-template-columns: 1fr;
    gap: 0;
  }
  
  .card-title {
    font-size: 2rem;
  }
  
  .hero-header h1 {
    font-size: 2.5rem;
  }
  
  .teachers-grid {
    grid-template-columns: 1fr;
  }
  
  .teacher-card {
    flex-direction: column;
    text-align: center;
    gap: 0.8rem;
  }
  
  .teacher-info {
    text-align: center;
  }
}

@media (max-width: 480px) {
  .hero-section {
    padding: 0.5rem;
  }
  
  .register-box,
  .life-skills-card {
    padding: 1rem;
    border-radius: 20px;
  }
  
  .lottie-overlay {
    height: 80px !important;
    width: 80px !important;
    top: -20px;
    right: 0.5rem;
  }
}
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap');
.hero-header{
  animation: titlePulse 2s ease-in-out infinite;
}

@keyframes titlePulse {
  0%, 100% { transform: scale(1); }
  50% { transform: scale(1.02); }
}

.title-icon, .sparkle {
  display: inline-block;
  animation: sparkle 2s ease-in-out infinite;
}

.sparkle {
  animation-delay: 1s;
}

@keyframes sparkle {
  0%, 100% { transform: rotate(0deg) scale(1); }
  25% { transform: rotate(10deg) scale(1.1); }
  75% { transform: rotate(-10deg) scale(1.1); }
}
.floating-shapes {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  pointer-events: none;
}

.shape {
  position: absolute;
  border-radius: 50%;
  background: rgba(255, 255, 255, 0.1);
  animation: floatShape 8s ease-in-out infinite;
}

.shape-1 {
  width: 60px;
  height: 60px;
  top: 20%;
  left: 10%;
  animation-delay: 0s;
}

.shape-2 {
  width: 40px;
  height: 40px;
  top: 60%;
  right: 15%;
  animation-delay: 2s;
}

.shape-3 {
  width: 80px;
  height: 80px;
  bottom: 20%;
  left: 20%;
  animation-delay: 4s;
}

@keyframes floatShape {
  0%, 100% { transform: translateY(0px) translateX(0px); }
  25% { transform: translateY(-20px) translateX(10px); }
  50% { transform: translateY(-10px) translateX(-10px); }
  75% { transform: translateY(-30px) translateX(5px); }
}

.lottie-header-container {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 30px; /* space between animations and text */
  margin-bottom: 20px;
}

.lottie-left, .lottie-right {
  height: 80px;
  width: 80px;
}

.register-box h2 {
  margin: 0;
}
.sticky-register-wrapper {
  position: sticky;
  bottom: 0;
  background: transparent;
  padding: 1rem;
  z-index: 1000;
  /* border-top: 1px solid #ddd; */
}

/* Optional: Style success/error messages */
.message.success {
  color: whitesmoke;
  font-weight: bold;
  margin-bottom: 0.5rem;
}

.message.error {
  color: red;
  font-weight: bold;
  margin-bottom: 0.5rem;
}

/* Keep your existing button styles */
.register-button {
  background: #7400b8;
  color: white;
  padding: 0.75rem 1.5rem;
  border: none;
  border-radius: 25px;
  font-size: 1rem;
  cursor: pointer;
  transition: background-color 0.3s ease;
  width: 100%; /* Optional: full width */
}

</style>