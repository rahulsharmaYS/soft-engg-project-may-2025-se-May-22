<template>
  <div class="dashboard" :class="{ 'dark-mode': isDarkMode }">
    <!-- Header Section -->
    <div class="header-section">
      <div class="welcome-text">
      <h1 :title="`Welcome back, ${studentName}`" class="welcome-title">
        Welcome Back! {{ studentName }} 🌟 ⭐ ❄️
      </h1>
        <p class="welcome-subtitle">Ready to learn something amazing today? Your cartoon friends are here to help!</p>
      </div>
      
      <div class="header-controls">
        <!-- <button @click="toggleTheme" class="theme-toggle">
          {{ isDarkMode ? '☀️' : '🌙' }}
        </button> -->
        <button @click="toggleDropdown" class="notification-btn">
          🔔
          <span v-if="notifications.length" class="notification-badge">{{ notifications.length }}</span>
        </button>
      </div>

      <!-- Notifications Dropdown -->
      <div v-if="dropdownOpen" class="notifications-dropdown">
        <h4>Notifications</h4>
        <ul class="notifications-list">
          <li v-if="notifications.length === 0">No new notifications</li>
          <li v-for="(note, idx) in notifications" :key="idx" class="notification-item">
            <strong>{{ formatTime(note.timestamp) }}</strong><br />
            {{ note.message }}
          </li>
        </ul>
      </div>
    </div>

    <!-- Class Stats Section -->
    <div class="section">
      <div class="section-header">
        <h2 class="section-title">Class Stats 🎯</h2>
        <div class="heart-icon">❤️</div>
      </div>
      
      <div class="stats-grid">
        <div class="stat-card green">
          <div class="stat-icon">
            <div class="avatar tom">😊</div>
            <span class="avatar-name">Today's Tasks</span>
          </div>
          <div class="stat-content">
            <!-- <h3></h3> -->
            <div class="stat-number">{{ studentStats.totalTasks }}</div>
            <div class="progress-bar">
              <div class="progress-fill" style="width: 75%"></div>
            </div>
          </div>
          
        </div>

        <div class="stat-card orange">
          <div class="stat-icon">
            <div class="avatar doraemon">👨‍🎓</div>
            <span class="avatar-name">Upcoming Assignments</span>
          </div>
          <div class="stat-content">
            <!-- <h3>Upcoming Assignments</h3> -->
            <div class="stat-number">{{ studentStats.upcomingAssignments }}</div>
            <div class="progress-bar">
              <div class="progress-fill" style="width: 60%"></div>
            </div>
          </div>
        </div>

        <div class="stat-card purple">
          <div class="stat-icon">
            <div class="avatar pooh">🐻</div>
            <span class="avatar-name">Completed Assignments</span>
          </div>
          <div class="stat-content">
            <!-- <h3>Completed Assignments</h3> -->
            <div class="stat-number">{{ studentStats.completedAssignments }}</div>
            <div class="progress-bar">
              <div class="progress-fill" style="width: 90%"></div>
            </div>
          </div>
        </div>
                  <section class="focus-mode">
      <h2>🎯 Focus Mode</h2>
      <button @click="startFocusSession" class="focus-btn">Start Focus Mode</button>

      <div v-if="focusActive">
        <p>🧘 Time Left: <strong>{{ formattedTime }}</strong></p>
        <div class="progress-bar">
          <div class="progress-fill" :style="{ width: progressPercentage + '%' }">
            {{ progressEmoji }}
          </div>
        </div>
        <p>{{ progressMessage }}</p>
        <!-- <button @click="cancelFocusMode">❌ Cancel</button> -->
      </div>
      
    </section>


    <!-- Report Section -->
    <div class="section">
      <h2 class="section-title">Report an Issue 📝</h2>
      <div class="report-container">
        <Report />
      </div>
    </div>
      </div>
    </div>

    <!-- Statistics Chart Section -->
    <div class="section">
      <div class="section-header">
        <h2 class="section-title">Statistics 📊 🎯</h2>
      </div>
      
      <div class="chart-container">
        <div class="chart-header">
          <div class="chart-title">
            <h3>Your Learning Progress! 📈</h3>
            <p>Keep up the great work!</p>
          </div>
          <div class="chart-mascot">🐱</div>
          <div class="chart-star">⭐</div>
        </div>
        
        <div class="chart-legend">
          <div class="legend-item">
            <span class="legend-dot blue"></span>
            <span>Progress 📈</span>
          </div>
          <div class="legend-item">
            <span class="legend-dot pink"></span>
            <span>Completed ⭐</span>
          </div>
        </div>
        
        <Chart :assignments="assignments" />
        
        <div class="chart-mascots">
          <div class="mascot bottom-left">🐹</div>
          <div class="mascot bottom-center">🏰</div>
          <div class="mascot bottom-right">😊</div>
          <div class="achievement-text">"Great job! 🎉"</div>
        </div>
      </div>
    </div>

    <!-- Focus Mode Section -->
    <!-- <div class="section">
      <div class="focus-section">
        <h2 class="section-title">Focus Mode 🎯</h2>
        <div class="focus-controls">
          <button @click="startFocusSession" class="focus-btn">
            🎯 Start Focus Mode
          </button>
        </div>
        
        <div v-if="focus.isFocusActive" class="focus-active">
          <div class="focus-timer">
            🧘 Focus Mode — Time Left: <strong>{{ focus.formattedTime }}</strong>
          </div>
          
          <div class="focus-progress-bar">
            <div class="bar-container">
              <div class="bar-fill" :style="{ width: progressPercentage + '%' }">
                <span class="emoji">{{ progressEmoji }}</span>
              </div>
            </div>
            <p class="progress-message">{{ progressMessage }}</p>
          </div>
        </div>
      </div>
    </div> -->



    <!-- Calendar Section -->
    <div class="section">
      <CalendarUpcoming />
    </div>

    <!-- Cancel Focus Button -->
    <button
      v-if="focus.isFocusActive"
      @click="focus.cancelFocusMode"
      class="cancel-focus-btn"
    >
      ❌ Cancel (Do not worry to switch between pages. Focus mode is still active. 😊)
    </button>
  </div>
</template>
<script setup>
import api from '../api';
import { ref, watch, computed, onMounted, onUnmounted } from 'vue';
import { useFocusStore } from '../stores/focusStores';
import Header from '../components/Header.vue';
import Card from '../components/Card.vue';
import Chart from '../components/Chart.vue';
import Report from '../components/Report.vue';
import CalendarUpcoming from '../components/CalendarUpcoming.vue';
import { useRoute } from 'vue-router';
import { DotLottieVue } from '@lottiefiles/dotlottie-vue';

// UI State
const dropdownOpen = ref(false);
const studentName = ref('');
const isDarkMode = ref(false);

// Theme toggles
function toggleDropdown() {
  dropdownOpen.value = !dropdownOpen.value;
}

function toggleTheme() {
  isDarkMode.value = !isDarkMode.value;
  localStorage.setItem('darkMode', isDarkMode.value);
}

// Time formatting utility
function formatTime(timestamp) {
  const date = new Date(timestamp);
  return date.toLocaleString('en-IN', {
    day: '2-digit',
    month: 'short',
    hour: '2-digit',
    minute: '2-digit',
  });
}

// Focus Mode
const focus = useFocusStore();
const focusActive = ref(false);
const totalSeconds = ref(0);
const remainingSeconds = ref(0);
let interval = null;

const formattedTime = computed(() => {
  const mins = Math.floor(remainingSeconds.value / 60).toString().padStart(2, '0');
  const secs = (remainingSeconds.value % 60).toString().padStart(2, '0');
  return `${mins}:${secs}`;
});

const progressPercentage = computed(() => {
  if (!totalSeconds.value) return 0;
  return Math.round(((totalSeconds.value - remainingSeconds.value) / totalSeconds.value) * 100);
});

const progressEmoji = computed(() => {
  const pct = progressPercentage.value;
  if (pct < 25) return '🐢';
  if (pct < 50) return '🚶‍♂️';
  if (pct < 75) return '🏃';
  if (pct < 100) return '🚀';
  return '🎉';
});

const progressMessage = computed(() => {
  const pct = progressPercentage.value;
  if (pct < 25) return "Let's start slow...";
  if (pct < 50) return "Great going!";
  if (pct < 75) return "Almost there!";
  if (pct < 100) return "Final push!";
  return "You did it!";
});

async function startFocusSession() {
  const minutes = parseInt(prompt("How many minutes to focus?"), 10);
  if (!minutes || minutes <= 0) return;

  try {
    const response = await api.post(`student/${studentId.value}/focus_mode`, {
      minutes,
    });
    const data = response.data;
    alert(`${data.message}\n📝 Log will be saved in: ${data.output_file}`);
    focus.startFocusMode(minutes);

    totalSeconds.value = minutes * 60;
    remainingSeconds.value = totalSeconds.value;
    focusActive.value = true;

    clearInterval(interval); // clear existing one
    interval = setInterval(() => {
      if (remainingSeconds.value > 0) {
        remainingSeconds.value--;
      } else {
        clearInterval(interval);
        alert("🎉 Focus session completed!");
        focusActive.value = false;
      }
    }, 1000);
  } catch (err) {
    console.error(err);
    alert("❌ Failed to start focus session.");
  }
}

function cancelFocusSession() {
  clearInterval(interval);
  focusActive.value = false;
  remainingSeconds.value = 0;
}

// Student Data
const studentStats = ref({
  totalTasks: 0,
  upcomingAssignments: 0,
  completedAssignments: 0,
});

const tasks = ref([]);
const assignments = ref([]);
const badges = ref([]);
const profile = ref({});
const calendarItems = ref([]);
const notifications = ref([]);
const resources = ref([]);

const route = useRoute();
const studentId = computed(() => route.params.id);

// API Fetchers
async function fetchTasks() {
  try {
    const res = await api.get(`student/${studentId.value}/calendar`);
    tasks.value = res.data;
    console.log("Fetched tasks:", tasks.value);
  } catch (e) {
    console.error("Error fetching tasks:", e);
  }
}

async function fetchAssignments() {
  try {
    const res = await api.get(`student/${studentId.value}/assignments`);
    assignments.value = res.data;
    console.log("Fetched assignments:", assignments.value);
  } catch (e) {
    console.error("Error fetching assignments:", e);
  }
}

async function fetchProfile() {
  try {
    const res = await api.get(`student/${studentId.value}/profile`);
    profile.value = res.data;
    console.log("Fetched profile:", profile.value);
    studentName.value = res.data.full_name || 'Learner';
  } catch (e) {
    console.error("Error fetching profile:", e);
  }
}

async function fetchNotifications() {
  try {
    const res = await api.get(`student/${studentId.value}/notifications`);
    notifications.value = res.data;
    console.log("Fetched notifications:", notifications.value);
  } catch (e) {
    console.error("Error fetching notifications:", e);
  }
}

// Derived Stats
const totalTasks = computed(() => tasks.value.length);

const upcomingAssignments = computed(() => {
  const today = new Date();
  return assignments.value.filter(assignment => {
    if (!assignment.assignment_deadline) return false;
    const dueDate = new Date(assignment.assignment_deadline);
    return dueDate > today && !assignment.is_completed;
  }).length;
});

const completedAssignments = computed(() => {
  return assignments.value.filter(a => a.is_completed).length;
});

// Watch stats and update
watch([totalTasks, upcomingAssignments, completedAssignments], () => {
  studentStats.value.totalTasks = totalTasks.value;
  studentStats.value.upcomingAssignments = upcomingAssignments.value;
  studentStats.value.completedAssignments = completedAssignments.value;
});

// Lifecycle
onMounted(async () => {
  isDarkMode.value = localStorage.getItem('darkMode') === 'true';
  await Promise.all([
    fetchTasks(),
    fetchAssignments(),
    fetchProfile(),
    fetchNotifications(),
  ]);
  clearInterval(interval);
});

onUnmounted(() => {
  clearInterval(interval);
});
</script>

<style scoped>
/* CSS Variables for theming */
.dashboard {
  --bg-primary: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  --bg-secondary: rgba(255, 255, 255, 0.1);
  --bg-card: rgba(255, 255, 255, 0.15);
  --text-primary: #ffffff;
  --text-secondary: rgba(255, 255, 255, 0.8);
  --border: rgba(255, 255, 255, 0.2);
  --shadow: rgba(0, 0, 0, 0.1);
  --accent-green: #4ade80;
  --accent-orange: #fbbf24;
  --accent-purple: #a78bfa;
}

.dashboard.dark-mode {
  --bg-primary: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
  --bg-secondary: rgba(0, 0, 0, 0.3);
  --bg-card: rgba(0, 0, 0, 0.25);
  --text-primary: #ffffff;
  --text-secondary: rgba(255, 255, 255, 0.7);
  --border: rgba(255, 255, 255, 0.1);
  --shadow: rgba(0, 0, 0, 0.3);
}

.dashboard {
  min-height: 100vh;
  background: var(--bg-primary);
  padding: 2rem;
  color: var(--text-primary);
  font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
}

/* Header Section */
.header-section {
  position: relative;
  margin-bottom: 3rem;
}

.welcome-text {
  margin-bottom: 1rem;
}

.welcome-title {
  font-size: 2.5rem;
  font-weight: 700;
  margin-bottom: 0.5rem;
  /* background: linear-gradient(45deg, #ff6b6b, #4ecdc4, #45b7d1, #96ceb4); */
  background-size: 300% 300%;
  background: white;
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  animation: gradientShift 3s ease infinite;
}

.welcome-subtitle {
  font-size: 1.1rem;
  color: var(--text-secondary);
  margin-bottom: 2rem;
}

.header-controls {
  position: absolute;
  top: 0;
  right: 0;
  display: flex;
  gap: 1rem;
  align-items: center;
}

.theme-toggle,
.notification-btn {
  background: var(--bg-card);
  backdrop-filter: blur(20px);
  border: 1px solid var(--border);
  border-radius: 12px;
  padding: 0.75rem;
  color: var(--text-primary);
  cursor: pointer;
  font-size: 1.2rem;
  transition: all 0.3s ease;
  position: relative;
}

.theme-toggle:hover,
.notification-btn:hover {
  transform: translateY(-2px);
  box-shadow: 0 8px 25px var(--shadow);
}

.notification-badge {
  position: absolute;
  top: -8px;
  right: -8px;
  background: #ef4444;
  color: white;
  border-radius: 50%;
  width: 20px;
  height: 20px;
  font-size: 0.7rem;
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: bold;
}

.notifications-dropdown {
  position: absolute;
  top: 100%;
  right: 0;
  width: 350px;
  background: var(--bg-card);
  backdrop-filter: blur(20px);
  border: 1px solid var(--border);
  border-radius: 16px;
  padding: 1.5rem;
  box-shadow: 0 20px 40px var(--shadow);
  z-index: 100;
  margin-top: 0.5rem;
}

.notifications-list {
  list-style: none;
  padding: 0;
  margin: 0;
  max-height: 300px;
  overflow-y: auto;
}

.notification-item {
  padding: 1rem 0;
  border-bottom: 1px solid var(--border);
}

/* Section Styling */
.section {
  margin-bottom: 3rem;
}

.section-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 2rem;
}

.section-title {
  font-size: 1.5rem;
  font-weight: 600;
  margin: 0;
}

.heart-icon {
  font-size: 1.5rem;
  animation: heartbeat 2s ease-in-out infinite;
}

/* Stats Grid */
.stats-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 2rem;
}

.stat-card {
  background: var(--bg-card);
  backdrop-filter: blur(20px);
  border: 1px solid var(--border);
  border-radius: 20px;
  padding: 2rem;
  transition: all 0.3s ease;
  position: relative;
  overflow: hidden;
}

.stat-card::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  height: 4px;
  border-radius: 20px 20px 0 0;
}

.stat-card.green::before { background: var(--accent-green); }
.stat-card.orange::before { background: var(--accent-orange); }
.stat-card.purple::before { background: var(--accent-purple); }

.stat-card:hover {
  transform: translateY(-8px);
  box-shadow: 0 20px 40px var(--shadow);
}

.stat-icon {
  display: flex;
  align-items: center;
  gap: 1rem;
  margin-bottom: 1.5rem;
}

.avatar {
  width: 50px;
  height: 50px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 1.5rem;
  background: var(--bg-secondary);
  border: 2px solid var(--border);
}

.avatar-name {
  font-weight: 600;
  font-size: 1rem;
}

.stat-content h3 {
  font-size: 1rem;
  margin-bottom: 0.5rem;
  color: var(--text-secondary);
}

.stat-number {
  font-size: 2.5rem;
  font-weight: 700;
  margin-bottom: 1rem;
}

.progress-bar {
  height: 8px;
  background: var(--bg-secondary);
  border-radius: 4px;
  overflow: hidden;
}

.progress-fill {
  height: 100%;
  border-radius: 4px;
  transition: width 1s ease;
}

.stat-card.green .progress-fill { background: var(--accent-green); }
.stat-card.orange .progress-fill { background: var(--accent-orange); }
.stat-card.purple .progress-fill { background: var(--accent-purple); }

/* Chart Container */
.chart-container {
  background: var(--bg-card);
  backdrop-filter: blur(20px);
  border: 1px solid var(--border);
  border-radius: 20px;
  padding: 2rem;
  position: relative;
}

.chart-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 1.5rem;
}

.chart-title h3 {
  margin: 0 0 0.5rem 0;
  font-size: 1.2rem;
}

.chart-title p {
  margin: 0;
  color: var(--text-secondary);
  font-size: 0.9rem;
}

.chart-mascot,
.chart-star {
  font-size: 2rem;
  animation: float 3s ease-in-out infinite;
}

.chart-legend {
  display: flex;
  gap: 2rem;
  margin-bottom: 1rem;
}

.legend-item {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  font-size: 0.9rem;
}

.legend-dot {
  width: 12px;
  height: 12px;
  border-radius: 50%;
}

.legend-dot.blue { background: #60a5fa; }
.legend-dot.pink { background: #f472b6; }

.chart-mascots {
  position: relative;
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-top: 1rem;
}

.mascot {
  font-size: 1.5rem;
  animation: bounce 2s ease-in-out infinite;
}

.achievement-text {
  position: absolute;
  right: 0;
  font-style: italic;
  color: var(--text-secondary);
}

/* Focus Section */
.focus-section {
  background: var(--bg-card);
  backdrop-filter: blur(20px);
  border: 1px solid var(--border);
  border-radius: 20px;
  padding: 2rem;
}

.focus-controls {
  margin: 1rem 0;
}

.focus-btn {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  border: none;
  padding: 1rem 2rem;
  border-radius: 12px;
  font-size: 1rem;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s ease;
}

.focus-btn:hover {
  transform: translateY(-2px);
  box-shadow: 0 10px 30px rgba(102, 126, 234, 0.4);
}

.focus-active {
  margin-top: 2rem;
}

.focus-timer {
  background: var(--bg-secondary);
  padding: 1rem;
  border-radius: 12px;
  text-align: center;
  margin-bottom: 1rem;
}

.focus-progress-bar {
  text-align: center;
}

.bar-container {
  background: var(--bg-secondary);
  height: 24px;
  border-radius: 12px;
  overflow: hidden;
  margin-bottom: 1rem;
  position: relative;
}

.bar-fill {
  background: linear-gradient(90deg, var(--accent-green), var(--accent-orange));
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: flex-end;
  border-radius: 12px;
  transition: width 1s linear;
  padding-right: 0.5rem;
  font-size: 16px;
}

.emoji {
  animation: bounce 1s infinite alternate;
}

.progress-message {
  font-weight: 600;
  color: var(--text-primary);
}

/* Report Container */
.report-container {
  background: var(--bg-card);
  backdrop-filter: blur(20px);
  border: 1px solid var(--border);
  border-radius: 20px;
  padding: 2rem;
}

/* Cancel Focus Button */
.cancel-focus-btn {
  position: fixed;
  top: 2rem;
  left: 2rem;
  z-index: 1000;
  background: #ef4444;
  color: white;
  border: none;
  padding: 1rem 1.5rem;
  border-radius: 12px;
  cursor: pointer;
  font-weight: 600;
  transition: all 0.3s ease;
}

.cancel-focus-btn:hover {
  transform: translateY(-2px);
  box-shadow: 0 10px 30px rgba(239, 68, 68, 0.4);
}

/* Animations */
@keyframes gradientShift {
  0%, 100% { background-position: 0% 50%; }
  50% { background-position: 100% 50%; }
}

@keyframes heartbeat {
  0%, 100% { transform: scale(1); }
  50% { transform: scale(1.2); }
}

@keyframes float {
  0%, 100% { transform: translateY(0px); }
  50% { transform: translateY(-10px); }
}

@keyframes bounce {
  0%, 100% { transform: translateY(0); }
  50% { transform: translateY(-5px); }
}

/* Responsive Design */
@media (max-width: 768px) {
  .dashboard {
    padding: 1rem;
  }

  .welcome-title {
    font-size: 1.8rem;
  }

  .header-controls {
    position: static;
    margin-top: 1rem;
  }

  .stats-grid {
    grid-template-columns: 1fr;
  }

  .chart-header {
    flex-direction: column;
    text-align: center;
    gap: 1rem;
  }

  .chart-legend {
    justify-content: center;
  }

  .chart-mascots {
    justify-content: center;
    gap: 1rem;
  }

  .notifications-dropdown {
    width: calc(100vw - 2rem);
    right: -1rem;
  }
}

@media (max-width: 480px) {
  .dashboard {
    padding: 0.5rem;
  }

  .section {
    margin-bottom: 2rem;
  }

  .stat-card,
  .chart-container,
  .focus-section,
  .report-container {
    padding: 1.5rem;
  }

  .welcome-title {
    font-size: 1.5rem;
  }
}

.focus-mode {
  background: var(--bg-card);
  backdrop-filter: blur(20px);
  border: 1px solid var(--border);
  border-radius: 20px;
  padding: 2rem;
}
button {
  padding: 10px 20px;
  margin: 10px 0;
}
.progress-bar {
  height: 20px;
  background: #ccc;
  border-radius: 10px;
  overflow: hidden;
}
.progress-fill {
  height: 100%;
  background: linear-gradient(90deg, #00bcd4, #4caf50);
  text-align: center;
  color: white;
  font-weight: bold;
}

</style>