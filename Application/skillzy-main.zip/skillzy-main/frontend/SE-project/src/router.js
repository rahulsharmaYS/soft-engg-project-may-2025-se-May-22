import { createRouter, createWebHistory } from 'vue-router';

// Layouts
import InstructorLayout from '@/layouts/InstructorLayout.vue';
import StudentLayout from '@/layouts/StudentLayout.vue';
import ParentLayout from '@/layouts/ParentLayout.vue';
import AdminLayout from './layouts/AdminLayout.vue';

// All Views & Components
import Dashboard from '@/views/Dashboard.vue';
import MySkills from '@/components/MySkills.vue';
import StudentCalendar from '@/components/StudentCalendar.vue';
import StudentMessages from '@/components/StudentMessages.vue';
import StudentProfile from '@/components/StudentProfile.vue';
import StudentAssignments from '@/components/StudentAssignments.vue';
import SubmitAssignment from '@/components/SubmitAssignment.vue';
import StudentTasks from '@/components/StudentTasks.vue';
import EditTask from '@/components/EditTask.vue';
import StudentBadges from '@/components/StudentBadges.vue';
import StudentNotifications from '@/components/StudentNotifications.vue';
import StudentResources from './components/StudentResources.vue';
import AI_Assistance from '@/components/AI_Assistance.vue';
import InstructorDashboard from '@/views/InstructorDashboard.vue';
import StudentManagement from '@/components/StudentManagement.vue';
import StudentDetail from '@/components/StudentDetail.vue';
import InstructorAssignments from '@/components/InstructorAssignments.vue';
import InstructorProfile from '@/components/InstructorProfile.vue';
import Resources from '@/components/Resources.vue';
import InstructorEvaluation from '@/components/InstructorEvaluation.vue'
import Instructor_AI from './components/Instructor_AI.vue';


import AdminDashboard from '@/views/AdminDashboard.vue';
import ParentDashboard from '@/views/ParentDashboard.vue';
import ParentsMessages from '@/components/ParentsMessages.vue';
import ParentProfile from '@/components/ParentProfile.vue';
import Health from '@/components/Health.vue';

import UserManagement from '@/components/UserManagement.vue';
import HelpCenter from '@/components/HelpCenter.vue';
import Announcements from '@/components/Announcements.vue';

import Welcome from '@/views/Welcome.vue';
import Login from '@/views/Login.vue';
import Register from '@/views/Register.vue';
import CommsCenter from '@/components/CommsCenter.vue';

// quick links section
import AboutUs from './components/AboutUs.vue';
import Features from './components/Features.vue';
import PrivacyPolicy from './components/PrivacyPolicy.vue';
import TermsOfService from './components/TermsOfService.vue';


const routes = [
  // --- General & Other Role Routes ---
  { path: '/', name: 'Welcome', component: Welcome },
  { path: '/login', name: 'Login', component: Login },
  { path: '/register', name: 'Register', component: Register },
  { path: '/admin', name: 'AdminDashboard', component: AdminDashboard },
  
  // --- STUDENT SECTION (Using StudentLayout) ---
 {
  path: '/student/:id',
  component: StudentLayout,
  children: [
    {
      path: 'dashboard',
      name: 'StudentDashboard',
      component: Dashboard
    },
    {
      path: 'assignments',
      name: 'StudentAssignments',
      component: StudentAssignments
    },
    {
      path: 'assignments/:assignmentId/submit',
      name: 'SubmitAssignment',
      component: SubmitAssignment 
    },
    {
      path: 'tasks',
      name: 'StudentTasks',
      component: StudentTasks 
    },
    {
      path: 'tasks/:taskId/edit',
      name: 'EditTask',
      component: EditTask 
    },
    {
      path: 'calendar',
      name: 'StudentCalendar',
      component: StudentCalendar
    },
    {
      path: 'ai-assistance',
      name: 'StudentAI_Assistance',
      component: AI_Assistance
    },
    {
      path: 'profile',
      name: 'StudentProfile',
      component: StudentProfile
    },
    {
      path: 'badges',
      name: 'StudentBadges',
      component: StudentBadges 
    },
    // {
    //   path: '/student/:user_id/resources',
    //   name: 'StudentResources',
    //   component: StudentResources
    // },
    {
  path: 'resources',
  name: 'StudentResources',
  component: StudentResources
},
    {
      path: 'messages',
      name: 'StudentMessages',
      component: StudentMessages
    },
    {
      path: 'notifications',
      name: 'StudentNotifications',
      component: StudentNotifications 
    }
  ]
}

,

  // --- INSTRUCTOR SECTION (Using InstructorLayout) ---
  {
    path: '/teacher/:teacher_id',
    component: InstructorLayout,
    children: [
      { path: 'dashboard', name: 'InstructorDashboard', component: InstructorDashboard },
      { path: 'students', name: 'StudentManagement', component: StudentManagement },
      // { path: 'student/:id', name: 'StudentDetail', component: StudentDetail },
      { path: 'assignments', name: 'InstructorAssignments', component: InstructorAssignments },
      { path: 'resources', name: 'InstructorResources', component: Resources },
      { path: 'ai-assistance', name: 'InstructorAI_Assistance', component: Instructor_AI},
      { path: 'profile', name: 'InstructorProfile', component: InstructorProfile },
      { path: 'comms', name: 'InstructorComms', component: CommsCenter },
      {
        path: 'evaluation',
        name: 'InstructorEvaluation',
        component: InstructorEvaluation
      }

    ]
  },
  
  // --- PARENT SECTION (Using ParentLayout) ---
  {
    path: '/parent/:parentId',
    component: ParentLayout,
    children: [
      { path: 'dashboard', name: 'ParentDashboard', component: ParentDashboard },
      { path: 'messages', name: 'ParentsMessages', component: ParentsMessages },
      { path: 'comms', name: 'ParentComms', component: CommsCenter },
      { path: 'ai-assistance', name: 'AI_Assistance', component: AI_Assistance },
      { path: 'profile', name: 'ParentProfile', component: ParentProfile },
      { path: 'health', name: 'ParentHealth', component: Health }
    ]
  },

  // --- ADMIN SECTION ---
  {
    path: '/admin',
    component: AdminLayout,
    children: [
      { path: 'dashboard', name: 'AdminDashboard', component: AdminDashboard },
      { path: 'usermanagement', name: 'UserManagement', component: UserManagement },
      { path: 'helpcenter', name: 'HelpCenter', component: HelpCenter },
      { path: 'announcements', name: 'Announcements', component: Announcements }
  ]
},

  // --- QUICK LINKS SECTION ---
  {
    path: '/about',
    name: 'AboutUs',
    component: AboutUs
  },
  {
    path: '/features',
    name: 'Features',
    component: Features
  },
  {
    path: '/privacy',
    name: 'PrivacyPolicy',
    component: PrivacyPolicy
  },
  {
    path: '/terms',
    name: 'TermsOfService',
    component: TermsOfService
  }
];

export const router = createRouter({
  history: createWebHistory(),
  routes
});
