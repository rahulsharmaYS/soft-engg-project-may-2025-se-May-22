import { createApp } from 'vue'
import App from './App.vue'
import './assets/style.css'
import { store } from './store.js'
import { router } from './router.js'
import { createPinia } from 'pinia'
import 'animate.css'
const app = createApp(App)


app.use(createPinia())
app.use(router)
app.provide('store', store)

app.mount('#app')
