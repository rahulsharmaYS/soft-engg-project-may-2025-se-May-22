<template>
  <div>
    <Header title="My Skills" subtitle="Track and grow your strengths!" />

    <div class="main-content-wrapper">
      <div class="skill-controls">
        <input v-model="searchQuery" type="text" placeholder="Search skills..." class="search-bar" />
        <select v-model="selectedNewSkill" class="dropdown">
          <option disabled value="">Add New Skill</option>
          <option v-for="option in allSkillOptions" :key="option">{{ option }}</option>
        </select>
        <button @click="addSkill">Add</button>
      </div>

      <section class="skills-overview">
        <div
          class="skill-progress hover-expand"
          v-for="skill in filteredSkills"
          :key="skill.name"
        >
          <h3>{{ skill.name }}</h3>
          <div class="progress-bar">
            <div class="progress" :style="{ width: skill.level + '%' }"></div>
          </div>
          <span>{{ skill.level }}%</span>
        </div>
      </section>

      <section class="resources">
        <div class="resource-card hover-expand" v-for="resource in recommendedResources" :key="resource.title">
          <h4>{{ resource.title }}</h4>
          <p>{{ resource.description }}</p>
          <button @click="openResource(resource.link)">View</button>
        </div>
      </section>

      <section class="achievement-section">
        <h2>Achievements</h2>
        <ul>
          <li v-for="badge in badges" :key="badge">🏅 {{ badge }}</li>
        </ul>
      </section>
    </div>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue'
import Header from '../components/Header.vue'

// NOTE: Sidebar and navLinks have been removed to use the main StudentLayout.
// All original functionality is preserved.

const skills = ref([
  { name: 'Math', level: 80 },
  { name: 'Science', level: 65 },
  { name: 'Writing', level: 70 },
  { name: 'Critical Thinking', level: 60 },
])

const badges = ref(['Top Scorer in Math', 'Completed Science Project', 'Essay Champion'])

const recommendedResources = ref([
  { title: 'Algebra Practice', description: 'Improve your algebra with guided problems.', link: '#' },
  { title: 'Science Lab Activities', description: 'Fun experiments to do at home.', link: '#' },
  { title: 'Essay Writing Tips', description: 'Boost your writing with these tips.', link: '#' },
])

const allSkillOptions = ref(['Art', 'Public Speaking', 'Leadership', 'Coding', 'Teamwork', 'Sports', 'Reading Comprehension'])
const selectedNewSkill = ref('')
const searchQuery = ref('')

const filteredSkills = computed(() => {
  return skills.value.filter(skill =>
    skill.name.toLowerCase().includes(searchQuery.value.toLowerCase())
  )
})

function addSkill() {
  if (selectedNewSkill.value && !skills.value.find(s => s.name === selectedNewSkill.value)) {
    skills.value.push({ name: selectedNewSkill.value, level: 0 })
    selectedNewSkill.value = ''
  }
}

function openResource(link) {
  window.open(link, '_blank')
}
</script>

<style scoped>
/* The top-level .student-skills and .main selectors were removed as those elements
  are no longer part of this component. A new wrapper is added for spacing.
  All other original styles are preserved.
*/
.main-content-wrapper {
  margin-top: 2rem;
  display: flex;
  flex-direction: column;
  gap: 2rem;
}

h2 {
  margin-bottom: 1rem;
  font-weight: 600;
}

.skill-controls {
  display: flex;
  flex-wrap: wrap;
  gap: 1rem;
  align-items: center;
}
.search-bar {
  padding: 0.5rem 1rem;
  border-radius: 0.5rem;
  border: 1px solid var(--border); /* Use border variable */
  font-size: 1rem;
  background-color: var(--card); /* Ensure search bar background adapts */
  color: var(--text); /* Ensure search bar text adapts */
}
.dropdown {
  padding: 0.5rem;
  border-radius: 0.5rem;
  border: 1px solid var(--border); /* Use border variable */
  background-color: var(--card); /* Ensure dropdown background adapts */
  color: var(--text); /* Ensure dropdown text adapts */
}
.skill-controls button {
  background: var(--primary);
  color: white;
  border: none;
  padding: 0.5rem 1rem;
  border-radius: 0.5rem;
  cursor: pointer;
}
.skills-overview {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 1.5rem;
}
.skill-progress {
  background: var(--card); /* Changed from 'white' */
  border-radius: 0.75rem;
  padding: 1rem;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
  transition: transform 0.2s, box-shadow 0.2s;
  /* Text color within skill-progress should inherit from body, which uses var(--text) */
  color: var(--text);
}
.progress-bar {
  height: 10px;
  background: var(--secondary); /* Use secondary variable for progress bar background */
  border-radius: 5px;
  margin: 0.5rem 0;
  overflow: hidden;
}
.progress {
  height: 100%;
  background: #4f46e5; /* Primary color is fine here */
  border-radius: 5px;
}
.resources {
  display: flex;
  flex-wrap: wrap;
  gap: 1rem;
}
.resource-card {
  background: var(--card); /* Changed from 'white' */
  padding: 1rem;
  border-radius: 0.75rem;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
  flex: 1 1 250px;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  transition: transform 0.2s, box-shadow 0.2s;
  /* Text color within resource-card should inherit from body, which uses var(--text) */
  color: var(--text);
}
.resource-card button {
  margin-top: 1rem;
  background: var(--primary); /* Use primary variable for button background */
  color: white;
  border: none;
  padding: 0.5rem;
  border-radius: 0.5rem;
  cursor: pointer;
}
.achievement-section ul {
  list-style: none;
  padding: 0;
  display: flex;
  gap: 1rem;
  flex-wrap: wrap;
}
.achievement-section li {
  background: var(--secondary); /* Changed from '#fef3c7' to adapt to theme */
  padding: 0.5rem 1rem;
  border-radius: 1rem;
  font-weight: 600;
  color: var(--text); /* Changed from '#92400e' to adapt to theme */
}
.hover-expand:hover {
  transform: scale(1.02);
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
}
@media (max-width: 768px) {
  .resources {
    flex-direction: column;
  }
  .skills-overview {
    grid-template-columns: 1fr;
  }
  .skill-controls {
    flex-direction: column;
    align-items: stretch;
  }
}
</style>