<template>
  <section class="about-container">
    <div class="hero-section">
      <div class="hero-content">
        <h1 class="hero-title">
          <span class="title-icon">🚀</span>
          About Skillzy
          <span class="title-accent">✨</span>
        </h1>
        <div class="hero-subtitle">
          <p class="main-description">
            Skillzy is an interactive platform built for students in grades 3 to 8, designed to make learning
            <span class="highlight">fun</span>,
            <span class="highlight">skill-driven</span>, and
            <span class="highlight">student-centric</span>.
            It's a Software Engineering project by a passionate team from
            <span class="university-badge">IIT Madras, BS in Data Science (May 2025 Batch)</span><br>
            <!-- team 22 -->
            <h1 class="highlight" style="font-size: 1.5rem; font-weight: bold;">Team 22</h1>
          </p>
        </div>
      </div>
      <div class="floating-elements">
        <div class="float-element float-1">📚</div>
        <div class="float-element float-2">🎯</div>
        <div class="float-element float-3">💡</div>
        <div class="float-element float-4">🌟</div>
      </div>
    </div>

    <div class="content-section">
      <div class="mission-card">
        <div class="card-header">
          <h2 class="section-title">
            <span class="section-icon">🎓</span>
            Our Mission
          </h2>
        </div>
        <div class="card-content">
          <p class="mission-text">
            We aim to empower young learners with structured, skill-based education by leveraging
            <span class="tech-highlight">clean design</span>,
            <span class="tech-highlight">smooth UX</span>, and
            <span class="tech-highlight">modern tech stacks</span>.
          </p>
          <div class="mission-features">
            <div class="feature-item">
              <span class="feature-icon">🎨</span>
              <span>Beautiful Design</span>
            </div>
            <div class="feature-item">
              <span class="feature-icon">⚡</span>
              <span>Fast Performance</span>
            </div>
            <div class="feature-item">
              <span class="feature-icon">🧠</span>
              <span>Smart Learning</span>
            </div>
          </div>
        </div>
      </div>

      <div class="team-section">
        <div class="team-header">
          <h2 class="section-title">
            <span class="section-icon">🧑‍🤝‍🧑</span>
            Meet the Team
          </h2>
          <p class="team-subtitle">The brilliant minds behind Skillzy</p>
        </div>

        <div class="team-grid">
          <div class="team-member leader">
            <div class="member-avatar">
              <span class="avatar-emoji">🧠</span>
            </div>
            <div class="member-info">
              <h3 class="member-name">Deepak</h3>
              <p class="member-role">Team Leader</p>
              <div class="member-badge leader-badge">Leader</div>
            </div>
          </div>

          <div class="team-member frontend">
            <div class="member-avatar">
              <span class="avatar-emoji">🎨</span>
            </div>
            <div class="member-info">
              <h3 class="member-name">Rahul</h3>
              <p class="member-role">Frontend Developer</p>
              <div class="member-badge frontend-badge">Frontend</div>
            </div>
          </div>

          <div class="team-member frontend">
            <div class="member-avatar">
              <span class="avatar-emoji">🖌️</span>
            </div>
            <div class="member-info">
              <h3 class="member-name">Nikhil</h3>
              <p class="member-role">Frontend Developer</p>
              <div class="member-badge frontend-badge">Frontend</div>
            </div>
          </div>

          <div class="team-member scrum">
            <div class="member-avatar">
              <span class="avatar-emoji">🧭</span>
            </div>
            <div class="member-info">
              <h3 class="member-name">Rishabh</h3>
              <p class="member-role">Scrum Master</p>
              <div class="member-badge scrum-badge">Scrum Master</div>
            </div>
          </div>

          <div class="team-member backend">
            <div class="member-avatar">
              <span class="avatar-emoji">⚙️</span>
            </div>
            <div class="member-info">
              <h3 class="member-name">Aarush</h3>
              <p class="member-role">Backend Developer</p>
              <div class="member-badge backend-badge">Backend</div>
            </div>
          </div>

          <div class="team-member backend">
            <div class="member-avatar">
              <span class="avatar-emoji">🔧</span>
            </div>
            <div class="member-info">
              <h3 class="member-name">Arya</h3>
              <p class="member-role">Backend Developer</p>
              <div class="member-badge backend-badge">Backend</div>
            </div>
          </div>

          <div class="team-member backend">
            <div class="member-avatar">
              <span class="avatar-emoji">🛠️</span>
            </div>
            <div class="member-info">
              <h3 class="member-name">Vishal</h3>
              <p class="member-role">Backend Developer</p>
              <div class="member-badge backend-badge">Backend</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- add footer -->    
   <footer class="footer">
      <div class="footer-content">
        <div class="footer-left">
          <h3>Skillzy</h3>
          <p>
            Empowering young minds with essential life skills through interactive
            learning, AI-powered assistance, and fun activities for ages 8–14.
          </p>
          <div class="social-icons">
          <a href="https://www.facebook.com/iitmadrasbsdegree/about/" target="_blank"><img src="https://cdn-icons-png.flaticon.com/512/733/733547.png" alt="Facebook" class="social-icon" /></a>
          <a href="https://github.com/rahulsharmaYS/soft-engg-project-may-2025-se-May-22" target="_blank"><img src="https://cdn-icons-png.flaticon.com/512/733/733609.png" alt="GitHub" class="social-icon" /></a>
          <a href="https://study.iitm.ac.in/ds/" target="_blank"><img src="https://cdn-icons-png.flaticon.com/512/2702/2702602.png" alt="Google" class="social-icon" /></a>
          <a href="https://www.instagram.com/iitmadras_bs/" target="_blank"><img src="https://cdn-icons-png.flaticon.com/512/733/733558.png" alt="Instagram" class="social-icon" /></a>
          </div>
        </div>

        <div class="footer-links">
          <h4>Quick Links</h4>
          <ul>
            <li><router-link to="/">Home</router-link></li>
            <li><router-link to="/about">About Us</router-link></li>
            <li><router-link to="/features">Features</router-link></li>
            <li><router-link to="/privacy">Privacy Policy</router-link></li>
            <li><router-link to="/terms">Terms of Service</router-link></li>
          </ul>
        </div>

        <div class="footer-contact">
          <h4>Contact Us</h4>
          <p>Dummy Email: <u>team22@seproject.com</u></p>
          <p>Phone: <u>+91 9560594522</u></p>
          <p>Address: <u>IIT Madras, SoftWare Engineering Course</u></p>
        </div>
      </div>
      <div class="footer-bottom">
        © 2025 Skillzy. Made with ❤️ for young learners.
      </div>
    </footer>
</template>

<style scoped>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap');

.footer {
  background: #7400b8;
  color: white;
  padding: 2rem 1rem 1rem;
}
.footer-content {
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
  gap: 2rem;
}
.footer-left,
.footer-links,
.footer-contact {
  flex: 1;
  min-width: 200px;
}
.footer h4 {
  margin-bottom: 1rem;
}
.footer-links ul {
  list-style: none;
  padding: 0;
}
.footer-links li {
  margin-bottom: 0.5rem;
}
.footer-links a {
  color: white;
  text-decoration: none;
}
.footer-links a:hover {
  text-decoration: underline;
}
.social-icons a {
  font-size: 1.5rem;
  margin-right: 0.5rem;
  color: white;
}
.footer-bottom {
  margin-top: 2rem;
  text-align: center;
  font-size: 0.85rem;
  border-top: 1px solid rgba(255, 255, 255, 0.2);
  padding-top: 1rem;
}
.social-icons {
  display: flex;
  justify-content: center;
  gap: 10px;
  margin-top: 30px;
}
.social-icon {
  width: 30px;
  height: 30px;
  transition: transform 0.3s;
  cursor: pointer;
}

.social-icon:hover {
  transform: scale(1.1);
}

.about-container {
  font-family: 'Inter', sans-serif;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  min-height: 100vh;
  position: relative;
  overflow: hidden;
}

/* Hero Section */
.hero-section {
  position: relative;
  padding: 4rem 2rem;
  text-align: center;
  color: white;
}

.hero-content {
  max-width: 800px;
  margin: 0 auto;
  position: relative;
  z-index: 2;
}

.hero-title {
  font-size: clamp(2.5rem, 6vw, 4rem);
  font-weight: 800;
  margin-bottom: 1rem;
  background: linear-gradient(45deg, #fff, #f0f9ff, #e0f2fe);
  background-clip: text;
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  text-shadow: 0 4px 20px rgba(255, 255, 255, 0.3);
  animation: titleGlow 2s ease-in-out infinite alternate;
}

@keyframes titleGlow {
  0% { text-shadow: 0 4px 20px rgba(255, 255, 255, 0.3); }
  100% { text-shadow: 0 8px 30px rgba(255, 255, 255, 0.5); }
}

.title-icon, .title-accent {
  display: inline-block;
  animation: bounce 2s infinite;
}

.title-accent {
  animation-delay: 0.5s;
}

@keyframes bounce {
  0%, 20%, 50%, 80%, 100% { transform: translateY(0); }
  40% { transform: translateY(-10px); }
  60% { transform: translateY(-5px); }
}

.hero-subtitle {
  margin-top: 2rem;
}

.main-description {
  font-size: 1.2rem;
  line-height: 1.8;
  font-weight: 400;
  color: rgba(255, 255, 255, 0.9);
}

.highlight {
  background: linear-gradient(45deg, #fbbf24, #f59e0b);
  background-clip: text;
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  font-weight: 600;
  position: relative;
}

.university-badge {
  display: inline-block;
  background: linear-gradient(45deg, #3b82f6, #1d4ed8);
  color: white;
  padding: 0.3rem 0.8rem;
  border-radius: 20px;
  font-weight: 600;
  font-size: 0.9rem;
  margin: 0 0.3rem;
  box-shadow: 0 4px 15px rgba(59, 130, 246, 0.3);
  animation: pulse 2s infinite;
}

@keyframes pulse {
  0%, 100% { transform: scale(1); }
  50% { transform: scale(1.05); }
}

/* Floating Elements */
.floating-elements {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  pointer-events: none;
}

.float-element {
  position: absolute;
  font-size: 2rem;
  opacity: 0.7;
  animation: float 6s ease-in-out infinite;
}

.float-1 {
  top: 20%;
  left: 10%;
  animation-delay: 0s;
}

.float-2 {
  top: 30%;
  right: 15%;
  animation-delay: 1.5s;
}

.float-3 {
  bottom: 30%;
  left: 15%;
  animation-delay: 3s;
}

.float-4 {
  bottom: 20%;
  right: 10%;
  animation-delay: 4.5s;
}

@keyframes float {
  0%, 100% { transform: translateY(0px) rotate(0deg); }
  25% { transform: translateY(-20px) rotate(5deg); }
  50% { transform: translateY(-10px) rotate(-5deg); }
  75% { transform: translateY(-30px) rotate(3deg); }
}

/* Content Section */
.content-section {
  padding: 2rem;
  max-width: 1200px;
  margin: 0 auto;
}

/* Mission Card */
.mission-card {
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(20px);
  border-radius: 24px;
  padding: 2.5rem;
  margin-bottom: 3rem;
  box-shadow: 0 20px 60px rgba(0, 0, 0, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.5);
  transform: translateY(0);
  transition: all 0.3s ease;
}

.mission-card:hover {
  transform: translateY(-5px);
  box-shadow: 0 30px 80px rgba(0, 0, 0, 0.15);
}

.card-header {
  text-align: center;
  margin-bottom: 2rem;
}

.section-title {
  font-size: 2.2rem;
  font-weight: 700;
  color: #1e293b;
  margin-bottom: 0.5rem;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 0.5rem;
}

.section-icon {
  font-size: 2.5rem;
  animation: rotate 3s ease-in-out infinite;
}

@keyframes rotate {
  0%, 100% { transform: rotate(0deg); }
  50% { transform: rotate(10deg); }
}

.mission-text {
  font-size: 1.1rem;
  line-height: 1.8;
  color: #475569;
  text-align: center;
  margin-bottom: 2rem;
}

.tech-highlight {
  background: linear-gradient(45deg, #8b5cf6, #a855f7);
  background-clip: text;
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  font-weight: 600;
}

.mission-features {
  display: flex;
  justify-content: center;
  gap: 2rem;
  flex-wrap: wrap;
}

.feature-item {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  background: linear-gradient(45deg, #f0f9ff, #e0f2fe);
  padding: 0.8rem 1.2rem;
  border-radius: 15px;
  font-weight: 500;
  color: #0f172a;
  box-shadow: 0 4px 15px rgba(14, 165, 233, 0.1);
  transition: all 0.3s ease;
}

.feature-item:hover {
  transform: translateY(-3px);
  box-shadow: 0 8px 25px rgba(14, 165, 233, 0.2);
}

.feature-icon {
  font-size: 1.2rem;
}

/* Team Section */
.team-section {
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(20px);
  border-radius: 24px;
  padding: 2.5rem;
  box-shadow: 0 20px 60px rgba(0, 0, 0, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.5);
}

.team-header {
  text-align: center;
  margin-bottom: 3rem;
}

.team-subtitle {
  color: #64748b;
  font-size: 1.1rem;
  margin-top: 0.5rem;
}

.team-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
  gap: 1.5rem;
}

.team-member {
  background: linear-gradient(145deg, #ffffff, #f8fafc);
  border-radius: 20px;
  padding: 1.5rem;
  text-align: center;
  box-shadow: 0 8px 30px rgba(0, 0, 0, 0.08);
  border: 1px solid rgba(226, 232, 240, 0.5);
  transition: all 0.3s ease;
  position: relative;
  overflow: hidden;
}

.team-member::before {
  content: '';
  position: absolute;
  top: 0;
  left: -100%;
  width: 100%;
  height: 3px;
  transition: all 0.3s ease;
}

.team-member.leader::before { background: linear-gradient(90deg, #f59e0b, #fbbf24); }
.team-member.frontend::before { background: linear-gradient(90deg, #3b82f6, #60a5fa); }
.team-member.backend::before { background: linear-gradient(90deg, #10b981, #34d399); }
.team-member.scrum::before { background: linear-gradient(90deg, #8b5cf6, #a78bfa); }

.team-member:hover {
  transform: translateY(-8px);
  box-shadow: 0 20px 50px rgba(0, 0, 0, 0.15);
}

.team-member:hover::before {
  left: 0;
}

.member-avatar {
  width: 80px;
  height: 80px;
  border-radius: 50%;
  background: linear-gradient(145deg, #f1f5f9, #e2e8f0);
  margin: 0 auto 1rem;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 8px 25px rgba(0, 0, 0, 0.1);
  transition: all 0.3s ease;
}

.team-member:hover .member-avatar {
  transform: scale(1.1) rotate(5deg);
}

.avatar-emoji {
  font-size: 2rem;
}

.member-name {
  font-size: 1.3rem;
  font-weight: 600;
  color: #1e293b;
  margin-bottom: 0.3rem;
}

.member-role {
  color: #64748b;
  font-size: 0.95rem;
  margin-bottom: 1rem;
}

.member-badge {
  display: inline-block;
  padding: 0.3rem 0.8rem;
  border-radius: 12px;
  font-size: 0.8rem;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.5px;
}

.leader-badge {
  background: linear-gradient(45deg, #f59e0b, #fbbf24);
  color: white;
}

.frontend-badge {
  background: linear-gradient(45deg, #3b82f6, #60a5fa);
  color: white;
}

.backend-badge {
  background: linear-gradient(45deg, #10b981, #34d399);
  color: white;
}

.scrum-badge {
  background: linear-gradient(45deg, #8b5cf6, #a78bfa);
  color: white;
}

/* Responsive Design */
@media (max-width: 768px) {
  .hero-section {
    padding: 2rem 1rem;
  }

  .content-section {
    padding: 1rem;
  }

  .mission-card,
  .team-section {
    padding: 1.5rem;
  }

  .mission-features {
    flex-direction: column;
    align-items: center;
  }

  .team-grid {
    grid-template-columns: 1fr;
    gap: 1rem;
  }

  .section-title {
    font-size: 1.8rem;
  }

  .floating-elements {
    display: none;
  }
}

@media (max-width: 480px) {
  .hero-title {
    font-size: 2rem;
  }

  .main-description {
    font-size: 1rem;
  }

  .university-badge {
    display: block;
    margin: 0.5rem auto;
    width: fit-content;
  }
}
</style>
