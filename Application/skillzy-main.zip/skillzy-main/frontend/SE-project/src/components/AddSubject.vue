<template>
  <div class="add-subject-container">
    <h2>Add New Subject</h2>
    <form @submit.prevent="handleSubmit" novalidate>
      <label for="subjectName">Subject Name</label>
      <input
        id="subjectName"
        v-model="subjectName"
        type="text"
        placeholder="Enter subject name"
        required
      />
      <div v-if="error" class="error-message">{{ error }}</div>
      <div v-if="success" class="success-message">{{ success }}</div>
      <button type="submit" :disabled="loading">
        {{ loading ? 'Adding...' : 'Add Subject' }}
      </button>
    </form>
  </div>
</template>

<script setup>
import { ref } from 'vue'

const subjectName = ref('')
const loading = ref(false)
const error = ref('')
const success = ref('')

async function handleSubmit() {
  error.value = ''
  success.value = ''

  if (!subjectName.value.trim()) {
    error.value = 'Subject name is required.'
    return
  }

  loading.value = true
  try {
    // Replace URL with your backend API endpoint
    const response = await fetch('/admin/dashboard', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ name: subjectName.value.trim() })
    })

    if (!response.ok) {
      const errData = await response.json()
      throw new Error(errData.message || 'Failed to add subject')
    }

    success.value = 'Subject added successfully!'
    subjectName.value = ''
  } catch (err) {
    error.value = err.message
  } finally {
    loading.value = false
  }
}
</script>

<style scoped>
.add-subject-container {
  max-width: 400px;
  margin: 2rem auto;
  padding: 1.5rem;
  border: 1px solid #ddd;
  border-radius: 8px;
  background: #fff;
  box-shadow: 0 2px 8px rgba(0,0,0,0.1);
}

h2 {
  margin-bottom: 1rem;
  text-align: center;
}

label {
  display: block;
  font-weight: 600;
  margin-bottom: 0.5rem;
}

input[type="text"] {
  width: 100%;
  padding: 0.5rem;
  border-radius: 5px;
  border: 1px solid #ccc;
  font-size: 1rem;
  margin-bottom: 1rem;
}

button {
  width: 100%;
  padding: 0.6rem;
  background: #3b82f6;
  color: white;
  border: none;
  font-size: 1rem;
  border-radius: 5px;
  cursor: pointer;
}

button:disabled {
  background: #93c5fd;
  cursor: not-allowed;
}

.error-message {
  color: #ef4444;
  margin-bottom: 1rem;
  font-weight: 600;
}

.success-message {
  color: #10b981;
  margin-bottom: 1rem;
  font-weight: 600;
  text-align: center;
}
</style>
