<template>
  <div class="announcements-page">
    <main class="main">
      <!-- <Header title="Announcements" subtitle="Broadcast messages to platform users" /> -->
      <header class="page-header" style="color: whitesmoke;">
        <h1>Announcements</h1>
        <p>Broadcast messages to platform users</p>
      </header>

      <div class="announcements-layout">
        <div class="left-column">
          <section class="card new-announcement">
            <h3>Create Announcement</h3>
            <div class="form-group">
              <label for="subject">Subject</label>
              <input v-model="newPost.subject" placeholder="Enter announcement subject" class="input" id="subject" />
            </div>

            <div class="form-group">
              <label for="message">Message</label>
              <textarea
                v-model="newPost.body"
                placeholder="Write your announcement..."
                class="textarea"
                id="message"
              ></textarea>
            </div>

            <div class="controls-row">
              <div class="form-group send-to-group">
                <label>Send to:</label>
                <select v-model="newPost.role" class="select">
                  <option value="all">All Users</option>
                  <option value="student">Students Only</option>
                  <option value="teacher">Teachers Only</option>
                  <option value="parent">Parents Only</option>
                </select>
              </div>
<!-- 
              <div class="form-group tag-users-group">
                <label>Tag Users:</label>
                <input
                  v-model="newTag"
                  @keyup.enter="addTag"
                  placeholder="Type user ID or name & press Enter"
                  class="input"
                />
              </div> -->
            </div>

            <div class="tags-container">
              <span v-for="(tag, i) in newPost.tags" :key="i" class="tag-pill">
                {{ tag }}
                <button @click="removeTag(i)" class="remove-tag-btn">✖</button>
              </span>
            </div>

            <div class="attachment-group">
              <label class="attach-label">
                <input type="file" @change="handleFileUpload" class="file-input" />
                <span class="file-btn">Choose File</span>
              </label>
              <span v-if="newPost.attachmentName" class="attachment-name">📎 {{ newPost.attachmentName }}</span>
              <span v-else class="no-file-text">No file chosen</span>
            </div>

            <button @click="postAnnouncement" class="submit-btn primary-btn">
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-send"><path d="m22 2-7 7m7-7L10 22 3 15m7-7L3 15"/></svg>
              Post Announcement
            </button>
          </section>

          <section class="card announcement-list">
            <h3>Previous Announcements</h3>
            <div v-for="post in paginatedAnnouncements" :key="post.id" class="post-card">
              <div class="post-meta-top">
                 <span class="send-label">Sent</span>
                <span class="timestamp">{{ post.timestamp }}</span>
              </div>
              <div class="post-header-main">
                <h4 class="post-subject">{{ post.subject }}</h4>
                <div class="post-actions">
                  <button @click="openModal(post)" class="action-btn view-btn">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-eye"><path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/></svg>
                    View
                  </button>
                  
                </div>
              </div>
              <p class="post-body">{{ truncateBody(post.body) }}</p>
              <div class="post-footer">
                <span class="target-role">To: {{ formatRole(post.role) }}</span>
                <span v-if="post.tags && post.tags.length" class="tags-inline">
                  Tags: <span v-for="t in post.tags" :key="t" class="tag-inline">{{ t }}</span>
                </span>
              </div>
            </div>

            <!-- Modal for full announcement -->
            <div v-if="showModal" class="announcement-modal-overlay" @click.self="closeModal">
              <div class="announcement-modal">
                <div class="announcement-modal-header">
                  <h4>{{ selectedAnnouncement.subject }}</h4>
                  <button class="close-modal-btn" @click="closeModal">&times;</button>
                </div>
                <div class="announcement-modal-body">
                  <div class="announcement-modal-meta">
                    <span class="timestamp">{{ selectedAnnouncement.timestamp }}</span>
                    <span class="target-role">To: {{ formatRole(selectedAnnouncement.role) }}</span>
                  </div>
                  <div class="announcement-modal-message">{{ selectedAnnouncement.body }}</div>
                </div>
              </div>
            </div>
             <div class="table-footer">
              <div class="results-summary">
                Showing {{ (currentPage - 1) * itemsPerPage + 1 }} - {{ Math.min(currentPage * itemsPerPage, announcements.length) }} of {{ announcements.length }} announcements
              </div>
              <div class="pagination">
                <button @click="prevPage" :disabled="currentPage === 1">Previous</button>
                <button
                  v-for="page in totalPages"
                  :key="page"
                  @click="goToPage(page)"
                  :class="{ active: currentPage === page }"
                >
                  {{ page }}
                </button>
                <button @click="nextPage" :disabled="currentPage === totalPages">Next</button>
              </div>
            </div>
          </section>
        </div>

        <div class="right-column">
          

          <section class="card send-statistics">
            <h3>Statistics</h3>
            <div class="stat-item">
              <span>Today</span>
              <span class="stat-value">{{ todayCount }} sent</span>
            </div>
            <div class="stat-item">
              <span>This Week</span>
              <span class="stat-value">{{ weekCount }} sent</span>
            </div>
            <div class="stat-item">
              <span>This Month</span>
              <span class="stat-value">{{ monthCount }} sent</span>
            </div>
          </section>
        </div>
      </div>
    </main>
  </div>
</template>

<script setup>
import { ref, onMounted, computed } from 'vue'
import Header from '../components/Header.vue'
import MetricCard from './MetricCard.vue';
import api from '../api'

const announcements = ref([])

const showModal = ref(false)
const selectedAnnouncement = ref({})

function openModal(post) {
  selectedAnnouncement.value = post
  showModal.value = true
}

function closeModal() {
  showModal.value = false
}

function truncateBody(body) {
  if (!body) return ''
  return body.length > 200 ? body.slice(0, 200) + '...' : body
}

const newPost = ref({
  subject: '',
  body: '',
  role: 'all',
  tags: [],
  attachment: null,
  attachmentName: ''
})

const newTag = ref('')

const currentPage = ref(1)
const itemsPerPage = 3

const paginatedAnnouncements = computed(() => {
  const start = (currentPage.value - 1) * itemsPerPage
  const end = start + itemsPerPage
  return announcements.value.slice(start, end)
})

const totalPages = computed(() => Math.ceil(announcements.value.length / itemsPerPage))

function goToPage(page) {
  if (page >= 1 && page <= totalPages.value) {
    currentPage.value = page
  }
}

function nextPage() {
  if (currentPage.value < totalPages.value) {
    currentPage.value++
  }
}

function prevPage() {
  if (currentPage.value > 1) {
    currentPage.value--
  }
}


function addTag() {
  if (newTag.value.trim()) {
    newPost.value.tags.push(newTag.value.trim())
    newTag.value = ''
  }
}

function removeTag(index) {
  newPost.value.tags.splice(index, 1)
}

function handleFileUpload(event) {
  const file = event.target.files[0]
  if (file) {
    newPost.value.attachment = file
    newPost.value.attachmentName = file.name
  } else {
    newPost.value.attachment = null;
    newPost.value.attachmentName = '';
  }
}

async function postAnnouncement() {
  if (!newPost.value.subject || !newPost.value.body) {
    alert('Subject and body are required.')
    return
  }

  const formData = new FormData()
  formData.append('subject', newPost.value.subject)
  formData.append('body', newPost.value.body)
  formData.append('recipient_role', newPost.value.role)
  if (newPost.value.attachment) {
    formData.append('file', newPost.value.attachment)
  }

  try {
    const res = await api.post('/admin/announcement', formData, {
      headers: { 'Content-Type': 'multipart/form-data' }
    })

    const newAnn = res.data.announcement
    announcements.value.unshift({
      id: newAnn.id,
      subject: newAnn.subject,
      body: newAnn.body,
      role: newAnn.recipient_role,
      tags: [],
      timestamp: new Date(newAnn.created_at).toLocaleDateString('en-US', {
        month: 'long',
        day: 'numeric',
        year: 'numeric'
      }),
      attachmentName: newAnn.file_url?.split('/').pop() || ''
    })

    newPost.value = {
      subject: '',
      body: '',
      role: 'all',
      tags: [],
      attachment: null,
      attachmentName: ''
    }
     alert('Announcement posted successfully!');
  } catch (error) {
    console.error('Error posting announcement:', error)
    alert('Failed to post announcement.')
  }
}

async function fetchAnnouncements() {
  try {
    const res = await api.get('/admin/announcements')
    announcements.value = res.data.announcements.map(a => ({
      id: a.id,
      subject: a.subject,
      body: a.body,
      role: a.recipient_role,
      tags: [],
      timestamp: new Date(a.created_at).toLocaleDateString('en-US', {
        month: 'long',
        day: 'numeric',
        year: 'numeric'
      }),
      attachmentName: a.file_url?.split('/').pop() || ''
    }))
  } catch (err) {
    console.error('Failed to fetch announcements:', err)
  }
}

onMounted(fetchAnnouncements)

function formatRole(role) {
  if (role === 'student') return 'Students'
  if (role === 'teacher') return 'Teachers'
  if (role === 'parent') return 'Parents'
  return 'All Users'
}

// Send statistics
const todayCount = computed(() => {
  const today = new Date();
  return announcements.value.filter(a => {
    const d = new Date(a.timestamp);
    return d.getDate() === today.getDate() &&
      d.getMonth() === today.getMonth() &&
      d.getFullYear() === today.getFullYear();
  }).length;
});

const weekCount = computed(() => {
  const now = new Date();
  const startOfWeek = new Date(now);
  startOfWeek.setDate(now.getDate() - now.getDay()); // Sunday
  startOfWeek.setHours(0,0,0,0);
  return announcements.value.filter(a => {
    const d = new Date(a.timestamp);
    return d >= startOfWeek && d <= now;
  }).length;
});

const monthCount = computed(() => {
  const now = new Date();
  return announcements.value.filter(a => {
    const d = new Date(a.timestamp);
    return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear();
  }).length;
});

function editAnnouncement(post) {
  alert(`Editing announcement: ${post.subject}\n\n(Functionality to edit will be implemented here)`);
}
</script>

<style scoped>
.announcements-page {
  /* No background here */
}

.main {
  flex: 1;
  padding: 2rem;
  color: var(--text);
  /* background: linear-gradient(135deg, #00c66f, #00c2c2); */
  background: linear-gradient(135deg, #427eff, #b72eff);

  width: 100%;
  min-height: calc(100vh - 2rem); /* Adjust for top padding */
  box-sizing: border-box;
  position: relative;
  z-index: 1;
}

.overview-metrics-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
  gap: 1.5rem;
  margin-bottom: 2rem;
  background: transparent;
  padding: 1 rem;
  border-radius: 12px;
}

.announcements-layout {
  display: grid;
  grid-template-columns: 2fr 1fr;
  gap: 2rem;
  align-items: flex-start;
}

.left-column {
  display: flex;
  flex-direction: column;
  gap: 2rem;
}

.right-column {
  display: flex;
  flex-direction: column;
  gap: 2rem;
}

.card {
  background-color: var(--card);
  padding: 1.5rem 2rem;
  border-radius: 12px;
  box-shadow: var(--shadow);
  border: 1px solid var(--border);
  color: var(--text);
}

.card h3 {
  margin-top: 0;
  margin-bottom: 1.5rem;
  font-size: 1.5rem;
  font-weight: 600;
  color: var(--primary);
}

.form-group {
  margin-bottom: 1.2rem;
}

.form-group label {
  display: block;
  margin-bottom: 0.6rem;
  font-weight: 500;
  color: var(--text-secondary);
  font-size: 0.95rem;
}

.input,
.textarea,
.select {
  width: 100%;
  padding: 0.75rem 1rem;
  border-radius: 8px;
  border: 1px solid var(--border);
  background-color: var(--bg);
  color: var(--text);
  font-size: 1rem;
  box-sizing: border-box;
  transition: border-color 0.2s ease, box-shadow 0.2s ease;
}

.input:focus,
.textarea:focus,
.select:focus {
  outline: none;
  border-color: var(--primary);
  box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.2);
}

.textarea {
  min-height: 100px;
  resize: vertical;
}

.controls-row {
  display: flex;
  gap: 1.5rem;
  margin-bottom: 1.2rem;
  flex-wrap: wrap;
}

.send-to-group,
.tag-users-group {
  flex: 1;
  min-width: 200px;
}

.tags-container {
  display: flex;
  flex-wrap: wrap;
  gap: 0.75rem;
  margin-bottom: 1.5rem;
}

.tag-pill {
  background-color: var(--secondary);
  padding: 6px 12px;
  border-radius: 20px;
  font-size: 0.85rem;
  display: inline-flex;
  align-items: center;
  color: var(--text);
  font-weight: 500;
}

.remove-tag-btn {
  background: none;
  border: none;
  color: var(--text);
  margin-left: 8px;
  cursor: pointer;
  font-size: 0.9rem;
  line-height: 1;
  padding: 0;
}

.attachment-group {
  display: flex;
  align-items: center;
  gap: 1rem;
  margin-bottom: 1.5rem;
  flex-wrap: wrap;
}

.attach-label {
  display: flex;
  align-items: center;
  cursor: pointer;
  background-color: blue;
  color: white;
  padding: 0.6rem 1rem;
  border-radius: 8px;
  font-weight: 500;
  transition: background-color 0.2s ease;
}

.attach-label:hover {
  background-color: var(--primary-hover);
}

.file-input {
  display: none;
}

.file-btn {
  line-height: 1;
  
}

.attachment-name {
  font-size: 0.9rem;
  color: var(--text-secondary);
}

.no-file-text {
  font-size: 0.9rem;
  color: #888;
}

.submit-btn {
  width: auto;
  padding: 0.8rem 1.8rem;
  font-size: 1rem;
  font-weight: 600;
  border-radius: 10px;
  display: flex;
  align-items: center;
  gap: 0.5rem;
  transition: all 0.2s ease;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
}

.primary-btn {
  background-color: blue;
  color: white;
}

.primary-btn:hover {
  background-color: var(--primary-hover);
  transform: translateY(-2px);
  box-shadow: 0 6px 15px rgba(79, 70, 229, 0.3);
}

.quick-actions {
  display: flex;
  flex-direction: column;
  gap: 1rem;
}

.action-card-btn {
  display: flex;
  align-items: center;
  gap: 0.8rem;
  width: 100%;
  padding: 0.8rem 1rem;
  border-radius: 10px;
  font-size: 1rem;
  font-weight: 600;
  color: white;
  border: none;
  cursor: pointer;
  transition: all 0.2s ease;
  box-shadow: 0 3px 8px rgba(0,0,0,0.1);
}

.action-card-btn svg {
  width: 20px;
  height: 20px;
}

.emergency-btn { background-color: #ef4444; }
.emergency-btn:hover { background-color: #dc2626; transform: translateY(-2px); box-shadow: 0 5px 12px rgba(239, 68, 68, 0.3); }

.schedule-btn { background-color: #3b82f6; }
.schedule-btn:hover { background-color: #2563eb; transform: translateY(-2px); box-shadow: 0 5px 12px rgba(59, 130, 246, 0.3); }

.template-btn { background-color: #10b981; }
.template-btn:hover { background-color: #059669; transform: translateY(-2px); box-shadow: 0 5px 12px rgba(16, 185, 129, 0.3); }

.send-statistics {
  display: flex;
  flex-direction: column;
  gap: 0.8rem;
}

.send-statistics .stat-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0.6rem 0;
  border-bottom: 1px solid var(--border);
  font-size: 0.95rem;
  color: var(--text-secondary);
}

.send-statistics .stat-item:last-child {
  border-bottom: none;
}

.stat-value {
  font-weight: 600;
  color: var(--primary);
}

.post-card {
  background-color: var(--bg);
  border: 1px solid var(--border);
  border-radius: 10px;
  padding: 1.2rem 1.5rem;
  margin-bottom: 1.2rem;
  box-shadow: 0 2px 8px rgba(0,0,0,0.03);
  transition: all 0.2s ease;
}

.post-card:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(0,0,0,0.08);
}

.post-meta-top {
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-size: 0.85rem;
  color: #888;
  margin-bottom: 0.5rem;
}

.send-label {
  background-color: #d1fae5;
  color: #065f46;
  padding: 3px 8px;
  border-radius: 12px;
  font-weight: 600;
}

.timestamp {
}

.post-header-main {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 0.8rem;
  flex-wrap: wrap;
  gap: 0.5rem;
}

.post-subject {
  font-size: 1.15rem;
  font-weight: 700;
  color: var(--text);
  margin: 0;
  flex-grow: 1;
}

.post-actions {
  display: flex;
  gap: 0.5rem;
}

.action-btn {
  display: flex;
  align-items: center;
  gap: 0.3rem;
  padding: 0.4rem 0.8rem;
  border-radius: 8px;
  font-size: 0.85rem;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.2s ease;
  border: 1px solid var(--border);
  background-color: var(--bg);
  color: var(--text);
}

.action-btn:hover {
  background-color: var(--primary);
  color: white;
  border-color: var(--primary);
}

.view-btn {
}

.edit-btn {
}

.post-body {
  font-size: 0.95rem;
  color: var(--text-secondary);
  line-height: 1.5;
  margin-bottom: 1rem;
  word-break: break-word;
  overflow-wrap: anywhere;
  max-width: 100%;
}

.announcement-modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100vw;
  height: 100vh;
  background: rgba(0,0,0,0.3);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
}
.announcement-modal {
  background: var(--card);
  border-radius: 12px;
  box-shadow: 0 8px 32px rgba(0,0,0,0.18);
  max-width: 480px;
  width: 95vw;
  padding: 1.5rem 1.5rem 1.2rem 1.5rem;
  position: relative;
  word-break: break-word;
}
.announcement-modal-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 1rem;
}
.close-modal-btn {
  background: none;
  border: none;
  font-size: 2rem;
  color: var(--text-secondary);
  cursor: pointer;
  line-height: 1;
}
.announcement-modal-body {
  word-break: break-word;
  overflow-wrap: anywhere;
  max-width: 100%;
}
.announcement-modal-meta {
  font-size: 0.9rem;
  color: var(--text-secondary);
  margin-bottom: 0.7rem;
  display: flex;
  gap: 1.2rem;
}
.announcement-modal-message {
  font-size: 1rem;
  color: var(--text);
  white-space: pre-line;
}

.post-footer {
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-size: 0.85rem;
  color: #888;
  flex-wrap: wrap;
  gap: 0.5rem;
}

.target-role {
  font-weight: 500;
  color: var(--primary);
}

.tags-inline {
  background-color: var(--secondary);
  color: var(--text);
  padding: 3px 8px;
  border-radius: 10px;
  font-size: 0.75rem;
  font-weight: 500;
}

.table-footer {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding-top: 1.5rem;
  border-top: 1px solid var(--border);
  margin-top: 1.5rem;
  flex-wrap: wrap;
  gap: 1rem;
}
.results-summary {
  font-size: 0.9rem;
  color: var(--text-secondary);
}
.pagination {
  display: flex;
  gap: 0.5rem;
}
.pagination button {
  padding: 0.5rem 1rem;
  border: 1px solid var(--border);
  border-radius: 6px;
  background-color: var(--bg);
  color: var(--text);
  cursor: pointer;
  transition: all 0.2s ease;
  font-weight: 500;
}
.pagination button:hover:not(:disabled),
.pagination button.active {
  background-color: var(--primary);
  color: white;
  border-color: var(--primary);
}
.pagination button:disabled {
  opacity: 0.6;
  cursor: not-allowed;
}

@media (max-width: 900px) {
  .announcements-layout {
    grid-template-columns: 1fr;
  }
  .left-column,
  .right-column {
    width: 100%;
  }
  .card {
    padding: 1rem;
  }
  .controls-row {
    flex-direction: column;
    gap: 0.8rem;
  }
  .send-to-group,
  .tag-users-group {
    width: 100%;
  }
  .post-card {
    padding: 1rem;
  }
  .post-subject {
    font-size: 1rem;
  }
  .post-body {
    font-size: 0.9rem;
  }
  .action-btn {
    padding: 0.3rem 0.6rem;
    font-size: 0.75rem;
  }
}

@media (max-width: 600px) {
  .main {
    padding: 1rem;
  }
  .overview-metrics-grid {
    grid-template-columns: 1fr;
  }
  .card h3 {
    font-size: 1.25rem;
  }
  .input,
  .textarea,
  .select {
    padding: 0.6rem;
    font-size: 0.9rem;
  }
  .submit-btn {
    padding: 0.6rem 1.5rem;
    font-size: 0.9rem;
  }
  .action-card-btn {
    padding: 0.6rem;
    font-size: 0.9rem;
  }
  .stat-item {
    font-size: 0.85rem;
  }
  .table-footer {
    flex-direction: column;
    align-items: center;
    gap: 0.8rem;
  }
}
</style>