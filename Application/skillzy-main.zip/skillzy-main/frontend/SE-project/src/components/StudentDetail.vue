<template>
  <div>
    <Header :title="'Student Profile: ' + student.name" subtitle="Detailed view of student progress and information." />

    <div class="profile-card">
      <img :src="student.avatar" alt="Student Avatar" class="profile-avatar">
      <h2>{{ student.name }}</h2>
      <p><strong>ID:</strong> {{ student.id }}</p>
      <p><strong>Class:</strong> {{ student.class }}</p>
      <p><strong>Status:</strong> <span :class="['status-pill', getStatusClass(student.status)]">{{ student.status }}</span></p>
      <p><strong>Last Activity:</strong> {{ student.lastActivity }}</p>
      <button @click="goBack" class="back-btn">← Back to All Students</button>
    </div>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue';
import { useRouter, useRoute } from 'vue-router';
import Header from './Header.vue';

const router = useRouter();
const route = useRoute();

// NOTE: Sidebar and navLinks are no longer needed here. They are handled by the parent layout.

// In a real app, you would fetch this data based on the ID from the route.
// For this example, we'll use a static list to find the student.
const allStudents = ref([
    { id: '#1001', name: 'Rahul Sharma', avatar: 'https://i.pravatar.cc/150?img=1', class: 'Grade 5', lastActivity: '2 hours ago', status: 'Active' },
    { id: '#1002', name: 'Arya Chavan', avatar: 'https://i.pravatar.cc/150?img=2', class: 'Grade 5', lastActivity: '5 hours ago', status: 'Active' },
    { id: '#1003', name: 'Aarush Saxena', avatar: 'https://i.pravatar.cc/150?img=3', class: 'Grade 6', lastActivity: '1 day ago', status: 'Inactive' },
    { id: '#1004', name: 'Gopu Vishal Reddy', avatar: 'https://i.pravatar.cc/150?img=4', class: 'Grade 6', lastActivity: '3 days ago', status: 'Blocked' },
]);

const student = computed(() => {
  // The ID from the URL does not have a '#', so we find it directly
  return allStudents.value.find(s => s.id === '#' + route.params.id) || {};
});

const goBack = () => {
  router.push('/instructor/studentmanagement');
};

const getStatusClass = (status) => {
  if (status === 'Active') return 'status-active';
  if (status === 'Inactive') return 'status-inactive';
  if (status === 'Blocked') return 'status-blocked';
  return '';
};
</script>

<style scoped>
.profile-card {
  background-color: var(--card);
  padding: 2rem;
  border-radius: 12px;
  margin-top: 2rem;
  text-align: center;
  box-shadow: 0 4px 12px rgba(0,0,0,0.05);
}
.profile-avatar {
  width: 120px;
  height: 120px;
  border-radius: 50%;
  margin-bottom: 1rem;
  border: 4px solid var(--primary);
}
.back-btn {
  margin-top: 2rem;
  padding: 0.75rem 1.5rem;
  border: none;
  background-color: var(--primary);
  color: white;
  border-radius: 8px;
  cursor: pointer;
  font-weight: 600;
}
.status-pill {
  padding: 4px 12px;
  border-radius: 20px;
  font-weight: 500;
  font-size: 0.9rem;
}
.status-active {
  background-color: #dcfce7;
  color: #166534;
}
.status-inactive {
  background-color: #fee2e2;
  color: #991b1b;
}
.status-blocked {
  background-color: #e5e7eb;
  color: #374151;
}
</style>