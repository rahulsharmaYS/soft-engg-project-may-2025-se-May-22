<template>
  <section class="features-container">
    <div class="hero-section">
      <div class="hero-content">
        <h1 class="hero-title">
          <span class="title-icon">✨</span>
          Skillzy Features
          <span class="sparkle">🌟</span>
        </h1>
        <p class="hero-subtitle">
          Discover the amazing features that make learning fun, interactive, and effective
        </p>
      </div>
      <div class="floating-shapes">
        <div class="shape shape-1"></div>
        <div class="shape shape-2"></div>
        <div class="shape shape-3"></div>
      </div>
    </div>

    <div class="features-grid">
      <div class="feature-card learning-tracks">
        <div class="card-header">
          <div class="feature-icon">📚</div>
          <h3 class="feature-title">Skill-Based Learning</h3>
        </div>
        <div class="feature-content">
          <p class="feature-description">
            Comprehensive learning tracks across <strong>Math</strong>, <strong>English</strong> & <strong>Logic</strong> 
            designed to build essential skills step by step.
          </p>
          <div class="feature-tags">
            <span class="tag">Math</span>
            <span class="tag">English</span>
            <span class="tag">Logic</span>
          </div>
        </div>
        <div class="card-glow learning-glow"></div>
      </div>

      <div class="feature-card instructors">
        <div class="card-header">
          <div class="feature-icon">👨‍🏫</div>
          <h3 class="feature-title">Choose Your Instructors</h3>
        </div>
        <div class="feature-content">
          <p class="feature-description">
            Select your favorite instructors based on your interests and learning style. 
            Personalized education at its finest!
          </p>
          <div class="instructor-avatars">
            <div class="avatar">👩‍🏫</div>
            <div class="avatar">👨‍🎓</div>
            <div class="avatar">👩‍🔬</div>
            <div class="avatar plus">+</div>
          </div>
        </div>
        <div class="card-glow instructor-glow"></div>
      </div>

      <div class="feature-card interactive">
        <div class="card-header">
          <div class="feature-icon">🧠</div>
          <h3 class="feature-title">Interactive & Fun</h3>
        </div>
        <div class="feature-content">
          <p class="feature-description">
            Engaging content designed specifically for grades 3 to 8 with gamification, 
            quizzes, and interactive activities.
          </p>
          <div class="grade-range">
            <span class="grade">3rd</span>
            <span class="grade-divider">→</span>
            <span class="grade">8th</span>
            <span class="grade-label">Grades</span>
          </div>
        </div>
        <div class="card-glow interactive-glow"></div>
      </div>

      <div class="feature-card safety">
        <div class="card-header">
          <div class="feature-icon">🔐</div>
          <h3 class="feature-title">Safe & Secure</h3>
        </div>
        <div class="feature-content">
          <p class="feature-description">
            Kid-friendly, privacy-first platform with robust security measures 
            to ensure a safe learning environment.
          </p>
          <div class="safety-badges">
            <div class="safety-badge">
              <span class="badge-icon">👶</span>
              <span>Kid-Safe</span>
            </div>
            <div class="safety-badge">
              <span class="badge-icon">🛡️</span>
              <span>Privacy First</span>
            </div>
          </div>
        </div>
        <div class="card-glow safety-glow"></div>
      </div>

      <div class="feature-card technology">
        <div class="card-header">
          <div class="feature-icon">🧪</div>
          <h3 class="feature-title">Modern Technology</h3>
        </div>
        <div class="feature-content">
          <p class="feature-description">
            Built with cutting-edge technologies including Vue 3, Tailwind CSS, 
            and Node.js for optimal performance.
          </p>
          <div class="tech-stack">
            <div class="tech-item vue">Vue 3</div>
            <div class="tech-item tailwind">Tailwind</div>
            <div class="tech-item node">Node.js</div>
          </div>
        </div>
        <div class="card-glow tech-glow"></div>
      </div>

      <div class="feature-card creators">
        <div class="card-header">
          <div class="feature-icon">💡</div>
          <h3 class="feature-title">Expert Creators</h3>
        </div>
        <div class="feature-content">
          <p class="feature-description">
            Developed by passionate IIT Madras BS Data Science students 
            with expertise in education technology.
          </p>
          <div class="creators-info">
            <div class="institution">
              <span class="institution-icon">🎓</span>
              <span>IIT Madras</span>
            </div>
            <div class="program">
              <span class="program-icon">📊</span>
              <span>Data Science</span>
            </div>
          </div>
        </div>
        <div class="card-glow creators-glow"></div>
      </div>
    </div>

    <div class="cta-section">
      <h2 class="cta-title">Ready to Start Your Learning Journey?</h2>
      <p class="cta-subtitle">Join thousands of students already learning with Skillzy</p>
      <div class="cta-stats">
        <div class="stat">
          <span class="stat-number">10K+</span>
          <span class="stat-label">Happy Students</span>
        </div>
        <div class="stat">
          <span class="stat-number">500+</span>
          <span class="stat-label">Expert Teachers</span>
        </div>
        <div class="stat">
          <span class="stat-number">98%</span>
          <span class="stat-label">Success Rate</span>
        </div>
      </div>
    </div>
  </section>
     <footer class="footer">
      <div class="footer-content">
        <div class="footer-left">
          <h3>Skillzy</h3>
          <p>
            Empowering young minds with essential life skills through interactive
            learning, AI-powered assistance, and fun activities for ages 8–14.
          </p>
          <div class="social-icons">
          <a href="https://www.facebook.com/iitmadrasbsdegree/about/" target="_blank"><img src="https://cdn-icons-png.flaticon.com/512/733/733547.png" alt="Facebook" class="social-icon" /></a>
          <a href="https://github.com/rahulsharmaYS/soft-engg-project-may-2025-se-May-22" target="_blank"><img src="https://cdn-icons-png.flaticon.com/512/733/733609.png" alt="GitHub" class="social-icon" /></a>
          <a href="https://study.iitm.ac.in/ds/" target="_blank"><img src="https://cdn-icons-png.flaticon.com/512/2702/2702602.png" alt="Google" class="social-icon" /></a>
          <a href="https://www.instagram.com/iitmadras_bs/" target="_blank"><img src="https://cdn-icons-png.flaticon.com/512/733/733558.png" alt="Instagram" class="social-icon" /></a>
          </div>
        </div>

        <div class="footer-links">
          <h4>Quick Links</h4>
          <ul>
            <li><router-link to="/">Home</router-link></li>
            <li><router-link to="/about">About Us</router-link></li>
            <li><router-link to="/features">Features</router-link></li>
            <li><router-link to="/privacy">Privacy Policy</router-link></li>
            <li><router-link to="/terms">Terms of Service</router-link></li>
          </ul>
        </div>

        <div class="footer-contact">
          <h4>Contact Us</h4>
          <p>Dummy Email: <u>team22@seproject.com</u></p>
          <p>Phone: <u>+91 9560594522</u></p>
          <p>Address: <u>IIT Madras, SoftWare Engineering Course</u></p>
        </div>
      </div>
      <div class="footer-bottom">
        © 2025 Skillzy. Made with ❤️ for young learners.
      </div>
    </footer>
</template>

<style scoped>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap');
.footer {
  background: #7400b8;
  color: white;
  padding: 2rem 1rem 1rem;
}
.footer-content {
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
  gap: 2rem;
}
.footer-left,
.footer-links,
.footer-contact {
  flex: 1;
  min-width: 200px;
}
.footer h4 {
  margin-bottom: 1rem;
}
.footer-links ul {
  list-style: none;
  padding: 0;
}
.footer-links li {
  margin-bottom: 0.5rem;
}
.footer-links a {
  color: white;
  text-decoration: none;
}
.footer-links a:hover {
  text-decoration: underline;
}
.social-icons a {
  font-size: 1.5rem;
  margin-right: 0.5rem;
  color: white;
}
.footer-bottom {
  margin-top: 2rem;
  text-align: center;
  font-size: 0.85rem;
  border-top: 1px solid rgba(255, 255, 255, 0.2);
  padding-top: 1rem;
}
.social-icons {
  display: flex;
  justify-content: center;
  gap: 10px;
  margin-top: 30px;
}
.social-icon {
  width: 30px;
  height: 30px;
  transition: transform 0.3s;
  cursor: pointer;
}

.social-icon:hover {
  transform: scale(1.1);
}

.features-container {
  font-family: 'Inter', sans-serif;
  background: linear-gradient(135deg, #0f766e 0%, #059669 50%, #10b981 100%);
  min-height: 100vh;
  position: relative;
  overflow: hidden;
}

/* Hero Section */
.hero-section {
  position: relative;
  padding: 4rem 2rem 2rem;
  text-align: center;
  color: white;
}

.hero-content {
  max-width: 800px;
  margin: 0 auto;
  position: relative;
  z-index: 2;
}

.hero-title {
  font-size: clamp(2.5rem, 6vw, 4rem);
  font-weight: 800;
  margin-bottom: 1rem;
  background: linear-gradient(45deg, #fff, #f0fdf4, #dcfce7);
  background-clip: text;
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  animation: titlePulse 3s ease-in-out infinite;
}

@keyframes titlePulse {
  0%, 100% { transform: scale(1); }
  50% { transform: scale(1.02); }
}

.title-icon, .sparkle {
  display: inline-block;
  animation: sparkle 2s ease-in-out infinite;
}

.sparkle {
  animation-delay: 1s;
}

@keyframes sparkle {
  0%, 100% { transform: rotate(0deg) scale(1); }
  25% { transform: rotate(10deg) scale(1.1); }
  75% { transform: rotate(-10deg) scale(1.1); }
}

.hero-subtitle {
  font-size: 1.2rem;
  line-height: 1.6;
  color: rgba(255, 255, 255, 0.9);
  font-weight: 400;
}

/* Floating Shapes */
.floating-shapes {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  pointer-events: none;
}

.shape {
  position: absolute;
  border-radius: 50%;
  background: rgba(255, 255, 255, 0.1);
  animation: floatShape 8s ease-in-out infinite;
}

.shape-1 {
  width: 60px;
  height: 60px;
  top: 20%;
  left: 10%;
  animation-delay: 0s;
}

.shape-2 {
  width: 40px;
  height: 40px;
  top: 60%;
  right: 15%;
  animation-delay: 2s;
}

.shape-3 {
  width: 80px;
  height: 80px;
  bottom: 20%;
  left: 20%;
  animation-delay: 4s;
}

@keyframes floatShape {
  0%, 100% { transform: translateY(0px) translateX(0px); }
  25% { transform: translateY(-20px) translateX(10px); }
  50% { transform: translateY(-10px) translateX(-10px); }
  75% { transform: translateY(-30px) translateX(5px); }
}

/* Features Grid */
.features-grid {
  padding: 2rem;
  max-width: 1200px;
  margin: 0 auto;
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
  gap: 2rem;
}

.feature-card {
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(20px);
  border-radius: 24px;
  padding: 2rem;
  position: relative;
  overflow: hidden;
  box-shadow: 0 20px 60px rgba(0, 0, 0, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.5);
  transition: all 0.4s ease;
  cursor: pointer;
}

.feature-card:hover {
  transform: translateY(-8px);
  box-shadow: 0 30px 80px rgba(0, 0, 0, 0.15);
}

.card-header {
  display: flex;
  align-items: center;
  gap: 1rem;
  margin-bottom: 1.5rem;
}

.feature-icon {
  font-size: 3rem;
  padding: 0.5rem;
  border-radius: 16px;
  background: linear-gradient(145deg, #f8fafc, #e2e8f0);
  box-shadow: 0 8px 25px rgba(0, 0, 0, 0.1);
  animation: iconBounce 2s ease-in-out infinite;
}

@keyframes iconBounce {
  0%, 100% { transform: translateY(0); }
  50% { transform: translateY(-3px); }
}

.feature-title {
  font-size: 1.4rem;
  font-weight: 700;
  color: #1e293b;
  margin: 0;
}

.feature-description {
  font-size: 1rem;
  line-height: 1.7;
  color: #475569;
  margin-bottom: 1.5rem;
}

/* Card-specific styles */
.feature-tags {
  display: flex;
  gap: 0.5rem;
  flex-wrap: wrap;
}

.tag {
  background: linear-gradient(45deg, #3b82f6, #1d4ed8);
  color: white;
  padding: 0.3rem 0.8rem;
  border-radius: 12px;
  font-size: 0.8rem;
  font-weight: 600;
}

.instructor-avatars {
  display: flex;
  gap: 0.5rem;
  align-items: center;
}

.avatar {
  width: 40px;
  height: 40px;
  border-radius: 50%;
  background: linear-gradient(145deg, #f1f5f9, #e2e8f0);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 1.2rem;
  box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
}

.avatar.plus {
  background: linear-gradient(45deg, #10b981, #059669);
  color: white;
  font-weight: bold;
}

.grade-range {
  display: flex;
  align-items: center;
  gap: 0.8rem;
  justify-content: center;
}

.grade {
  background: linear-gradient(45deg, #8b5cf6, #7c3aed);
  color: white;
  padding: 0.5rem 1rem;
  border-radius: 15px;
  font-weight: 700;
  font-size: 1.1rem;
}

.grade-divider {
  font-size: 1.5rem;
  color: #64748b;
  font-weight: bold;
}

.grade-label {
  background: linear-gradient(45deg, #f59e0b, #d97706);
  color: white;
  padding: 0.3rem 0.8rem;
  border-radius: 10px;
  font-size: 0.8rem;
  font-weight: 600;
}

.safety-badges {
  display: flex;
  gap: 1rem;
  justify-content: center;
}

.safety-badge {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  background: linear-gradient(45deg, #ef4444, #dc2626);
  color: white;
  padding: 0.6rem 1rem;
  border-radius: 12px;
  font-weight: 600;
  font-size: 0.9rem;
}

.tech-stack {
  display: flex;
  gap: 0.8rem;
  justify-content: center;
  flex-wrap: wrap;
}

.tech-item {
  padding: 0.5rem 1rem;
  border-radius: 12px;
  font-weight: 600;
  font-size: 0.9rem;
}

.tech-item.vue {
  background: linear-gradient(45deg, #42b883, #35495e);
  color: white;
}

.tech-item.tailwind {
  background: linear-gradient(45deg, #06b6d4, #0891b2);
  color: white;
}

.tech-item.node {
  background: linear-gradient(45deg, #68cc68, #5a9f5a);
  color: white;
}

.creators-info {
  display: flex;
  gap: 1rem;
  justify-content: center;
}

.institution, .program {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  background: linear-gradient(45deg, #f59e0b, #d97706);
  color: white;
  padding: 0.6rem 1rem;
  border-radius: 12px;
  font-weight: 600;
  font-size: 0.9rem;
}

/* Card Glow Effects */
.card-glow {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: linear-gradient(45deg, transparent, rgba(255, 255, 255, 0.1), transparent);
  opacity: 0;
  transition: opacity 0.4s ease;
  pointer-events: none;
}

.feature-card:hover .card-glow {
  opacity: 1;
  animation: shimmer 1.5s ease-in-out;
}

@keyframes shimmer {
  0% { transform: translateX(-100%); }
  100% { transform: translateX(100%); }
}

/* CTA Section */
.cta-section {
  padding: 4rem 2rem;
  text-align: center;
  color: white;
  background: rgba(0, 0, 0, 0.1);
  backdrop-filter: blur(10px);
  margin: 2rem;
  border-radius: 24px;
  border: 1px solid rgba(255, 255, 255, 0.2);
}

.cta-title {
  font-size: 2.5rem;
  font-weight: 700;
  margin-bottom: 1rem;
  background: linear-gradient(45deg, #fff, #f0fdf4);
  background-clip: text;
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
}

.cta-subtitle {
  font-size: 1.1rem;
  margin-bottom: 2rem;
  color: rgba(255, 255, 255, 0.9);
}

.cta-stats {
  display: flex;
  justify-content: center;
  gap: 3rem;
  flex-wrap: wrap;
}

.stat {
  text-align: center;
}

.stat-number {
  display: block;
  font-size: 2.5rem;
  font-weight: 800;
  color: #fbbf24;
  margin-bottom: 0.5rem;
}

.stat-label {
  font-size: 0.9rem;
  color: rgba(255, 255, 255, 0.8);
  text-transform: uppercase;
  letter-spacing: 1px;
}

/* Responsive Design */
@media (max-width: 768px) {
  .hero-section {
    padding: 2rem 1rem;
  }
  
  .features-grid {
    grid-template-columns: 1fr;
    padding: 1rem;
    gap: 1.5rem;
  }
  
  .feature-card {
    padding: 1.5rem;
  }
  
  .cta-section {
    padding: 2rem 1rem;
    margin: 1rem;
  }
  
  .cta-stats {
    gap: 2rem;
  }
  
  .grade-range,
  .safety-badges,
  .tech-stack,
  .creators-info {
    flex-direction: column;
    align-items: center;
  }
}

@media (max-width: 480px) {
  .hero-title {
    font-size: 2rem;
  }
  
  .cta-title {
    font-size: 1.8rem;
  }
  
  .floating-shapes {
    display: none;
  }
}
</style>
