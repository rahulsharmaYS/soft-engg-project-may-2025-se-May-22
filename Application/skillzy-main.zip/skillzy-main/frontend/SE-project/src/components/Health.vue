  <template>
    <div class="health-dashboard">
      <main class="main">
        <!-- Header -->
        <Header /> <!-- Correct -->

      </main>
      <div class="header">
        <div class="header-content">
          <div class="header-left">
            <h1>
              <i class="fas fa-heart"></i>
              Child Health Monitor
            </h1>
            <p>Comprehensive digital wellness and health tracking for your child</p>
          </div>
        </div>
      </div>


    <div class="daily-summary" style="color: whitesmoke; margin-left: 20px;">
      <h3>📊 Today's Health Summary (Grade: {{ healthGrade }})</h3>
      <p>{{ dailySummary }}</p>
    </div>
      <!-- Health Metrics Overview -->
      <div class="metrics-overview">
        <div class="metric-card screen-time">
          <div class="metric-content">
            <h3>Screen Time Tip</h3>
            <div class="metric-value">~ {{ screenTimeToday }}</div>
            <div class="metric-subtitle">Recommended: {{ recommendedScreenTime }}</div>
          </div>
          <i class="fas fa-desktop metric-icon"></i>
        </div>

        <div class="metric-card mental-health">
          <div class="metric-content">
            <h3>Mental Health Tip</h3>
            <div class="metric-value">{{ mentalHealthScore }}%</div>
            <div class="metric-subtitle">{{ mentalHealthStatus }}</div>
          </div>
          <i class="fas fa-brain metric-icon"></i>
        </div>

        <div class="metric-card eye-health">
          <div class="metric-content">
            <h3>Eye Health Tip</h3>
            <div class="metric-value">{{ eyeHealthScore }}%</div>
            <div class="metric-subtitle">{{ eyeHealthStatus }}</div>
          </div>
          <i class="fas fa-eye metric-icon"></i>
        </div>

        <div class="metric-card physical-activity">
          <div class="metric-content">
            <h3>Physical Activity Tip</h3>
            <div class="metric-value">{{ physicalActivityScore }}%</div>
            <div class="metric-subtitle">{{ physicalActivityStatus }}</div>
          </div>
          <i class="fas fa-running metric-icon"></i>
        </div>
      </div>

      <!-- Tab Navigation -->
      <div class="tab-navigation">
        <button v-for="tab in tabs" :key="tab.id" :class="['tab-btn', { active: activeTab === tab.id }]"
          @click="activeTab = tab.id">
          {{ tab.name }}
        </button>
      </div>

      <!-- Tab Content -->
      <div class="tab-content">
        <!-- Overview Tab -->
        <div v-if="activeTab === 'overview'" class="tab-panel">
          <div class="overview-grid">
            <!-- add summarisation of child's health and all -->
            <div class="overview-left">

              <div class="activity-summary">
                <h4>Activity Summary</h4>
                <p>Outdoor Playtime: Should be 1-2 hours</p>
                <p>Activities: Should include a mix of physical and creative play</p>
                <p>Sleep Hours: Should be 9-11 hours</p>
              </div>
            </div>


            <!-- Health Insights & Tips -->
            <div class="card health-insights">
              <h3><i class="fas fa-lightbulb"></i> Health Insights & Tips</h3>

              <div class="rotating-tips">
                <div class="tip-card" :key="currentTip.id">
                  <div class="tip-icon">{{ currentTip.icon }}</div>
                  <div class="tip-content">
                    <h4>{{ currentTip.category }}</h4>
                    <p>{{ currentTip.text }}</p>
                  </div>
                </div>
              </div>

              <div class="tips-categories">
                <div class="tip-category eye-health">
                  <h4><i class="fas fa-eye"></i> Eye Health Tips</h4>
                  <ul>
                    <li>Take 20-second breaks every 20 minutes</li>
                    <li>Look at something 20 feet away</li>
                    <li>Ensure proper lighting</li>
                    <li>Keep screen 20-24 inches away</li>
                  </ul>
                </div>

                <div class="tip-category mental-wellness">
                  <h4><i class="fas fa-leaf"></i> Mental Wellness</h4>
                  <ul>
                    <li>Balance educational and fun content</li>
                    <li>Encourage creative activities</li>
                    <li>Limit stimulating content before bed</li>
                    <li>Regular family discussions about online safety</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>

          <!-- Health Status Summary -->
          <!-- <div class="health-status-summary">
            <h3><i class="fas fa-chart-line"></i> Health Status Summary</h3>
            <div class="status-grid">
              <div class="status-item" :class="getStatusClass('screen')">
                <i class="fas fa-desktop"></i>
                <span>Screen Time</span>
                <span class="status-badge">{{ getScreenTimeStatus() }}</span>
              </div>
              
              <div class="status-item" :class="getStatusClass('mental')">
                <i class="fas fa-brain"></i>
                <span>Mental Wellness</span>
                <span class="status-badge">{{ getMentalWellnessStatus() }}</span>
              </div>
              
              <div class="status-item" :class="getStatusClass('eye')">
                <i class="fas fa-eye"></i>
                <span>Eye Health</span>
                <span class="status-badge">{{ getEyeHealthStatus() }}</span>
              </div>
            </div>
          </div> -->
        </div>

        <!-- Screen Time Tab -->
        <div v-if="activeTab === 'screen-time'" class="tab-panel">
          <div class="screen-time-analysis" v-if="weeklyScreenTime.length > 0">
            <h3><i class="fas fa-clock"></i> Weekly Screen Time Analysis</h3>

            <div class="daily-breakdown">
              <div v-for="day in weeklyScreenTime" :key="day.name" class="day-item">
                <div class="day-info">
                  <i class="fas fa-calendar"></i>
                  <div>
                    <h4>{{ day.name }}</h4>
                    <p>{{ day.date }}</p>
                  </div>
                </div>
                <div class="time-info">
                  <span class="actual">{{ day.actual }}</span>
                  <span class="recommended">{{ day.recommended }}</span>
                  <span class="status-tag" :class="day.status.toLowerCase()">
                    {{ day.status }}
                  </span>
                </div>
              </div>
            </div>
          </div>
          <div v-else style="color: whitesmoke;">
            No screen time data available.
          </div>

        </div>

        <!-- Websites Tab -->
        <div v-if="activeTab === 'websites'" class="tab-panel">
          <div class="website-analysis">
            <h3><i class="fas fa-globe"></i> Website Usage Analysis</h3>

            <div class="website-list">
              <div v-if="websiteUsage.length > 0" class="website-list">
                <div v-for="site in websiteUsage" :key="site.name" class="website-item">
                  <div class="site-info">
                    <h4>{{ site.name }}</h4>
                  </div>
                  <div class="time-spent">
                    <span class="duration">{{ site.duration }}</span>
                    <span class="status-badge" :class="site.status.toLowerCase()">{{ site.status }}</span>
                  </div>
                </div>
              </div>
              <div v-else>
                No website usage data available.
              </div>

            </div>

            <!-- Content Categories Chart -->
            <div class="content-categories">
              <h4><i class="fas fa-chart-pie"></i> Content Categories</h4>
              <div class="category-chart">
                <div class="chart-item" v-for="category in contentCategories" :key="category.name">
                  <div class="category-bar">
                    <div class="bar-fill" :style="{ width: category.percentage + '%', backgroundColor: category.color }">
                    </div>
                  </div>
                  <span class="category-label">{{ category.name }} {{ category.percentage }}%</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Physical Health Tab -->
        <div v-if="activeTab === 'physical-health'" class="tab-panel">
          <div class="physical-health-detailed">
            <h3><i class="fas fa-heartbeat"></i> Physical Health Monitoring</h3>

            <!-- Parent Input Form -->
            <div class="parent-input-section">
              <h4>Parent Assessment Form</h4>
              <div class="assessment-form">
                <div class="form-row">
                  <div class="form-group">
                    <label>Child's Energy Level (1-10)</label>
                    <input v-model.number="healthAssessment.energyLevel" type="range" min="1" max="10">
                    <span>{{ healthAssessment.energyLevel }}</span>
                  </div>

                  <div class="form-group">
                    <label>Sleep Quality (1-10)</label>
                    <input v-model.number="healthAssessment.sleepQuality" type="range" min="1" max="10">
                    <span>{{ healthAssessment.sleepQuality }}</span>
                  </div>
                </div>

                <div class="form-row">
                  <div class="form-group">
                    <label>Appetite (1-10)</label>
                    <input v-model.number="healthAssessment.appetite" type="range" min="1" max="10">
                    <span>{{ healthAssessment.appetite }}</span>
                  </div>

                  <div class="form-group">
                    <label>Mood & Behavior (1-10)</label>
                    <input v-model.number="healthAssessment.mood" type="range" min="1" max="10">
                    <span>{{ healthAssessment.mood }}</span>
                  </div>
                </div>
                <div class="form-row">
                  <div class="form-group">
                    <label>Hydration Level (1-10)</label>
                    <input v-model.number="healthAssessment.hydration" type="range" min="1" max="10">
                    <span>{{ healthAssessment.hydration }}</span>
                  </div>

                  <div class="form-group">
                    <label>Posture Quality (1-10)</label>
                    <input v-model.number="healthAssessment.posture" type="range" min="1" max="10">
                    <span>{{ healthAssessment.posture }}</span>
                  </div>
                </div>

                <div class="form-group">
                  <label>Nutritional Balance (1-10)</label>
                  <input v-model.number="healthAssessment.nutrition" type="range" min="1" max="10">
                  <span>{{ healthAssessment.nutrition }}</span>
                </div>
                <!-- <div class="form-group">
                  <label>Any Health Concerns?</label>
                  <textarea v-model="healthAssessment.concerns"
                    placeholder="Describe any health concerns or observations..."></textarea>
                </div> -->

                <button @click="analyzeHealth" class="analyze-btn">
                  <i class="fas fa-stethoscope"></i> Analyze Health Status
                </button>
              </div>
            </div>

            <!-- Health Analysis Results -->
            <div v-if="healthAnalysis" class="health-analysis-results">
              <h4>Health Analysis Results</h4>
              <div class="analysis-card" :class="healthAnalysis.status.toLowerCase()">
                <div class="analysis-header">
                  <i :class="healthAnalysis.icon"></i>
                  <h5>{{ healthAnalysis.title }}</h5>
                  <span class="health-score">{{ healthAnalysis.score }}/100</span>
                </div>
                <p>{{ healthAnalysis.summary }}</p>

                <div class="recommendations">
                  <h6>Recommendations:</h6>
                  <ul>
                    <li v-for="rec in healthAnalysis.recommendations" :key="rec">{{ rec }}</li>
                  </ul>
                </div>
              </div>
            </div>

            <!-- Health Recommendations -->
            <div class="health-recommendations">
              <h4><i class="fas fa-first-aid"></i> Health Recommendations</h4>
              <div class="recommendation-grid">
                <div class="rec-card screen-time">
                  <h5><i class="fas fa-desktop"></i> Screen Time</h5>
                  <p>Reduce daily screen time by 30 minutes. Take breaks every 20 minutes.</p>
                </div>

                <div class="rec-card eye-care">
                  <h5><i class="fas fa-eye"></i> Eye Care</h5>
                  <p>Follow the 20-20-20 rule. Ensure proper lighting during screen use.</p>
                </div>

                <div class="rec-card physical-activity">
                  <h5><i class="fas fa-running"></i> Physical Activity</h5>
                  <p>Increase outdoor playtime to 1.5 hours daily for better health.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

    </div>
  </template>

<script>
import { ref, onMounted, computed } from 'vue';
import { useRoute, useRouter } from 'vue-router';
import Header from './Header.vue';
import api from '../api';

export default {
  name: 'Health',
  data() {
    return {
      activeTab: 'overview',
      currentTipIndex: 0,
      tipInterval: null,
      scoreHistory: [], // Improvement #4: Track scores over time

      tabs: [
        { id: 'overview', name: 'Overview' },
        { id: 'screen-time', name: 'Screen Time' },
        { id: 'websites', name: 'Websites' },
        { id: 'physical-health', name: 'Physical Health' }
      ],

      // Health metrics
      screenTimeToday: '0.0h',
      recommendedScreenTime: '2h',
      mentalHealthScore: 0,
      mentalHealthStatus: '',
      eyeHealthScore: 0,
      eyeHealthStatus: '',
      physicalActivityScore: 0,
      physicalActivityStatus: '',

      // Today's activities
      todayActivities: {
        outdoorTime: 2.5,
        activities: 'cycling, football, swimming',
        sleepHours: 9
      },

      playtimeProgress: 75,
      sleepProgress: 88,
      activeDaysProgress: 71,
      activeDays: 5,
      activeDaysStatus: 'Above average activity',

      // Tips
      healthTips: [
        { id: 1, category: 'Eye Health', icon: '👀', text: 'Every 20 minutes, look at something 20 feet away for 20 seconds!' },
        { id: 2, category: 'Physical Activity', icon: '🏃‍♂️', text: 'Play outside for at least 1 hour every day!' },
        { id: 3, category: 'Sleep Health', icon: '😴', text: 'Kids need 9-11 hours of sleep each night.' },
        { id: 4, category: 'Nutrition', icon: '🥕', text: 'Eat colorful fruits and vegetables daily.' },
        { id: 5, category: 'Screen Time', icon: '📱', text: 'Take breaks from screens and rest your eyes.' },
        { id: 6, category: 'Hydration', icon: '💧', text: 'Drink plenty of water throughout the day.' },
        { id: 7, category: 'Mental Health', icon: '🧠', text: 'Talk to your parents about your feelings.' },
        { id: 8, category: 'Posture', icon: '🪑', text: 'Sit up straight to keep your back healthy.' },
        { id: 9, category: 'Fresh Air', icon: '🌳', text: 'Spend time outdoors for fresh air and sunlight.' }
      ],

      // Weekly screen time data (offline demo mode)
      weeklyScreenTime: [
        { name: 'Monday', date: 'Today', actual: '2.5h', recommended: '2h', status: 'Moderate' },
        { name: 'Tuesday', date: 'Dec 17', actual: '3.2h', recommended: '2h', status: 'Excessive' },
        { name: 'Wednesday', date: 'Dec 18', actual: '1.8h', recommended: '2h', status: 'Good' }
      ],

      dailyAverage: '3.4h',
      recommendedDaily: '2.3h',
      timeDifference: '+1.1h',

      // Website usage (offline demo mode)
      websiteUsage: [
        { name: 'Khan Academy Kids', category: 'Educational', visits: 8, duration: '45 min', status: 'Good' },
        { name: 'YouTube Kids', category: 'Entertainment', visits: 15, duration: '120 min', status: 'Moderate' }
      ],

      // Content categories
      contentCategories: [
        { name: 'Entertainment', percentage: 59, color: '#ff9800' },
        { name: 'Educational', percentage: 22, color: '#4caf50' },
        { name: 'Gaming', percentage: 20, color: '#f44336' }
      ],

      // Health assessment form
      healthAssessment: {
        energyLevel: 7,
        sleepQuality: 8,
        appetite: 6,
        mood: 7,
        hydration: 7,
        posture: 6,
        nutrition: 8,
        concerns: ''
      },

      healthAnalysis: null,

      // Improvement #7: Daily goals
      goals: {
        screenTimeLimit: 2, // hours
        outdoorActivityTarget: 1.5, // hours
        sleepGoal: 9 // hours
      }
    };
  },

  computed: {
    currentTip() {
      return this.healthTips[this.currentTipIndex];
    },

    // Improvement #3: Daily Health Summary
    dailyHealthSummary() {
      return `Overall: ${this.healthAnalysis?.title || 'Unknown'} — 
      Mental: ${this.mentalHealthStatus}, Eye: ${this.eyeHealthStatus}, 
      Physical: ${this.physicalActivityStatus}.`;
    },

    // Improvement #6: Letter grade
    healthGrade() {
      const score = this.healthAnalysis?.score || 0;
      if (score >= 90) return 'A';
      if (score >= 75) return 'B';
      if (score >= 60) return 'C';
      if (score >= 45) return 'D';
      return 'F';
    },

    // Improvement #7: Goal tracking
    goalStatus() {
      return {
        screen: parseFloat(this.screenTimeToday) <= this.goals.screenTimeLimit ? '✅' : '❌',
        outdoor: this.todayActivities.outdoorTime >= this.goals.outdoorActivityTarget ? '✅' : '❌',
        sleep: this.todayActivities.sleepHours >= this.goals.sleepGoal ? '✅' : '❌'
      };
    }
  },

  mounted() {
    this.startTipRotation();
    this.fetchWebsiteUsage();
    this.fetchScreenTime();
  },

  beforeUnmount() {
    if (this.tipInterval) clearInterval(this.tipInterval);
  },

  methods: {
    // Keep fallback data if API fails (Improvement #10)
    async fetchWebsiteUsage() {
      try {
        const parentId = this.$route.params.parentId;
        const res = await api.get(`/parent/${parentId}/websites-usage`);
        if (res.data?.data?.length > 0) {
          this.websiteUsage = res.data.data[0].weekly_usage.map(item => ({
            name: item.name,
            duration: this.formatDuration(item.total_time_sec),
            status: this.getUsageStatus(item.total_time_sec)
          }));
        }
      } catch {
        console.warn('Website usage: using demo data');
      }
    },

    async fetchScreenTime() {
      try {
        const parentId = this.$route.params.parentId;
        const res = await api.get(`/parent/${parentId}/screen-time`);
        if (res.data?.data?.length > 0) {
          this.weeklyScreenTime = res.data.data[0].weekly_screen_time.map(day => ({
            name: day.day,
            date: this.formatDate(day.date),
            actual: this.formatHours(day.actual_sec),
            recommended: this.formatHours(day.recommended_sec),
            status: this.getTimeStatus(day.actual_sec, day.recommended_sec)
          }));
        }
      } catch {
        console.warn('Screen time: using demo data');
      }
    },

    // Utility functions
    formatDate(dateStr) {
      const d = new Date(dateStr);
      return d.toLocaleDateString('en-GB', { day: 'numeric', month: 'short' });
    },
    formatHours(seconds) {
      return (seconds / 3600).toFixed(1) + 'h';
    },
    getTimeStatus(actualSec, recommendedSec) {
      if (actualSec <= recommendedSec) return 'Good';
      if (actualSec <= recommendedSec * 1.5) return 'Moderate';
      return 'Excessive';
    },
    formatDuration(seconds) {
      const m = Math.floor(seconds / 60);
      const s = Math.round(seconds % 60);
      return `${m} min ${s} sec`;
    },
    getUsageStatus(seconds) {
      const mins = seconds / 60;
      if (mins < 30) return 'Good';
      if (mins < 90) return 'Moderate';
      return 'Excessive';
    },

    // Improvement #2: Prioritize relevant tips
    startTipRotation() {
      this.tipInterval = setInterval(() => {
        this.currentTipIndex = (this.currentTipIndex + 1) % this.healthTips.length;
      }, 5000);
    },

    logActivity() {
      this.$toast.success('Activity logged successfully!');
      this.updateProgress();
    },

    updateProgress() {
      this.playtimeProgress = Math.min((this.todayActivities.outdoorTime / this.goals.outdoorActivityTarget) * 100, 100);
      this.sleepProgress = Math.min((this.todayActivities.sleepHours / this.goals.sleepGoal) * 100, 100);
    },

    // improvement part #8 & #9: Better analysis & varied recommendations
analyzeHealth() {
  const a = this.healthAssessment;

  // defined weighted scores for a more realistic assessment
  const weights = {
    energyLevel: 0.15,
    sleepQuality: 0.2,
    appetite: 0.1,
    mood: 0.2,
    hydration: 0.1,
    posture: 0.1,
    nutrition: 0.15
  };

  const weightedScore = (
    a.energyLevel * weights.energyLevel +
    a.sleepQuality * weights.sleepQuality +
    a.appetite * weights.appetite +
    a.mood * weights.mood +
    a.hydration * weights.hydration +
    a.posture * weights.posture +
    a.nutrition * weights.nutrition
  );

  const score = Math.round(weightedScore * 10);

  // 2. Subscores with revised, realistic groupings
  const mentalHealth = Math.round(((a.mood * 0.4) + (a.sleepQuality * 0.4) + (a.hydration * 0.2)) * 10 / 1);
  const eyeHealth = Math.round(((a.posture * 0.5) + (a.sleepQuality * 0.3) + (a.hydration * 0.2)) * 10 / 1);
  const physicalActivity = Math.round(((a.energyLevel * 0.4) + (a.appetite * 0.3) + (a.mood * 0.3)) * 10 / 1);

  const getStatus = val => {
    if (val >= 85) return 'Excellent';
    if (val >= 70) return 'Good';
    if (val >= 50) return 'Needs Attention';
    return 'Poor';
  };

  // Save subscores and statuses
  this.mentalHealthScore = mentalHealth;
  this.mentalHealthStatus = getStatus(mentalHealth);

  this.eyeHealthScore = eyeHealth;
  this.eyeHealthStatus = getStatus(eyeHealth);

  this.physicalActivityScore = physicalActivity;
  this.physicalActivityStatus = getStatus(physicalActivity);

  // 3. Estimate screen time with better formula
  const screenTimeImpact = ((10 - a.energyLevel) * 0.3 + (10 - a.posture) * 0.4 + (10 - a.mood) * 0.3);
  this.screenTimeToday = `${(screenTimeImpact * 0.25).toFixed(1)}h`;

  // 4. Analyze weak points for personalized recommendations
  const lowScores = Object.entries(a).filter(([key, val]) => val < 6);

  const recommendationBank = {
    energyLevel: ['Encourage outdoor play', 'Optimize sleep schedule', 'Limit sugar intake'],
    sleepQuality: ['Establish bedtime routine', 'Reduce screen time before bed', 'Use calming music or stories'],
    appetite: ['Offer nutrient-dense snacks', 'Involve child in meal prep', 'Avoid force-feeding'],
    mood: ['Talk openly about emotions', 'Limit overstimulation', 'Introduce mindfulness games'],
    hydration: ['Set hydration reminders', 'Offer fruits with high water content', 'Use fun water bottles'],
    posture: ['Encourage stretching breaks', 'Adjust screen/viewing ergonomics', 'Use posture-friendly seating'],
    nutrition: ['Balance meals with protein & veggies', 'Limit processed foods', 'Use colorful food presentations']
  };

  let recommendations = [];
  lowScores.forEach(([key]) => {
    const tips = recommendationBank[key];
    if (tips) {
      // Add a random suggestion per weak area
      recommendations.push(tips[Math.floor(Math.random() * tips.length)]);
    }
  });

  if (recommendations.length === 0) {
    recommendations = ['Maintain current healthy habits!', 'Introduce variety in meals', 'Monitor health weekly'];
  }

  // 5. Determine overall status
  let status, title, summary, icon;
  if (score >= 85) {
    status = 'excellent';
    title = 'Peak Health';
    summary = 'Your child is thriving physically and emotionally!';
    icon = 'fas fa-star';
  } else if (score >= 70) {
    status = 'good';
    title = 'Healthy & Strong';
    summary = 'Your child is doing well with room for small improvements.';
    icon = 'fas fa-heart';
  } else if (score >= 50) {
    status = 'moderate';
    title = 'Monitor Closely';
    summary = 'Some signs show attention is needed. Small changes can help.';
    icon = 'fas fa-exclamation-triangle';
  } else {
    status = 'poor';
    title = 'Action Needed';
    summary = 'Several health indicators are concerning. Please act promptly.';
    icon = 'fas fa-exclamation-circle';
  }

  // Shuffle for freshness
  recommendations.sort(() => Math.random() - 0.5);

  // 6. Tag categories for extra UX flair
  const tags = lowScores.map(([key]) => key);

  this.healthAnalysis = {
    status,
    title,
    summary,
    score,
    icon,
    tags,
    recommendations
  };

  // 7. Trend tracking over time
  const today = new Date().toLocaleDateString();
  this.scoreHistory.push({ date: today, score });

  if (this.scoreHistory.length > 1) {
    const prev = this.scoreHistory[this.scoreHistory.length - 2].score;
    const diff = score - prev;
    this.healthAnalysis.trend = diff > 0 ? `↑ Improved by ${diff} pts` :
                                 diff < 0 ? `↓ Dropped by ${Math.abs(diff)} pts` :
                                 '→ No change';
  } else {
    this.healthAnalysis.trend = '↗ First record';
  }
}

  }
};
</script>

<style scoped>
/* add styles of that here */
.overview-left {
  flex: 1;
  margin-right: 2rem;
}

.activity-form {
  background: #fff;
  padding: 1.5rem;
  border-radius: 8px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
}

.activity-summary {
  background: #f0f0f0;
  padding: 1rem;
  border-radius: 8px;
  margin-top: 1rem;
}

.outdoor-playtime-label {
  font-weight: bold;
}

.sleep-hours-label {
  font-weight: bold;
}

.activities-label {
  font-weight: bold;
}

.submit-btn {
  background: #4caf50;
  color: white;
  border: none;
  padding: 0.5rem 1rem;
  border-radius: 8px;
  cursor: pointer;
  transition: background 0.3s ease;
}

.health-dashboard {
  min-height: 100vh;
  /* background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); */
    background: linear-gradient(135deg, #B12BE2, #1F6CF3);
  padding: 2rem;
  font-family: 'Inter', sans-serif;
}

.header {
  background: rgba(255, 255, 255, 0.1);
  backdrop-filter: blur(10px);
  border-bottom: 1px solid rgba(255, 255, 255, 0.2);
  padding: 1rem 2rem;
}

.header-content {
  display: flex;
  justify-content: space-between;
  align-items: center;
  max-width: 1200px;
  margin: 0 auto;
}

.header-left h1 {
  color: white;
  margin: 0;
  font-size: 1.8rem;
  font-weight: 600;
}

.header-left h1 i {
  color: #ff6b6b;
  margin-right: 0.5rem;
}

.header-left p {
  color: rgba(255, 255, 255, 0.8);
  margin: 0.25rem 0 0 0;
  font-size: 0.9rem;
}

.header-right {
  display: flex;
  gap: 1rem;
}

.btn-teacher,
.btn-parent {
  background: rgba(255, 255, 255, 0.2);
  color: white;
  border: 1px solid rgba(255, 255, 255, 0.3);
  padding: 0.5rem 1rem;
  border-radius: 8px;
  cursor: pointer;
  transition: all 0.3s ease;
}

.btn-teacher:hover,
.btn-parent:hover {
  background: rgba(255, 255, 255, 0.3);
  transform: translateY(-2px);
}

.metrics-overview {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 1.5rem;
  padding: 2rem;
  max-width: 1200px;
  margin: 0 auto;
}

.metric-card {
  background: white;
  border-radius: 12px;
  padding: 1.5rem;
  display: flex;
  justify-content: space-between;
  align-items: center;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
  transition: transform 0.3s ease;
}

.metric-card:hover {
  transform: translateY(-5px);
}

.metric-content h3 {
  margin: 0 0 0.5rem 0;
  color: #333;
  font-size: 0.9rem;
  font-weight: 500;
}

.metric-value {
  font-size: 2rem;
  font-weight: 700;
  margin: 0.25rem 0;
}

.metric-subtitle {
  font-size: 0.8rem;
  color: #666;
}

.metric-icon {
  font-size: 2rem;
  opacity: 0.3;
}

.screen-time .metric-value {
  color: #2196f3;
}

.mental-health .metric-value {
  color: #4caf50;
}

.eye-health .metric-value {
  color: #ff9800;
}

.physical-activity .metric-value {
  color: #e91e63;
}

.tab-navigation {
  display: flex;
  background: rgba(255, 255, 255, 0.1);
  backdrop-filter: blur(10px);
  border-radius: 12px;
  margin: 0 2rem;
  padding: 0.5rem;
  max-width: 1200px;
  margin-left: auto;
  margin-right: auto;
}

.tab-btn {
  flex: 1;
  background: transparent;
  border: none;
  color: rgba(255, 255, 255, 0.7);
  padding: 1rem;
  border-radius: 8px;
  cursor: pointer;
  transition: all 0.3s ease;
  font-weight: 500;
}

.tab-btn.active {
  background: white;
  color: #333;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
}

.tab-content {
  padding: 2rem;
  max-width: 1200px;
  margin: 0 auto;
}

.overview-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 2rem;
  margin-bottom: 2rem;
}

.card {
  background: white;
  border-radius: 12px;
  padding: 1.5rem;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
}

.card h3 {
  margin: 0 0 1.5rem 0;
  color: #333;
  display: flex;
  align-items: center;
  gap: 0.5rem;
}

.activity-form {
  margin-bottom: 2rem;
}

.form-group {
  margin-bottom: 1rem;
}

main.main-content {
  padding: 0 !important;
}

.main {

  color: var(--text);
  background: transparent;
  flex: 1;
  margin-top: 2rem;
  display: flex;
  flex-direction: column;
  gap: 2rem;
  max-width: 1200px;
  margin-left: auto;
  margin-right: auto;
  padding: 0 1rem;
}

.form-group label {
  display: block;
  margin-bottom: 0.5rem;
  color: #555;
  font-weight: 500;
}

.form-group input,
.form-group textarea {
  width: 90%;
  padding: 0.75rem;
  border: 2px solid #e0e0e0;
  border-radius: 8px;
  font-size: 0.9rem;
  transition: border-color 0.3s ease;
}

.form-group input:focus,
.form-group textarea:focus {
  outline: none;
  border-color: #667eea;
}

.log-btn {
  background: linear-gradient(45deg, #667eea, #764ba2);
  color: white;
  border: none;
  padding: 0.75rem 1.5rem;
  border-radius: 8px;
  cursor: pointer;
  font-weight: 500;
  transition: transform 0.3s ease;
}

.log-btn:hover {
  transform: translateY(-2px);
}

.progress-item {
  display: flex;
  align-items: center;
  gap: 1rem;
  margin-bottom: 1rem;
}

.progress-item span:first-child {
  min-width: 150px;
  font-weight: 500;
}

.progress-bar {
  flex: 1;
  height: 8px;
  background: #e0e0e0;
  border-radius: 4px;
  overflow: hidden;
}

.progress-fill {
  height: 100%;
  background: #4caf50;
  transition: width 0.3s ease;
}

.progress-fill.sleep {
  background: #2196f3;
}

.progress-fill.active {
  background: #ff9800;
}

.rotating-tips {
  margin-bottom: 2rem;
}

.tip-card {
  display: flex;
  align-items: center;
  gap: 1rem;
  padding: 1rem;
  background: linear-gradient(45deg, #f8f9fa, #e9ecef);
  border-radius: 8px;
  border-left: 4px solid #667eea;
}

.tip-icon {
  font-size: 2rem;
}

.tip-content h4 {
  margin: 0 0 0.5rem 0;
  color: #333;
}

.tip-content p {
  margin: 0;
  color: #666;
}

.tips-categories {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 1.5rem;
}

.tip-category {
  padding: 1rem;
  border-radius: 8px;
  background: #f8f9fa;
}

.tip-category h4 {
  margin: 0 0 1rem 0;
  color: #333;
  display: flex;
  align-items: center;
  gap: 0.5rem;
}

.tip-category ul {
  margin: 0;
  padding-left: 1.5rem;
}

.tip-category li {
  margin-bottom: 0.5rem;
  color: #555;
}

.health-status-summary {
  background: white;
  border-radius: 12px;
  padding: 1.5rem;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
}

.status-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 1rem;
}

.status-item {
  display: flex;
  align-items: center;
  gap: 1rem;
  padding: 1rem;
  border-radius: 8px;
  background: #f8f9fa;
}

.status-item.good {
  border-left: 4px solid #4caf50;
}

.status-item.moderate {
  border-left: 4px solid #ff9800;
}

.status-item.poor {
  border-left: 4px solid #f44336;
}

.status-badge {
  margin-left: auto;
  padding: 0.25rem 0.75rem;
  border-radius: 12px;
  font-size: 0.8rem;
  font-weight: 500;
}

.status-item.good .status-badge {
  background: #e8f5e8;
  color: #4caf50;
}

.status-item.moderate .status-badge {
  background: #fff3e0;
  color: #ff9800;
}

.screen-time-analysis {
  background: white;
  border-radius: 12px;
  padding: 1.5rem;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
}

.daily-breakdown {
  margin: 2rem 0;
}

.day-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 1rem;
  border-bottom: 1px solid #e0e0e0;
}

.day-info {
  display: flex;
  align-items: center;
  gap: 1rem;
}

.day-info h4 {
  margin: 0;
  color: #333;
}

.day-info p {
  margin: 0;
  color: #666;
  font-size: 0.9rem;
}

.time-info {
  display: flex;
  align-items: center;
  gap: 1rem;
}

.actual {
  font-weight: 600;
  color: #333;
}

.recommended {
  color: #666;
  font-size: 0.9rem;
}

.status-tag {
  padding: 0.25rem 0.75rem;
  border-radius: 12px;
  font-size: 0.8rem;
  font-weight: 500;
}

.status-tag.good {
  background: #e8f5e8;
  color: #4caf50;
}

.status-tag.moderate {
  background: #fff3e0;
  color: #ff9800;
}

.status-tag.excessive {
  background: #ffebee;
  color: #f44336;
}

.screen-time-stats {
  display: flex;
  justify-content: space-around;
  margin-top: 2rem;
  padding: 1rem;
  background: #f8f9fa;
  border-radius: 8px;
}

.stat {
  text-align: center;
}

.stat h4 {
  margin: 0;
  font-size: 1.5rem;
  color: #333;
}

.stat.difference h4 {
  color: #f44336;
}

.stat p {
  margin: 0.5rem 0 0 0;
  color: #666;
  font-size: 0.9rem;
}

.website-analysis {
  background: white;
  border-radius: 12px;
  padding: 1.5rem;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
}

.website-list {
  margin: 2rem 0;
}

.website-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 1rem;
  border-bottom: 1px solid #e0e0e0;
}

.site-info {
  display: flex;
  align-items: center;
  gap: 1rem;
}

.site-icon {
  width: 40px;
  height: 40px;
  background: #f0f0f0;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
}

.site-details h4 {
  margin: 0;
  color: #333;
}

.site-details p {
  margin: 0.25rem 0;
  color: #666;
  font-size: 0.9rem;
}

.site-details small {
  color: #999;
  font-size: 0.8rem;
}

.time-spent {
  display: flex;
  align-items: center;
  gap: 1rem;
}

.duration {
  font-weight: 600;
  color: #333;
}

.content-categories {
  margin-top: 2rem;
  padding: 1.5rem;
  background: #f8f9fa;
  border-radius: 8px;
}

.category-chart {
  margin-top: 1rem;
}

.chart-item {
  display: flex;
  align-items: center;
  gap: 1rem;
  margin-bottom: 1rem;
}

.category-bar {
  flex: 1;
  height: 20px;
  background: #e0e0e0;
  border-radius: 10px;
  overflow: hidden;
}

.bar-fill {
  height: 100%;
  transition: width 0.3s ease;
}

.category-label {
  min-width: 120px;
  font-weight: 500;
  color: #333;
}

.physical-health-detailed {
  background: white;
  border-radius: 12px;
  padding: 1.5rem;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
}

.parent-input-section {
  margin-bottom: 2rem;
}

.form-row {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 1rem;
  margin-bottom: 1rem;
}

.form-group input[type="range"] {
  width: calc(100% - 3rem);
}

.form-group span {
  font-weight: 600;
  color: #667eea;
  margin-left: 0.5rem;
}

.analyze-btn {
  background: linear-gradient(45deg, #4caf50, #45a049);
  color: white;
  border: none;
  padding: 1rem 2rem;
  border-radius: 8px;
  cursor: pointer;
  font-weight: 500;
  transition: transform 0.3s ease;
  display: flex;
  align-items: center;
  gap: 0.5rem;
  margin: 1rem 0;
}

.analyze-btn:hover {
  transform: translateY(-2px);
}

.health-analysis-results {
  margin: 2rem 0;
}

.analysis-card {
  padding: 1.5rem;
  border-radius: 8px;
  border-left: 4px solid;
}

.analysis-card.excellent {
  background: #e8f5e8;
  border-left-color: #4caf50;
}

.analysis-card.good {
  background: #e8f5e8;
  border-left-color: #4caf50;
}

.analysis-card.moderate {
  background: #fff3e0;
  border-left-color: #ff9800;
}

.analysis-card.poor {
  background: #ffebee;
  border-left-color: #f44336;
}

.analysis-header {
  display: flex;
  align-items: center;
  gap: 1rem;
  margin-bottom: 1rem;
}

.health-score {
  margin-left: auto;
  font-size: 1.2rem;
  font-weight: 600;
}

.recommendations h6 {
  margin: 1rem 0 0.5rem 0;
  color: #333;
}

.recommendations ul {
  margin: 0;
  padding-left: 1.5rem;
}

.recommendations li {
  margin-bottom: 0.5rem;
  color: #555;
}

.health-recommendations {
  margin-top: 2rem;
}

.recommendation-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 1rem;
  margin-top: 1rem;
}

.rec-card {
  padding: 1rem;
  border-radius: 8px;
  background: #f8f9fa;
  border-left: 4px solid;
}

.rec-card.screen-time {
  border-left-color: #2196f3;
}

.rec-card.eye-care {
  border-left-color: #ff9800;
}

.rec-card.physical-activity {
  border-left-color: #4caf50;
}

.rec-card h5 {
  margin: 0 0 0.5rem 0;
  color: #333;
  display: flex;
  align-items: center;
  gap: 0.5rem;
}

.rec-card p {
  margin: 0;
  color: #555;
  font-size: 0.9rem;
}

@media (max-width: 768px) {
  .metrics-overview {
    grid-template-columns: 1fr;
    padding: 1rem;
  }

  .overview-grid {
    grid-template-columns: 1fr;
  }

  .tab-navigation {
    margin: 0 1rem;
    flex-wrap: wrap;
  }

  .tab-content {
    padding: 1rem;
  }

  .form-row {
    grid-template-columns: 1fr;
  }

  .tips-categories {
    grid-template-columns: 1fr;
  }

  .recommendation-grid {
    grid-template-columns: 1fr;
  }
}

</style>
