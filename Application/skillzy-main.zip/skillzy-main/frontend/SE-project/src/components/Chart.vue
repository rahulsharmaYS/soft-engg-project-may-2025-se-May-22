<template>
  <div class="charts-container-wrapper">
    <div class="filter-bar">
      <label>📅 Filter by Month:</label>
      <br />
      <select v-model="selectedMonth">
        <option disabled value="">Select Month</option>
        <option v-for="month in uniqueMonths" :key="month.value" :value="month.value">
          {{ month.label }}
        </option>
      </select>
    </div>

    <div class="charts-container">
      <!-- Chart 1: Bar - Evaluation Breakdown -->
      <div class="chart-card">
        <h3>📊 Evaluation Breakdown by Assignment</h3>
        <div class="chart-area">
          <Bar :data="evaluationBreakdownChartData" :options="barChartOptions" />
        </div>
      </div>

      <!-- Chart 2: 3D Pie - Question Type Distribution -->
      <div class="chart-card">
        <h3>🧐 Question Type Distribution</h3>
        <div class="chart-area">
          <Doughnut :data="questionTypeChartData" :options="pieChartOptions" />
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue';
import { Bar, Doughnut } from 'vue-chartjs';
import {
  Chart as ChartJS,
  Title,
  Tooltip,
  Legend,
  BarElement,
  ArcElement,
  CategoryScale,
  LinearScale,
} from 'chart.js';
import dayjs from 'dayjs';

ChartJS.register(Title, Tooltip, Legend, BarElement, ArcElement, CategoryScale, LinearScale);

const props = defineProps({
  assignments: {
    type: Array,
    required: true,
  },
});

// 📅 Month Options
const uniqueMonths = computed(() => {
  const months = props.assignments.map(a => {
    const date = dayjs(a.assignment_deadline);
    return {
      value: date.format('YYYY-MM'),
      label: date.format('MMMM YYYY'),
    };
  });
  const deduped = Array.from(new Map(months.map(m => [m.value, m])).values());
  return deduped;
});

const selectedMonth = ref(uniqueMonths.value[0]?.value ?? '');

// 🎯 Filtered Assignments
const filteredAssignments = computed(() =>
  props.assignments.filter(a =>
    dayjs(a.assignment_deadline).format('YYYY-MM') === selectedMonth.value
  )
);

const getLabel = (a, index) => a.title || `Assignment ${index + 1}`;

// 📊 Chart 1: Evaluation Breakdown
const evaluationBreakdownChartData = computed(() => {
  const labels = filteredAssignments.value.map(getLabel);
  const mcqScores = filteredAssignments.value.map(a =>
    a.question_type === 'multiple_choice' ? a.score_info?.percentage ?? 0 : 0
  );
  const textScores = filteredAssignments.value.map(a =>
    a.question_type === 'text' ? a.score_info?.score ?? 0 : 0
  );

  return {
    labels,
    datasets: [
      {
        label: 'Multiple Choice (%)',
        data: mcqScores,
        backgroundColor: '#00D5FF',
        borderRadius: 10,
        barThickness: 40,
      },
      {
        label: 'Subjective Score (%)',
        data: textScores,
        backgroundColor: '#FF9BD2',
        borderRadius: 10,
        barThickness: 40,
      },
    ],
  };
});

// 🍰 Chart 2: Pie – Question Type Distribution
const questionTypeChartData = computed(() => {
  const counts = filteredAssignments.value.reduce(
    (acc, a) => {
      if (a.question_type === 'multiple_choice') acc.mcq += 1;
      else if (a.question_type === 'text') acc.text += 1;
      return acc;
    },
    { mcq: 0, text: 0 }
  );

  return {
    labels: ['Multiple Choice', 'Subjective'],
    datasets: [
      {
        data: [counts.mcq, counts.text],
        backgroundColor: ['#36A2EB', '#FF6384'],
        hoverOffset: 12,
        borderColor: '#fff',
        borderWidth: 3,
      },
    ],
  };
});

const barChartOptions = {
  responsive: true,
  maintainAspectRatio: false,
  animation: {
    duration: 800,
    easing: 'easeOutQuart',
  },
  plugins: {
    legend: {
      labels: {
        color: '#444',
        font: {
          family: 'Poppins',
          size: 14,
        },
      },
    },
    tooltip: {
      backgroundColor: '#333',
      titleColor: '#fff',
      bodyColor: '#eee',
      padding: 10,
      cornerRadius: 8,
    },
  },
  scales: {
    y: {
      beginAtZero: true,
      max: 100,
      ticks: {
        color: '#666',
        font: {
          family: 'Poppins',
        },
      },
      grid: {
        color: '#eee',
      },
    },
    x: {
      ticks: {
        color: '#666',
        font: {
          family: 'Poppins',
        },
      },
      grid: {
        display: false,
      },
    },
  },
};

const pieChartOptions = {
  responsive: true,
  maintainAspectRatio: false,
  plugins: {
    legend: {
      position: 'top',
      labels: {
        font: {
          family: 'Poppins',
        },
      },
    },
    tooltip: {
      backgroundColor: '#333',
      titleColor: '#fff',
      bodyColor: '#eee',
    },
  },
  layout: {
    padding: 20,
  },
  cutout: '40%',
};
</script>

<style scoped>
.charts-container-wrapper {
  padding: 20px;
  background: #f6f6fc;
  border-radius: 12px;
  color: black;
}

.filter-bar {
  position: static;
  top: 0;
  background: #f0f2f5;
  padding: 12px 24px;
  z-index: 9999;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}

.filter-bar label {
  display: flex;
  align-items: center;
  gap: 6px;
}

.filter-bar select {
  padding: 10px 16px;
  border-radius: 12px;
  border: 2px solid #d1d5db;
  background-color: #fff;
  font-family: 'Poppins', sans-serif;
  font-size: 14px;
  color: #333;
  appearance: none;
  outline: none;
  transition: 0.2s ease;
}

.filter-bar select:hover {
  border-color: #a78bfa;
}

.filter-bar select:focus {
  border-color: #6366f1;
  box-shadow: 0 0 0 3px rgba(99, 102, 241, 0.2);
}

.charts-container {
  display: flex;
  flex-direction: row;
  gap: 10px;
  justify-content: space-between;
  flex-wrap: nowrap;
}

.chart-card {
  flex: 1 1 48%;
  max-width: 45%;
  background: white;
  padding: 24px;
  border-radius: 12px;
  box-shadow: 0 10px 25px rgba(0, 0, 0, 0.07);
  height: 340px;
}

.chart-card:hover {
  transform: scale(1.01);
}

.chart-card h3 {
  font-family: 'Poppins', sans-serif;
  font-weight: 600;
  font-size: 18px;
  margin-bottom: 12px;
  color: #1f2937;
}

.chart-area {
  height: 240px;
  overflow-x: auto;
}

@media (max-width: 768px) {
  .charts-container {
    flex-direction: column;
  }

  .chart-card {
    flex: 1 1 100%;
    max-width: 100%;
  }
}
</style>
