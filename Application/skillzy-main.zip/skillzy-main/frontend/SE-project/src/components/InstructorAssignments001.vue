<template>
  <div class="instructor-assignments-page">
    <main class="main">
      <Header title="Assignments 📚" subtitle="Create and manage assignments dynamically" />

      <!-- Tabs Navigation -->
      <div class="tabs-container">
        <button
          class="tab-button"
          :class="{ active: activeTab === 'create' }"
          @click="activeTab = 'create'"
        >
          Create Assignment
        </button>
        <button
          class="tab-button"
          :class="{ active: activeTab === 'view' }"
          @click="activeTab = 'view'"
        >
          View Assignments
        </button>
      </div>

      <!-- Tab Content -->
      <div class="tab-content">
        <!-- Create Assignment Tab -->
        <div v-if="activeTab === 'create'" class="card assignment-form-card">
          <h3>
            <span v-if="!isEditing">+ New Assignment</span>
            <span v-else>Edit Assignment</span>
          </h3>
          <form @submit.prevent="saveAssignment">
            <div class="form-group">
              <label for="title">Title</label>
              <input id="title" v-model="draft.title" type="text" placeholder="Enter assignment title" class="input" required />
            </div>

            <div class="form-group">
              <label for="description">Description</label>
              <textarea id="description" v-model="draft.description" placeholder="Enter assignment description" class="textarea"></textarea>
            </div>

            <div class="form-group">
              <label for="type">Type</label>
              <select id="type" v-model="draft.question_type" class="select" required>
                <option value="">Select type</option>
                <option value="multiple_choice">Objective</option>
                <option value="text">Subjective</option>
              </select>
            </div>

            <div v-if="draft.question_type" class="form-group">
              <label for="timeLimit">Time Limit (HH:MM)</label>
              <input id="timeLimit" v-model="draft.timeLimit" type="time" class="input" />
            </div>

            <div class="form-group">
              <label for="dueDate">Due Date</label>
              <input id="dueDate" v-model="draft.assignment_deadline" type="datetime-local" class="input" required />
            </div>

            <button type="submit" class="submit-btn assign-btn">
              <span v-if="!isEditing">Assign</span>
              <span v-else>Update</span>
            </button>
          </form>

          <div v-if="draft.question_type" class="question-management-section">
            <h4>Manage Questions <span class="question-header-emoji">❓</span> ({{ draft.question_type === 'multiple_choice' ? 'Objective' : 'Subjective' }})</h4>
            <form @submit.prevent="addOrUpdateQuestion">
              <div class="form-group">
                <label for="question">Question</label>
                <textarea id="question" v-model="qForm.question" placeholder="Enter question" class="textarea" required></textarea>
              </div>

              <template v-if="draft.question_type === 'multiple_choice'">
                <div class="form-group">
                  <label for="option1">Option 1</label>
                  <input id="option1" v-model="qForm.option_1" type="text" class="input" placeholder="Option 1" />
                </div>
                <div class="form-group">
                  <label for="option2">Option 2</label>
                  <input id="option2" v-model="qForm.option_2" type="text" class="input" placeholder="Option 2" />
                </div>
                <div class="form-group">
                  <label for="option3">Option 3</label>
                  <input id="option3" v-model="qForm.option_3" type="text" class="input" placeholder="Option 3" />
                </div>
                <div class="form-group">
                  <label for="option4">Option 4</label>
                  <input id="option4" v-model="qForm.option_4" type="text" class="input" placeholder="Option 4" />
                </div>
                <div class="form-group">
                  <label for="correctAnswer">Correct Option</label>
                  <select id="correctAnswer" v-model="qForm.correct_answer" class="select">
                    <option value="">Select correct option</option>
                    <option :value="qForm.option_1" :disabled="!qForm.option_1">Option 1</option>
                    <option :value="qForm.option_2" :disabled="!qForm.option_2">Option 2</option>
                    <option :value="qForm.option_3" :disabled="!qForm.option_3">Option 3</option>
                    <option :value="qForm.option_4" :disabled="!qForm.option_4">Option 4</option>
                  </select>
                </div>
              </template>

              <template v-else>
                <div class="form-group">
                  <label for="descriptiveAnswer">Descriptive Answer (Optional)</label>
                  <textarea id="descriptiveAnswer" v-model="qForm.descriptive_answer" class="textarea" placeholder="Enter expected answer or notes"></textarea>
                </div>
              </template>

              <button type="submit" class="add-question-btn">{{ isEditingQuestion ? 'Update' : 'Add' }} Question</button>
            </form>

            <div v-if="draft.questions.length" class="existing-questions mt-4">
              <h5>Existing Questions:</h5>
              <div v-for="(q, index) in draft.questions" :key="q.id || index" class="question-item">
                <p>{{ index + 1 }}. {{ q.question }} <span v-if="draft.question_type === 'multiple_choice'">(Correct: {{ q.correct_answer }})</span></p>
                <div class="question-actions">
                  <button @click="editQuestion(index)" class="action-icon-btn edit-icon">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-pencil"><path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4Z"/></svg>
                  </button>
                  <button @click="deleteQuestion(index)" class="action-icon-btn delete-icon">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-trash"><path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/></svg>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- View Assignments Tab -->
        <div v-if="activeTab === 'view'" class="card all-assignments-list-card">
          <h3>All Assignments</h3>
          <div class="controls-row">
            <input
              v-model="searchQuery"
              type="text"
              placeholder="Search by title..."
              class="search-input"
            />
            <select v-model="filterType" class="filter-select">
              <option value="">All Types</option>
              <option value="multiple_choice">Objective</option>
              <option value="text">Subjective</option>
            </select>
          </div>

          <div v-if="filteredAssignments.length === 0" class="no-assignments-message">
            No assignments found matching your criteria.
          </div>

          <div class="assignment-list-items">
            <div class="assignment-item" v-for="assignment in filteredAssignments" :key="assignment.id">
              <div class="item-header">
                <h4 class="item-title">{{ assignment.title }}</h4>
                <span class="status-pill" :class="assignment.question_type === 'multiple_choice' ? 'published' : 'draft'">
                  {{ assignment.question_type === 'multiple_choice' ? 'Objective' : 'Subjective' }}
                </span>
              </div>
              <p class="item-meta">
                {{ assignment.subject?.name || 'N/A' }}
                <span>Due: {{ formatDate(assignment.assignment_deadline) }}</span>
                <span v-if="assignment.timeLimit"> | Time: {{ assignment.timeLimit }}</span>
              </p>
              <p class="item-submission-status">
                {{ assignment.description || 'No description provided.' }}
              </p>
              <div class="item-actions">
                <button @click="editAssignment(assignment)" class="action-icon-btn edit-icon">
                  <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-pencil"><path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4Z"/></svg>
                </button>
                <button @click="discardAssignment(assignment.id)" class="action-icon-btn delete-icon">
                  <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-trash"><path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/></svg>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
  </div>
</template>

<script setup>
import { ref, computed, onMounted, watch } from 'vue';
import { useRoute } from 'vue-router';
import Header from './Header.vue';
import api from '../api';

const route = useRoute();
const teacherId = route.params.teacher_id;

const activeTab = ref('create');
const assignments = ref([]);
const searchQuery = ref('');
const filterType = ref('');

const draft = ref({
  id: null,
  title: '',
  description: '',
  question_type: '',
  timeLimit: '',
  assignment_deadline: '',
  questions: [],
});

const qForm = ref({
  id: null,
  question: '',
  option_1: '',
  option_2: '',
  option_3: '',
  option_4: '',
  correct_answer: '',
  descriptive_answer: '',
});

const isEditing = ref(false);
const isEditingQuestion = ref(false);
let editingQIndex = -1;

onMounted(() => {
  fetchAssignments();
});

async function fetchAssignments() {
  try {
    const response = await api.get(`/teacher/${teacherId}/assignments`, {
      params: {
        type: filterType.value,
        search: searchQuery.value,
      },
    });
    assignments.value = response.data.map(assignment => ({
      ...assignment,
      timeLimit: assignment.timeLimit || '00:00',
    }));
  } catch (error) {
    console.error('Failed to fetch assignments:', error);
    alert('Failed to load assignments.');
  }
}

async function saveAssignment() {
  if (!draft.value.title || !draft.value.question_type || !draft.value.assignment_deadline) {
    alert('Please fill all required assignment fields.');
    return;
  }

  const payload = {
    title: draft.value.title,
    description: draft.value.description,
    assignment_deadline: draft.value.assignment_deadline,
    question_type: draft.value.question_type,
    score: 0,
  };

  try {
    if (isEditing.value) {
      await api.put(`/teacher/${teacherId}/assignments/${draft.value.id}`, payload);
      alert('Assignment updated successfully!');
    } else {
      const response = await api.post(`/teacher/${teacherId}/assignments`, payload);
      draft.value.id = response.data.assignment.id;
      alert('Assignment created successfully! You can now add questions.');
    }
    await fetchAssignments();
    const currentQuestionType = draft.value.question_type;
    const currentAssignmentId = draft.value.id;
    resetDraft();
    draft.value.question_type = currentQuestionType;
    draft.value.id = currentAssignmentId;
  } catch (error) {
    console.error('Error saving assignment:', error);
    alert('Failed to save assignment: ' + (error.response?.data?.detail || 'Server error'));
  }
}

async function addOrUpdateQuestion() {
  if (!draft.value.id) {
    alert('Please create or select an assignment first.');
    return;
  }
  if (!qForm.value.question) {
    alert('Question text is required.');
    return;
  }
  if (draft.value.question_type === 'multiple_choice') {
    if (!qForm.value.option_1 || !qForm.value.option_2 || !qForm.value.option_3 || !qForm.value.option_4 || !qForm.value.correct_answer) {
      alert('Complete all options and select a correct option for objective questions.');
      return;
    }
  }

  const payload = {
    question: qForm.value.question,
    option_1: qForm.value.option_1 || null,
    option_2: qForm.value.option_2 || null,
    option_3: qForm.value.option_3 || null,
    option_4: qForm.value.option_4 || null,
    correct_answer: qForm.value.correct_answer || null,
    descriptive_answer: qForm.value.descriptive_answer || null,
  };

  try {
    if (isEditingQuestion.value) {
      await api.put(`/teacher/${teacherId}/assignments/${draft.value.id}/questions/${qForm.value.id}`, payload);
      Object.assign(draft.value.questions[editingQIndex], payload);
      alert('Question updated successfully!');
    } else {
      const response = await api.post(`/teacher/${teacherId}/assignments/${draft.value.id}/questions`, payload);
      draft.value.questions.push(response.data.question);
      alert('Question added successfully!');
    }
    resetQForm();
  } catch (error) {
    console.error('Error saving question:', error);
    alert('Failed to save question: ' + (error.response?.data?.detail || 'Server error'));
  }
}

function editQuestion(index) {
  const q = draft.value.questions[index];
  qForm.value = JSON.parse(JSON.stringify(q));
  editingQIndex = index;
  isEditingQuestion.value = true;
}

async function deleteQuestion(index) {
  if (!confirm('Are you sure you want to delete this question?')) return;
  const questionId = draft.value.questions[index].id;
  if (!questionId) {
    alert('Cannot delete unsaved question.');
    return;
  }
  try {
    await api.delete(`/teacher/${teacherId}/assignments/${draft.value.id}/questions/${questionId}`);
    draft.value.questions.splice(index, 1);
    alert('Question deleted successfully!');
  } catch (error) {
    console.error('Error deleting question:', error);
    alert('Failed to delete question: ' + (error.response?.data?.detail || 'Server error'));
  }
}

async function editAssignment(assignment) {
  draft.value = JSON.parse(JSON.stringify(assignment));
  if (draft.value.assignment_deadline) {
    const date = new Date(draft.value.assignment_deadline);
    draft.value.assignment_deadline = date.toISOString().slice(0, 16);
  }
  try {
    const response = await api.get(`/teacher/${teacherId}/assignments/${assignment.id}/questions`);
    draft.value.questions = response.data;
  } catch (error) {
    console.warn('Failed to fetch questions for assignment during edit:', error);
    draft.value.questions = [];
  }
  isEditing.value = true;
  resetQForm();
  activeTab.value = 'create';
}

async function discardAssignment(assignmentId) {
  if (!confirm('Are you sure you want to delete this assignment? All associated questions will also be deleted.')) return;
  try {
    await api.delete(`/teacher/${teacherId}/assignments/${assignmentId}`);
    await fetchAssignments();
    alert('Assignment deleted successfully!');
  } catch (error) {
    console.error('Error deleting assignment:', error);
    alert('Failed to delete assignment: ' + (error.response?.data?.detail || 'Server error'));
  }
}

function resetDraft() {
  draft.value = {
    id: null,
    title: '',
    description: '',
    question_type: '',
    timeLimit: '',
    assignment_deadline: '',
    questions: [],
  };
  resetQForm();
}

function resetQForm() {
  qForm.value = {
    id: null,
    question: '',
    option_1: '',
    option_2: '',
    option_3: '',
    option_4: '',
    correct_answer: '',
    descriptive_answer: '',
  };
  editingQIndex = -1;
  isEditingQuestion.value = false;
}

function formatDate(dateString) {
  if (!dateString) return 'N/A';
  const date = new Date(dateString);
  if (isNaN(date.getTime())) return dateString;
  return date.toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

const filteredAssignments = computed(() =>
  assignments.value.filter(a =>
    (!filterType.value || a.question_type === filterType.value) &&
    a.title.toLowerCase().includes(searchQuery.value.toLowerCase())
  )
);

watch([searchQuery, filterType], () => {
  fetchAssignments();
});
</script>

<style scoped>
.instructor-assignments-page {
  min-height: 100vh;
}

.main {
  
  color: var(--text);
  background: transparent;
  flex: 1;
}

.tabs-container {
  display: flex;
  gap: 0.5rem;
  margin-bottom: 1.5rem;
  border-bottom: 1px solid var(--border);
}

.tab-button {
  padding: 0.75rem 1.5rem;
  font-size: 1rem;
  font-weight: 500;
  border: none;
  background: none;
  color: var(--text-secondary);
  cursor: pointer;
  transition: all 0.2s ease;
  border-bottom: 2px solid transparent;
  color: white;
}

.tab-button:hover {
  color: var(--primary);
}

.tab-button.active {
  color: white;
  border-bottom: 2px solid var(--primary);
}

.tab-content {
  margin-top: 1rem;
}

.card {
  background-color: var(--card);
  padding: 1.5rem;
  border-radius: 12px;
  box-shadow: var(--shadow);
  border: 1px solid var(--border);
  color: var(--text);
}

.card h3 {
  margin-top: 0;
  margin-bottom: 1.5rem;
  font-size: 1.5rem;
  font-weight: 600;
  color: var(--primary);
}

.form-group {
  margin-bottom: 1rem;
}

.form-group label {
  display: block;
  margin-bottom: 0.5rem;
  font-weight: 500;
  color: var(--text-secondary);
  font-size: 0.95rem;
}

.input,
.select,
.textarea {
  width: 100%;
  padding: 0.75rem 1rem;
  border-radius: 8px;
  border: 1px solid var(--border);
  background-color: var(--bg);
  color: var(--text);
  font-size: 1rem;
  box-sizing: border-box;
  transition: border-color 0.2s ease, box-shadow 0.2s ease;
}

.input:focus,
.select:focus,
.textarea:focus {
  outline: none;
  border-color: var(--primary);
  box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.2);
}

.textarea {
  min-height: 90px;
  resize: vertical;
}

.submit-btn {
  width: 100%;
  padding: 0.85rem 1.5rem;
  border: none;
  border-radius: 10px;
  font-size: 1rem;
  font-weight: 600;
  color: white;
  cursor: pointer;
  transition: all 0.2s ease;
  background: linear-gradient(135deg, #a78bfa 0%, #d8b4fe 100%);
  box-shadow: 0 4px 10px rgba(167, 139, 250, 0.3);
}

.submit-btn:hover {
  transform: translateY(-2px);
  box-shadow: 0 6px 15px rgba(167, 139, 250, 0.5);
}

.question-management-section {
  border-top: 1px solid var(--border);
  padding-top: 1.5rem;
  margin-top: 1.5rem;
}

.question-management-section h4 {
  margin-top: 0;
  margin-bottom: 1rem;
  font-size: 1.25rem;
  font-weight: 600;
  color: var(--primary);
  display: flex;
  align-items: center;
  gap: 0.5rem;
}

.question-header-emoji {
  font-size: 1rem;
}

.add-question-btn {
  background-color: var(--primary);
  color: white;
  padding: 0.7rem 1.2rem;
  border: none;
  border-radius: 8px;
  font-weight: 500;
  cursor: pointer;
  margin-top: 1rem;
  transition: background-color 0.2s ease;
}

.add-question-btn:hover {
  background-color: var(--primary-hover);
}

.existing-questions {
  margin-top: 1.5rem;
  border-top: 1px dashed var(--border);
  padding-top: 1rem;
}

.existing-questions h5 {
  margin-top: 0;
  margin-bottom: 1rem;
  font-size: 1rem;
  color: var(--text-secondary);
}

.question-item {
  background-color: var(--bg);
  border: 1px solid var(--border);
  border-radius: 8px;
  padding: 0.75rem 1rem;
  margin-bottom: 0.75rem;
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 1rem;
  font-size: 0.95rem;
  color: var(--text);
}

.question-item p {
  margin: 0;
  flex-grow: 1;
}

.question-actions {
  display: flex;
  gap: 0.5rem;
}

.action-icon-btn {
  background: none;
  border: none;
  cursor: pointer;
  padding: 0.3rem;
  border-radius: 4px;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: background-color 0.2s ease;
}

.action-icon-btn svg {
  color: var(--text-secondary);
  width: 18px;
  height: 18px;
}

.action-icon-btn:hover {
  background-color: var(--secondary);
}

.action-icon-btn.delete-icon svg { color: #ef4444; }
.action-icon-btn.delete-icon:hover { background-color: rgba(239, 68, 68, 0.1); }
.action-icon-btn.edit-icon svg { color: #3b82f6; }
.action-icon-btn.edit-icon:hover { background-color: rgba(59, 130, 246, 0.1); }

.all-assignments-list-card {
}

.controls-row {
  display: flex;
  gap: 1rem;
  margin-bottom: 1.5rem;
  flex-wrap: wrap;
}

.search-input,
.filter-select {
  flex: 1;
  min-width: 180px;
}

.assignment-list-items {
  display: flex;
  flex-direction: column;
  gap: 1rem;
}

.assignment-item {
  background-color: var(--bg);
  border: 1px solid var(--border);
  border-radius: 10px;
  padding: 1.2rem;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.03);
  transition: transform 0.2s ease, box-shadow 0.2s ease;
}

.assignment-item:hover {
  transform: translateY(-3px);
  box-shadow: 0 5px 15px rgba(0, 0, 0, 0.08);
}

.item-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 0.5rem;
}

.item-title {
  font-size: 1.1rem;
  font-weight: 700;
  color: var(--text);
  margin: 0;
  flex-grow: 1;
}

.status-pill {
  display: inline-block;
  padding: 3px 10px;
  border-radius: 15px;
  font-size: 0.75rem;
  font-weight: 600;
  text-transform: capitalize;
  white-space: nowrap;
}

.status-pill.published { background-color: #d1fae5; color: #065f46; }
.status-pill.draft { background-color: #e0f2fe; color: #0369a1; }

.item-meta {
  font-size: 0.85rem;
  color: var(--text-secondary);
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 0.8rem;
}

.item-submission-status {
  font-size: 0.85rem;
  color: var(--text-secondary);
  margin-bottom: 0.5rem;
}

.item-actions {
  display: flex;
  justify-content: flex-end;
  align-items: center;
  gap: 0.5rem;
  margin-top: 1rem;
}

.no-assignments-message {
  text-align: center;
  color: var(--text-secondary);
  font-style: italic;
  padding: 3rem 0;
}

@media (max-width: 1024px) {
  .tabs-container {
    flex-direction: column;
    align-items: flex-start;
  }
  .tab-button {
    width: 100%;
    text-align: left;
    border-bottom: none;
    border-left: 2px solid transparent;
    
  }
  .tab-button.active {
    border-left: 2px solid var(--primary);
  }
}

@media (max-width: 768px) {
  .main {
    padding: 1rem;
  }
  .card {
    padding: 1rem;
  }
  .card h3 {
    font-size: 1.3rem;
  }
  .input, .select, .textarea {
    font-size: 0.9rem;
    padding: 0.6rem 0.8rem;
  }
  .submit-btn {
    padding: 0.7rem 1.2rem;
    font-size: 0.9rem;
  }
  .question-management-section h4 {
    font-size: 1.1rem;
  }
  .add-question-btn {
    padding: 0.6rem 1rem;
    font-size: 0.85rem;
  }
  .question-item {
    font-size: 0.85rem;
  }
  .item-title {
    font-size: 1rem;
  }
  .item-meta, .item-submission-status {
    font-size: 0.8rem;
  }
  .action-icon-btn svg {
    width: 16px;
    height: 16px;
  }
}

@media (max-width: 480px) {
  .controls-row {
    flex-direction: column;
    gap: 0.8rem;
  }
  .search-input, .filter-select {
    min-width: unset;
  }
  .item-actions {
    flex-direction: column;
    align-items: flex-start;
    gap: 0.5rem;
  }
}
</style>