<template>
  <div class="messages">
    <h3>Staff Room</h3>
    <ul>
      <li v-for="msg in messages" :key="msg.name">
        <strong>{{ msg.name }}</strong> <br />
        <small>{{ msg.text }}</small>
        <span class="time">{{ msg.time }}</span>
      </li>
    </ul>
  </div>
</template>

<script setup>
const messages = [
  { name: 'A. Adedayo', text: 'Hey, please check analytics', time: '10:25 am' },
  { name: 'B. Omile', text: 'Meeting tomorrow @ 3pm', time: '12:35 pm' },
  { name: 'E. John', text: 'Update session notes', time: '04:30 pm' }
]
</script>

<style scoped>
.messages {
  background: var(--card);
  color: var(--text);
  
  padding: 1rem;
  border-radius: var(--card-radius);
  box-shadow: var(--shadow);
}
ul {
  padding: 0;
  list-style: none;
}
li {
  margin-bottom: 1rem;
}
.time {
  display: block;
  font-size: 0.8rem;
  color: gray;
}
</style>
