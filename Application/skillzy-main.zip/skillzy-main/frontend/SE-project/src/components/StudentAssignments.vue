<template>
  <div :class="['student-assignments-page', { dark: store.darkMode }]">
    <!-- Your Header.vue -->
    <!-- <Header /> -->
<div class="assignments-header">
  <h1 class="page-title">Assignments Overview</h1>
  <DotLottieVue
    src="https://lottie.host/5e277d4a-551b-46f9-9949-4547e6a9c52b/br6tdNJsNp.lottie"
    class="lottie-animation"
    autoplay
    loop
  />
</div>

      <!-- search filter method -->

      <!-- <h2 class="section-title" style="color: whitesmoke; padding-left: 50px;">Search Assignments...</h2> -->
      <div style="color: white; padding: 2rem 3rem; display: flex; align-items: flex-end; gap: 3rem; flex-wrap: wrap; background: transparent; border-radius: 10px;">
        <div style="position: relative; top: -15px;">
          <label for="searchInput"><strong>Search:  </strong></label>
          <input
            id="searchInput"
            v-model="searchQuery"
            type="text"
            placeholder="Search by title..."
            style="padding: 0.5rem; border-radius: 4px; border: 1px solid #ccc;"
          />
        </div>
      <div class="filters" style="display: flex; gap: 1rem; padding: 1rem 0;">
        <!-- Assignment Type Filter -->
        <div>
          <label for="typeFilter"><strong>Type of Assignment:  </strong></label>
          <select id="typeFilter" v-model="filterType">
            <option value="all">All</option>
            <option value="multiple_choice">Multiple Choice</option>
            <option value="text">Text</option>
          </select>
        </div>

        <!-- Due Date Filter -->
        <div>
          <label for="dateFilter"><strong>Due Before: </strong></label>
          <input type="date" id="dateFilter" v-model="filterDate" />
        </div>
      </div>
      </div>

      <section v-if="activeAssignment" class="attempt-section container">
      <div class="attempt-header">
        <h2>{{ activeAssignment.progress?.answered_questions > 0 ? 'Continuing' : 'Attempting' }}: {{ activeAssignment.title }}</h2>
        <div class="timer">⏳ {{ formattedTimeLeft }}</div>
        <button @click="exitAssignment" class="exit-btn">Exit Assignment</button>
      </div>

      <nav class="questions-nav">
        <button
          v-for="(q, i) in questions"
          :key="q.id"
          :class="{ 
            active: currentQuestionIndex === i,
            answered: answers[q.id] && answers[q.id].toString().trim()
          }"
          @mouseenter="hoveredQuestion = i"
          @mouseleave="hoveredQuestion = null"
          @click="goToQuestion(i)"
          :title="'Go to question ' + (i + 1)"
        >
          Q{{ i + 1 }}
        </button>
      </nav>

      <div v-if="currentQuestion && currentQuestion.id" class="question-display">
        <h3>Question: {{ currentQuestionIndex + 1 }} of {{ questions.length }}</h3>
        <p class="question-text">{{ currentQuestion.question }}</p>

        <!-- Multiple Choice Questions -->
        <template v-if="isMultipleChoice(currentQuestion)">
          <div class="options">
            <label
              v-for="(option, idx) in getQuestionOptions(currentQuestion)"
              :key="idx"
              class="option-label"
            >
              <input
                type="radio"
                :name="'q_' + currentQuestion.id"
                :value="option"
                v-model="answers[currentQuestion.id]"
                @change="autoSave"
              />
              {{ option }}
            </label>
          </div>
        </template>

        <!-- Descriptive Questions -->
        <template v-else>
          <textarea
            v-model="answers[currentQuestion.id]"
            :maxlength="getWordLimit(currentQuestion) * 6"
            placeholder="Type your answer here..."
            @input="handleTextInput"
            @blur="autoSave"
            rows="6"
          ></textarea>
          <div class="word-count">
            {{ wordCount(answers[currentQuestion.id]) }} / {{ getWordLimit(currentQuestion) }} words
          </div>
        </template>
      </div>

      <div class="attempt-actions">
        <button @click="prevQuestion" :disabled="currentQuestionIndex === 0">
          ← Previous
        </button>
        <button
          @click="nextQuestion"
          :disabled="currentQuestionIndex === questions.length - 1"
        >
          Next →
        </button>
        <button @click="saveCurrentAnswer" class="secondary-btn" :disabled="!currentQuestion || saving">
          {{ saving ? 'Saving...' : 'Save Answer' }}
        </button>
        <button @click="reviewAnswers" class="secondary-btn">Review Answers</button>
        <button class="submit-btn" @click="confirmSubmit" :disabled="submitting">
          {{ submitting ? 'Submitting...' : 'Submit Assignment' }}
        </button>
      </div>

      <!-- Confirmation Modal -->
      <div v-if="showConfirmSubmit" class="modal-overlay" @click="closeConfirmSubmit">
        <div class="modal-content" @click.stop>
          <h3>Confirm Submission</h3>
          <p>Are you sure you want to submit this assignment?</p>
          <p>Answered questions: {{ Object.keys(answers).filter(id => answers[id] && answers[id].toString().trim()).length }}/{{ questions.length }}</p>
          <div class="modal-actions">
            <button @click="submitAssignment" class="submit-btn" :disabled="submitting">
              {{ submitting ? 'Submitting...' : 'Yes, Submit' }}
            </button>
            <button @click="closeConfirmSubmit" class="cancel-btn">Cancel</button>
          </div>
        </div>
      </div>

      <div v-if="isReviewing" class="review-section">
        <h3>Review Your Answers</h3>
        <div class="review-summary">
          <p><strong>Total Questions:</strong> {{ questions.length }}</p>
          <p><strong>Answered:</strong> {{ Object.keys(answers).filter(id => answers[id] && answers[id].toString().trim()).length }}</p>
          <p><strong>Unanswered:</strong> {{ questions.length - Object.keys(answers).filter(id => answers[id] && answers[id].toString().trim()).length }}</p>
        </div>
        <div class="review-questions">
          <div v-for="(q, i) in questions" :key="'review-' + q.id" class="review-question">
            <div class="review-header">
              <strong>Q{{ i + 1 }}:</strong>
              <button @click="goToQuestionFromReview(i)" class="goto-btn">Go to Question</button>
            </div>
            <p class="question-text">{{ q.question }}</p>
            <div class="answer-section">
              <em>Your answer:</em>
              <div v-if="answers[q.id] && answers[q.id].toString().trim()" class="answer">
                {{ answers[q.id] }}
              </div>
              <div v-else class="no-answer">No answer provided</div>
            </div>
          </div>
        </div>
        <button @click="isReviewing = false" class="secondary-btn">Close Review</button>
      </div>
    </section>

    <section class="assignments-overview container" style="background: transparent; min-width: 90%">


      <!-- Loading state -->
      <div v-if="loading" class="loading-state">
        <p>Loading assignments...</p>
      </div>

      <!-- Error state -->
      <div v-else-if="error" class="error-state">
        <p>{{ error }}</p>
        <button @click="retryFetch" class="retry-btn">Retry</button>
      </div>

      <!-- No user state -->
      <div v-else-if="!userId" class="no-user-state">
        <p>Please log in to view your assignments.</p>
      </div>

      <!-- Assignments grid -->
      <div v-else-if="assignments.length > 0" class="assignments-grid">
        <div
          v-for="assignment in filteredAssignments"
          :key="assignment.id"
          class="assignment-card"
          style="background: white;"
        >
          <div
            class="type-segment"
            :class="assignment.question_type ? assignment.question_type.toLowerCase() : 'default'"
            aria-label="Assignment type"
          ></div>

          <div class="assignment-content">
            <h2 class="assignment-title"><strong>Name:</strong> {{ assignment.title || 'Untitled Assignment' }}</h2>
            <!-- a line break -->
            <hr style="color: black; margin-top: 5px;"/>
            <div class="assignment-type"><strong>Type:</strong> {{ assignment.question_type || 'Unknown Type' }}</div>
            <div class="assignment-info">
              <div><strong>Due:</strong> {{ formatDate(assignment.deadline || assignment.assignment_deadline) }}</div>
              <div><strong>Time Limit:</strong> {{ assignment.assignment_deadline || assignment.time_limit || 'N/A' }}</div>
              <div v-if="assignment.score_info" class="score-info">
                <strong>Score:</strong> {{ assignment.score_info.percentage }}% ({{ assignment.score_info.score }}/{{ assignment.score_info.max_score }})
              </div>
              <div v-if="assignment.progress" class="progress-info">
                <strong>Progress:</strong> {{ assignment.progress.answered_questions }}/{{ assignment.progress.total_questions }} questions ({{ Math.round(assignment.progress.completion_percentage) }}%)
              </div>
            </div>
          </div>

          <div class="assignment-actions">
            <button
              v-if="!assignment.is_completed"
              class="attempt-btn"
              style="background: linear-gradient(to right, #6a76ec, #6e62dd); color: white;"
              @click="attemptAssignment(assignment)"
              :disabled="activeAssignment && activeAssignment.id === assignment.id"
            >
              {{ activeAssignment && activeAssignment.id === assignment.id
                ? 'Loading...'
                  : getProgressText(assignment) }}
            </button>
            <!-- <button
              v-else
              class="view-score-btn"
              @click="viewAssignmentScore(assignment)"
            >
              View Score
            </button> -->
            <!-- <button
              class="progress-btn"
              @click="viewProgress(assignment)"
            >
              View Progress
            </button> -->
          </div>
        </div>
      </div>

      <!-- No assignments state -->
      <div v-else class="no-assignments-state">
        <p>No assignments available at this time.</p>
      </div>
    </section>

    <!-- Score Modal -->
    <div v-if="showScoreModal" class="modal-overlay" @click="closeScoreModal">
      <div class="modal-content" @click.stop>
        <h3>Assignment Score</h3>
        <div v-if="selectedScore">
          <p><strong>Assignment:</strong> {{ selectedScore.assignment_title }}</p>
          <p><strong>Score:</strong> {{ selectedScore.score }}/{{ selectedScore.max_score }} ({{ selectedScore.percentage }}%)</p>
          <p><strong>Status:</strong> {{ selectedScore.status }}</p>
          <p><strong>Submitted:</strong> {{ formatDateTime(selectedScore.submitted_at) }}</p>
          <p v-if="selectedScore.graded_at"><strong>Graded:</strong> {{ formatDateTime(selectedScore.graded_at) }}</p>
          <p v-if="selectedScore.feedback"><strong>Feedback:</strong> {{ selectedScore.feedback }}</p>
        </div>
        <button @click="closeScoreModal" class="close-btn">Close</button>
      </div>
    </div>

    <!-- Progress Modal -->
    <div v-if="showProgressModal" class="modal-overlay" @click="closeProgressModal">
      <div class="modal-content" @click.stop>
        <h3>Assignment Progress</h3>
        <div v-if="assignmentProgress">
          <p><strong>Assignment:</strong> {{ assignmentProgress.assignment_title }}</p>
          <p><strong>Progress:</strong> {{ assignmentProgress.answered_questions }}/{{ assignmentProgress.total_questions }} questions ({{ Math.round(assignmentProgress.completion_percentage) }}%)</p>
          <p v-if="assignmentProgress.score_info"><strong>Final Score:</strong> {{ assignmentProgress.score_info.percentage }}%</p>
          
          <div class="questions-progress">
            <h4>Questions Status:</h4>
            <div v-for="q in assignmentProgress.questions" :key="q.question_id" class="question-status">
              <span class="question-number">Q{{ q.question_number }}:</span>
              <span :class="['status', q.answered ? 'answered' : 'unanswered']">
                {{ q.answered ? '✓ Answered' : '○ Not Answered' }}
              </span>
              <span v-if="q.is_correct !== null" :class="['correctness', q.is_correct ? 'correct' : 'incorrect']">
                {{ q.is_correct ? '✓ Correct' : '✗ Incorrect' }}
              </span>
            </div>
          </div>
        </div>
        <button @click="closeProgressModal" class="close-btn">Close</button>
      </div>
    </div>


  </div>
</template>

<script setup>

import Header from './Header.vue'
import { ref, computed, onMounted, onUnmounted, watch, nextTick } from 'vue'
import { store } from '../store.js'
import api from '../api'
import { DotLottieVue } from '@lottiefiles/dotlottie-vue'

// State variables
const assignments = ref([])
const loading = ref(false)
const error = ref(null)
const activeAssignment = ref(null)
const questions = ref([])
const currentQuestionIndex = ref(0)
const hoveredQuestion = ref(null)
const answers = ref({})
const isReviewing = ref(false)
const submitting = ref(false)
const saving = ref(false)
const timerSeconds = ref(0)
let timerInterval = null
let autoSaveTimeout = null

// Modal states
const showScoreModal = ref(false)
const showProgressModal = ref(false)
const showConfirmSubmit = ref(false)
const selectedScore = ref(null)
const assignmentProgress = ref(null)
const filterType = ref('all') // 'all', 'multiple_choice', 'text'
const filterDate = ref('') // formatted as 'YYYY-MM-DD'
const searchQuery = ref('')
const filteredAssignments = computed(() => {
  return assignments.value.filter((a) => {
    const matchType = filterType.value === 'all' || a.question_type === filterType.value
    const matchDate = !filterDate.value || new Date(a.deadline || a.assignment_deadline) <= new Date(filterDate.value)
    const matchSearch = !searchQuery.value || a.title?.toLowerCase().includes(searchQuery.value.toLowerCase())
    return matchType && matchDate && matchSearch
  })
})

// Get user ID from store
const userId = computed(() => {
  const id = store.user?.id || store.userId
  console.log('🔍 userId computed - store.user:', store.user)
  console.log('🔍 userId computed - store.userId:', store.userId) 
  console.log('🔍 userId computed - final id:', id)
  return id
})

// Watch for userId changes
watch(userId, (newUserId, oldUserId) => {
  console.log('👀 userId watcher triggered')
  console.log('👀 Old userId:', oldUserId)
  console.log('👀 New userId:', newUserId)
  if (newUserId && newUserId !== oldUserId) {
    console.log('✅ Calling fetchAssignments...')
    fetchAssignments()
  } else if (!newUserId) {
    console.log('❌ No userId, clearing assignments')
    assignments.value = []
  }
}, { immediate: true })

// Computed properties
const currentQuestion = computed(() => {
  const question = questions.value[currentQuestionIndex.value]
  console.log('🔍 Current question:', question)
  return question || {}
})

const formattedTimeLeft = computed(() => {
  const hours = Math.floor(timerSeconds.value / 3600)
  const minutes = Math.floor((timerSeconds.value % 3600) / 60)
  const seconds = timerSeconds.value % 60
  
  if (hours > 0) {
    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`
  }
  return `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`
})

// API Functions
async function fetchAssignments() {
  if (!userId.value) {
    console.warn('User ID not available, waiting for authentication...')
    return
  }

  try {
    loading.value = true
    error.value = null
    
    console.log('🚀 Fetching assignments for user:', userId.value)
    const response = await api.get(`/student/${userId.value}/assignments`)
    console.log('📦 Raw API response:', response)
    console.log('📋 Response data:', response.data)
    
    // Handle different response formats
    const assignmentsData = Array.isArray(response.data) ? response.data : (response.data?.assignments || [])
    
    // Sort assignments by deadline
    assignments.value = assignmentsData.sort((a, b) => {
      const dateA = new Date(a.deadline || a.assignment_deadline || '9999-12-31')
      const dateB = new Date(b.deadline || b.assignment_deadline || '9999-12-31')
      return dateA - dateB
    })
    
    console.log('✅ Assignments set to:', assignments.value)
  } catch (err) {
    console.error('❌ Error fetching assignments:', err)
    console.error('❌ Error response:', err.response?.data)
    error.value = err.response?.data?.message || err.message || 'Failed to load assignments'
    assignments.value = []
  } finally {
    loading.value = false
  }
}

function getProgressText(assignment) {
  if (!assignment || !assignment.progress) return 'Start Assignment'
  return assignment.progress.answered_questions > 0 ? 'Continue Assignment' : 'Start Assignment'
}


async function attemptAssignment(assignment) {
  console.log('🎯 Attempting assignment:', assignment)
  
  try {
    loading.value = true
    
    // Use the attempt endpoint to get assignment details and questions
    const response = await api.get(`/student/${userId.value}/assignments/${assignment.id}/attempt`)
    console.log('📝 Assignment attempt data:', response.data)
    
    activeAssignment.value = {
      ...assignment,
      ...response.data.assignment
    }
    
    questions.value = response.data.questions || []
    console.log('❓ Questions loaded:', questions.value)
    
    // Load existing answers if any
    await loadExistingAnswers(assignment.id)
    
    currentQuestionIndex.value = 0
    isReviewing.value = false

    // Setup timer
    setupTimer(assignment)
    
  } catch (err) {
    console.error('❌ Error starting assignment attempt:', err)
    alert(`Failed to start assignment: ${err.response?.data?.message || err.message}`)
  } finally {
    loading.value = false
  }
}

async function loadExistingAnswers(assignmentId) {
  try {
    const response = await api.get(`/student/${userId.value}/assignments/${assignmentId}/progress`)
    console.log('📊 Assignment progress:', response.data)
    
    // Load existing answers
    const existingAnswers = {}
    if (response.data.questions) {
      response.data.questions.forEach(q => {
        if (q.answered && q.answer) {
          existingAnswers[q.question_id] = q.answer
        }
      })
    }
    
    answers.value = existingAnswers
    console.log('📝 Loaded existing answers:', existingAnswers)
    
  } catch (err) {
    console.error('❌ Error loading existing answers:', err)
    // Don't throw error, just start fresh
    answers.value = {}
  }
}

function setupTimer(assignment) {
  // Parse time limit from assignment
  const timeLimit = assignment.time_limit || assignment.timeLimit || '00:30' // default 30 minutes
  const timeParts = timeLimit.split(':')
  
  let totalSeconds = 0
  if (timeParts.length >= 2) {
    const hours = parseInt(timeParts[0]) || 0
    const minutes = parseInt(timeParts[1]) || 0
    const seconds = parseInt(timeParts[2]) || 0
    totalSeconds = hours * 3600 + minutes * 60 + seconds
  } else {
    // Fallback: assume it's minutes
    totalSeconds = (parseInt(timeLimit) || 30) * 60
  }
  
  timerSeconds.value = totalSeconds

  if (timerInterval) clearInterval(timerInterval)
  timerInterval = setInterval(() => {
    if (timerSeconds.value > 0) {
      timerSeconds.value--
      
      // Warning when 5 minutes left
      if (timerSeconds.value === 300) {
        alert('Warning: 5 minutes remaining!')
      }
      // Warning when 1 minute left
      if (timerSeconds.value === 60) {
        alert('Warning: 1 minute remaining!')
      }
    } else {
      clearInterval(timerInterval)
      alert('Time is up! Submitting your assignment.')
      submitAssignment()
    }
  }, 1000)
}

async function saveCurrentAnswer() {
  if (!currentQuestion.value || !activeAssignment.value) {
    console.error('No current question or active assignment')
    return
  }

  try {
    saving.value = true
    const answer = answers.value[currentQuestion.value.id] || ''
    
    console.log('💾 Saving answer:', {
      questionId: currentQuestion.value.id,
      answer: answer
    })

    const response = await api.post(
      `/student/${userId.value}/assignments/${activeAssignment.value.id}/questions/${currentQuestion.value.id}/answer`,
      { answer: answer }
    )
    
    console.log('✅ Answer saved:', response.data)
    
    // Show success message briefly
    showSaveSuccess()
    
  } catch (err) {
    console.error('❌ Error saving answer:', err)
    alert(`Failed to save answer: ${err.response?.data?.message || err.message}`)
  } finally {
    saving.value = false
  }
}

function showSaveSuccess() {
  // You can implement a toast notification here
  console.log('Answer saved successfully!')
}

async function submitAssignment() {
  if (!activeAssignment.value || !userId.value) {
    console.error('Missing assignment or user ID')
    alert('Error: Missing assignment or user information')
    return
  }

  if (submitting.value) return // Prevent double submission

  try {
    submitting.value = true
    clearInterval(timerInterval)

    console.log('📤 Submitting assignment:', {
      userId: userId.value,
      assignmentId: activeAssignment.value.id,
      answers: answers.value
    })

    // Prepare answers in the format expected by backend
    const answersArray = Object.entries(answers.value).map(([questionId, answer]) => ({
      question_id: parseInt(questionId),
      answer: answer || '',
    }))

    const response = await api.post(
      `/student/${userId.value}/assignments/${activeAssignment.value.id}/submit`,
      answersArray
    )

    console.log('✅ Assignment submitted successfully:', response.data)
    alert(`Assignment submitted successfully! ${response.data.score_info ? `Score: ${response.data.score_info.percentage}%` : ''}`)
    
    // Reset state
    exitAssignment()
    
    // Refresh assignments list
    await fetchAssignments()
    
  } catch (err) {
    console.error('❌ Error submitting assignment:', err)
    console.error('❌ Error response:', err.response?.data)
    alert(`Failed to submit assignment: ${err.response?.data?.message || err.message}`)
  } finally {
    submitting.value = false
    showConfirmSubmit.value = false
  }
}

async function viewAssignmentScore(assignment) {
  selectedScore.value = assignment.score_info
  showScoreModal.value = true
}

async function viewProgress(assignment) {
  try {
    const response = await api.get(`/student/${userId.value}/assignments/${assignment.id}/progress`)
    console.log('📊 Progress data:', response.data)
    assignmentProgress.value = response.data
    showProgressModal.value = true
  } catch (err) {
    console.error('❌ Error fetching progress:', err)
    alert(`Failed to fetch progress: ${err.response?.data?.message || err.message}`)
  }
}

// Navigation functions
function goToQuestion(index) {
  if (index >= 0 && index < questions.value.length) {
    currentQuestionIndex.value = index
  }
}

function goToQuestionFromReview(index) {
  goToQuestion(index)
  isReviewing.value = false
}

function nextQuestion() {
  if (currentQuestionIndex.value < questions.value.length - 1) {
    currentQuestionIndex.value++
  }
}

function prevQuestion() {
  if (currentQuestionIndex.value > 0) {
    currentQuestionIndex.value--
  }
}

// Helper functions
function isMultipleChoice(question) {
  return activeAssignment.value?.question_type === 'multiple_choice' || 
         (!activeAssignment.value?.question_type && hasOptions(question))
}

function hasOptions(question) {
  return question.option_1 || question.option_2 || question.option_3 || question.option_4
}

function getQuestionOptions(question) {
  const options = []
  if (question.option_1) options.push(question.option_1)
  if (question.option_2) options.push(question.option_2)
  if (question.option_3) options.push(question.option_3)
  if (question.option_4) options.push(question.option_4)
  return options
}

function getWordLimit(question) {
  return question.word_limit || question.wordLimit || 500
}

function wordCount(text) {
  if (!text) return 0
  return text.trim().split(/\s+/).filter(word => word.length > 0).length
}

function limitWordCount(qId) {
  const text = answers.value[qId] || ''
  const question = questions.value.find((q) => q.id == qId)
  const limit = getWordLimit(question)
  
  if (limit > 0 && wordCount(text) > limit) {
    const words = text.trim().split(/\s+/).slice(0, limit)
    answers.value[qId] = words.join(' ')
  }
}

function formatDate(dateStr) {
  if (!dateStr) return 'N/A'
  try {
    return new Date(dateStr).toLocaleDateString()
  } catch (e) {
    console.error('Date formatting error:', e)
    return 'Invalid Date'
  }
}

function formatDateTime(dateStr) {
  if (!dateStr) return 'N/A'
  try {
    return new Date(dateStr).toLocaleString()
  } catch (e) {
    console.error('DateTime formatting error:', e)
    return 'Invalid DateTime'
  }
}

// Event handlers
function handleTextInput(event) {
  const questionId = currentQuestion.value.id
  limitWordCount(questionId)
  
  // Auto-save after 2 seconds of inactivity
  if (autoSaveTimeout) {
    clearTimeout(autoSaveTimeout)
  }
  autoSaveTimeout = setTimeout(() => {
    autoSave()
  }, 2000)
}

function autoSave() {
  if (currentQuestion.value && activeAssignment.value) {
    saveCurrentAnswer()
  }
}

function confirmSubmit() {
  showConfirmSubmit.value = true
}

function closeConfirmSubmit() {
  showConfirmSubmit.value = false
}

function reviewAnswers() {
  isReviewing.value = true
}

function exitAssignment() {
  if (confirm('Are you sure you want to exit this assignment? Your progress will be saved.')) {
    activeAssignment.value = null
    questions.value = []
    answers.value = {}
    currentQuestionIndex.value = 0
    isReviewing.value = false
    
    if (timerInterval) {
      clearInterval(timerInterval)
      timerInterval = null
    }
  }
}

function closeScoreModal() {
  showScoreModal.value = false
  selectedScore.value = null
}

function closeProgressModal() {
  showProgressModal.value = false
  assignmentProgress.value = null
}

async function retryFetch() {
  await fetchAssignments()
}

// Lifecycle hooks
onMounted(() => {
  console.log('📱 Component mounted, userId:', userId.value)
  if (userId.value) {
    fetchAssignments()
  }
})

onUnmounted(() => {
  if (timerInterval) {
    clearInterval(timerInterval)
  }
  if (autoSaveTimeout) {
    clearTimeout(autoSaveTimeout)
  }
})

// Keyboard navigation
onMounted(() => {
  const handleKeydown = (event) => {
    if (!activeAssignment.value) return
    
    switch (event.key) {
      case 'ArrowLeft':
        if (event.ctrlKey || event.metaKey) {
          event.preventDefault()
          prevQuestion()
        }
        break
      case 'ArrowRight':
        if (event.ctrlKey || event.metaKey) {
          event.preventDefault()
          nextQuestion()
        }
        break
      case 's':
        if (event.ctrlKey || event.metaKey) {
          event.preventDefault()
          saveCurrentAnswer()
        }
        break
    }
  }
  
  document.addEventListener('keydown', handleKeydown)
  
  onUnmounted(() => {
    document.removeEventListener('keydown', handleKeydown)
  })
})
</script>

<style scoped>

.exit-btn{
  background-color: rgb(221, 34, 34);
  color: white;
  border: none;
  padding: 0.5rem 1rem;
  border-radius: 12px;
  cursor: pointer;
  transition: background-color 0.3s ease;
}

/* .exit-btn:hover {
  background-color: var(--danger-hover);
} */

/* Global Color Variables */
.filters select,
.filters input {
  padding: 0.5rem;
  border-radius: 4px;
  border: 1px solid #ccc;
}
.filters input[type="text"] {
  min-width: 200px;
}


:root {
  --bg: #f9fafb;
  --text-primary: #111827;
  --text-secondary: #374151;
  --primary: #4f46e5;
  --primary-hover: #4338ca;
  --objective-color: #3b82f6;
  --subjective-color: #10b981;
  --btn-bg: var(--primary);
  --btn-hover: var(--primary-hover);
  --border: #e5e7eb;
  --card-bg: #fff;
  --shadow: rgba(0, 0, 0, 0.05);
  --secondary-btn-bg: #6b7280;
  --secondary-btn-hover: #4b5563;
  --danger: #ef4444;
  --danger-hover: #dc2626;
  --input-bg: #fff;
  --input-border: #d1d5db;
  --input-text: var(--text-primary);
  --mode-toggle-bg: #4f46e5;
  --mode-toggle-hover: #4338ca;
  --scrollbar-thumb: #cbd5e1;
  --scrollbar-thumb-hover: #a1aebf;
}

.dark {
  --bg: #111827;
  --text-primary: #f3f4f6;
  --text-secondary: #d1d5db;
  --primary: #818cf8;
  --primary-hover: #6366f1;
  --objective-color: #60a5fa;
  --subjective-color: #34d399;
  --btn-bg: var(--primary);
  --btn-hover: var(--primary-hover);
  --border: #374151;
  --card-bg: #1f2937;
  --shadow: rgba(0, 0, 0, 0.3);
  --secondary-btn-bg: #6b7280;
  --secondary-btn-hover: #4b5563;
  --danger: #f87171;
  --danger-hover: #ef4444;
  --input-bg: #374151;
  --input-border: #4b5563;
  --input-text: var(--text-primary);
  --mode-toggle-bg: #818cf8;
  --mode-toggle-hover: #6366f1;
  --scrollbar-thumb: #4b5563;
  --scrollbar-thumb-hover: #6b7280;
}

/* Base styles */
.student-assignments-page {
  font-family: 'Inter', 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);

  color: var(--text-primary);
  min-height: 100vh;
  padding-bottom: 4rem;
  transition: background-color 0.3s ease, color 0.3s ease;
}

/* Container to center content */
.container {
  max-width: 900px;
  margin: 2rem auto;
  padding: 0 1rem;
}

/* Page title */
.assignments-header {
  display: flex !important;
  justify-content: space-between !important;
  align-items: center !important;
  /* background: linear-gradient(to right, #6a76ec, #6e62dd) !important; */
  background: transparent;
  padding-top: -3rem !important;
  padding-left: 2rem;
  border-radius: 12px !important;
}

.page-title {
  font-weight: 800 !important;
  font-size: 3rem !important;
  margin: 0 !important;
  color: white !important;
}

.lottie-animation {
  height: 100px !important;
  width: 200px !important;
}


/* Mode toggle */
.mode-toggle-container {
  display: flex;
  justify-content: flex-end;
  margin: 1rem 2rem 0 0;
}

.mode-toggle-btn {
  background-color: var(--mode-toggle-bg);
  border: none;
  padding: 0.5rem 1rem;
  border-radius: 12px;
  color: white;
  font-weight: 600;
  cursor: pointer;
  transition: background-color 0.3s ease;
  user-select: none;
}

.mode-toggle-btn:hover {
  background-color: var(--mode-toggle-hover);
}

/* Assignments Grid */
.assignments-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
  gap: 1.4rem;
}

/* Assignment Card */
.assignment-card {
  background-color: var(--card-bg);
  border: 1px solid var(--border);
  border-radius: 12px;
  box-shadow: 0 4px 10px var(--shadow);
  display: flex;
  flex-direction: row;
  align-items: center;
  padding: 1rem;
  transition: box-shadow 0.3s ease, border-color 0.3s ease;
}

.assignment-card:hover {
  box-shadow: 0 6px 18px var(--shadow);
  border-color: var(--primary);
}

/* Colored left segment for type */
.type-segment {
  width: 8px;
  height: 100%;
  border-radius: 8px 0 0 8px;
  margin-right: 1rem;
}

.type-segment.objective {
  background-color: var(--objective-color);
}

.type-segment.subjective {
  background-color: var(--subjective-color);
}

/* Assignment Content */
.assignment-content {
  flex-grow: 1;
}

.assignment-title {
  margin: 0;
  font-weight: 700;
  font-size: 1.2rem;
  color: var(--text-primary);
}

.assignment-type {
  font-weight: 600;
  font-size: 0.9rem;
  color: var(--text-secondary);
  margin: 0.2rem 0 0.8rem 0;
}

.assignment-info {
  font-size: 0.85rem;
  color: var(--text-secondary);
  display: flex;
  gap: 1.4rem;
  flex-wrap: wrap;
}

.assignment-actions {
  gap: 1.6rem;
  display:  grid;
  /* justify-content: last baseline; */
}

/* Attempt button */
.attempt-btn {
  background-color: var(--btn-bg);
  border: none;
  /* color: white; */
  font-weight: 700;
  padding: 0.65rem 1.2rem;
  border-radius: 12px;
  cursor: pointer;
  user-select: none;
  transition: background-color 0.3s ease, box-shadow 0.3s ease;
  box-shadow: 0 5px 12px rgb(79 70 229 / 0.5);
}

.view-score-btn{
    background-color: var(--btn-bg);
  border: none;
  /* color: white; */
  font-weight: 700;
  padding: 0.65rem 1.2rem;
  border-radius: 12px;
  cursor: pointer;
  user-select: none;
  transition: background-color 0.3s ease, box-shadow 0.3s ease;
  box-shadow: 0 5px 12px rgb(79 70 229 / 0.5);
}

.progress-btn{
    background-color: var(--btn-bg);
  border: none;
  /* color: white; */
  font-weight: 700;
  padding: 0.65rem 1.2rem;
  border-radius: 12px;
  cursor: pointer;
  user-select: none;
  transition: background-color 0.3s ease, box-shadow 0.3s ease;
  box-shadow: 0 5px 12px rgb(79 70 229 / 0.5);
}

.attempt-btn:hover:not(:disabled) {
  background-color: var(--btn-hover);
  box-shadow: 0 7px 18px rgb(67 56 202 / 0.7);
}

.attempt-btn:disabled {
  opacity: 0.5;
  cursor: not-allowed;
  box-shadow: none;
}

/* Attempt Section */
.attempt-section {
  margin-top: 3rem;
  background-color: var(--bg);
  border-radius: 16px;
  padding: 1.6rem 2rem;
  border: 1px solid var(--border);
  box-shadow: 0 5px 20px var(--shadow);
  color: var(--text-primary);
}

/* Attempt header */
.attempt-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 1.6rem;
  font-weight: 700;
  font-size: 1.4rem;
}

/* Timer */
.timer {
  background-color: var(--objective-color);
  /* color: white; */
  font-weight: 700;
  padding: 0.3rem 0.9rem;
  border-radius: 10px;
  user-select: none;
  font-family: monospace;
}

/* Questions Navigation */
.questions-nav {
  display: flex;
  flex-wrap: wrap;
  gap: 0.6rem;
  margin-bottom: 1.2rem;
}

.questions-nav button {
  border: 1px solid var(--border);
  background-color: transparent;
  padding: 0.5rem 0.8rem;
  border-radius: 8px;
  font-weight: 600;
  cursor: pointer;
  color: var(--text-primary);
  transition: background-color 0.3s ease, color 0.3s ease;
  user-select: none;
}

.questions-nav button:hover,
.questions-nav button.active {
  background-color: var(--btn-bg);
  /* color: white; */
  border-color: var(--btn-bg);
}

/* Question Display */
.question-display {
  background-color: var(--bg);
  padding: 1.4rem 1.6rem;
  border-radius: 12px;
  border: 1px solid black;
  margin-bottom: 1.6rem;
  box-shadow: inset 0 0 8px var(--shadow);
  color: var(--text-primary);
}

.question-text {
  font-weight: 600;
  font-size: 1.1rem;
  margin-bottom: 1.2rem;
}

/* Options */
.options {
  display: flex;
  flex-direction: column;
  gap: 0.75rem;
}

.option-label {
  cursor: pointer;
  font-weight: 500;
  user-select: none;
  display: flex;
  align-items: center;
  gap: 0.6rem;
  color: var(--text-primary);
}

.option-label input[type='radio'] {
  cursor: pointer;
}

/* Textarea */
textarea {
  width: 100%;
  resize: vertical;
  padding: 0.7rem 1rem;
  border: 1px solid black;
  border-radius: 12px;
  font-size: 1rem;
  font-family: inherit;
  color: var(--input-text);
  font-weight: 400;
  background-color: var(--input-bg);
  min-height: 130px;
  transition: border-color 0.3s ease, background-color 0.3s ease, color 0.3s ease;
  position: relative;
  left: -12.5px;
}

textarea:focus {
  outline: none;
  border-color: var(--primary);
  box-shadow: 0 0 6px var(--primary);
}

/* Word count */
.word-count {
  font-size: 0.85rem;
  color: var(--text-secondary);
  margin-top: 0.5rem;
  font-weight: 600;
  text-align: right;
}

/* Attempt Actions Buttons */
.attempt-actions {
  display: flex;
  gap: 1rem;
  flex-wrap: wrap;
  justify-content: flex-end;
  margin-top: 0.8rem;

}

.attempt-actions button {
  background-color: var(--btn-bg);
  border: none;
  /* color: white; */
  font-weight: 700;
  padding: 0.7rem 1.4rem;
  border-radius: 14px;
  cursor: pointer;
  transition: background-color 0.3s ease, box-shadow 0.3s ease;
  box-shadow: 0 6px 16px rgb(79 70 229 / 0.45);
  user-select: none;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: whitesmoke;
}

.attempt-actions button:hover:not(:disabled) {
  background-color: var(--btn-hover);
  box-shadow: 0 8px 26px rgb(67 56 202 / 0.7);
}

.attempt-actions button:disabled {
  opacity: 0.5;
  cursor: not-allowed;
  box-shadow: none;
}

/* Secondary buttons */
.secondary-btn {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  box-shadow: none;
  color: whitesmoke;
}

.secondary-btn:hover {
  background-color: var(--secondary-btn-hover);
}

/* Submit button */
.submit-btn {
  /* add pink, purple gradient */
  background: linear-gradient(135deg, #a527e3 0%, #764ba2 100%);
  color: whitesmoke;
  box-shadow: 0 6px 14px rgb(239 68 68 / 0.5);
}

.submit-btn:hover {
  background-color: var(--danger-hover);
  box-shadow: 0 8px 26px rgb(220 38 38 / 0.7);
}

/* Review Section */
.review-section {
  margin-top: 2rem;
  background-color: var(--card-bg);
  border-radius: 16px;
  padding: 1.8rem 2.2rem;
  border: 1px solid var(--border);
  max-height: 320px;
  overflow-y: auto;
  color: var(--text-primary);
  box-shadow: 0 4px 16px var(--shadow);
}

.review-section h3 {
  margin-bottom: 1.2rem;
  font-weight: 700;
  font-size: 1.3rem;
}

.review-section ul {
  list-style-type: none;
  padding: 0;
  margin: 0;
}

.review-section li {
  margin-bottom: 1.4rem;
  line-height: 1.5;
  font-weight: 500;
  color: var(--text-secondary);
}

.no-answer {
  font-style: italic;
  color: var(--danger);
}

/* Scrollbar styling for review section */
.review-section::-webkit-scrollbar {
  width: 8px;
}
.review-section::-webkit-scrollbar-thumb {
  background-color: var(--scrollbar-thumb);
  border-radius: 8px;
}
.review-section::-webkit-scrollbar-thumb:hover {
  background-color: var(--scrollbar-thumb-hover);
}

/* Responsive tweaks */
@media (max-width: 600px) {
  .assignments-grid {
    grid-template-columns: 1fr;
  }

  .attempt-header {
    flex-direction: column;
    align-items: flex-start;
    gap: 0.8rem;
  }

  .attempt-actions {
    justify-content: center;
  }
}


/* Background overlay */
.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.5);
  backdrop-filter: blur(3px);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
}

/* Modal container */
.modal-content {
  background: #fffbe6;
  border: 4px solid #fcd34d;
  border-radius: 20px;
  padding: 30px;
  width: 90%;
  max-width: 400px;
  box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15);
  font-family: 'Comic Sans MS', 'Poppins', sans-serif;
  text-align: center;
}

/* Heading */
.modal-content h3 {
  font-size: 24px;
  color: #ff6b6b;
  margin-bottom: 15px;
}

/* Paragraphs */
.modal-content p {
  font-size: 18px;
  color: #333;
  margin: 10px 0;
}

/* Action buttons */
.modal-actions {
  margin-top: 20px;
  display: flex;
  justify-content: center;
  gap: 15px;
}

/* Submit button */
.submit-btn {
  background-color: #4ade80;
  color: white;
  font-size: 16px;
  padding: 10px 18px;
  border: none;
  border-radius: 10px;
  cursor: pointer;
  transition: background 0.3s;
}

.submit-btn:hover {
  background-color: #22c55e;
}

.submit-btn:disabled {
  background-color: #a7f3d0;
  cursor: not-allowed;
}

/* Cancel button */
.cancel-btn {
  background-color: #f87171;
  color: white;
  font-size: 16px;
  padding: 10px 18px;
  border: none;
  border-radius: 10px;
  cursor: pointer;
  transition: background 0.3s;
}

.cancel-btn:hover {
  background-color: #ef4444;
}


.student-assignments-page {
  font-family: 'Inter', sans-serif !important;
  background: linear-gradient(135deg, #667eea, #764ba2) !important;
  min-height: 100vh !important;
  padding: 2rem !important;
}

.filters select,
.filters input {
  padding: 0.5rem !important;
  border-radius: 4px !important;
  border: 1px solid #ccc !important;
}

.assignments-grid {
  display: grid !important;
  grid-template-columns: repeat(auto-fill, minmax(260px, 1fr)) !important;
  gap: 1.4rem !important;
}

.assignment-card {
  /* background-color: var(--card-bg) !important; */
  background: whitesmoke;
  border: 1px solid var(--border) !important;
  border-radius: 12px !important;
  box-shadow: 0 4px 10px var(--shadow) !important;
  display: flex !important;
  flex-direction: column !important;
  justify-content: space-between !important;
  padding: 1rem !important;
  min-height: 220px !important;
}

.assignment-card:hover {
  box-shadow: 0 6px 18px var(--shadow) !important;
  border-color: var(--primary) !important;
}

.assignment-title {
  font-weight: 700 !important;
  font-size: 1.2rem !important;
  margin-bottom: 0.5rem !important;
  color: var(--text-primary) !important;
}

.assignment-type {
  font-weight: 600 !important;
  font-size: 0.9rem !important;
  color: var(--text-secondary) !important;
  margin-bottom: 0.8rem !important;
}

.assignment-info {
  font-size: 0.85rem !important;
  color: var(--text-secondary) !important;
  margin-bottom: 1rem !important;
}

.attempt-btn {
  background: linear-gradient(135deg, #667eea, #764ba2) !important;
  color: white !important;
  font-weight: 700 !important;
  padding: 0.65rem 1.2rem !important;
  border-radius: 12px !important;
  border: none !important;
  cursor: pointer !important;
  transition: all 0.3s ease !important;
}

.attempt-btn:hover {
  background: var(--primary-hover) !important;
}

@media (max-width: 600px) {
  .assignments-grid {
    grid-template-columns: 1fr !important;
  }
}
</style>
