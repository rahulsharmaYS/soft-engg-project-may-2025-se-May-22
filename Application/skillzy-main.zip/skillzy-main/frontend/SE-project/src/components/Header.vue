<template>
  <header class="header">
    <div class="header-content">
      <h1>{{ title }}</h1>
      <p>{{ subtitle }}</p>
    </div>
    <div class="controls">
      <label class="switch">
        <input type="checkbox" v-model="$store.darkMode" @change="$store.toggleDarkMode()" />
        <span class="slider" />
      </label>
    </div>
  </header>
</template>

<script setup>
import { store as $store } from '../store.js' // Import the shared store

defineProps({ title: String, subtitle: String })
</script>

<style scoped>

.header {
  display: flex;
  justify-content: space-between;
  align-items: center; /* Vertically align items */
  /* padding: 1rem 2rem; -- REMOVED to fix displacement */
  margin-bottom: 2rem;
  /* Removed background-color, border-bottom, and box-shadow */
  color: var(--text); /* Use theme text color */
}



h1 {
  margin: 0; /* Remove default margin */
  /* font-size: 1.8rem; -- REMOVED to revert to original size */
  font-weight: 700;
}

p {
  margin: 0; /* Remove default margin */
  /* font-size: 0.9rem; -- REMOVED to revert to original size */
  opacity: 0.8; /* Make subtitle slightly faded */
}

.controls {
  display: flex;
  align-items: center;
}

.switch {
  position: relative;
  display: inline-block;
  width: 52px;
  height: 28px;
}

.switch input {
  opacity: 0;
  width: 0;
  height: 0;
}

.slider {
  position: absolute;
  inset: 0;
  cursor: pointer;
  background-color: var(--secondary); /* Uses theme variable */
  border-radius: 34px;
  transition: background-color 0.4s;
}

.slider:before {
  position: absolute;
  content: '🌞';
  height: 24px;
  width: 24px;
  left: 2px;
  bottom: 2px;
  display: flex;
  align-items: center;
  justify-content: center;
  background-color: var(--card); /* Uses theme variable */
  border-radius: 50%;
  font-size: 14px;
  transition: transform 0.4s, content 0.4s;
}

input:checked + .slider {
  background-color: var(--primary); /* Uses theme variable */
}

input:checked + .slider:before {
  transform: translateX(24px);
  content: '🌙';
}

/* Responsive adjustments */
@media (max-width: 768px) {
  .header {
    flex-direction: column;
    text-align: center;
    padding: 1rem; /* Padding retained for mobile responsiveness */
  }

  .controls {
    margin-top: 1rem;
    justify-content: center; /* Center toggle in mobile view */
  }
}
</style>