<template>
  <section class="privacy-container">
    <div class="hero-section">
      <div class="hero-content">
        <h1 class="hero-title">
          <span class="title-icon">🔐</span>
          Privacy Policy
          <span class="shield">🛡️</span>
        </h1>
        <p class="hero-subtitle">
          Your privacy and security are our top priorities
        </p>
        <div class="last-updated">
          <span class="update-icon">📅</span>
          Last updated: August 2025
        </div>
      </div>
      <div class="privacy-illustration">
        <div class="shield-icon">🛡️</div>
        <div class="lock-icon">🔒</div>
        <div class="key-icon">🔑</div>
      </div>
    </div>

    <div class="content-section">
      <div class="intro-card">
        <div class="intro-header">
          <span class="intro-icon">👨‍👩‍👧‍👦</span>
          <h2>Built with Student Privacy in Mind</h2>
        </div>
        <p class="intro-text">
          Skillzy is designed with the highest standards of privacy and security. 
          We collect only what's necessary to provide a safe, personalized, and effective learning experience 
          for students aged 8-14.
        </p>
      </div>

      <div class="policy-sections">
        <div class="policy-card data-collection">
          <div class="card-header">
            <span class="card-icon">📊</span>
            <h3>What We Collect</h3>
          </div>
          <div class="card-content">
            <ul class="policy-list">
              <li>
                <span class="list-icon">👤</span>
                <div>
                  <strong>Basic Profile Information:</strong> Name, grade level, and learning preferences
                </div>
              </li>
              <li>
                <span class="list-icon">📚</span>
                <div>
                  <strong>Learning Data:</strong> Progress, completed activities, and skill assessments
                </div>
              </li>
              <li>
                <span class="list-icon">🎯</span>
                <div>
                  <strong>Usage Analytics:</strong> Platform interaction data to improve user experience
                </div>
              </li>
            </ul>
          </div>
        </div>

        <div class="policy-card data-protection">
          <div class="card-header">
            <span class="card-icon">🔒</span>
            <h3>How We Protect Your Data</h3>
          </div>
          <div class="card-content">
            <div class="protection-grid">
              <div class="protection-item">
                <span class="protection-icon">🔐</span>
                <h4>Encryption</h4>
                <p>All data is encrypted both in transit and at rest</p>
              </div>
              <div class="protection-item">
                <span class="protection-icon">🚫</span>
                <h4>No Third Parties</h4>
                <p>We never sell or share personal data with third parties</p>
              </div>
              <div class="protection-item">
                <span class="protection-icon">🏢</span>
                <h4>Secure Storage</h4>
                <p>Data stored in secure, monitored cloud infrastructure</p>
              </div>
              <div class="protection-item">
                <span class="protection-icon">👁️</span>
                <h4>Access Control</h4>
                <p>Strict access controls and regular security audits</p>
              </div>
            </div>
          </div>
        </div>

        <div class="policy-card data-usage">
          <div class="card-header">
            <span class="card-icon">🎯</span>
            <h3>How We Use Your Data</h3>
          </div>
          <div class="card-content">
            <div class="usage-items">
              <div class="usage-item">
                <span class="usage-icon">📈</span>
                <div>
                  <strong>Personalized Learning:</strong> Tailor content to individual learning styles and pace
                </div>
              </div>
              <div class="usage-item">
                <span class="usage-icon">📊</span>
                <div>
                  <strong>Progress Tracking:</strong> Monitor learning achievements and identify areas for improvement
                </div>
              </div>
              <div class="usage-item">
                <span class="usage-icon">🔧</span>
                <div>
                  <strong>Platform Improvement:</strong> Analyze usage patterns to enhance features and functionality
                </div>
              </div>
              <div class="usage-item">
                <span class="usage-icon">🛡️</span>
                <div>
                  <strong>Safety & Security:</strong> Detect and prevent inappropriate usage or security threats
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="policy-card parental-rights">
          <div class="card-header">
            <span class="card-icon">👨‍👩‍👧‍👦</span>
            <h3>Parental Rights & Controls</h3>
          </div>
          <div class="card-content">
            <div class="rights-grid">
              <div class="right-item">
                <span class="right-icon">👀</span>
                <h4>Access</h4>
                <p>View all data collected about your child</p>
              </div>
              <div class="right-item">
                <span class="right-icon">✏️</span>
                <h4>Modify</h4>
                <p>Request corrections to any information</p>
              </div>
              <div class="right-item">
                <span class="right-icon">🗑️</span>
                <h4>Delete</h4>
                <p>Request deletion of your child's account and data</p>
              </div>
              <div class="right-item">
                <span class="right-icon">📤</span>
                <h4>Export</h4>
                <p>Download a copy of all stored data</p>
              </div>
            </div>
          </div>
        </div>

        <div class="policy-card compliance">
          <div class="card-header">
            <span class="card-icon">⚖️</span>
            <h3>Legal Compliance</h3>
          </div>
          <div class="card-content">
            <div class="compliance-badges">
              <div class="compliance-badge">
                <span class="badge-icon">🇺🇸</span>
                <div>
                  <strong>COPPA</strong>
                  <span>Children's Online Privacy Protection Act</span>
                </div>
              </div>
              <div class="compliance-badge">
                <span class="badge-icon">🇪🇺</span>
                <div>
                  <strong>GDPR</strong>
                  <span>General Data Protection Regulation</span>
                </div>
              </div>
              <div class="compliance-badge">
                <span class="badge-icon">📚</span>
                <div>
                  <strong>FERPA</strong>
                  <span>Family Educational Rights and Privacy Act</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="contact-section">
        <div class="contact-card">
          <div class="contact-header">
            <span class="contact-icon">📧</span>
            <h3>Questions About Privacy?</h3>
          </div>
          <div class="contact-content">
            <p>
              If you're a parent, guardian, or have any questions about our privacy practices, 
              we're here to help. Contact our privacy team directly.
            </p>
            <div class="contact-methods">
              <div class="contact-method">
                <span class="method-icon">📧</span>
                <div>
                  <strong>Email:</strong>
                  <span>rahulsharmays97@gmail.com</span>
                </div>
              </div>
              <div class="contact-method">
                <span class="method-icon">💬</span>
                <div>
                  <strong>In-App Support:</strong>
                  <span>Available 24/7 through the help center</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

     <footer class="footer">
      <div class="footer-content">
        <div class="footer-left">
          <h3>Skillzy</h3>
          <p>
            Empowering young minds with essential life skills through interactive
            learning, AI-powered assistance, and fun activities for ages 8–14.
          </p>
          <div class="social-icons">
          <a href="https://www.facebook.com/iitmadrasbsdegree/about/" target="_blank"><img src="https://cdn-icons-png.flaticon.com/512/733/733547.png" alt="Facebook" class="social-icon" /></a>
          <a href="https://github.com/rahulsharmaYS/soft-engg-project-may-2025-se-May-22" target="_blank"><img src="https://cdn-icons-png.flaticon.com/512/733/733609.png" alt="GitHub" class="social-icon" /></a>
          <a href="https://study.iitm.ac.in/ds/" target="_blank"><img src="https://cdn-icons-png.flaticon.com/512/2702/2702602.png" alt="Google" class="social-icon" /></a>
          <a href="https://www.instagram.com/iitmadras_bs/" target="_blank"><img src="https://cdn-icons-png.flaticon.com/512/733/733558.png" alt="Instagram" class="social-icon" /></a>
          </div>
        </div>

        <div class="footer-links">
          <h4>Quick Links</h4>
          <ul>
            <li><router-link to="/">Home</router-link></li>
            <li><router-link to="/about">About Us</router-link></li>
            <li><router-link to="/features">Features</router-link></li>
            <li><router-link to="/privacy">Privacy Policy</router-link></li>
            <li><router-link to="/terms">Terms of Service</router-link></li>
          </ul>
        </div>

        <div class="footer-contact">
          <h4>Contact Us</h4>
          <p>Dummy Email: <u>team22@seproject.com</u></p>
          <p>Phone: <u>+91 9560594522</u></p>
          <p>Address: <u>IIT Madras, SoftWare Engineering Course</u></p>
        </div>
      </div>
      <div class="footer-bottom">
        © 2025 Skillzy. Made with ❤️ for young learners.
      </div>
    </footer>
</template>

<style scoped>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap');
.footer {
  background: #7400b8;
  color: white;
  padding: 2rem 1rem 1rem;
}
.footer-content {
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
  gap: 2rem;
}
.footer-left,
.footer-links,
.footer-contact {
  flex: 1;
  min-width: 200px;
}
.footer h4 {
  margin-bottom: 1rem;
}
.footer-links ul {
  list-style: none;
  padding: 0;
}
.footer-links li {
  margin-bottom: 0.5rem;
}
.footer-links a {
  color: white;
  text-decoration: none;
}
.footer-links a:hover {
  text-decoration: underline;
}
.social-icons a {
  font-size: 1.5rem;
  margin-right: 0.5rem;
  color: white;
}
.footer-bottom {
  margin-top: 2rem;
  text-align: center;
  font-size: 0.85rem;
  border-top: 1px solid rgba(255, 255, 255, 0.2);
  padding-top: 1rem;
}
.social-icons {
  display: flex;
  justify-content: center;
  gap: 10px;
  margin-top: 30px;
}
.social-icon {
  width: 30px;
  height: 30px;
  transition: transform 0.3s;
  cursor: pointer;
}

.social-icon:hover {
  transform: scale(1.1);
}

.privacy-container {
  font-family: 'Inter', sans-serif;
  background: linear-gradient(135deg, #dc2626 0%, #b91c1c 50%, #991b1b 100%);
  min-height: 100vh;
  position: relative;
  overflow: hidden;
}

/* Hero Section */
.hero-section {
  position: relative;
  padding: 4rem 2rem 2rem;
  display: flex;
  align-items: center;
  justify-content: space-between;
  max-width: 1200px;
  margin: 0 auto;
  color: white;
}

.hero-content {
  flex: 1;
  max-width: 600px;
}

.hero-title {
  font-size: clamp(2.5rem, 6vw, 4rem);
  font-weight: 800;
  margin-bottom: 1rem;
  background: linear-gradient(45deg, #fff, #fef2f2, #fecaca);
  background-clip: text;
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  animation: titleGlow 3s ease-in-out infinite;
}

@keyframes titleGlow {
  0%, 100% { text-shadow: 0 4px 20px rgba(255, 255, 255, 0.3); }
  50% { text-shadow: 0 8px 30px rgba(255, 255, 255, 0.5); }
}

.title-icon, .shield {
  display: inline-block;
  animation: bounce 2s infinite;
}

.shield {
  animation-delay: 1s;
}

@keyframes bounce {
  0%, 20%, 50%, 80%, 100% { transform: translateY(0); }
  40% { transform: translateY(-10px); }
  60% { transform: translateY(-5px); }
}

.hero-subtitle {
  font-size: 1.3rem;
  line-height: 1.6;
  color: rgba(255, 255, 255, 0.9);
  margin-bottom: 1rem;
}

.last-updated {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  background: rgba(255, 255, 255, 0.1);
  backdrop-filter: blur(10px);
  padding: 0.5rem 1rem;
  border-radius: 12px;
  font-size: 0.9rem;
  color: rgba(255, 255, 255, 0.8);
  width: fit-content;
}

.privacy-illustration {
  flex: 1;
  display: flex;
  justify-content: center;
  align-items: center;
  position: relative;
  max-width: 300px;
}

.shield-icon, .lock-icon, .key-icon {
  position: absolute;
  font-size: 4rem;
  animation: float 4s ease-in-out infinite;
}

.shield-icon {
  animation-delay: 0s;
}

.lock-icon {
  animation-delay: 1.3s;
  top: 20px;
  left: 20px;
  font-size: 3rem;
}

.key-icon {
  animation-delay: 2.6s;
  bottom: 20px;
  right: 20px;
  font-size: 2.5rem;
}

@keyframes float {
  0%, 100% { transform: translateY(0px); }
  50% { transform: translateY(-15px); }
}

/* Content Section */
.content-section {
  padding: 2rem;
  max-width: 1200px;
  margin: 0 auto;
}

.intro-card {
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(20px);
  border-radius: 24px;
  padding: 2.5rem;
  margin-bottom: 3rem;
  box-shadow: 0 20px 60px rgba(0, 0, 0, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.5);
  text-align: center;
}

.intro-header {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 1rem;
  margin-bottom: 1.5rem;
}

.intro-icon {
  font-size: 3rem;
}

.intro-header h2 {
  font-size: 2rem;
  font-weight: 700;
  color: #1e293b;
  margin: 0;
}

.intro-text {
  font-size: 1.1rem;
  line-height: 1.8;
  color: #475569;
}

/* Policy Sections */
.policy-sections {
  display: grid;
  gap: 2rem;
}

.policy-card {
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(20px);
  border-radius: 20px;
  padding: 2rem;
  box-shadow: 0 15px 45px rgba(0, 0, 0, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.5);
  transition: all 0.3s ease;
}

.policy-card:hover {
  transform: translateY(-5px);
  box-shadow: 0 25px 60px rgba(0, 0, 0, 0.15);
}

.card-header {
  display: flex;
  align-items: center;
  gap: 1rem;
  margin-bottom: 1.5rem;
}

.card-icon {
  font-size: 2.5rem;
  padding: 0.5rem;
  border-radius: 12px;
  background: linear-gradient(145deg, #f8fafc, #e2e8f0);
  box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
}

.card-header h3 {
  font-size: 1.5rem;
  font-weight: 700;
  color: #1e293b;
  margin: 0;
}

/* Policy List */
.policy-list {
  list-style: none;
  padding: 0;
  margin: 0;
}

.policy-list li {
  display: flex;
  align-items: flex-start;
  gap: 1rem;
  margin-bottom: 1.5rem;
  padding: 1rem;
  background: rgba(59, 130, 246, 0.05);
  border-radius: 12px;
  border-left: 4px solid #3b82f6;
}

.list-icon {
  font-size: 1.5rem;
  flex-shrink: 0;
  margin-top: 0.2rem;
}

/* Protection Grid */
.protection-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 1.5rem;
}

.protection-item {
  text-align: center;
  padding: 1.5rem;
  background: linear-gradient(145deg, #f8fafc, #f1f5f9);
  border-radius: 16px;
  transition: all 0.3s ease;
}

.protection-item:hover {
  transform: translateY(-3px);
  box-shadow: 0 8px 25px rgba(0, 0, 0, 0.1);
}

.protection-icon {
  font-size: 2.5rem;
  display: block;
  margin-bottom: 1rem;
}

.protection-item h4 {
  font-size: 1.1rem;
  font-weight: 600;
  color: #1e293b;
  margin-bottom: 0.5rem;
}

.protection-item p {
  font-size: 0.9rem;
  color: #64748b;
  line-height: 1.5;
  margin: 0;
}

/* Usage Items */
.usage-items {
  display: flex;
  flex-direction: column;
  gap: 1rem;
}

.usage-item {
  display: flex;
  align-items: flex-start;
  gap: 1rem;
  padding: 1rem;
  background: rgba(16, 185, 129, 0.05);
  border-radius: 12px;
  border-left: 4px solid #10b981;
}

.usage-icon {
  font-size: 1.5rem;
  flex-shrink: 0;
  margin-top: 0.2rem;
}

/* Rights Grid */
.rights-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 1.5rem;
}

.right-item {
  text-align: center;
  padding: 1.5rem;
  background: linear-gradient(145deg, #fef3c7, #fde68a);
  border-radius: 16px;
  transition: all 0.3s ease;
}

.right-item:hover {
  transform: translateY(-3px);
  box-shadow: 0 8px 25px rgba(245, 158, 11, 0.2);
}

.right-icon {
  font-size: 2rem;
  display: block;
  margin-bottom: 1rem;
}

.right-item h4 {
  font-size: 1.1rem;
  font-weight: 600;
  color: #92400e;
  margin-bottom: 0.5rem;
}

.right-item p {
  font-size: 0.9rem;
  color: #a16207;
  margin: 0;
}

/* Compliance Badges */
.compliance-badges {
  display: flex;
  flex-direction: column;
  gap: 1rem;
}

.compliance-badge {
  display: flex;
  align-items: center;
  gap: 1rem;
  padding: 1.5rem;
  background: linear-gradient(145deg, #e0e7ff, #c7d2fe);
  border-radius: 16px;
  border-left: 4px solid #6366f1;
}

.badge-icon {
  font-size: 2rem;
  flex-shrink: 0;
}

.compliance-badge strong {
  display: block;
  font-size: 1.1rem;
  color: #312e81;
  margin-bottom: 0.2rem;
}

.compliance-badge span {
  font-size: 0.9rem;
  color: #4338ca;
}

/* Contact Section */
.contact-section {
  margin-top: 3rem;
}

.contact-card {
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(20px);
  border-radius: 20px;
  padding: 2.5rem;
  text-align: center;
  box-shadow: 0 20px 60px rgba(0, 0, 0, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.5);
}

.contact-header {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 1rem;
  margin-bottom: 1.5rem;
}

.contact-icon {
  font-size: 3rem;
}

.contact-header h3 {
  font-size: 2rem;
  font-weight: 700;
  color: #1e293b;
  margin: 0;
}

.contact-content p {
  font-size: 1.1rem;
  line-height: 1.7;
  color: #475569;
  margin-bottom: 2rem;
}

.contact-methods {
  display: flex;
  justify-content: center;
  gap: 2rem;
  flex-wrap: wrap;
}

.contact-method {
  display: flex;
  align-items: center;
  gap: 0.8rem;
  background: linear-gradient(145deg, #dcfce7, #bbf7d0);
  padding: 1rem 1.5rem;
  border-radius: 12px;
  border-left: 4px solid #10b981;
}

.method-icon {
  font-size: 1.5rem;
}

.contact-method strong {
  display: block;
  color: #065f46;
  margin-bottom: 0.2rem;
}

.contact-method span {
  color: #047857;
  font-size: 0.9rem;
}

/* Responsive Design */
@media (max-width: 768px) {
  .hero-section {
    flex-direction: column;
    text-align: center;
    gap: 2rem;
  }
  
  .privacy-illustration {
    max-width: 200px;
  }
  
  .content-section {
    padding: 1rem;
  }
  
  .policy-card,
  .intro-card,
  .contact-card {
    padding: 1.5rem;
  }
  
  .protection-grid,
  .rights-grid {
    grid-template-columns: 1fr;
  }
  
  .contact-methods {
    flex-direction: column;
    align-items: center;
  }
}

@media (max-width: 480px) {
  .hero-title {
    font-size: 2rem;
  }
  
  .card-header {
    flex-direction: column;
    text-align: center;
    gap: 0.5rem;
  }
  
  .policy-list li,
  .usage-item {
    flex-direction: column;
    text-align: center;
  }
}
</style>
