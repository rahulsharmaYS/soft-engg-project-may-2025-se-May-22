<template>
  <div class="profile-container" :class="{ 'dark-mode': isDarkMode }">
    <!-- Header Section -->
    <div class="profile-header">
      <div class="header-content" style="min-width: 50vh;">
        <h1 class="profile-title">My Profile 

        </h1>
        <p class="profile-subtitle">Manage your account details and preferences.</p>

      </div>
      
      <div class="header-controls">
        <!-- <button @click="toggleTheme" class="theme-toggle">
          {{ isDarkMode ? '☀️' : '🌙' }}
        </button> -->
        
      </div>
    </div>

    <!-- Main Profile Grid -->
    <div class="profile-grid">
      <!-- Main Profile Card -->
      <div class="profile-main-card">
        <div class="profile-header-section">
          <div class="avatar-section">
            <div class="avatar-container">
              <img :src="student.avatar || defaultAvatar" alt="Student Avatar" class="profile-avatar">
              <!-- <button @click="triggerFileUpload" class="avatar-upload-btn">
                📷
              </button> -->
              <!-- <input 
                ref="fileInput" 
                type="file" 
                accept="image/*" 
                @change="handleFileUpload" 
                style="display: none"
              > -->
            </div>
          </div>
          
          <div class="profile-info">
            <h2 class="student-name">{{ student.name || 'Young Learner' }}</h2>
            <div class="student-badges">
              <span class="grade-badge">{{ student.grade || 'N/A' }}</span>
              <span class="experience-badge">{{ student.memberSince || '2 years experience' }}</span>
            </div>
            <p class="student-description">
              {{ student.description || 'Passionate learner with a focus on making learning fun and accessible!' }}
            </p>

          </div>
            <div class="profile-lottie">
    <DotLottieVue 
              autoplay loop
      src="https://lottie.host/64448ebd-9a37-4ece-8576-991759fe1a8d/SzjP16kcuK.lottie" 
      style="width: 100px; height: 100px;"
    />
  </div>
        </div>

        <!-- Contact Information -->
        <div class="info-section">
          <h3 class="section-title">Contact Information 📞</h3>
          <div class="info-grid">
            <div class="info-item">
              <span class="info-icon">📧</span>
              <span class="info-label">Email:</span>
              <span class="info-value">{{ student.email || 'student@school.edu' }}</span>
            </div>
            <!-- <div class="info-item">
              <span class="info-icon">📱</span>
              <span class="info-label">Phone:</span>
              <span class="info-value">{{ student.phone || '+1 (555) 123-4567' }}</span>
            </div>
            <div class="info-item">
              <span class="info-icon">🏠</span>
              <span class="info-label">Address:</span>
              <span class="info-value">{{ student.address || '123 Learning Street, Education City, EC 12345' }}</span>
            </div> -->
          </div>
        </div>

        <!-- Academic Details -->
        <div class="info-section">
          <h3 class="section-title">Academic Details 📚</h3>
          <div class="academic-grid">
            <div class="academic-item">
              <span class="academic-label">Joined:</span>
              <span class="academic-value">{{ student.joinDate || 'N/A' }}</span>
            </div>
            <!-- <div class="academic-item">
              <span class="academic-label">Favorite Subject:</span>
              <span class="academic-value">{{ student.favoriteSubject || 'Mathematics' }}</span>
            </div> -->
            <div class="academic-item">
              <span class="academic-label">Current Level:</span>
              <span class="academic-value">{{ student.currentLevel || 'Intermediate' }}</span>
            </div>
          </div>
        </div>
      </div>

      <!-- Settings & Actions Card -->
<div class="side-card">
  <!-- Relative container for Lottie to be placed absolutely -->
  <div class="card-header">
    <h3 class="card-title">Settings & Actions ⚙️</h3>
    <DotLottieVue 
      autoplay 
      loop
      src="https://lottie.host/5cc9c5c6-7f0d-41a6-8026-67a423e52073/yT7L2XrgGC.lottie" 
      class="doraemon-lottie"
    />
  </div>

  <div class="actions-list">
    <button @click="openEditModal" class="action-item edit-action">
      <span class="action-icon">✏️</span>
      <div class="action-content">
        <span class="action-title">Edit Profile</span>
        <span class="action-subtitle">Update your personal information</span>
      </div>
      <span class="action-arrow">→</span>
    </button>

    <button @click="openPasswordModal" class="action-item password-action">
      <span class="action-icon">🔒</span>
      <div class="action-content">
        <span class="action-title">Change Password</span>
        <span class="action-subtitle">Update your login credentials</span>
      </div>
      <span class="action-arrow">→</span>
    </button>

    <button @click="logout" class="action-item logout-action">
      <span class="action-icon">🚪</span>
      <div class="action-content">
        <span class="action-title">Logout</span>
        <span class="action-subtitle">Sign out of your account</span>
      </div>
      <span class="action-arrow">→</span>
    </button>
  </div>
</div>


      <!-- Account Status Card -->
      <div class="side-card">
        <h3 class="card-title">Account Status 🌟</h3>
        <div class="status-content">
          <div class="status-indicator">
            <span class="status-dot active"></span>
            <span class="status-text">Active & Verified</span>
          </div>
          <p class="status-description">
            Your account is in good standing with full access to all features.
          </p>
          
          <!-- Achievement Badges -->
          <div class="badges-section">
            <h4>Your Badges 🏆</h4>
            <div class="badges-grid">
              <div v-for="badge in student.badges" :key="badge" class="badge-item">
                <span class="badge-emoji">🏅</span>
                <span class="badge-name">{{ badge }}</span>
              </div>
              <div v-if="!student.badges || student.badges.length === 0" class="no-badges">
                <span class="no-badges-emoji">⭐</span>
                <span>Start learning to earn badges!</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Edit Profile Modal -->
    <div v-if="showEditModal" class="modal-overlay" @click.self="closeEditModal">
      <div class="modal-content">
        <div class="modal-header">
          <h3>✏️ Edit Your Profile</h3>
          <button @click="closeEditModal" class="close-btn">✕</button>
        </div>
        
        <form @submit.prevent="submitEdit" class="edit-form">
          <div class="form-group">
            <label>👤 Full Name:</label>
            <input v-model="editForm.full_name" type="text" placeholder="Enter your name" required>
          </div>
          
          <div class="form-group">
            <label>📧 Email:</label>
            <input v-model="editForm.email" type="email" placeholder="Enter your email" required>
          </div>
          <!-- file upload input -->
<input 
  type="file" 
  @change="(e) => editForm.value.profile_picture = e.target.files[0]" 
  accept="image/*"
>


          <!-- <div class="form-group">
            <label>📱 Phone:</label>
            <input v-model="editForm.phone" type="tel" placeholder="Enter your phone number">
          </div> -->
          
          <!-- <div class="form-group">
            <label>📚 Favorite Subject:</label>
            <select v-model="editForm.favoriteSubject">
              <option value="Mathematics">Mathematics 🔢</option>
              <option value="Science">Science 🔬</option>
              <option value="English">English 📖</option>
              <option value="History">History 🏛️</option>
              <option value="Art">Art 🎨</option>
              <option value="Music">Music 🎵</option>
            </select>
          </div> -->
          
          <div class="modal-actions">
            <button type="submit" class="save-btn">💾 Save Changes</button>
            <button type="button" @click="closeEditModal" class="cancel-btn">❌ Cancel</button>
          </div>
        </form>
      </div>
    </div>

    <!-- Change Password Modal -->
    <div v-if="showPasswordModal" class="modal-overlay" @click.self="closePasswordModal">
      <div class="modal-content">
        <div class="modal-header">
          <h3>🔒 Change Password</h3>
          <button @click="closePasswordModal" class="close-btn">✕</button>
        </div>
        
        <form @submit.prevent="submitPasswordChange" class="edit-form">
          <div class="form-group">
            <label>🔑 Current Password:</label>
            <input v-model="passwordForm.currentPassword" type="password" placeholder="Enter current password" required>
          </div>
          
          <div class="form-group">
            <label>🆕 New Password:</label>
            <input v-model="passwordForm.newPassword" type="password" placeholder="Enter new password" required>
          </div>
          
          <div class="form-group">
            <label>✅ Confirm New Password:</label>
            <input v-model="passwordForm.confirmPassword" type="password" placeholder="Confirm new password" required>
          </div>
          
          <div class="modal-actions">
            <button type="submit" class="save-btn">🔐 Update Password</button>
            <button type="button" @click="closePasswordModal" class="cancel-btn">❌ Cancel</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, watch, computed, onMounted } from 'vue';
import { useRouter, useRoute } from 'vue-router';
import api from '../api';
import { DotLottieVue } from '@lottiefiles/dotlottie-vue';

const router = useRouter();
const route = useRoute();
const fileInput = ref(null);

const isDarkMode = ref(false);
const studentId = computed(() => route.params.id);

const defaultAvatar = 'https://avatar.iran.liara.run/public/boy?username=student';

const student = ref({
  name: '',
  email: '',
  phone: '',
  address: '',
  grade: '',
  memberSince: '',
  joinDate: '',
  favoriteSubject: '',
  currentLevel: '',
  description: '',
  avatar: '',
  badges: []
});

const showEditModal = ref(false);
const showPasswordModal = ref(false);

const editForm = ref({
  full_name: '',
  email: '',
  // file upload
  profile_picture: '',
  phone: '',
  favoriteSubject: ''
});

const passwordForm = ref({
  currentPassword: '',
  newPassword: '',
  confirmPassword: ''
});

const toggleTheme = () => {
  isDarkMode.value = !isDarkMode.value;
  localStorage.setItem('darkMode', isDarkMode.value);
};

const logout = () => {
  router.push('/login');
};

const triggerFileUpload = () => {
  fileInput.value.click();
};

const handleFileUpload = async (event) => {
  const file = event.target.files[0];
  if (!file) return;

  // Create FormData for file upload
  const formData = new FormData();
  formData.append('avatar', file);

  try {
    const response = await api.post(`/student/${studentId.value}/upload-avatar`, formData, {
      headers: {
        'Content-Type': 'multipart/form-data'
      }
    });
    
    student.value.avatar = response.data.avatar_url;
    alert('✅ Profile picture updated successfully!');
  } catch (err) {
    console.error('Failed to upload avatar:', err);
    alert('❌ Failed to upload profile picture. Please try again.');
  }
};

const openEditModal = () => {
  editForm.value.full_name = student.value.name;
  editForm.value.email = student.value.email;
  editForm.value.phone = student.value.phone;
  editForm.value.favoriteSubject = student.value.favoriteSubject;
  showEditModal.value = true;
};

const closeEditModal = () => {
  showEditModal.value = false;
};

const openPasswordModal = () => {
  passwordForm.value = {
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  };
  showPasswordModal.value = true;
};

const closePasswordModal = () => {
  showPasswordModal.value = false;
};

const submitEdit = async () => {
  try {
    const formData = new FormData();
    formData.append('full_name', editForm.value.full_name);
    formData.append('email', editForm.value.email);
    
    // Check and add profile picture
    if (editForm.value.profile_picture instanceof File) {
      formData.append('avatar', editForm.value.profile_picture);
    }

    console.log('Sending form data to:', `/student/${studentId.value}/profile`);
    console.log('Avatar path should be:', `/static/profile_pictures/student/${studentId.value}/profile.png`);

    const response = await api.put(
      `/student/${studentId.value}/profile`,
      formData,
      {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      }
    );

    // update UI after successful upload
    student.value.name = editForm.value.full_name;
    student.value.email = editForm.value.email;
    
    if (response.data.avatar_url) {
      student.value.avatar = response.data.avatar_url;
      console.log('Uploaded avatar URL:', response.data.avatar_url);
    }

    closeEditModal();
    alert('✅ Profile updated successfully!');
  } catch (err) {
    console.error("Failed to update profile", err);
    alert('❌ Failed to update profile. Please try again.');
  }
};


const submitPasswordChange = async () => {
  if (passwordForm.value.newPassword !== passwordForm.value.confirmPassword) {
    alert('❌ New passwords do not match!');
    return;
  }

  try {
    await api.put(`/student/${studentId.value}/change-password`, {
      current_password: passwordForm.value.currentPassword,
      new_password: passwordForm.value.newPassword
    });
    
    closePasswordModal();
    alert('✅ Password updated successfully!');
  } catch (err) {
    console.error("Failed to change password", err);
    alert('❌ Failed to change password. Please check your current password.');
  }
};

async function loadProfile(id) {
  try {
    const res = await api.get(`/student/${id}/profile`);
    const data = res.data;
    console.log('Profile data:', data);
    student.value.name = data.full_name;
    student.value.email = data.email;
    student.value.phone = data.phone || 'N/A';
    student.value.address = data.address || 'N/A ';
    // student.value.grade = `Class ${data.class?.standard} - ${data.class?.division}`;
    // class value will come as an interer nothing else
    student.value.grade = data.class ? `Class ${data.class}` : 'N/A';
    student.value.memberSince = `Member Since: ${new Date(data.created_at).toLocaleString('default', { month: 'long', year: 'numeric' })}`; 
    student.value.joinDate = new Date(data.created_at).toLocaleDateString();
    // student.value.favoriteSubject = data.favorite_subject || 'Mathematics';
    // student.value.currentLevel = data.current_level || 'Intermediate';
    // Determine current level based on account age
    const createdDate = new Date(data.created_at);
    const currentDate = new Date();
    const monthsDifference = (currentDate.getFullYear() - createdDate.getFullYear()) * 12 + (currentDate.getMonth() - createdDate.getMonth());

    let level = 'Beginner';
    if (monthsDifference > 2 && monthsDifference <= 6) {
      level = 'Intermediate';
    } else if (monthsDifference > 6) {
      level = 'Advanced';
    }

    student.value.currentLevel = level;

    student.value.description = data.description || 'Passionate learner ready to explore new subjects!';
    student.value.avatar = data.avatar || `https://avatar.iran.liara.run/public/boy?username=${data.username}`;

    const badgeRes = await api.get(`/student/${id}/badges`);
    student.value.badges = badgeRes.data;
  } catch (err) {
    console.error("Failed to load student profile", err);
  }
}

onMounted(() => {
  isDarkMode.value = localStorage.getItem('darkMode') === 'true';
  if (studentId.value) loadProfile(studentId.value);
});

watch(studentId, (newId) => {
  if (newId) loadProfile(newId);
});
</script>

<style scoped>
/* CSS Variables for theming */
.profile-container {
  --bg-primary: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  --bg-card: rgba(255, 255, 255, 0.95);
  --bg-secondary: rgba(255, 255, 255, 0.1);
  --text-primary: #1F2937;
  --text-secondary: #6B7280;
  --text-white: #FFFFFF;
  --border: rgba(139, 92, 246, 0.2);
  --shadow: rgba(0, 0, 0, 0.1);
  --accent-purple: #8B5CF6;
  --accent-green: #10B981;
  --accent-red: #EF4444;
  --accent-orange: #F59E0B;
}

.profile-container.dark-mode {
  --bg-primary: linear-gradient(135deg, #1E1B4B 0%, #312E81 50%, #3730A3 100%);
  --bg-card: rgba(30, 27, 75, 0.95);
  --text-primary: #F9FAFB;
  --text-secondary: #D1D5DB;
  --border: rgba(139, 92, 246, 0.3);
  --shadow: rgba(0, 0, 0, 0.3);
}

.profile-container {
  min-height: 100vh;
  background: var(--bg-primary);
  padding: 2rem;
  color: var(--text-primary);
  font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
}

/* Header Section */
.profile-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 3rem;
}

.profile-title {
  font-size: 2.5rem;
  font-weight: 700;
  color: var(--text-white);
  margin: 0 0 0.5rem 0;
  text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.2);
  width: calc(100% - 120px) !important;
}

.profile-subtitle {
  font-size: 1.1rem;
  color: rgba(255, 255, 255, 0.8);
  margin: 0;
}

.theme-toggle {
  background: var(--bg-secondary);
  backdrop-filter: blur(20px);
  border: 1px solid var(--border);
  border-radius: 12px;
  padding: 0.75rem;
  color: var(--text-white);
  cursor: pointer;
  font-size: 1.2rem;
  transition: all 0.3s ease;
}

.theme-toggle:hover {
  transform: translateY(-2px);
  box-shadow: 0 8px 25px var(--shadow);
}

/* Profile Grid */
.profile-grid {
  display: grid;
  grid-template-columns: 2fr 1fr;
  gap: 2rem;
}

/* Main Profile Card */
.profile-main-card {
  background: var(--bg-card);
  backdrop-filter: blur(20px);
  border: 1px solid var(--border);
  border-radius: 24px;
  padding: 3rem;
  box-shadow: 0 20px 40px var(--shadow);
}

.profile-header-section {
  display: flex;
  gap: 2rem;
  margin-bottom: 3rem;
  align-items: center;
}

.avatar-section {
  flex-shrink: 0;
}

.avatar-container {
  position: relative;
  display: inline-block;
}

.profile-avatar {
  width: 120px;
  height: 120px;
  border-radius: 50%;
  border: 4px solid var(--accent-purple);
  object-fit: cover;
  box-shadow: 0 10px 30px rgba(139, 92, 246, 0.3);
  transition: transform 0.3s ease;
}

.profile-avatar:hover {
  transform: scale(1.05);
}

.avatar-upload-btn {
  position: absolute;
  bottom: 0;
  right: 0;
  background: var(--accent-purple);
  border: none;
  border-radius: 50%;
  width: 40px;
  height: 40px;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  font-size: 1.2rem;
  color: white;
  box-shadow: 0 4px 12px rgba(139, 92, 246, 0.4);
  transition: all 0.3s ease;
}

.avatar-upload-btn:hover {
  transform: scale(1.1);
  background: #7C3AED;
}

.profile-info {
  flex: 1;
}

.student-name {
  font-size: 2rem;
  font-weight: 700;
  margin: 0 0 1rem 0;
  color: var(--text-primary);
}

.student-badges {
  display: flex;
  gap: 1rem;
  margin-bottom: 1rem;
}

.grade-badge,
.experience-badge {
  background: linear-gradient(135deg, var(--accent-purple), #A855F7);
  color: white;
  padding: 0.5rem 1rem;
  border-radius: 20px;
  font-size: 0.85rem;
  font-weight: 600;
}

.experience-badge {
  background: linear-gradient(135deg, var(--accent-green), #059669);
}

.student-description {
  color: var(--text-secondary);
  font-size: 1rem;
  line-height: 1.6;
  margin: 0;
}

/* Info Sections */
.info-section {
  margin-bottom: 2.5rem;
}

.section-title {
  font-size: 1.3rem;
  font-weight: 600;
  color: var(--text-primary);
  margin-bottom: 1.5rem;
  border-bottom: 2px solid var(--border);
  padding-bottom: 0.5rem;
}

.info-grid {
  display: grid;
  gap: 1rem;
}

.info-item {
  display: flex;
  align-items: center;
  gap: 1rem;
  padding: 1rem;
  background: var(--bg-secondary);
  border-radius: 12px;
  border: 1px solid var(--border);
}

.info-icon {
  font-size: 1.5rem;
  flex-shrink: 0;
}

.info-label {
  font-weight: 600;
  color: var(--text-primary);
  min-width: 80px;
}

.info-value {
  color: var(--text-secondary);
  flex: 1;
}

.academic-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 1rem;
}

.academic-item {
  background: var(--bg-secondary);
  padding: 1.5rem;
  border-radius: 12px;
  text-align: center;
  border: 1px solid var(--border);
}

.academic-label {
  display: block;
  font-size: 0.9rem;
  color: var(--text-secondary);
  margin-bottom: 0.5rem;
}

.academic-value {
  font-size: 1.1rem;
  font-weight: 600;
  color: var(--accent-purple);
}

/* Side Cards */
.side-card {
  background: var(--bg-card);
  backdrop-filter: blur(20px);
  border: 1px solid var(--border);
  border-radius: 20px;
  padding: 2rem;
  box-shadow: 0 15px 35px var(--shadow);
  height: fit-content;
  margin-bottom: 2rem;
}

.card-title {
  font-size: 1.2rem;
  font-weight: 600;
  color: var(--text-primary);
  margin-bottom: 1.5rem;
  border-bottom: 2px solid var(--border);
  padding-bottom: 0.5rem;
}

/* Actions List */
.actions-list {
  display: flex;
  flex-direction: column;
  gap: 1rem;
}

.action-item {
  display: flex;
  align-items: center;
  gap: 1rem;
  padding: 1rem;
  background: var(--bg-secondary);
  border: 1px solid var(--border);
  border-radius: 12px;
  cursor: pointer;
  transition: all 0.3s ease;
  text-align: left;
}

.action-item:hover {
  transform: translateY(-2px);
  box-shadow: 0 8px 25px var(--shadow);
}

.action-icon {
  font-size: 1.5rem;
  flex-shrink: 0;
}

.action-content {
  flex: 1;
}

.action-title {
  display: block;
  font-weight: 600;
  color: var(--text-primary);
  margin-bottom: 0.25rem;
}

.action-subtitle {
  display: block;
  font-size: 0.85rem;
  color: var(--text-secondary);
}

.action-arrow {
  font-size: 1.2rem;
  color: var(--accent-purple);
  transition: transform 0.3s ease;
}

.action-item:hover .action-arrow {
  transform: translateX(4px);
}

/* Status Section */
.status-content {
  text-align: center;
}

.status-indicator {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 0.5rem;
  margin-bottom: 1rem;
}

.status-dot {
  width: 12px;
  height: 12px;
  border-radius: 50%;
  background: var(--accent-green);
}

.status-text {
  font-weight: 600;
  color: var(--accent-green);
}

.status-description {
  color: var(--text-secondary);
  font-size: 0.9rem;
  margin-bottom: 2rem;
}

/* Badges Section */
.badges-section h4 {
  font-size: 1rem;
  font-weight: 600;
  color: var(--text-primary);
  margin-bottom: 1rem;
}

.badges-grid {
  display: flex;
  flex-direction: column;
  gap: 0.75rem;
}

.badge-item {
  display: flex;
  align-items: center;
  gap: 0.75rem;
  padding: 0.75rem;
  background: var(--bg-secondary);
  border-radius: 8px;
  border: 1px solid var(--border);
}

.badge-emoji {
  font-size: 1.2rem;
}

.badge-name {
  font-size: 0.9rem;
  color: var(--text-primary);
  font-weight: 500;
}

.no-badges {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 0.5rem;
  padding: 2rem;
  color: var(--text-secondary);
  text-align: center;
}

.no-badges-emoji {
  font-size: 2rem;
}

/* Modal Styles */
.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
  backdrop-filter: blur(5px);
}

.modal-content {
  background: var(--bg-card);
  border-radius: 20px;
  width: 90%;
  max-width: 500px;
  box-shadow: 0 25px 50px rgba(0, 0, 0, 0.25);
  border: 1px solid var(--border);
  overflow: hidden;
}

.modal-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 2rem 2rem 1rem 2rem;
  border-bottom: 1px solid var(--border);
}

.modal-header h3 {
  font-size: 1.3rem;
  font-weight: 600;
  color: var(--text-primary);
  margin: 0;
}

.close-btn {
  background: none;
  border: none;
  font-size: 1.5rem;
  color: var(--text-secondary);
  cursor: pointer;
  padding: 0.25rem;
  border-radius: 50%;
  transition: all 0.3s ease;
}

.close-btn:hover {
  background: var(--bg-secondary);
  color: var(--text-primary);
}

.edit-form {
  padding: 2rem;
}

.form-group {
  margin-bottom: 1.5rem;
}

.form-group label {
  display: block;
  font-weight: 600;
  color: var(--text-primary);
  margin-bottom: 0.5rem;
  font-size: 0.95rem;
}

.form-group input,
.form-group select {
  width: 100%;
  padding: 0.75rem;
  border: 1px solid var(--border);
  border-radius: 8px;
  background: var(--bg-secondary);
  color: var(--text-primary);
  font-size: 0.95rem;
  transition: all 0.3s ease;
}

.form-group input:focus,
.form-group select:focus {
  outline: none;
  border-color: var(--accent-purple);
  box-shadow: 0 0 0 3px rgba(139, 92, 246, 0.1);
}

.modal-actions {
  display: flex;
  gap: 1rem;
  justify-content: flex-end;
}

.save-btn,
.cancel-btn {
  padding: 0.75rem 1.5rem;
  border: none;
  border-radius: 8px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s ease;
  font-size: 0.95rem;
}

.save-btn {
  background: var(--accent-purple);
  color: white;
}

.save-btn:hover {
  background: #7C3AED;
  transform: translateY(-2px);
}

.cancel-btn {
  background: var(--bg-secondary);
  color: var(--text-primary);
  border: 1px solid var(--border);
}

.cancel-btn:hover {
  background: var(--border);
}

/* Responsive Design */
@media (max-width: 1024px) {
  .profile-grid {
    grid-template-columns: 1fr;
    gap: 2rem;
  }
  
  .profile-header-section {
    flex-direction: column;
    text-align: center;
    gap: 1.5rem;
  }
}

@media (max-width: 768px) {
  .profile-container {
    padding: 1rem;
  }
  
  .profile-title {
    font-size: 2rem;
  }
  
  .profile-main-card,
  .side-card {
    padding: 1.5rem;
  }
  
  .student-name {
    font-size: 1.5rem;
  }
  
  .info-item {
    flex-direction: column;
    text-align: center;
    gap: 0.5rem;
  }
  
  .academic-grid {
    grid-template-columns: 1fr;
  }
  
  .modal-content {
    margin: 1rem;
    max-width: none;
  }
}

@media (max-width: 480px) {
  .profile-header {
    flex-direction: column;
    gap: 1rem;
    text-align: center;
  }
  
  .student-badges {
    flex-direction: column;
    gap: 0.5rem;
  }
  
  .modal-actions {
    flex-direction: column;
  }
  
  .save-btn,
  .cancel-btn {
    width: 100%;
  }
}
.profile-header {
  display: flex;
  align-items: center;
  justify-content: space-between; /* push photo left, lottie right */
  flex-wrap: wrap; /* responsive fallback */
  gap: 1rem;
  padding: 1rem;
}

.profile-photo {
  flex-shrink: 0;
}

.avatar-img {
  width: 200px;
  height: 200px;
  border-radius: 50%;
}

.profile-info {
  flex: 1;
  min-width: 200px;
}

.profile-lottie {
  flex-shrink: 0;
}
@media (max-width: 600px) {
  .profile-header {
    flex-direction: column;
    align-items: center;
    text-align: center;
  }

  .profile-lottie {
    margin-top: 1rem;
  }
}

.side-card {
  position: relative;
  background: #fff;
  border-radius: 12px;
  padding: 2rem;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.05);
  overflow: hidden;
}

.card-header {
  position: relative;
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
}

.card-title {
  font-size: 1.4rem;
  font-weight: bold;
  color: #333;
}

.doraemon-lottie {
  position: absolute;
  top: -10px;
  right: -10px;
  width: 80px;
  height: 80px;
  pointer-events: none;
}

</style>