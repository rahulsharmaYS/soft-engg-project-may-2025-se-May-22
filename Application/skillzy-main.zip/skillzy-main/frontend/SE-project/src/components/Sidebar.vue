<template>
  <aside
    class="sidebar"
    @mouseenter="expand = true"
    @mouseleave="expand = false"
  >
    <div class="sidebar-header">
      <span class="sidebar-logo">
        <!-- Example SVG icon, replace as needed -->
        <svg width="36" height="36" fill="none" viewBox="0 0 24 24">
          <circle cx="12" cy="12" r="12" fill="url(#grad)" />
          <path d="M7 10l5-3 5 3v2a5 5 0 01-10 0v-2z" fill="#fff"/>
          <defs>
            <linearGradient id="grad" x1="0" y1="0" x2="24" y2="24" gradientUnits="userSpaceOnUse">
              <stop stop-color="#a445ff"/>
              <stop offset="1" stop-color="#ff6a9f"/>
            </linearGradient>
          </defs>
        </svg>
      </span>
      <div class="sidebar-title" :class="{ expanded: expand }">
        <div class="main-title">Skillzy</div>
        <!-- Render the header slot here -->
        <slot name="header"></slot>
      </div>
    </div>
    <ul class="sidebar-links">
      <li
        v-for="link in navLinks"
        :key="link.name"
        :class="{ active: link.active }"
        @click="link.onClick && link.onClick()"
      >
        <span class="icon">{{ link.icon }}</span>
        <span v-if="expand" class="link-text">{{ link.name }}</span>
      </li>
    </ul>
    <div class="sidebar-logout" @click="handleLogout">
      <span class="icon">↩️</span>
      <span v-if="expand" class="link-text">Logout</span>
    </div>
  </aside>
</template>

<script setup>
import { ref } from 'vue';
import { useRouter } from 'vue-router';

defineProps({
  navLinks: {
    type: Array,
    required: true,
  },
});

const router = useRouter();
const expand = ref(false);

const handleLogout = () => {
  localStorage.clear();
  document.body.classList.remove('dark');
  localStorage.setItem('darkMode', 'false');
  router.push('/login');
};
</script>

<style scoped>
/* Sidebar base styles */
.sidebar {
  background: var(--sidebar-bg); /* Use transparent background */
  color: #222;
  width: 72px;
  min-height: 100vh;
  border-right: 1px solid #ececec;
  box-shadow: 0 2px 16px 0 rgba(44, 62, 80, 0.04);
  transition: width 0.2s cubic-bezier(.4,0,.2,1);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  position: relative;
  z-index: 10;
}
.sidebar:hover {
  width: 240px;
}

/* Sidebar header always reserves space for title */
.sidebar-header {
  display: flex;
  align-items: center;
  gap: 1rem;
  padding: 2rem 1.2rem 1.2rem 1.2rem;
  min-height: 64px;
  /* Ensure enough width for logo + text */
  min-width: 260px;
}

/* Sidebar logo */
.sidebar-logo {
  display: flex;
  align-items: center;
  justify-content: center;
  min-width: 36px;
}

/* Sidebar title always rendered, but hidden/collapsed when not expanded */
.sidebar-title {
  display: flex;
  flex-direction: column;
  gap: 0.2rem;
  opacity: 0;
  transform: translateY(10px);
  pointer-events: none;
  transition: opacity 0.18s, transform 0.18s;
  width: 200px;      /* increased from 180px */
  min-width: 180px;  /* ensure minimum width */
  max-width: 240px;  /* increased from 200px */
  height: 40px;
  overflow: visible; /* allow text to show */
}
.sidebar-title.expanded {
  opacity: 1;
  transform: translateY(0);
  pointer-events: auto;
}

.main-title {
  font-size: 1.15rem;
  font-weight: 700;
  color: #222;
}
.subtitle {
  font-size: 0.85rem;
  color: #888;
  font-weight: 500;
  display: flex;
  align-items: center;
  gap: 0.2rem;
}
.cap {
  font-size: 1rem;
}
.sidebar-links {
  flex: 1;
  list-style: none;
  padding: 0;
  margin: 0;
}
li {
  display: flex;
  align-items: center;
  gap: 1.1rem;
  padding: 0.85rem 1.2rem;
  font-weight: 500;
  font-size: 1rem;
  cursor: pointer;
  border-radius: 8px;
  margin: 0.2rem 0.6rem;
  transition: background 0.15s, color 0.15s;
  color: #222;
}
li.active, li:hover {
  background: linear-gradient(90deg, #a445ff 0%, #ff6a9f 100%);
  color: #fff;
}
li .icon {
  font-size: 1.2rem;
  min-width: 24px;
  display: flex;
  align-items: center;
  justify-content: center;
}
.link-text {
  white-space: nowrap;
}
.sidebar-logout {
  display: flex;
  align-items: center;
  gap: 1.1rem;
  padding: 1rem 1.2rem;
  font-weight: 500;
  font-size: 1rem;
  color: #888;
  cursor: pointer;
  border-top: 1px solid #ececec;
  margin-top: auto;
  transition: background 0.15s, color 0.15s;
}
.sidebar-logout:hover {
  background: #f8f6ff;
  color: #a445ff;
}
.sidebar-logout .icon {
  font-size: 1.2rem;
  min-width: 24px;
  display: flex;
  align-items: center;
  justify-content: center;
}

/* --- DARK MODE SUPPORT --- */
:root {
  --sidebar-bg: #fff;
  --sidebar-color: #222;
  --sidebar-border: #ececec;
  --sidebar-link-hover-bg: linear-gradient(90deg, #a445ff 0%, #ff6a9f 100%);
  --sidebar-link-hover-color: #fff;
  --sidebar-logout-hover-bg: #f8f6ff;
  --sidebar-logout-hover-color: #a445ff;
}
.dark .sidebar {
  background: #181a20;
  color: #e5e5e5;
  border-right: 1px solid #23242a;
  box-shadow: 0 2px 16px 0 rgba(0,0,0,0.12);
}
.dark .sidebar-header,
.dark .sidebar-title,
.dark .main-title {
  color: #e5e5e5;
}
.dark .subtitle {
  color: #aaa;
}
.dark li {
  color: #e5e5e5;
}
.dark li.active, .dark li:hover {
  background: linear-gradient(90deg, #a445ff 0%, #ff6a9f 100%);
  color: #fff;
}
.dark .sidebar-logout {
  color: #aaa;
  border-top: 1px solid #23242a;
}
.dark .sidebar-logout:hover {
  background: #232042;
  color: #a445ff;
}
</style>