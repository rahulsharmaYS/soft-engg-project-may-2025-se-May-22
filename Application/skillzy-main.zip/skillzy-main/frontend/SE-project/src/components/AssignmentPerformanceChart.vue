<template>
  <div class="chart-container">
    <canvas ref="chartCanvas"></canvas>
  </div>
</template>

<script setup>
import { ref, onMounted, watch } from 'vue';
import Chart from 'chart.js/auto';
import { store } from '../store.js';
import axios from 'axios';

const props = defineProps({
  teacherId: Number,
});

let chartInstance = null;
const chartCanvas = ref(null);

const fetchAssignmentPerformance = async () => {
  try {
    const res = await axios.get(`/teacher/${props.teacherId}/dashboard`);
    const performance = res.data.assignment_performance;
    return {
      labels: performance.map(a => a.title),
      data: performance.map(a => a.average_score),
    };
  } catch (error) {
    console.error('Failed to load assignment performance:', error);
    return { labels: [], data: [] };
  }
};

const createChart = async () => {
  if (chartInstance) {
    chartInstance.destroy();
  }
  if (!chartCanvas.value) return;

  const { labels, data } = await fetchAssignmentPerformance();

  const textColor = getComputedStyle(chartCanvas.value).getPropertyValue('--text').trim();
  const gridColor = getComputedStyle(chartCanvas.value).getPropertyValue('--border').trim();

  chartInstance = new Chart(chartCanvas.value, {
    type: 'bar',
    data: {
      labels,
      datasets: [
        {
          label: 'Average Score',
          data,
          backgroundColor: '#3b82f6',
          borderColor: '#1d4ed8',
          borderWidth: 1,
          borderRadius: 4,
        },
      ],
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false },
        tooltip: {
          callbacks: {
            label: ctx => `Average Score: ${ctx.raw}%`,
          },
        },
      },
      scales: {
        x: {
          title: { display: true, text: 'Assignments', color: textColor },
          ticks: { color: textColor },
          grid: { display: false },
        },
        y: {
          title: { display: true, text: 'Avg. Score (%)', color: textColor },
          ticks: {
            color: textColor,
            callback: val => val + '%',
          },
          grid: { color: gridColor },
          beginAtZero: true,
          max: 100,
        },
      },
    },
  });
};

onMounted(() => {
  createChart();
});

watch(() => [store.isDarkMode, props.teacherId], () => {
  createChart();
});
</script>

<style scoped>
.chart-container {
  position: relative;
  width: 100%;
  height: 100%;
  min-height: 300px;
}
</style>
