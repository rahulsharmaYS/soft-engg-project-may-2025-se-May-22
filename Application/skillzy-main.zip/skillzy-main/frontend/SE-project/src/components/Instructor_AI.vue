<template>
  <div class="ai-assistance-page">
    <!-- Header -->
    <!-- <Header 
      title="Assignment Agent Hub" 
      subtitle="Your intelligent assignment management assistant"
    /> -->
    <header class="ai-header" style="color: whitesmoke;">
      <h1>Assignment Agent</h1>
      <p>Manage your assignments and generate questions with AI assistance</p>
    </header>

    <div class="ai-container">
      <!-- Main Content -->
      <div class="ai-main-content">
        <!-- Assignment Agent Tab -->
        <div class="ai-tabs-container">
          <div class="ai-tabs single-tab">
            <div class="tab-btn active">
              <span class="tab-icon">📝</span>
              <span class="tab-text">Assignment Agent</span>
              <span class="tab-badge">Manager</span>
            </div>
          </div>
        </div>

        <!-- Content Area -->
        <div class="ai-content-area">
          <!-- Assignment Agent Section -->
          <div class="task-section">
            <div class="section-grid">
              <!-- Assignment Interface -->
              <div class="task-panel">
                <div class="task-header">
                  <div class="header-info">
                    <h3>
                      <span class="header-icon">📝</span>
                      Assignment Agent
                    </h3>
                    <p>Create, manage assignments and generate questions with AI assistance</p>
                  </div>
                  <div class="header-controls">
                    <button class="control-btn" @click="toggleDarkMode" :title="isDarkMode ? 'Light Mode' : 'Dark Mode'">
                      {{ isDarkMode ? '☀️' : '🌙' }}
                    </button>
                    <div class="task-stats">
                      <span class="stat-item">
                        <span class="stat-number">{{ getAssignmentCount() }}</span>
                        <span class="stat-label"> Assignment</span>
                      </span>
                      <span class="stat-item">
                        <span class="stat-number">{{ getQuestionCount() }}</span>
                        <span class="stat-label"> Question</span>
                      </span>
                    </div>
                    <div class="status-indicator">
                      <div class="status-dot" :class="{ listening: isListening }"></div>
                      <span>{{ isListening ? 'Listening...' : 'Ready' }}</span>
                    </div>
                  </div>
                </div>
                
                <div class="messages-container" ref="assignmentMessages" :class="{ 'dark-mode': isDarkMode }">
                  <div v-for="(msg, index) in assignmentConversation" :key="index" :class="['message', msg.sender]">
                    <div class="message-avatar">
                      {{ msg.sender === 'user' ? getUserAvatar() : '📝' }}
                    </div>
                    <div class="message-content">
                      <div class="message-text">{{ msg.text }}</div>
                      <div class="message-time">{{ msg.time }}</div>
                      
                      <!-- Assignment Data Display -->
                      <div v-if="msg.assignmentData" class="assignment-data">
                        <div class="assignment-item">
                          <div class="assignment-header-item">
                            <span class="assignment-title">{{ msg.assignmentData.title }}</span>
                            <span class="assignment-type" :class="msg.assignmentData.question_type">{{ msg.assignmentData.question_type }}</span>
                          </div>
                          <div class="assignment-details">
                            <span class="assignment-subject">📚 {{ msg.assignmentData.subject_name || 'General' }}</span>
                            <span class="assignment-due">📅 Due: {{ formatDueDate(msg.assignmentData.assignment_deadline) }}</span>
                            <span class="assignment-students">👥 {{ msg.assignmentData.students_count || 'Multiple' }} Students</span>
                          </div>
                        </div>
                      </div>

                      <!-- Assignments List Display -->
                      <div v-if="msg.assignments && msg.assignments.length > 0" class="assignments-list">
                        <div v-for="assignment in msg.assignments" :key="assignment.id" class="assignment-item-small">
                          <div class="assignment-info">
                            <span class="assignment-title">{{ assignment.title }}</span>
                            <span class="assignment-meta">{{ assignment.question_type }} • {{ formatDueDate(assignment.assignment_deadline) }}</span>
                          </div>
                        </div>
                      </div>

                      <!-- Questions Display -->
                      <div v-if="msg.questions && msg.questions.length > 0" class="questions-list">
                        <div class="questions-header">
                          <span>Generated {{ msg.questions.length }} Questions:</span>
                        </div>
                        <div v-for="(question, qIndex) in msg.questions.slice(0, 3)" :key="question.id || qIndex" class="question-item">
                          <div class="question-number">Q{{ qIndex + 1 }}</div>
                          <div class="question-content">
                            <div class="question-text">{{ question.question }}</div>
                            <div v-if="question.option_1" class="question-options">
                              <span class="option">A) {{ question.option_1 }}</span>
                              <span class="option">B) {{ question.option_2 }}</span>
                              <span class="option" v-if="question.option_3">C) {{ question.option_3 }}</span>
                              <span class="option" v-if="question.option_4">D) {{ question.option_4 }}</span>
                            </div>
                            <div v-if="question.correct_answer" class="correct-answer">
                              ✓ Answer: {{ question.correct_answer }}
                            </div>
                          </div>
                        </div>
                        <div v-if="msg.questions.length > 3" class="more-questions">
                          ... and {{ msg.questions.length - 3 }} more questions
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div class="input-section" :class="{ 'dark-mode': isDarkMode }">
                  <div class="input-container">
                    <textarea 
                      v-model="assignmentInput" 
                      placeholder="Describe your assignment task or question generation needs..."
                      @keydown.enter.exact.prevent="sendAssignmentMessage"
                      @keydown.enter.shift.exact="handleNewLine"
                      rows="1"
                      ref="assignmentTextarea"
                    ></textarea>
                    <div class="input-actions">
                      <button 
                        class="voice-btn" 
                        :class="{ listening: isListening }"
                        @click="toggleVoiceInput"
                        :title="isListening ? 'Stop Listening' : 'Start Voice Input'"
                      >
                        🎤
                      </button>
                      <button class="send-btn" @click="sendAssignmentMessage" :disabled="!assignmentInput.trim()">
                        ➤
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              <!-- Assignment Management Sidebar -->
              <div class="task-sidebar">
                <div class="feature-card">
                  <h4>📝 Assignment Examples</h4>
                  <div class="task-examples">
                    <button class="example-btn" @click="insertAssignmentExample('Create a math assignment on algebra due next Friday')">
                      📊 Create Math Assignment
                    </button>
                    <button class="example-btn" @click="insertAssignmentExample('Generate 10 MCQ questions for physics assignment about motion')">
                      🔬 Generate Physics Questions
                    </button>
                    <button class="example-btn" @click="insertAssignmentExample('Show me all my assignments')">
                      📋 View All Assignments
                    </button>
                    <button class="example-btn" @click="insertAssignmentExample('Create 5 questions about photosynthesis for biology assignment')">
                      🌱 Biology Questions
                    </button>
                    <!-- <button class="example-btn" @click="insertAssignmentExample('Update chemistry assignment due date to tomorrow')">
                      ⏰ Update Due Date
                    </button>
                    <button class="example-btn" @click="insertAssignmentExample('Delete the old history project assignment')">
                      🗑️ Delete Assignment
                    </button> -->
                  </div>
                </div>

                <div class="feature-card">
                  <h4>🎯 Assignment Tips</h4>
                  <div class="tips-list">
                    <div class="tip-item">
                      <span class="tip-icon">📅</span>
                      <span>Include due dates like "next Friday" or "tomorrow"</span>
                    </div>
                    <div class="tip-item">
                      <span class="tip-icon">❓</span>
                      <span>Specify question count: "5 questions", "10 MCQs"</span>
                    </div>
                    <div class="tip-item">
                      <span class="tip-icon">📚</span>
                      <span>Mention topics for better question generation</span>
                    </div>
                    <div class="tip-item">
                      <span class="tip-icon">🎯</span>
                      <span>Use "multiple choice" or "text" for question types</span>
                    </div>
                  </div>
                </div>
<!-- 
                <div class="feature-card">
                  <h4>⚡ Quick Actions</h4>
                  <div class="quick-actions">
                    <button class="action-btn" @click="openBulkGenerator">
                      🎲 Bulk Question Generator
                    </button>
                    <button class="action-btn" @click="getAssignmentSuggestions">
                      💡 Assignment Suggestions
                    </button>
                    <button class="action-btn" @click="showHelp">
                      ❓ Help & Examples
                    </button>
                  </div>
                </div> -->
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Bulk Question Generator Modal -->
    <div v-if="showBulkModal" class="modal-overlay" @click="closeBulkModal">
      <div class="modal-content" @click.stop>
        <div class="modal-header">
          <h3>🎲 Bulk Question Generator</h3>
          <button class="close-btn" @click="closeBulkModal">×</button>
        </div>
        <div class="modal-body">
          <div class="form-group">
            <label>Assignment ID:</label>
            <input v-model="bulkForm.assignmentId" type="number" placeholder="Enter assignment ID">
          </div>
          <div class="form-group">
            <label>Topic:</label>
            <input v-model="bulkForm.topic" placeholder="e.g., Photosynthesis, Algebra, World War 2">
          </div>
          <div class="form-group">
            <label>Question Count:</label>
            <input v-model="bulkForm.questionCount" type="number" min="1" max="50" placeholder="5">
          </div>
          <div class="form-group">
            <label>Question Type:</label>
            <select v-model="bulkForm.questionType">
              <option value="multiple_choice">Multiple Choice</option>
              <option value="text">Text/Descriptive</option>
            </select>
          </div>
          <div class="form-group">
            <label>Difficulty:</label>
            <select v-model="bulkForm.difficulty">
              <option value="easy">Easy</option>
              <option value="medium">Medium</option>
              <option value="hard">Hard</option>
            </select>
          </div>
        </div>
        <div class="modal-footer">
          <button class="cancel-btn" @click="closeBulkModal">Cancel</button>
          <button class="generate-btn" @click="generateBulkQuestions" :disabled="!bulkForm.assignmentId">
            Generate Questions
          </button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, nextTick, watch } from 'vue';
import Header from './Header.vue';
import { useRoute, useRouter } from 'vue-router';
import api from '../api'

const route = useRoute();
const router = useRouter();
const userRole = ref('teacher');
const teacherId = ref(null);
const isDarkMode = ref(false);
const isListening = ref(false);
const isProcessing = ref(false);
const assignmentInput = ref('');
const assignmentConversation = ref([]);
const showBulkModal = ref(false);

// Bulk generator form
const bulkForm = ref({
  assignmentId: '',
  topic: '',
  questionCount: 5,
  questionType: 'multiple_choice',
  difficulty: 'medium'
});

// Voice recognition
let recognition = null;

// References
const assignmentMessages = ref(null);
const assignmentTextarea = ref(null);

// Get teacher ID from route params
onMounted(() => {
  teacherId.value = route.params.teacher_id || route.params.id || localStorage.getItem('teacher_id');
});

// Watch route changes to update teacher ID
watch(() => route.path, (newPath) => {
  teacherId.value = route.params.teacher_id || route.params.id || localStorage.getItem('teacher_id');
}, { immediate: true });

// Utility functions
function getCurrentTime() {
  return new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

function getUserAvatar() {
  return '👩‍🏫';
}

function getAssignmentCount() {
  return assignmentConversation.value.filter(msg => msg.assignmentData || (msg.assignments && msg.assignments.length)).length;
}

function getQuestionCount() {
  return assignmentConversation.value.reduce((count, msg) => {
    return count + (msg.questions ? msg.questions.length : 0);
  }, 0);
}

function toggleDarkMode() {
  isDarkMode.value = !isDarkMode.value;
}

function handleNewLine() {
  // Allow Shift+Enter for new lines
}

function scrollToBottom() {
  if (assignmentMessages.value) {
    assignmentMessages.value.scrollTop = assignmentMessages.value.scrollHeight;
  }
}

function insertAssignmentExample(example) {
  assignmentInput.value = example;
  nextTick(() => {
    if (assignmentTextarea.value) {
      assignmentTextarea.value.focus();
    }
  });
}

// Initialize assignment conversation
function initializeAssignmentConversation() {
  assignmentConversation.value = [
    {
      sender: 'bot',
      text: "Welcome to Assignment Agent! I can help you create assignments, generate questions, and manage your teaching tasks. Try saying something like 'Create a math assignment on algebra' or 'Generate 5 questions about photosynthesis'.",
      time: getCurrentTime()
    }
  ];
}

// Assignment message handling
async function sendAssignmentMessage() {
  if (!assignmentInput.value.trim() || isProcessing.value) return;
  
  if (!teacherId.value) {
    alert('Teacher ID not found. Please login again.');
    return;
  }
  
  const userMessage = {
    sender: 'user',
    text: assignmentInput.value.trim(),
    time: getCurrentTime()
  };
  
  assignmentConversation.value.push(userMessage);
  
  // Show processing state
  isProcessing.value = true;
  const messageText = assignmentInput.value.trim();
  assignmentInput.value = '';
  
  // Add loading message
  const loadingMessage = {
    sender: 'bot',
    text: '🤔 Processing your assignment request...',
    time: getCurrentTime(),
    isLoading: true
  };
  assignmentConversation.value.push(loadingMessage);
  
  // Scroll to bottom
  nextTick(() => scrollToBottom());
  
  try {
    // Call FastAPI backend for teacher assignment agent
    const response = await api.post(`/teacher/${teacherId.value}/ai-assignment`, {
      message: messageText
    });
    
    // Remove loading message
    assignmentConversation.value = assignmentConversation.value.filter(msg => !msg.isLoading);
    
    if (response.data.success) {
      const botResponse = {
        sender: 'bot',
        text: response.data.message,
        time: getCurrentTime()
      };
      
      // Add assignment data if created
      if (response.data.assignment_data) {
        botResponse.assignmentData = {
          ...response.data.assignment_data,
          subject_name: getSubjectName(response.data.assignment_data.subject_id),
          students_count: extractStudentsCount(response.data.message)
        };
      }
      
      // Add assignments list if retrieved
      if (response.data.assignments && response.data.assignments.length > 0) {
        botResponse.assignments = response.data.assignments;
      }
      
      // Add questions if generated
      if (response.data.questions && response.data.questions.length > 0) {
        botResponse.questions = response.data.questions;
      }
      
      assignmentConversation.value.push(botResponse);
    } else {
      // Handle API errors
      assignmentConversation.value.push({
        sender: 'bot',
        text: `❌ ${response.data.message}`,
        time: getCurrentTime()
      });
    }
  } catch (error) {
    console.error('Assignment API Error:', error);
    
    // Remove loading message
    assignmentConversation.value = assignmentConversation.value.filter(msg => !msg.isLoading);
    
    let errorMessage = '❌ Sorry, I encountered an error processing your assignment request.';
    
    if (error.response?.status === 401) {
      errorMessage = '❌ Authentication failed. Please login again.';
    } else if (error.response?.status === 404) {
      errorMessage = '❌ Teacher account not found.';
    } else if (error.response?.data?.message) {
      errorMessage = `❌ ${error.response.data.message}`;
    }
    
    assignmentConversation.value.push({
      sender: 'bot',
      text: errorMessage,
      time: getCurrentTime()
    });
  } finally {
    isProcessing.value = false;
    nextTick(() => scrollToBottom());
  }
}

// Helper functions
function getSubjectName(subjectId) {
  const subjects = {
    1: 'Time Management',
    2: 'Communication', 
    3: 'Health',
    4: 'Decision Making',
    5: 'Financial Literacy',
    6: 'Problem Solving',
    7: 'Emotion Theory'
  };
  return subjects[subjectId] || 'General';
}

function extractStudentsCount(message) {
  const match = message.match(/(\d+)\s+students?/);
  return match ? match[1] : 'Multiple';
}

function formatDueDate(dateString) {
  if (!dateString) return 'Not specified';
  
  try {
    const date = new Date(dateString);
    const today = new Date();
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);
    
    if (date.toDateString() === today.toDateString()) {
      return 'Today';
    } else if (date.toDateString() === tomorrow.toDateString()) {
      return 'Tomorrow';
    } else {
      return date.toLocaleDateString('en-US', { 
        weekday: 'short', 
        month: 'short', 
        day: 'numeric' 
      });
    }
  } catch (error) {
    return dateString;
  }
}

// Bulk question generator
function openBulkGenerator() {
  showBulkModal.value = true;
}

function closeBulkModal() {
  showBulkModal.value = false;
}

async function generateBulkQuestions() {
  if (!bulkForm.value.assignmentId) return;
  
  try {
    const response = await api.post(`/teacher/${teacherId.value}/ai-assignment/bulk-questions`, bulkForm.value);
    
    if (response.data.success) {
      // Add success message to conversation
      assignmentConversation.value.push({
        sender: 'bot',
        text: response.data.message,
        time: getCurrentTime(),
        questions: response.data.questions
      });
      
      closeBulkModal();
      nextTick(() => scrollToBottom());
    } else {
      alert(`Error: ${response.data.message}`);
    }
  } catch (error) {
    console.error('Bulk generation error:', error);
    alert('Failed to generate questions. Please try again.');
  }
}

// Assignment suggestions
async function getAssignmentSuggestions() {
  try {
    const response = await api.get(`/teacher/${teacherId.value}/ai-assignment/suggestions`);
    
    if (response.data.success) {
      const suggestionsText = response.data.suggestions.map((s, index) => 
        `${index + 1}. ${s.title}\n   ${s.description}\n   Topics: ${s.topics?.join(', ')}`
      ).join('\n\n');
      
      assignmentConversation.value.push({
        sender: 'bot',
        text: `💡 Here are some assignment suggestions:\n\n${suggestionsText}`,
        time: getCurrentTime()
      });
      
      nextTick(() => scrollToBottom());
    }
  } catch (error) {
    console.error('Suggestions error:', error);
    alert('Failed to get suggestions. Please try again.');
  }
}

// Show help
function showHelp() {
  const helpMessage = `🎯 Assignment Agent Help:

📝 Creating Assignments:
• "Create a math assignment on algebra due next Friday"
• "Make a science quiz about photosynthesis"

❓ Generating Questions:
• "Create 5 MCQ questions for physics assignment"
• "Generate 10 questions about World War 2"
• "Add questions to chemistry assignment about atoms"

📋 Managing Assignments:
• "Show me all my assignments"
• "Update math assignment due date to tomorrow"
• "Delete the old history project"

🎲 Question Types:
• Use "multiple choice" or "MCQ" for multiple choice
• Use "text" or "descriptive" for essay questions
• Specify count: "5 questions", "10 MCQs"

💡 Tips:
• Be specific about topics for better questions
• Include due dates in natural language
• Mention difficulty if needed (easy, medium, hard)`;

  assignmentConversation.value.push({
    sender: 'bot',
    text: helpMessage,
    time: getCurrentTime()
  });
  
  nextTick(() => scrollToBottom());
}

// Voice input functions
function toggleVoiceInput() {
  if (isListening.value) {
    stopVoiceInput();
  } else {
    startVoiceInput();
  }
}

function startVoiceInput() {
  if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
    alert('Speech recognition is not supported in your browser. Please use Chrome or Edge.');
    return;
  }
  
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  recognition = new SpeechRecognition();
  
  recognition.continuous = false;
  recognition.interimResults = false;
  recognition.lang = 'en-US';
  
  recognition.onstart = () => {
    isListening.value = true;
  };
  
  recognition.onresult = (event) => {
    const transcript = event.results[0][0].transcript;
    assignmentInput.value = transcript;
  };
  
  recognition.onerror = (event) => {
    console.error('Speech recognition error:', event.error);
    stopVoiceInput();
  };
  
  recognition.onend = () => {
    stopVoiceInput();
  };
  
  recognition.start();
}

function stopVoiceInput() {
  if (recognition) {
    recognition.stop();
  }
  isListening.value = false;
}

// Initialize component
onMounted(() => {
  console.log('Initializing Assignment Agent...');
  console.log('User role:', userRole.value);
  console.log('Teacher ID:', teacherId.value);
  
  initializeAssignmentConversation();
  
  nextTick(() => scrollToBottom());
});
</script>

<style scoped>
.ai-assistance-page {
  min-height: 100vh;
  background: transparent;
  padding: 2rem;
}

.ai-container {
  max-width: 1400px;
  margin: 0 auto;
  padding: 0 1rem;
}

.ai-main-content {
  margin-top: 2rem;
}

/* Tab Navigation */
.ai-tabs-container {
  margin-bottom: 2rem;
}

.ai-tabs {
  display: flex;
  gap: 1rem;
  background: rgba(255, 255, 255, 0.1);
  backdrop-filter: blur(10px);
  border-radius: 16px;
  padding: 0.5rem;
}

.ai-tabs.single-tab {
  justify-content: center;
}

.tab-btn {
  flex: 1;
  background: transparent;
  border: none;
  color: rgba(255, 255, 255, 0.8);
  padding: 1.5rem 2rem;
  border-radius: 12px;
  cursor: pointer;
  transition: all 0.3s ease;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 0.5rem;
  position: relative;
  overflow: hidden;
}

.tab-btn:hover {
  background: rgba(255, 255, 255, 0.1);
  color: white;
}

.tab-btn.active {
  background: white;
  color: #1f2937;
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
}

.tab-icon {
  font-size: 2rem;
}

.tab-text {
  font-weight: 700;
  font-size: 1.1rem;
}

.tab-badge {
  font-size: 0.8rem;
  opacity: 0.8;
  font-weight: 500;
}

.tab-btn.active .tab-badge {
  background: linear-gradient(135deg, #667eea, #764ba2);
  color: white;
  padding: 0.25rem 0.75rem;
  border-radius: 12px;
  opacity: 1;
}

/* Content Area */
.ai-content-area {
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(10px);
  border-radius: 20px;
  box-shadow: 0 20px 60px rgba(0, 0, 0, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.2);
  overflow: hidden;
}

.section-grid {
  display: grid;
  grid-template-columns: 1fr 350px;
  min-height: 600px;
}

/* Chat Panel */
.chat-panel,
.task-panel {
  display: flex;
  flex-direction: column;
  border-right: 1px solid #e2e8f0;
}

.chat-header,
.task-header {
  padding: 2rem;
  background: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%);
  border-bottom: 1px solid #e2e8f0;
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
}

.header-info h3 {
  margin: 0 0 0.5rem 0;
  font-size: 1.5rem;
  font-weight: 700;
  color: #1f2937;
  display: flex;
  align-items: center;
  gap: 0.5rem;
}

.header-icon {
  font-size: 1.8rem;
}

.header-info p {
  margin: 0;
  color: #6b7280;
  font-size: 1rem;
}

.header-controls {
  display: flex;
  flex-direction: column;
  align-items: flex-end;
  gap: 1rem;
}

.control-btn {
  background: rgba(102, 126, 234, 0.1);
  border: 1px solid #667eea;
  color: #667eea;
  width: 40px;
  height: 40px;
  border-radius: 50%;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all 0.3s ease;
}

.control-btn:hover {
  background: #667eea;
  color: white;
}

.status-indicator {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  font-size: 0.9rem;
  color: #6b7280;
}

.status-dot {
  width: 10px;
  height: 10px;
  background: #10b981;
  border-radius: 50%;
  animation: pulse 2s infinite;
}

.status-dot.listening {
  background: #ef4444;
  animation: voicePulse 1s infinite;
}

.task-stats {
  display: flex;
  gap: 1rem;
}

.stat-item {
  display: flex;
  flex-direction: column;
  align-items: center;
  text-align: center;
}

.stat-number {
  font-size: 1.5rem;
  font-weight: 700;
  color: #667eea;
}

.stat-label {
  font-size: 0.8rem;
  color: #6b7280;
}

/* Messages Container */
.messages-container {
  flex: 1;
  overflow-y: auto;
  padding: 2rem;
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
  min-height: 0;
  background: white;
}

.messages-container.dark-mode {
  background: #1a1a1a;
}

.messages-container::-webkit-scrollbar {
  width: 8px;
}

.messages-container::-webkit-scrollbar-track {
  background: transparent;
}

.messages-container::-webkit-scrollbar-thumb {
  background: #cbd5e0;
  border-radius: 4px;
}

.message {
  display: flex;
  gap: 1rem;
  max-width: 85%;
  animation: messageSlide 0.3s ease;
}

.message.user {
  align-self: flex-end;
  flex-direction: row-reverse;
}

.message.bot {
  align-self: flex-start;
}

.message-avatar {
  width: 45px;
  height: 45px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 20px;
  flex-shrink: 0;
  background: linear-gradient(135deg, #f8fafc, #e2e8f0);
}

.message.user .message-avatar {
  background: linear-gradient(135deg, #667eea, #764ba2);
}

.message-content {
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
}

.message-text {
  background: #f1f5f9;
  padding: 1rem 1.25rem;
  border-radius: 20px;
  font-size: 1rem;
  line-height: 1.5;
  word-wrap: break-word;
}

.message.user .message-text {
  background: linear-gradient(135deg, #667eea, #764ba2);
  color: white;
  border-bottom-right-radius: 8px;
}

.message.bot .message-text {
  border-bottom-left-radius: 8px;
}

.dark-mode .message.bot .message-text {
  background: #374151;
  color: white;
}

.message-time {
  font-size: 0.8rem;
  color: #94a3b8;
  align-self: flex-start;
}

.message.user .message-time {
  align-self: flex-end;
}

/* Task Data */
.task-data {
  margin-top: 0.75rem;
}

.task-item {
  background: #f8fafc;
  border: 1px solid #e2e8f0;
  border-radius: 12px;
  padding: 1rem;
  display: flex;
  flex-direction: column;
  gap: 0.75rem;
}

.dark-mode .task-item {
  background: #2d3748;
  border-color: #4a5568;
}

.task-header-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.task-title {
  font-weight: 700;
  color: #1e293b;
  font-size: 1rem;
}

.dark-mode .task-title {
  color: white;
}

.task-priority {
  font-size: 0.8rem;
  padding: 0.25rem 0.75rem;
  border-radius: 12px;
  font-weight: 600;
}

.task-priority.high {
  background: #fef2f2;
  color: #dc2626;
}

.task-priority.medium {
  background: #fffbeb;
  color: #d97706;
}

.task-priority.low {
  background: #f0fdf4;
  color: #16a34a;
}

.task-details {
  display: flex;
  gap: 1rem;
  font-size: 0.9rem;
  color: #6b7280;
}

.dark-mode .task-details {
  color: #cbd5e0;
}

/* Input Section */
.input-section {
  padding: 2rem;
  border-top: 1px solid #e2e8f0;
  background: #f8fafc;
}

.input-section.dark-mode {
  background: #2d3748;
  border-top-color: #4a5568;
}

.input-container {
  display: flex;
  gap: 1rem;
  align-items: flex-end;
}

.input-container textarea {
  flex: 1;
  border: 2px solid #e2e8f0;
  border-radius: 12px;
  padding: 1rem 1.25rem;
  font-size: 1rem;
  font-family: inherit;
  resize: none;
  min-height: 50px;
  max-height: 150px;
  transition: border-color 0.3s ease;
  background: white;
}

.input-container textarea:focus {
  outline: none;
  border-color: #667eea;
  box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
}

.dark-mode .input-container textarea {
  background: #374151;
  border-color: #4a5568;
  color: white;
}

.input-actions {
  display: flex;
  gap: 0.75rem;
}

.voice-btn,
.send-btn {
  width: 50px;
  height: 50px;
  border: none;
  border-radius: 50%;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 20px;
  transition: all 0.3s ease;
}

.voice-btn {
  background: #f1f5f9;
  color: #64748b;
}

.voice-btn:hover {
  background: #e2e8f0;
}

.voice-btn.listening {
  background: #ef4444;
  color: white;
  animation: voicePulse 1s infinite;
}

.send-btn {
  background: linear-gradient(135deg, #667eea, #764ba2);
  color: white;
}

.send-btn:hover:not(:disabled) {
  transform: scale(1.05);
  box-shadow: 0 8px 25px rgba(102, 126, 234, 0.4);
}

.send-btn:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

/* Sidebar */
.features-sidebar,
.task-sidebar {
  background: #f8fafc;
  padding: 2rem;
  display: flex;
  flex-direction: column;
  gap: 2rem;
  overflow-y: auto;
}

.feature-card {
  background: white;
  border-radius: 12px;
  padding: 1.5rem;
  border: 1px solid #e2e8f0;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.05);
}

.feature-card h4 {
  margin: 0 0 1rem 0;
  font-size: 1.1rem;
  font-weight: 700;
  color: #1f2937;
  display: flex;
  align-items: center;
  gap: 0.5rem;
}

.quick-actions,
.task-examples {
  display: flex;
  flex-direction: column;
  gap: 0.75rem;
}

.quick-btn,
.example-btn {
  background: #f1f5f9;
  border: 1px solid #e2e8f0;
  color: #374151;
  padding: 0.75rem 1rem;
  border-radius: 8px;
  cursor: pointer;
  text-align: left;
  font-size: 0.9rem;
  transition: all 0.3s ease;
}

.quick-btn:hover,
.example-btn:hover {
  background: linear-gradient(135deg, #667eea, #764ba2);
  color: white;
  border-color: #667eea;
  transform: translateY(-2px);
}

.tips-list {
  display: flex;
  flex-direction: column;
  gap: 1rem;
}

.tip-item {
  display: flex;
  align-items: flex-start;
  gap: 0.75rem;
  font-size: 0.9rem;
  color: #6b7280;
  line-height: 1.4;
}

.tip-icon {
  font-size: 1.1rem;
  flex-shrink: 0;
  margin-top: 0.1rem;
}

/* Animations */
@keyframes messageSlide {
  from { opacity: 0; transform: translateY(20px); }
  to { opacity: 1; transform: translateY(0); }
}

@keyframes pulse {
  0%, 100% { opacity: 1; }
  50% { opacity: 0.5; }
}

@keyframes voicePulse {
  0%, 100% { transform: scale(1); }
  50% { transform: scale(1.1); }
}

/* Responsive Design */
@media (max-width: 1200px) {
  .section-grid {
    grid-template-columns: 1fr 300px;
  }
}

@media (max-width: 968px) {
  .section-grid {
    grid-template-columns: 1fr;
  }
  
  .features-sidebar,
  .task-sidebar {
    border-top: 1px solid #e2e8f0;
    max-height: 300px;
  }
  
  .chat-panel,
  .task-panel {
    border-right: none;
  }
}

@media (max-width: 768px) {
  .ai-tabs {
    flex-direction: column;
  }
  
  .tab-btn {
    flex-direction: row;
    justify-content: center;
    padding: 1rem 1.5rem;
  }
  
  .tab-text {
    font-size: 1rem;
  }
  
  .ai-container {
    padding: 0 0.5rem;
  }
  
  .header-controls {
    flex-direction: row;
    align-items: center;
  }
  
  .chat-header,
  .task-header {
    flex-direction: column;
    gap: 1rem;
    text-align: center;
  }
}

@media (max-width: 480px) {
  .messages-container {
    padding: 1rem;
  }
  
  .input-section {
    padding: 1rem;
  }
  
  .features-sidebar,
  .task-sidebar {
    padding: 1rem;
  }
  
  .voice-btn,
  .send-btn {
    width: 45px;
    height: 45px;
    font-size: 18px;
  }
}

  
  .ai-container {
    padding: 0 0.5rem;
  }
  
  .header-controls {
    flex-direction: row;
    align-items: center;
  }
  
  .chat-header,
  .task-header {
    flex-direction: column;
    gap: 1rem;
    text-align: center;
  }


@media (max-width: 480px) {
  .messages-container {
    padding: 1rem;
  }
  
  .input-section {
    padding: 1rem;
  }
  
  .features-sidebar,
  .task-sidebar {
    padding: 1rem;
  }
  
  .voice-btn,
  .send-btn {
    width: 45px;
    height: 45px;
    font-size: 18px;
  }
}

.control-btn.audio-enabled {
  background: rgba(16, 185, 129, 0.1);
  border-color: #10b981;
  color: #10b981;
}

.control-btn.audio-enabled:hover {
  background: #10b981;
  color: white;
}
</style>
