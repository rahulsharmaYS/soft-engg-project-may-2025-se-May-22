<template>
  <section class="terms-container">
    <div class="hero-section">
      <div class="hero-content">
        <h1 class="hero-title">
          <span class="title-icon">📜</span>
          Terms of Service
          <span class="legal-icon">⚖️</span>
        </h1>
        <p class="hero-subtitle">
          Clear, fair terms for a safe and educational learning environment
        </p>
        <div class="effective-date">
          <span class="date-icon">📅</span>
          Effective Date: August 20, 2025
        </div>
      </div>
      <div class="legal-illustration">
        <div class="scroll-icon">📜</div>
        <div class="handshake-icon">🤝</div>
        <div class="balance-icon">⚖️</div>
      </div>
    </div>

    <div class="content-section">
      <div class="welcome-card">
        <div class="welcome-header">
          <span class="welcome-icon">🎉</span>
          <h2>Welcome to Skillzy!</h2>
        </div>
        <p class="welcome-text">
          By using our platform, you agree to these terms of service. We've made them clear and straightforward
          because we believe in transparency. These terms help us create a safe, educational, and fun environment
          for all our learners.
        </p>
      </div>

      <div class="terms-sections">
        <div class="terms-card acceptable-use">
          <div class="card-header">
            <span class="card-icon">✅</span>
            <h3>Acceptable Use</h3>
          </div>
          <div class="card-content">
            <div class="use-grid">
              <div class="use-item positive">
                <span class="use-icon">🎓</span>
                <div>
                  <strong>Educational Purpose:</strong>
                  <p>Use Skillzy for learning and skill development</p>
                </div>
              </div>
              <div class="use-item positive">
                <span class="use-icon">🤝</span>
                <div>
                  <strong>Respectful Interaction:</strong>
                  <p>Be kind and respectful to teachers and peers</p>
                </div>
              </div>
              <div class="use-item positive">
                <span class="use-icon">🔒</span>
                <div>
                  <strong>Account Security:</strong>
                  <p>Keep your login credentials safe and private</p>
                </div>
              </div>
              <div class="use-item positive">
                <span class="use-icon">📚</span>
                <div>
                  <strong>Content Engagement:</strong>
                  <p>Actively participate in learning activities</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="terms-card prohibited-activities">
          <div class="card-header">
            <span class="card-icon">🚫</span>
            <h3>Prohibited Activities</h3>
          </div>
          <div class="card-content">
            <div class="prohibition-list">
              <div class="prohibition-item">
                <span class="prohibition-icon">⚠️</span>
                <div>
                  <strong>Hacking or System Abuse:</strong>
                  <p>Do not attempt to hack, exploit, or misuse the platform</p>
                </div>
              </div>
              <div class="prohibition-item">
                <span class="prohibition-icon">💬</span>
                <div>
                  <strong>Inappropriate Content:</strong>
                  <p>No offensive, harmful, or inappropriate messages or content</p>
                </div>
              </div>
              <div class="prohibition-item">
                <span class="prohibition-icon">👤</span>
                <div>
                  <strong>Account Sharing:</strong>
                  <p>Do not share your account or impersonate others</p>
                </div>
              </div>
              <div class="prohibition-item">
                <span class="prohibition-icon">📋</span>
                <div>
                  <strong>Content Misuse:</strong>
                  <p>Do not redistribute or commercialize platform content</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="terms-card content-usage">
          <div class="card-header">
            <span class="card-icon">📄</span>
            <h3>Content & Intellectual Property</h3>
          </div>
          <div class="card-content">
            <div class="content-rules">
              <div class="content-rule">
                <span class="rule-icon">🎯</span>
                <div>
                  <strong>Personal Learning Only:</strong>
                  <p>All content is for your personal educational use</p>
                </div>
              </div>
              <div class="content-rule">
                <span class="rule-icon">🔐</span>
                <div>
                  <strong>Copyright Protection:</strong>
                  <p>Our content is protected by intellectual property laws</p>
                </div>
              </div>
              <div class="content-rule">
                <span class="rule-icon">📤</span>
                <div>
                  <strong>No Redistribution:</strong>
                  <p>Don't share, sell, or redistribute our materials</p>
                </div>
              </div>
              <div class="content-rule">
                <span class="rule-icon">✨</span>
                <div>
                  <strong>User-Generated Content:</strong>
                  <p>You retain rights to your submissions while granting us usage rights</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="terms-card user-responsibilities">
          <div class="card-header">
            <span class="card-icon">👤</span>
            <h3>User Responsibilities</h3>
          </div>
          <div class="card-content">
            <div class="responsibility-grid">
              <div class="responsibility-item">
                <span class="resp-icon">📧</span>
                <h4>Accurate Information</h4>
                <p>Provide truthful and accurate account information</p>
              </div>
              <div class="responsibility-item">
                <span class="resp-icon">🔑</span>
                <h4>Account Security</h4>
                <p>Maintain the confidentiality of your password</p>
              </div>
              <div class="responsibility-item">
                <span class="resp-icon">👨‍👩‍👧‍👦</span>
                <h4>Parental Supervision</h4>
                <p>Parents should monitor their child's platform usage</p>
              </div>
              <div class="responsibility-item">
                <span class="resp-icon">📱</span>
                <h4>Device Responsibility</h4>
                <p>Ensure your device meets platform requirements</p>
              </div>
            </div>
          </div>
        </div>

        <div class="terms-card platform-policies">
          <div class="card-header">
            <span class="card-icon">🏛️</span>
            <h3>Platform Policies</h3>
          </div>
          <div class="card-content">
            <div class="policy-items">
              <div class="policy-item">
                <span class="policy-icon">🔄</span>
                <div>
                  <strong>Service Updates:</strong>
                  <p>We may update features, content, and terms as we improve the platform</p>
                </div>
              </div>
              <div class="policy-item">
                <span class="policy-icon">⏰</span>
                <div>
                  <strong>Service Availability:</strong>
                  <p>While we strive for 24/7 availability, maintenance may cause temporary downtime</p>
                </div>
              </div>
              <div class="policy-item">
                <span class="policy-icon">🎓</span>
                <div>
                  <strong>Educational Standards:</strong>
                  <p>All content meets educational standards for grades 3-8</p>
                </div>
              </div>
              <div class="policy-item">
                <span class="policy-icon">🛡️</span>
                <div>
                  <strong>Safety First:</strong>
                  <p>We prioritize student safety and maintain a kid-friendly environment</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="terms-card student-platform">
          <div class="card-header">
            <span class="card-icon">🎒</span>
            <h3>Student-Led Platform</h3>
          </div>
          <div class="card-content">
            <div class="student-info">
              <div class="student-badge">
                <span class="badge-icon">🎓</span>
                <div>
                  <strong>Built by Students</strong>
                  <p>Created by IIT Madras Data Science students</p>
                </div>
              </div>
              <div class="student-badge">
                <span class="badge-icon">💡</span>
                <div>
                  <strong>Continuous Learning</strong>
                  <p>We're learning and improving alongside you</p>
                </div>
              </div>
              <div class="student-badge">
                <span class="badge-icon">🤝</span>
                <div>
                  <strong>Community Support</strong>
                  <p>Your feedback helps us grow and improve</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="support-section">
        <div class="support-card">
          <div class="support-header">
            <span class="support-icon">🆘</span>
            <h3>Need Help or Have Questions?</h3>
          </div>
          <div class="support-content">
            <p>
              We're here to help! If you have questions about these terms or need support,
              don't hesitate to reach out to our friendly team.
            </p>
            <div class="support-methods">
              <div class="support-method">
                <span class="method-icon">💬</span>
                <div>
                  <strong>In-App Support:</strong>
                  <span>Use the help center in your dashboard</span>
                </div>
              </div>
              <div class="support-method">
                <span class="method-icon">📧</span>
                <div>
                  <strong>Email Support:</strong>
                  <span>support@skillzy.com</span>
                </div>
              </div>
            </div>
            <div class="thanks-message">
              <p><strong>Thanks for supporting our journey! 🚀</strong></p>
              <p>As a student-led platform, your understanding and support mean the world to us.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
     <footer class="footer">
      <div class="footer-content">
        <div class="footer-left">
          <h3>Skillzy</h3>
          <p>
            Empowering young minds with essential life skills through interactive
            learning, AI-powered assistance, and fun activities for ages 8–14.
          </p>
          <div class="social-icons">
          <a href="https://www.facebook.com/iitmadrasbsdegree/about/" target="_blank"><img src="https://cdn-icons-png.flaticon.com/512/733/733547.png" alt="Facebook" class="social-icon" /></a>
          <a href="https://github.com/rahulsharmaYS/soft-engg-project-may-2025-se-May-22" target="_blank"><img src="https://cdn-icons-png.flaticon.com/512/733/733609.png" alt="GitHub" class="social-icon" /></a>
          <a href="https://study.iitm.ac.in/ds/" target="_blank"><img src="https://cdn-icons-png.flaticon.com/512/2702/2702602.png" alt="Google" class="social-icon" /></a>
          <a href="https://www.instagram.com/iitmadras_bs/" target="_blank"><img src="https://cdn-icons-png.flaticon.com/512/733/733558.png" alt="Instagram" class="social-icon" /></a>
          </div>
        </div>

        <div class="footer-links">
          <h4>Quick Links</h4>
          <ul>
            <li><router-link to="/">Home</router-link></li>
            <li><router-link to="/about">About Us</router-link></li>
            <li><router-link to="/features">Features</router-link></li>
            <li><router-link to="/privacy">Privacy Policy</router-link></li>
            <li><router-link to="/terms">Terms of Service</router-link></li>
          </ul>
        </div>

        <div class="footer-contact">
          <h4>Contact Us</h4>
          <p>Dummy Email: <u>team22@seproject.com</u></p>
          <p>Phone: <u>+91 9560594522</u></p>
          <p>Address: <u>IIT Madras, SoftWare Engineering Course</u></p>
        </div>
      </div>
      <div class="footer-bottom">
        © 2025 Skillzy. Made with ❤️ for young learners.
      </div>
    </footer>
</template>

<style scoped>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap');
.footer {
  background: #7400b8;
  color: white;
  padding: 2rem 1rem 1rem;
}
.footer-content {
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
  gap: 2rem;
}
.footer-left,
.footer-links,
.footer-contact {
  flex: 1;
  min-width: 200px;
}
.footer h4 {
  margin-bottom: 1rem;
}
.footer-links ul {
  list-style: none;
  padding: 0;
}
.footer-links li {
  margin-bottom: 0.5rem;
}
.footer-links a {
  color: white;
  text-decoration: none;
}
.footer-links a:hover {
  text-decoration: underline;
}
.social-icons a {
  font-size: 1.5rem;
  margin-right: 0.5rem;
  color: white;
}
.footer-bottom {
  margin-top: 2rem;
  text-align: center;
  font-size: 0.85rem;
  border-top: 1px solid rgba(255, 255, 255, 0.2);
  padding-top: 1rem;
}
.social-icons {
  display: flex;
  justify-content: center;
  gap: 10px;
  margin-top: 30px;
}
.social-icon {
  width: 30px;
  height: 30px;
  transition: transform 0.3s;
  cursor: pointer;
}

.social-icon:hover {
  transform: scale(1.1);
}

.terms-container {
  font-family: 'Inter', sans-serif;
  background: linear-gradient(135deg, #7c3aed 0%, #6d28d9 50%, #5b21b6 100%);
  min-height: 100vh;
  position: relative;
  overflow: hidden;
}

/* Hero Section */
.hero-section {
  position: relative;
  padding: 4rem 2rem 2rem;
  display: flex;
  align-items: center;
  justify-content: space-between;
  max-width: 1200px;
  margin: 0 auto;
  color: white;
}

.hero-content {
  flex: 1;
  max-width: 600px;
}

.hero-title {
  font-size: clamp(2.5rem, 6vw, 4rem);
  font-weight: 800;
  margin-bottom: 1rem;
  background: linear-gradient(45deg, #fff, #f3e8ff, #e9d5ff);
  background-clip: text;
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  animation: titleShine 3s ease-in-out infinite;
}

@keyframes titleShine {
  0%, 100% { text-shadow: 0 4px 20px rgba(255, 255, 255, 0.3); }
  50% { text-shadow: 0 8px 30px rgba(255, 255, 255, 0.5); }
}

.title-icon, .legal-icon {
  display: inline-block;
  animation: swing 2s ease-in-out infinite;
}

.legal-icon {
  animation-delay: 1s;
}

@keyframes swing {
  0%, 100% { transform: rotate(0deg); }
  25% { transform: rotate(5deg); }
  75% { transform: rotate(-5deg); }
}

.hero-subtitle {
  font-size: 1.3rem;
  line-height: 1.6;
  color: rgba(255, 255, 255, 0.9);
  margin-bottom: 1rem;
}

.effective-date {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  background: rgba(255, 255, 255, 0.1);
  backdrop-filter: blur(10px);
  padding: 0.5rem 1rem;
  border-radius: 12px;
  font-size: 0.9rem;
  color: rgba(255, 255, 255, 0.8);
  width: fit-content;
}

.legal-illustration {
  flex: 1;
  display: flex;
  justify-content: center;
  align-items: center;
  position: relative;
  max-width: 300px;
}

.scroll-icon, .handshake-icon, .balance-icon {
  position: absolute;
  font-size: 4rem;
  animation: legalFloat 5s ease-in-out infinite;
}

.scroll-icon {
  animation-delay: 0s;
}

.handshake-icon {
  animation-delay: 1.5s;
  top: 20px;
  left: 20px;
  font-size: 3rem;
}

.balance-icon {
  animation-delay: 3s;
  bottom: 20px;
  right: 20px;
  font-size: 2.5rem;
}

@keyframes legalFloat {
  0%, 100% { transform: translateY(0px) rotate(0deg); }
  50% { transform: translateY(-12px) rotate(2deg); }
}

/* Content Section */
.content-section {
  padding: 2rem;
  max-width: 1200px;
  margin: 0 auto;
}

.welcome-card {
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(20px);
  border-radius: 24px;
  padding: 2.5rem;
  margin-bottom: 3rem;
  box-shadow: 0 20px 60px rgba(0, 0, 0, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.5);
  text-align: center;
}

.welcome-header {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 1rem;
  margin-bottom: 1.5rem;
}

.welcome-icon {
  font-size: 3rem;
}

.welcome-header h2 {
  font-size: 2rem;
  font-weight: 700;
  color: #1e293b;
  margin: 0;
}

.welcome-text {
  font-size: 1.1rem;
  line-height: 1.8;
  color: #475569;
}

/* Terms Sections */
.terms-sections {
  display: grid;
  gap: 2rem;
}

.terms-card {
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(20px);
  border-radius: 20px;
  padding: 2rem;
  box-shadow: 0 15px 45px rgba(0, 0, 0, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.5);
  transition: all 0.3s ease;
}

.terms-card:hover {
  transform: translateY(-5px);
  box-shadow: 0 25px 60px rgba(0, 0, 0, 0.15);
}

.card-header {
  display: flex;
  align-items: center;
  gap: 1rem;
  margin-bottom: 1.5rem;
}

.card-icon {
  font-size: 2.5rem;
  padding: 0.5rem;
  border-radius: 12px;
  background: linear-gradient(145deg, #f8fafc, #e2e8f0);
  box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
}

.card-header h3 {
  font-size: 1.5rem;
  font-weight: 700;
  color: #1e293b;
  margin: 0;
}

/* Use Grid */
.use-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 1.5rem;
}

.use-item {
  display: flex;
  align-items: flex-start;
  gap: 1rem;
  padding: 1.5rem;
  background: linear-gradient(145deg, #dcfce7, #bbf7d0);
  border-radius: 16px;
  border-left: 4px solid #10b981;
}

.use-icon {
  font-size: 1.8rem;
  flex-shrink: 0;
}

.use-item strong {
  display: block;
  color: #065f46;
  margin-bottom: 0.5rem;
  font-weight: 600;
}

.use-item p {
  color: #047857;
  margin: 0;
  font-size: 0.9rem;
  line-height: 1.4;
}

/* Prohibition List */
.prohibition-list {
  display: flex;
  flex-direction: column;
  gap: 1rem;
}

.prohibition-item {
  display: flex;
  align-items: flex-start;
  gap: 1rem;
  padding: 1.5rem;
  background: linear-gradient(145deg, #fee2e2, #fecaca);
  border-radius: 16px;
  border-left: 4px solid #ef4444;
}

.prohibition-icon {
  font-size: 1.8rem;
  flex-shrink: 0;
}

.prohibition-item strong {
  display: block;
  color: #7f1d1d;
  margin-bottom: 0.5rem;
  font-weight: 600;
}

.prohibition-item p {
  color: #991b1b;
  margin: 0;
  font-size: 0.9rem;
  line-height: 1.4;
}

/* Content Rules */
.content-rules {
  display: flex;
  flex-direction: column;
  gap: 1rem;
}

.content-rule {
  display: flex;
  align-items: flex-start;
  gap: 1rem;
  padding: 1.5rem;
  background: linear-gradient(145deg, #dbeafe, #bfdbfe);
  border-radius: 16px;
  border-left: 4px solid #3b82f6;
}

.rule-icon {
  font-size: 1.8rem;
  flex-shrink: 0;
}

.content-rule strong {
  display: block;
  color: #1e3a8a;
  margin-bottom: 0.5rem;
  font-weight: 600;
}

.content-rule p {
  color: #1d4ed8;
  margin: 0;
  font-size: 0.9rem;
  line-height: 1.4;
}

/* Responsibility Grid */
.responsibility-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
  gap: 1.5rem;
}

.responsibility-item {
  text-align: center;
  padding: 1.5rem;
  background: linear-gradient(145deg, #fef3c7, #fde68a);
  border-radius: 16px;
  transition: all 0.3s ease;
}

.responsibility-item:hover {
  transform: translateY(-3px);
  box-shadow: 0 8px 25px rgba(245, 158, 11, 0.2);
}

.resp-icon {
  font-size: 2.5rem;
  display: block;
  margin-bottom: 1rem;
}

.responsibility-item h4 {
  font-size: 1.1rem;
  font-weight: 600;
  color: #92400e;
  margin-bottom: 0.5rem;
}

.responsibility-item p {
  font-size: 0.9rem;
  color: #a16207;
  margin: 0;
  line-height: 1.4;
}

/* Policy Items */
.policy-items {
  display: flex;
  flex-direction: column;
  gap: 1rem;
}

.policy-item {
  display: flex;
  align-items: flex-start;
  gap: 1rem;
  padding: 1.5rem;
  background: linear-gradient(145deg, #e0e7ff, #c7d2fe);
  border-radius: 16px;
  border-left: 4px solid #6366f1;
}

.policy-icon {
  font-size: 1.8rem;
  flex-shrink: 0;
}

.policy-item strong {
  display: block;
  color: #312e81;
  margin-bottom: 0.5rem;
  font-weight: 600;
}

.policy-item p {
  color: #4338ca;
  margin: 0;
  font-size: 0.9rem;
  line-height: 1.4;
}

/* Student Info */
.student-info {
  display: flex;
  flex-direction: column;
  gap: 1rem;
}

.student-badge {
  display: flex;
  align-items: center;
  gap: 1rem;
  padding: 1.5rem;
  background: linear-gradient(145deg, #ecfdf5, #d1fae5);
  border-radius: 16px;
  border-left: 4px solid #10b981;
}

.badge-icon {
  font-size: 2rem;
  flex-shrink: 0;
}

.student-badge strong {
  display: block;
  font-size: 1.1rem;
  color: #065f46;
  margin-bottom: 0.2rem;
}

.student-badge p {
  font-size: 0.9rem;
  color: #047857;
  margin: 0;
}

/* Support Section */
.support-section {
  margin-top: 3rem;
}

.support-card {
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(20px);
  border-radius: 20px;
  padding: 2.5rem;
  text-align: center;
  box-shadow: 0 20px 60px rgba(0, 0, 0, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.5);
}

.support-header {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 1rem;
  margin-bottom: 1.5rem;
}

.support-icon {
  font-size: 3rem;
}

.support-header h3 {
  font-size: 2rem;
  font-weight: 700;
  color: #1e293b;
  margin: 0;
}

.support-content p {
  font-size: 1.1rem;
  line-height: 1.7;
  color: #475569;
  margin-bottom: 2rem;
}

.support-methods {
  display: flex;
  justify-content: center;
  gap: 2rem;
  margin-bottom: 2rem;
  flex-wrap: wrap;
}

.support-method {
  display: flex;
  align-items: center;
  gap: 0.8rem;
  background: linear-gradient(145deg, #e0f2fe, #bae6fd);
  padding: 1rem 1.5rem;
  border-radius: 12px;
  border-left: 4px solid #0ea5e9;
}

.method-icon {
  font-size: 1.5rem;
}

.support-method strong {
  display: block;
  color: #0c4a6e;
  margin-bottom: 0.2rem;
}

.support-method span {
  color: #0369a1;
  font-size: 0.9rem;
}

.thanks-message {
  background: linear-gradient(145deg, #fef3c7, #fde68a);
  padding: 1.5rem;
  border-radius: 16px;
  border-left: 4px solid #f59e0b;
  text-align: center;
}

.thanks-message p {
  color: #92400e;
  margin: 0.5rem 0;
  font-size: 1rem;
}

/* Responsive Design */
@media (max-width: 768px) {
  .hero-section {
    flex-direction: column;
    text-align: center;
    gap: 2rem;
  }
  
  .legal-illustration {
    max-width: 200px;
  }
  
  .content-section {
    padding: 1rem;
  }
  
  .terms-card,
  .welcome-card,
  .support-card {
    padding: 1.5rem;
  }
  
  .use-grid,
  .responsibility-grid {
    grid-template-columns: 1fr;
  }
  
  .support-methods {
    flex-direction: column;
    align-items: center;
  }
}

@media (max-width: 480px) {
  .hero-title {
    font-size: 2rem;
  }
  
  .card-header {
    flex-direction: column;
    text-align: center;
    gap: 0.5rem;
  }
  
  .use-item,
  .prohibition-item,
  .content-rule,
  .policy-item {
    flex-direction: column;
    text-align: center;
  }
}
</style>
