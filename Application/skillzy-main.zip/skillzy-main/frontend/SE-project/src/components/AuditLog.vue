<!-- Admin Audit logs -->
<template>
  <div class="audit">
    <h3>Audit Logs</h3>
    <ul>
      <li v-for="log in logs" :key="log.text">
        <span>{{ log.time }}</span> - {{ log.text }}
      </li>
    </ul>
  </div>
</template>

<script setup>
const logs = [
  { time: '10:05', text: 'User John updated profile' },
  { time: '11:10', text: 'Teacher A removed comment' },
  { time: '12:00', text: 'System config changed' }
]
</script>

<style scoped>
.audit {
  background: var(--card);
    color: var(--text);
  padding: 1rem;
  border-radius: var(--card-radius);
  box-shadow: var(--shadow);
  width: 100%;
  max-width: 400px;
}
ul {
  list-style: none;
  padding: 0;
}
li {
  margin-bottom: 0.5rem;
  font-size: 0.95rem;
}
</style>
