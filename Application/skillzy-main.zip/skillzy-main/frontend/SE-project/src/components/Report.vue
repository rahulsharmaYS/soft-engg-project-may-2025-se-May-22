<template>
  <div>
    <button @click="openModal" class="report-button">
      📝 Report an Issue
    </button>
    <teleport to="body">
      <div v-if="showModal" class="modal-overlay">
        <div class="modal">
          <h2 class="modal-title">Submit a Report</h2>

          <form @submit.prevent="submitReport" class="report-form">
            <div class="form-group">
              <label for="subject">Subject</label>
              <input id="subject" v-model="form.subject" type="text" required />
            </div>

            <div class="form-group">
              <label for="type">Type of Issue</label>
              <select id="type" v-model="form.type" required>
                <option value="" disabled>Select type</option>
                <option value="technical">Technical</option>
                <option value="behavioral">Behavioral</option>
                <option value="other">Other</option>
              </select>
            </div>

            <div class="form-group">
              <label for="reportedUsername">Reported Username <strong>(Kindly provide the exact username!)</strong></label>
              <input id="reportedUsername" v-model="form.reportedUsername" type="text" required />
            </div>

            <div class="form-group">
              <label for="message">Message</label>
              <textarea id="message" v-model="form.message" rows="4" required
                placeholder="Describe the issue in detail..."></textarea>
            </div>

            <!-- file upload div screenshot should be conveted in text format for db (use any encoding method) -->
            <div class="form-group">
              <label for="screenshot">Upload Screenshot (optional)</label>
              <input id="screenshot" type="file" @change="handleFileUpload" accept="image/*" />
            </div>

            <div class="form-actions">
              <button type="submit" class="submit-btn">Submit</button>
              <button type="button" class="cancel-btn" @click="closeModal">Cancel</button>
            </div>
          </form>
        </div>
      </div>
    </teleport>
  </div>
</template>
<script setup>
import { ref, computed } from 'vue'
import api from '../api'
import { store } from '@/store'

const showModal = ref(false)
const isStudentView = computed(() => store.user?.role === 'student')

const form = ref({
  subject: '',
  type: '',
  reportedUsername: '',
  message: '',
  screenshot: ''
})

const openModal = () => {
  showModal.value = true
}

const closeModal = () => {
  showModal.value = false
  form.value = {
    subject: '',
    type: '',
    reportedUsername: '',
    message: '',
    screenshot: ''
  }
}

// ✅ Converts image to base64 string
const handleFileUpload = (event) => {
  const file = event.target.files[0]
  if (!file) return

  // ✅ Check file type to prevent PDFs or other non-image files
  if (!file.type.startsWith('image/')) {
    alert('Only image files are allowed (JPG, PNG, etc.).')
    event.target.value = ''
    return
  }

  const reader = new FileReader()
  reader.onload = () => {
    form.value.screenshot = reader.result // base64 string
  }
  reader.readAsDataURL(file)
}

const submitReport = async () => {
  if (!store.userId) {
    alert('User not logged in.')
    return
  }

  const payload = {
    title: `${form.value.subject} - ${form.value.type}`,
    content: `Reported User: ${form.value.reportedUsername}\n\n${form.value.message}`,
    screenshot: form.value.screenshot // base64 string here
  }

  try {
    let endpoint;
    console.log(`StudentView: ${isStudentView.value}`)
    if (isStudentView.value) {
      endpoint = `/student/${store.userId}/reports`;
    } else {
      endpoint = `/parent/${store.userId}/reports`;
    }

    const { data } = await api.post(endpoint, payload, {
      headers: {
        Authorization: `Bearer ${store.token}`
      }
    });
    alert(data.message)
    closeModal()
  } catch (err) {
    console.error('Error submitting report:', err)
    alert(err.response?.data?.detail || 'Something went wrong while submitting the report.')
  }
}
</script>

<style scoped>
/* Fonts & Base */
:root {
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}

button,
input,
select,
textarea {
  font-family: inherit;
}

/* Report Button */
.report-button {
  background-color: #0d6efd;
  color: #fff;
  padding: 10px 18px;
  border: none;
  border-radius: 6px;
  font-size: 15px;
  cursor: pointer;
  transition: background-color 0.3s ease;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

.report-button:hover {
  background-color: #084dce;
}

/* Modal */
.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(33, 33, 33, 0.65);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 2147483647 !important;
}

.modal {
  background-color: #fff;
  padding: 30px;
  border-radius: 10px;
  width: 100%;
  max-width: 500px;
  box-shadow: 0 8px 30px rgba(0, 0, 0, 0.2);
  animation: fadeIn 0.3s ease-in-out;
}

@keyframes fadeIn {
  from {
    transform: translateY(-20px);
    opacity: 0;
  }

  to {
    transform: translateY(0px);
    opacity: 1;
  }
}

/* Modal Title */
.modal-title {
  margin-bottom: 20px;
  font-size: 22px;
  font-weight: 600;
  color: #333;
}

/* Form */
.report-form {
  display: flex;
  flex-direction: column;
}

.form-group {
  margin-bottom: 16px;
}

.form-group label {
  display: block;
  font-weight: 600;
  margin-bottom: 6px;
  color: #333;
}

.form-group input,
.form-group select,
.form-group textarea {
  width: 100%;
  padding: 10px 12px;
  border-radius: 6px;
  border: 1px solid #ccc;
  font-size: 14px;
  transition: border-color 0.2s;
}

.form-group input:focus,
.form-group select:focus,
.form-group textarea:focus {
  border-color: #0d6efd;
  outline: none;
  box-shadow: 0 0 0 2px rgba(13, 110, 253, 0.2);
}

/* Form Buttons */
.form-actions {
  display: flex;
  justify-content: flex-end;
  gap: 12px;
  margin-top: 10px;
}

.submit-btn {
  background-color: #198754;
  color: white;
  border: none;
  padding: 10px 16px;
  border-radius: 6px;
  cursor: pointer;
  transition: background-color 0.3s ease;
}

.submit-btn:hover {
  background-color: #157347;
}

.cancel-btn {
  background-color: #dee2e6;
  color: #333;
  border: none;
  padding: 10px 16px;
  border-radius: 6px;
  cursor: pointer;
  transition: background-color 0.3s ease;
}

.cancel-btn:hover {
  background-color: #cfd4d9;
}
</style>
