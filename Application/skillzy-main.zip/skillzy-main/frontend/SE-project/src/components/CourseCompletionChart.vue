<template>
  <div class="chart-container" ref="chartContainer">
    <h3>Course Completion Rates</h3>
    <canvas ref="courseCompletionCanvas"></canvas>
  </div>
</template>

<script setup>
import { ref, onMounted, watch, nextTick } from 'vue';
import Chart from 'chart.js/auto';
import { store } from '../store.js';
import axios from 'axios';

const props = defineProps({
  teacherId: Number,
});

let courseCompletionChart = null;
const chartContainer = ref(null);
const courseCompletionCanvas = ref(null);

const createChart = async () => {
  if (courseCompletionChart) courseCompletionChart.destroy();
  if (!chartContainer.value || !courseCompletionCanvas.value) return;

  // Fetch backend data for course completion
  try {
    const res = await axios.get(`/teacher/${props.teacherId}/dashboard`);
    const completionPercent = res.data.summary.course_completion_percentage;

    // You can replace the labels and colors with your real course data or keep generic here
    const labels = ['Time Management', 'Communication', 'Health & Wellness', 'Decision Making', 'Financial Literacy'];
    
    // Since backend returns one overall percentage, let's apply it uniformly or
    // alternatively use mock per-course completion rates (replace with backend data when ready)
    const data = labels.map(() => completionPercent);

    courseCompletionChart = new Chart(courseCompletionCanvas.value, {
      type: 'bar',
      data: {
        labels,
        datasets: [{
          label: 'Completion Rate (%)',
          data,
          backgroundColor: [
            'rgba(59, 130, 246, 0.7)',
            'rgba(132, 204, 22, 0.7)',
            'rgba(249, 115, 22, 0.7)',
            'rgba(239, 68, 68, 0.7)',
            'rgba(168, 85, 247, 0.7)'
          ],
        }],
      },
      options: {
        indexAxis: 'y',
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: {
          x: { ticks: { color: getComputedStyle(chartContainer.value).getPropertyValue('--text').trim() }, grid: { color: store.isDarkMode ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.1)' } },
          y: { ticks: { color: getComputedStyle(chartContainer.value).getPropertyValue('--text').trim() }, grid: { color: store.isDarkMode ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.1)' } }
        },
      },
    });

  } catch (error) {
    console.error('Failed to load course completion:', error);
  }
};

onMounted(async () => {
  await nextTick();
  createChart();
});

watch(() => [store.isDarkMode, props.teacherId], async () => {
  await nextTick();
  createChart();
});
</script>

<style scoped>
.chart-container {
  background: var(--card);
  padding: 1rem;
  border-radius: var(--card-radius);
  box-shadow: var(--shadow);
  width: 90%;
  height: 400px;
}
.chart-container canvas {
  width: 100% !important;
  height: 85% !important;
}
</style>
