<template>
  <div class="chart" ref="chartContainer">
    <canvas id="analyticsChart"></canvas>
  </div>
</template>

<script setup>
import { onMounted, watch, nextTick, ref } from 'vue';
import Chart from 'chart.js/auto';
import { store } from '../store.js';

let analyticsChart = null;
const chartContainer = ref(null);

const createChart = () => {
  if (analyticsChart) analyticsChart.destroy();
  if (!chartContainer.value) return;

  const textColor = getComputedStyle(chartContainer.value).getPropertyValue('--text').trim();
  analyticsChart = new Chart(document.getElementById('analyticsChart'), {
    type: 'bar',
    data: {
      labels: ['Time Management', 'Communication', 'Health', 'Decision Making'],
      datasets: [{
        label: 'Student Engagement Hours',
        data: [250, 180, 210, 150],
        backgroundColor: '#3b82f6'
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        title: { display: true, text: 'Skill Module Engagement', color: textColor },
        legend: { labels: { color: textColor } }
      },
      scales: {
        x: { ticks: { color: textColor }, grid: { color: store.darkMode ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.1)' } },
        y: { ticks: { color: textColor }, grid: { color: store.darkMode ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.1)' } }
      }
    }
  });
};

onMounted(async () => {
  await nextTick();
  createChart();
});
watch(() => store.darkMode, async () => {
  await nextTick();
  createChart();
});
</script>

<style scoped>
.chart {
  background: var(--card);
  padding: 1rem;
  border-radius: var(--card-radius);
  box-shadow: var(--shadow);
  width: 100%;
  height: 400px;
}
</style>