<template>
  <div class="user-management-page">
    <main class="main">
      <!-- <Header title="User Management" subtitle="Manage users, view profiles, and control access" /> -->
      <header class="page-header" style="color: whitesmoke;">
        <h1>User Management</h1>
        <p>Manage users, view profiles, and control access</p>
      </header>

      <section class="overview-metrics-grid">
        <MetricCard icon="👥" :value="totalUsers" label="Total Users" subLabel="Platform-wide" iconBg="linear-gradient(135deg, #6a11cb 0%, #2575fc 100%)" />
        <MetricCard icon="🔥" :value="totalActiveUsers" label="Active Users" subLabel="Currently online" iconBg="linear-gradient(135deg, #a020f0 0%, #f72585 100%)" />
        <MetricCard icon="🚫" :value="totalBlockedUsers" label="Total Blocked Users" subLabel="Temporarily Inactive" iconBg="linear-gradient(135deg, #FF6B6B 0%, #FFD166 100%)" />
        <!-- <MetricCard icon="👑" :value="totalAdmins" label="Admins" subLabel="System Staff" /> -->
      </section>



      <section class="user-directory-card">
        <div class="card-header">
          <h3>User Directory</h3>
          <div class="controls">
            <input
              v-model="searchQuery"
              placeholder="Search by email or user ID"
              class="search-input"
            />
            <select v-model="roleFilter" class="filter-select">
              <option value="">All Roles</option>
              <option value="student">Student</option>
              <option value="teacher">Teacher</option>
              <option value="parent">Parent</option>
              <option value="admin">Admin</option>
            </select>
          </div>
        </div>

        <table class="user-table">
          <thead>
            <tr>
              <!-- <th>Profile</th> -->
              <th>User ID</th>
              <th>Email</th>
              <th>Role</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="user in paginatedUsers" :key="user.id">
              <!-- <td>
                <template v-if="user.role === 'teacher' && user.profilePic && !user.profilePic.includes('pravatar')">
                  <img
                    :src="user.profilePic"
                    class="profile-pic"
                    @click="openProfile(user)"
                    title="Click to view profile"
                  />
                </template>
                <span class="user-name-cell">{{ user.full_name }}</span>
              </td> -->
              <td>{{ user.id }}</td>
              <td>{{ user.email }}</td>
              <td><span :class="['role-pill', user.role]">{{ user.role }}</span></td>
              <td>
                <span
                  :class="{
                    status: true,
                    blocked: user.blocked,
                    active: !user.blocked
                  }"
                >
                  {{ user.blocked ? 'Blocked' : 'Active' }}
                </span>
              </td>

              <td>
                <button @click="openProfile(user)" class="action-btn edit-btn">
                  View
                </button>
                <button
                  v-if="!user.blocked"
                  @click="toggleBlock(user)"
                  class="action-btn warning-btn"
                >
                  Block
                </button>
                <button
                  v-else
                  @click="toggleBlock(user)"
                  class="action-btn success-btn"
                >
                  Unblock
                </button>
              </td>
            </tr>
          </tbody>
        </table>

        <div class="table-footer">
          <div class="results-summary">
            Showing {{ (currentPage - 1) * itemsPerPage + 1 }} - {{ Math.min(currentPage * itemsPerPage, filteredUsers.length) }} of {{ filteredUsers.length }} results
          </div>
          <div class="pagination">
            <button @click="prevPage" :disabled="currentPage === 1">Previous</button>
            <button
              v-for="page in totalPages"
              :key="page"
              @click="goToPage(page)"
              :class="{ active: currentPage === page }"
            >
              {{ page }}
            </button>
            <button @click="nextPage" :disabled="currentPage === totalPages">Next</button>
          </div>
        </div>
      </section>

      <div v-if="selectedUser" class="modal-overlay" @click.self="closeModal">
        <div class="modal">
          <div class="modal-header">
            <h3>User Profile</h3>
            <button class="close-btn" @click="closeModal">✖</button>
          </div>
          <div class="modal-body" style="text-align: left !important;">
            <!-- <template v-if="selectedUser && selectedUser.role === 'teacher' && selectedUser.profilePic && !selectedUser.profilePic.includes('pravatar')">
              <img :src="selectedUser.profilePic" class="modal-pic" />
            </template> -->
            <p><strong>ID:</strong> {{ selectedUser.id }}</p>
            <p><strong>Email:</strong> {{ selectedUser.email }}</p>
            <p><strong>Role:</strong> {{ selectedUser.role }}</p>
            <p><strong>Status:</strong> {{ selectedUser.blocked ? 'Blocked' : 'Active' }}</p>
            <p><strong>Joined:</strong> {{ selectedUser.joined }}</p>
            <p><strong>Last Activity:</strong> {{ selectedUser.activity }}</p>
          </div>
        </div>
      </div>
    </main>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import api from '../api'
import Header from './Header.vue'
import MetricCard from './MetricCard.vue'

const searchQuery = ref('')
const roleFilter = ref('')
const selectedUser = ref(null)
const users = ref([])

const currentPage = ref(1)
const itemsPerPage = 10

const totalUsers = ref(0)
const totalActiveUsers = ref(0)
const totalBlockedUsers = ref(0)
const totalAdmins = ref(0)

onMounted(async () => {
  try {
    const response = await api.get('/admin/dashboard')
    const backendBase = 'http://localhost:8000';
    users.value = response.data.users.map(u => {
      let profilePic = u.profile_picture;
      if (profilePic) {
        // Replace backslashes with forward slashes
        profilePic = profilePic.replace(/\\/g, '/');
        if (!/^https?:\/\//.test(profilePic)) {
          profilePic = backendBase + (profilePic.startsWith('/') ? '' : '/') + profilePic;
        }
      }
      return {
        id: u.id,
        email: u.email,
        full_name: u.full_name,
        role: u.role_name,
        blocked: u.user_status === 'inactive' || u.user_status === 'suspended',
        profilePic: profilePic || `https://i.pravatar.cc/100?u=${u.id}`,
        joined: u.created_at?.slice(0, 10),
        activity: 'Active'
      }
    })
    totalUsers.value = users.value.length
    totalActiveUsers.value = users.value.filter(u => !u.blocked).length
    totalBlockedUsers.value = users.value.filter(u => u.blocked).length
    totalAdmins.value = users.value.filter(u => u.role === 'admin').length
  } catch (error) {
    console.error('Failed to load users:', error)
  }
})

const filteredUsers = computed(() => {
  const query = searchQuery.value.toLowerCase()

  return users.value.filter(user => {
    const matchesQuery =
      user.email.toLowerCase().includes(query) ||
      user.id.toString().toLowerCase().includes(query) ||
      user.full_name.toLowerCase().includes(query)

    const matchesRole = roleFilter.value ? user.role === roleFilter.value : true

    return matchesQuery && matchesRole
  })
})

const totalPages = computed(() => Math.ceil(filteredUsers.value.length / itemsPerPage))
const paginatedUsers = computed(() => {
  const start = (currentPage.value - 1) * itemsPerPage
  const end = start + itemsPerPage
  return filteredUsers.value.slice(start, end)
})

function goToPage(page) {
  if (page >= 1 && page <= totalPages.value) {
    currentPage.value = page
  }
}

function nextPage() {
  if (currentPage.value < totalPages.value) {
    currentPage.value++
  }
}

function prevPage() {
  if (currentPage.value > 1) {
    currentPage.value--
  }
}

async function toggleBlock(user) {
  try {
    if (user.blocked) {
      await api.put(`/admin/user/${user.id}/unblock`)
      user.blocked = false
    } else {
      await api.put(`/admin/user/${user.id}/block`)
      user.blocked = true
    }
    totalActiveUsers.value = users.value.filter(u => !u.blocked).length
    totalBlockedUsers.value = users.value.filter(u => u.blocked).length
  } catch (err) {
    console.error('Error updating user status:', err)
    alert(`Failed to update user status for ${user.full_name}. Please try again.`)
  }
}

function openProfile(user) {
  selectedUser.value = user
}

function closeModal() {
  selectedUser.value = null
}
</script>

<style scoped>
.user-management-page {
  /* No background here */
}

.main {
  flex: 1;
  padding: 2rem;
  color: var(--text);
  background: linear-gradient(135deg, #427eff, #b72eff);

  width: 100%;
  min-height: calc(100vh - 2rem); /* Adjust for top padding */
  box-sizing: border-box;
  position: relative;
  z-index: 1;
}

.overview-metrics-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
  gap: 1.5rem;
  margin-bottom: 2rem;
  background: transparent;
  padding: 1 rem;
  border-radius: 12px;
}

.user-directory-card {
  background-color: var(--card);
  padding: 1.5rem 2rem;
  border-radius: 12px;
  box-shadow: var(--shadow);
  border: 1px solid var(--border);
}

.user-directory-card .card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 1.5rem;
  flex-wrap: wrap;
  gap: 1rem;
}

.user-directory-card h3 {
  margin: 0;
  font-size: 1.5rem;
  font-weight: 600;
  color: var(--text);
}

.user-directory-card .controls {
  display: flex;
  gap: 1rem;
  align-items: center;
}

.search-input,
.filter-select {
  padding: 0.75rem 1rem;
  font-size: 0.95rem;
  border-radius: 8px;
  border: 1px solid var(--border);
  background-color: var(--bg);
  color: var(--text);
  transition: border-color 0.2s ease, box-shadow 0.2s ease;
}

.search-input:focus,
.filter-select:focus {
  outline: none;
  border-color: var(--primary);
  box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.2);
}

.user-table {
  width: 100%;
  border-collapse: collapse;
  background: var(--card);
  color: var(--text);
}
.user-table th,
.user-table td {
  padding: 0.85rem 1rem;
  text-align: left;
  border-bottom: 1px solid var(--border);
}
.user-table th {
  font-weight: 600;
  color: var(--text-secondary);
  font-size: 0.9rem;
  text-transform: uppercase;
}

.profile-pic {
  width: 36px;
  height: 36px;
  border-radius: 50%;
  cursor: pointer;
  object-fit: cover;
  margin-right: 0.75rem;
}
.user-name-cell {
  display: flex;
  align-items: center;
  font-weight: 500;
}

.role-pill {
  display: inline-block;
  padding: 3px 10px;
  border-radius: 15px;
  font-size: 0.75rem;
  font-weight: 600;
  text-transform: capitalize;
  text-align: center;
  white-space: nowrap;
}

.role-pill.student { background-color: #dcfce7; color: #166534; }
.role-pill.teacher { background-color: #e0f2fe; color: #0369a1; }
.role-pill.parent { background-color: #fefce8; color: #854d0e; }
.role-pill.admin { background-color: #f3e8ff; color: #6d28d9; }


.status {
  display: inline-block;
  padding: 3px 10px;
  border-radius: 15px;
  font-size: 0.75rem;
  font-weight: 600;
  text-align: center;
  white-space: nowrap;
}

.status.blocked {
  background-color: #fff3cd;
  color: #92400e;
}

.status.active {
  background-color: #d1fae5;
  color: #065f46;
}

td .action-btn {
  margin-right: 0.5rem;
  padding: 0.5rem 0.9rem;
  font-size: 0.8rem;
  border: none;
  border-radius: 6px;
  cursor: pointer;
  transition: all 0.2s ease;
  white-space: nowrap;
}
.action-btn.edit-btn {
  background-color: #6366f1; /* Changed to a distinct purple for better visibility */
  color: white; 
}



.action-btn.edit-btn:hover {
  background-color: #4f46e5; /* Slightly darker shade on hover for the new edit button color */
  box-shadow: 0 2px 8px rgba(99, 102, 241, 0.3); /* Adjust shadow color to match button */
}

.action-btn.warning-btn {
  background-color: #f97316;
  color: white;
}
.action-btn.warning-btn:hover {
  background-color: #ea580c;
  box-shadow: 0 2px 8px rgba(249, 115, 22, 0.3);
}

.action-btn.success-btn {
  background-color: #22c55e;
  color: white;
}
.action-btn.success-btn:hover {
  background-color: #16a34a;
  box-shadow: 0 2px 8px rgba(34, 197, 94, 0.3);
}

.table-footer {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding-top: 1.5rem;
  border-top: 1px solid var(--border);
  margin-top: 1.5rem;
  flex-wrap: wrap;
  gap: 1rem;
}
.results-summary {
  font-size: 0.9rem;
  color: var(--text-secondary);
}
.pagination {
  display: flex;
  gap: 0.5rem;
}
.pagination button {
  padding: 0.5rem 1rem;
  border: 1px solid var(--border);
  border-radius: 6px;
  background-color: var(--bg);
  color: var(--text);
  cursor: pointer;
  transition: all 0.2s ease;
  font-weight: 500;
}
.pagination button:hover:not(:disabled),
.pagination button.active {
  background-color: var(--primary);
  color: white;
  border-color: var(--primary);
}
.pagination button:disabled {
  opacity: 0.6;
  cursor: not-allowed;
}

.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.5);
  z-index: 1000;
  display: flex;
  align-items: center;
  justify-content: center;
}
.modal {
  background: var(--card);
  padding: 2rem;
  border-radius: 8px;
  width: 90%;
  max-width: 400px;
  animation: fadeIn 0.3s ease;
  box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
  color: var(--text);
}
.modal-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 1rem;
}
.close-btn {
  background: transparent;
  border: none;
  font-size: 1.2rem;
  cursor: pointer;
  color: var(--text);
}
.modal-body {
  text-align: center;
}
.modal-pic {
  width: 80px;
  height: 80px;
  border-radius: 50%;
  margin-bottom: 1rem;
}
@keyframes fadeIn {
  from {
    opacity: 0;
    transform: scale(0.96);
  }
  to {
    opacity: 1;
    transform: scale(1);
  }
}

@media (max-width: 900px) {
  .user-directory-card .card-header {
    flex-direction: column;
    align-items: flex-start;
  }
  .user-directory-card .controls {
    width: 100%;
    justify-content: space-between;
  }
  .search-input, .filter-select {
    flex-grow: 1;
  }
  .user-table th, .user-table td {
    padding: 0.6rem 0.8rem;
    font-size: 0.9rem;
  }
  .action-btn {
    padding: 0.4rem 0.7rem;
    font-size: 0.75rem;
  }
}

@media (max-width: 600px) {
  .main {
    padding: 1rem;
  }
  .overview-metrics-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
    gap: 1.5rem;
    margin-bottom: 2rem;
    background: #000;
    padding: 1.5rem;
    border-radius: 12px;
  }
  .user-directory-card {
    padding: 1rem;
  }
  .user-directory-card .controls {
    flex-direction: column;
    gap: 0.8rem;
  }
  .user-table {
    font-size: 0.85rem;
  }
  .user-table th, .user-table td {
    padding: 0.5rem;
  }
  .profile-pic {
    width: 30px;
    height: 30px;
    margin-right: 0.5rem;
  }
  .user-name-cell {
    font-size: 0.9rem;
  }
  .role-pill, .status {
    padding: 2px 8px;
    font-size: 0.7rem;
  }
  .action-btn {
    padding: 0.3rem 0.6rem;
    font-size: 0.7rem;
    margin-right: 0.3rem;
  }
  .table-footer {
    flex-direction: column;
    align-items: center;
    gap: 0.8rem;
  }
}
</style>