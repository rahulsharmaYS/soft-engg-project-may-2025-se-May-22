<template>
  <div class="panel">
    <h3 class="text-lg font-semibold mb-2">📋 Upcoming Tasks and Assignments</h3>
    <p class="text-sm text-gray-600 mb-4">
      🗓️ Today: {{ today }} | 🕒 {{ currentTime }}
    </p>

    <div v-if="upcomingTasksAndAssignments.length > 0">
      <div class="task-table">
        <div class="task-header">
          <span>Time</span>
          <span>Title</span>
          <span>Status</span>
        </div>
        <div
          v-for="event in upcomingTasksAndAssignments"
          :key="event.id"
          class="task-row"
        >
          <span>
            {{ event.time }}
            <br />
            <small class="time-left">{{ event.timeLeft }}</small>
          </span>
          <span>{{ event.title }}</span>
          <span :class="['status-badge', event.status]">{{ event.status }}</span>
        </div>
      </div>
    </div>

    <div v-else class="text-sm text-gray-500 mt-4">No tasks available</div>

    <div class="see-more">
      <a :href="`/student/${studentId}/calendar`" class="see-more-link">
        See more...
      </a>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRoute } from 'vue-router'
import api from '../api'

const route = useRoute()
const studentId = route.params.id

const today = ref('')
const currentTime = ref('')
const upcomingTasksAndAssignments = ref([])

function updateDateTime() {
  const now = new Date()
  today.value = now.toLocaleDateString(undefined, {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  })
  currentTime.value = now.toLocaleTimeString(undefined, {
    hour: '2-digit',
    minute: '2-digit',
  })
}

function getTimeLeft(dueDate) {
  const now = new Date()
  const due = new Date(dueDate)
  const diffMs = due - now
  const absDiff = Math.abs(diffMs)
  const minutes = Math.floor(absDiff / 60000)
  const hours = Math.floor(absDiff / (1000 * 60 * 60))
  const days = Math.floor(absDiff / (1000 * 60 * 60 * 24))

  if (diffMs > 0) {
    if (minutes < 60) return `${minutes} min${minutes !== 1 ? 's' : ''} left`
    if (hours < 24) return `${hours} hour${hours !== 1 ? 's' : ''} left`
    return `${days} day${days !== 1 ? 's' : ''} left`
  } else {
    if (minutes < 60) return `${minutes} min${minutes !== 1 ? 's' : ''} ago`
    if (hours < 24) return `${hours} hour${hours !== 1 ? 's' : ''} ago`
    return `${days} day${days !== 1 ? 's' : ''} ago`
  }
}

async function fetchTasks() {
  try {
    const res = await api.get(`/student/${studentId}/calendar`)
    upcomingTasksAndAssignments.value = res.data.map((item, idx) => {
      const due = new Date(item.due_date)
      return {
        id: idx + 1,
        time: due.toLocaleTimeString(undefined, {
          hour: '2-digit',
          minute: '2-digit',
        }),
        timeLeft: getTimeLeft(item.due_date),
        title: item.title,
        status: item.status.toLowerCase(),
      }
    })
  } catch (err) {
    console.error('Failed to fetch tasks:', err)
  }
}

onMounted(() => {
  updateDateTime()
  setInterval(updateDateTime, 1000)
  fetchTasks()
})
</script>

<style scoped>
.panel {
  background: var(--card);
  color: var(--text);
  padding: 1rem;
  border-radius: var(--card-radius);
  box-shadow: var(--shadow);
  font-size: 0.95rem;
}

/* Task table structure */
.task-table {
  display: flex;
  flex-direction: column;
}

.task-header {
  display: grid;
  grid-template-columns: 80px 1fr 100px;
  font-weight: bold;
  padding: 0.5rem 0;
  border-bottom: 1px solid #ddd;
  color: #555;
}

.task-row {
  display: grid;
  grid-template-columns: 80px 1fr 100px;
  padding: 0.4rem 0;
  border-bottom: 1px dashed #eee;
  align-items: center;
}

/* Status colors */
.status-badge {
  padding: 2px 8px;
  border-radius: 12px;
  font-size: 0.75rem;
  text-transform: capitalize;
  font-weight: 600;
  text-align: center;
  width: fit-content;
}

.status-badge.pending {
  background-color: #fef3c7;
  color: #92400e;
}

.status-badge.completed {
  background-color: #d1fae5;
  color: #065f46;
}

.status-badge.overdue {
  background-color: #fee2e2;
  color: #991b1b;
}

/* See more link styling */
.see-more {
  margin-top: 0.75rem;
  text-align: right;
}

.see-more-link {
  font-size: 0.9em;
  color: var(--primary, #0d6efd);
  text-decoration: underline;
}
</style>
