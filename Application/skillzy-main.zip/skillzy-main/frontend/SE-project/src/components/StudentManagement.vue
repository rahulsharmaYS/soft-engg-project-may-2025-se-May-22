<template>
  <div class="student-management-page">
    <main class="main">
      <!-- <Header title="My Students ☀️" subtitle="Manage your students and view their progress" /> -->

      <header style="color: whitesmoke;">
        <h1>My Students ☀️</h1>
        <p>Manage your students and view their progress</p>
      </header>
      <div class="controls-container">
        <input
          v-model="searchQuery"
          type="text"
          placeholder="Search students by name or ID..."
          class="search-input"
        />
        <select v-model="statusFilter" class="filter-select">
          <option value="">All Status</option>
          <option value="active">Active</option>
          <option value="inactive">Inactive</option>
          <option value="blocked">Blocked</option>
        </select>
      </div>

      <div class="student-cards-grid">
        <div class="student-card" v-for="student in paginatedStudents" :key="student.id">
          <div class="student-header">
            <div class="student-avatar-initials" :style="{ backgroundColor: getAvatarBg(student.id) }">
              {{ getInitials(student.name) }}
            </div>
            <div class="student-info">
              <span class="student-name">{{ student.name }}</span>
              <span class="student-id">{{ student.id }}</span>
            </div>
            <span :class="['status-pill', student.status.toLowerCase()]">{{ student.status }}</span>
          </div>

          <div class="overall-progress">
            <span class="progress-label">Overall Progress</span>
            <div class="progress-bar-container">
              <div class="progress-bar" :style="{ width: student.overallProgress + '%' }"></div>
            </div>
            <span class="progress-percentage">{{ student.overallProgress }}%</span>
          </div>

          <div class="details-row">
            <div class="detail-item">
              <span class="icon">📝</span>
              <span class="value">{{ student.assignmentsCompleted }}/{{ student.assignmentsTotal }} Assignments</span>
            </div>
          </div>

          <div class="footer-row">
            <button @click="viewDetails(student)" class="view-details-btn">View Details</button>
          </div>
        </div>
        <div v-if="paginatedStudents.length === 0" class="no-students-message">
          No students found matching your criteria.
        </div>
      </div>

      <div class="table-footer" v-if="filteredStudents.length > 0">
        <div class="results-summary">
          Showing {{ (currentPage - 1) * itemsPerPage + 1 }} - {{ Math.min(currentPage * itemsPerPage, filteredStudents.length) }} of {{ filteredStudents.length }} results
        </div>
        <div class="pagination">
          <button @click="prevPage" :disabled="currentPage === 1">Previous</button>
          <button
            v-for="page in totalPages"
            :key="page"
            @click="goToPage(page)"
            :class="{ active: currentPage === page }"
          >
            {{ page }}
          </button>
          <button @click="nextPage" :disabled="currentPage === totalPages">Next</button>
        </div>
      </div>
    </main>

    <div v-if="showDetailModal" class="modal-overlay" @click.self="closeDetailModal">
      <div class="modal">
        <h3>Student Details</h3>
        <p><strong>Name:</strong> {{ selectedStudent.name }}</p>
        <p><strong>Status:</strong> {{ selectedStudent.status }}</p>
        <p><strong>Assigned Assignments:</strong> {{ selectedStudent.assignmentsTotal }}</p>
        <p><strong>Completed Assignments:</strong> {{ selectedStudent.assignmentsCompleted }}</p>
        <button @click="closeDetailModal" class="close-btn">Close</button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, computed } from 'vue';
import { useRoute } from 'vue-router';
import Header from './Header.vue';
import api from '../api';

const route = useRoute();
const teacher_id = route.params.teacher_id;

const students = ref([]);
const searchQuery = ref('');
const statusFilter = ref('');
const showDetailModal = ref(false);
const selectedStudent = ref(null);

const currentPage = ref(1);
const itemsPerPage = 6;


onMounted(async () => {
  try {
    const response = await api.get(`/teacher/${teacher_id}/students`);
    students.value = response.data.map((student) => {
      const assignmentsTotal = student.assigned_assignments ? student.assigned_assignments.length : 0;
      const assignmentsCompleted = student.completed_assignments ? student.completed_assignments.length : 0;
      // Progress as percent of completed assignments
      const overallProgress = assignmentsTotal > 0 ? Math.round((assignmentsCompleted / assignmentsTotal) * 100) : 0;
      return {
        id: student.id,
        name: student.name,
        status: student.status,
        assignmentsCompleted,
        assignmentsTotal,
        overallProgress,
        assignedAssignments: student.assigned_assignments,
        completedAssignments: student.completed_assignments,
      };
    });
  } catch (error) {
    console.error('Failed to fetch students:', error);
    students.value = [];
  }
});

const filteredStudents = computed(() => {
  return students.value.filter(student => {
    const matchesSearch = student.name.toLowerCase().includes(searchQuery.value.toLowerCase()) ||
                          student.id.toLowerCase().includes(searchQuery.value.toLowerCase());
    const matchesStatus = statusFilter.value ? student.status.toLowerCase() === statusFilter.value.toLowerCase() : true;
    return matchesSearch && matchesStatus;
  });
});

const totalPages = computed(() => Math.ceil(filteredStudents.value.length / itemsPerPage));
const paginatedStudents = computed(() => {
  const start = (currentPage.value - 1) * itemsPerPage;
  const end = start + itemsPerPage;
  return filteredStudents.value.slice(start, end);
});

function goToPage(page) {
  if (page >= 1 && page <= totalPages.value) {
    currentPage.value = page;
  }
}

function nextPage() {
  if (currentPage.value < totalPages.value) {
    currentPage.value++;
  }
}

function prevPage() {
  if (currentPage.value > 1) {
    currentPage.value--;
  }
}

function getInitials(name) {
  if (!name) return '';
  const parts = name.split(' ');
  if (parts.length === 1) return parts[0].charAt(0).toUpperCase();
  return (parts[0].charAt(0) + parts[parts.length - 1].charAt(0)).toUpperCase();
}

function getAvatarBg(id) {
  const colors = ['#FF6F61', '#6B5B95', '#88B04B', '#F7CAC9', '#92A8D1', '#FFD700', '#DAF7A6'];
  const hash = id.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
  return colors[hash % colors.length];
}

function viewDetails(student) {
  selectedStudent.value = student;
  showDetailModal.value = true;
}

function closeDetailModal() {
  showDetailModal.value = false;
  selectedStudent.value = null;
}
</script>

<style scoped>
.student-management-page {
  min-height: 100vh;
  
}

.main {
  
  color: var(--text);
  background: transparent;
  flex: 1;
}

.controls-container {
  display: flex;
  gap: 1rem;
  margin-bottom: 2rem;
  flex-wrap: wrap;
}

.search-input,
.filter-select {
  flex: 1;
  min-width: 200px;
  padding: 0.75rem 1rem;
  font-size: 0.95rem;
  border-radius: 8px;
  border: 1px solid var(--border);
  background-color: var(--card);
  color: var(--text);
  transition: border-color 0.2s ease, box-shadow 0.2s ease;
}

.search-input:focus,
.filter-select:focus {
  outline: none;
  border-color: var(--primary);
  box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.2);
}


.student-cards-grid {
  display: flex;
  flex-wrap: wrap;
  gap: 1.2rem;
  align-items: flex-start;
}

.student-card {
  background-color: var(--card);
  border: 1px solid var(--border);
  border-radius: 12px;
  box-shadow: var(--shadow);
  padding: 1.2rem 1rem;
  display: flex;
  flex-direction: column;
  gap: 0.8rem;
  min-width: 240px;
  max-width: 320px;
  margin: 0;
  transition: transform 0.2s ease, box-shadow 0.2s ease;
  flex: 1 1 280px;
}

.student-card:hover {
  transform: translateY(-5px);
  box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
}

.student-header {
  display: flex;
  align-items: center;
  gap: 0.6rem;
  padding-bottom: 0.6rem;
  border-bottom: 1px solid var(--border);
}

.student-avatar-initials {
  width: 36px;
  height: 36px;
  border-radius: 50%;
  display: flex;
  justify-content: center;
  align-items: center;
  font-size: 1.1rem;
  font-weight: bold;
  color: white;
  flex-shrink: 0;
}

.student-info {
  display: flex;
  flex-direction: column;
  flex-grow: 1;
  /* Ensure text doesn't force min-width */
  min-width: 0; 
}

.student-name {
  font-size: 0.95rem;
  font-weight: 600;
  color: var(--text);
  /* Allow text to wrap if necessary */
  word-break: break-word; 
}

.student-id {
  font-size: 0.75rem;
  color: var(--text-secondary);
}

.status-pill {
  display: inline-block;
  padding: 3px 8px;
  border-radius: 15px;
  font-size: 0.7rem;
  font-weight: 600;
  text-transform: capitalize;
  text-align: center;
  white-space: nowrap;
}

.status-pill.active { background-color: #d1fae5; color: #065f46; }
.status-pill.inactive { background-color: #fee2e2; color: #991b1b; }
.status-pill.blocked { background-color: #fefce8; color: #b45309; }


.overall-progress {
  padding-top: 0.6rem;
  display: flex;
  flex-direction: column;
  gap: 0.3rem;
}

.progress-label {
  font-size: 0.8rem;
  font-weight: 500;
  color: var(--text-secondary);
}

.progress-bar-container {
  width: 100%;
  background-color: var(--border);
  border-radius: 4px;
  overflow: hidden;
  height: 6px;
}

.progress-bar {
  height: 100%;
  background: linear-gradient(90deg, #6a11cb 0%, #2575fc 100%);
  border-radius: 4px;
  transition: width 0.5s ease-in-out;
}

.progress-percentage {
  text-align: right;
  font-size: 0.75rem;
  font-weight: 600;
  color: var(--primary);
}

.details-row {
  display: flex;
  justify-content: space-around;
  gap: 0.6rem;
  padding: 0.6rem 0;
  border-top: 1px solid var(--border);
  border-bottom: 1px solid var(--border);
  margin-top: 0.6rem;
}

.detail-item {
  display: flex;
  align-items: center;
  gap: 0.3rem;
  font-size: 0.8rem;
  color: var(--text);
  font-weight: 500;
  /* Allow shrinking in flex container */
  flex-shrink: 1;
  /* Prevent content from forcing item width */
  min-width: 0; 
}

.detail-item .icon {
  font-size: 1rem;
  color: var(--primary);
}

.footer-row {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-top: 0.6rem;
}

.last-seen {
  font-size: 0.7rem;
  color: var(--text-secondary);
  display: flex;
  align-items: center;
  gap: 0.2rem;
  /* Allow shrinking in flex container */
  flex-shrink: 1;
  min-width: 0;
  word-break: break-word;
}
.last-seen .icon {
  font-size: 0.8rem;
}

.view-details-btn {
  background-color: #a78bfa;
  color: white;
  padding: 0.4rem 0.8rem;
  border: none;
  border-radius: 8px;
  font-weight: 600;
  cursor: pointer;
  transition: background-color 0.2s ease, transform 0.2s ease;
  box-shadow: 0 2px 6px rgba(167, 139, 250, 0.2);
  /* Prevent button from shrinking */
  flex-shrink: 0;
}

.view-details-btn:hover {
  background-color: #8b5cf6;
  transform: translateY(-2px);
  box-shadow: 0 4px 10px rgba(167, 139, 250, 0.4);
}

.no-students-message {
  grid-column: 1 / -1;
  text-align: center;
  color: var(--text-secondary);
  font-style: italic;
  padding: 3rem 0;
}

.table-footer {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding-top: 1.2rem;
  border-top: 1px solid var(--border);
  margin-top: 1.5rem;
  flex-wrap: wrap;
  gap: 1rem;
}
.results-summary {
  font-size: 0.85rem;
  color: whitesmoke;
}
.pagination {
  display: flex;
  gap: 0.4rem;
}
.pagination button {
  padding: 0.4rem 0.8rem;
  border: 1px solid var(--border);
  border-radius: 6px;
  background-color: var(--card);
  color: var(--text);
  cursor: pointer;
  transition: all 0.2s ease;
  font-weight: 500;
}
.pagination button:hover:not(:disabled),
.pagination button.active {
  background-color: var(--primary);
  color: white;
  border-color: var(--primary);
}
.pagination button:disabled {
  opacity: 0.6;
  cursor: not-allowed;
}

.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.5);
  z-index: 1000;
  display: flex;
  align-items: center;
  justify-content: center;
}

.modal {
  background: var(--card);
  padding: 1.5rem;
  border-radius: 12px;
  width: 90%;
  max-width: 450px;
  box-shadow: var(--shadow);
  color: var(--text);
  display: flex;
  flex-direction: column;
  gap: 0.8rem;
  animation: fadeIn 0.3s ease;
}

.modal h3 {
  margin-top: 0;
  color: var(--primary);
  font-size: 1.3rem;
}

.modal p {
  margin: 0;
  font-size: 0.95rem;
  color: var(--text-secondary);
}

.modal strong {
  color: var(--text);
}

.modal .close-btn {
  align-self: flex-end;
  background: none;
  border: none;
  font-size: 1.3rem;
  cursor: pointer;
  color: var(--text);
}

@keyframes fadeIn {
  from {
    opacity: 0;
    transform: scale(0.95);
  }
  to {
    opacity: 1;
    transform: scale(1);
  }
}

@media (max-width: 768px) {
  .main {
    padding: 1rem;
  }
  .controls-container {
    flex-direction: column;
    gap: 0.8rem;
  }
  .search-input, .filter-select {
    min-width: unset;
  }
  .student-cards-grid {
    grid-template-columns: 1fr;
  }
  .student-card {
    padding: 0.8rem;
  }
  .student-header {
    flex-direction: column;
    align-items: flex-start;
    gap: 0.5rem;
  }
  .student-avatar-initials {
    width: 36px;
    height: 36px;
    font-size: 1.1rem;
  }
  .status-pill {
    margin-left: 0;
    margin-top: 0.5rem;
  }
  .details-row {
    flex-direction: column;
    align-items: flex-start;
    gap: 0.5rem;
  }
  .footer-row {
    flex-direction: column;
    align-items: flex-start;
    gap: 0.8rem;
  }
  .view-details-btn {
    width: 100%;
    text-align: center;
  }
  .table-footer {
    flex-direction: column;
    align-items: center;
  }
  .modal {
    padding: 1rem;
  }
}
</style>