<template>
  <div class="metric-card">
    <div class="icon-wrapper" :style="{ background: iconBg }">
      <span class="icon">{{ icon }}</span>
    </div>
    <div class="content">
      <div class="value-row">
        <span class="value">{{ value }}</span>
        <span v-if="valueSuffix" class="value-suffix">{{ valueSuffix }}</span>
      </div>
      <div class="label">{{ label }}</div>
      <div v-if="subLabel" class="sub-label">{{ subLabel }}</div>
    </div>
  </div>
</template>

<script setup>
defineProps({
  icon: String,
  value: [String, Number],
  label: String,
  iconBg: {
    type: String,
    default: 'var(--primary)' 
  },
  valueSuffix: { 
    type: String,
    default: ''
  },
  subLabel: { 
    type: String,
    default: ''
  }
})
</script>

<style scoped>
.metric-card {
  display: flex;
  align-items: center;
  gap: 1rem;
  background-color: var(--card); /* Base card background */
  padding: 1.5rem;
  border-radius: var(--card-radius);
  box-shadow: var(--shadow);
  border: 1px solid var(--border); /* Added border */
  flex-grow: 1;
  color: var(--text); /* Ensure text color adapts */
}

.icon-wrapper {
  width: 50px; /* Adjust size */
  height: 50px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
}

.icon {
  font-size: 1.8rem; /* Larger icon size */
  color: white; /* Icon color, should be white on colorful backgrounds */
}

.content {
  display: flex;
  flex-direction: column;
  flex-grow: 1;
}

.value-row {
  display: flex;
  align-items: baseline;
  gap: 0.2rem;
}

.value {
  font-size: 1.75rem;
  font-weight: 700; /* Bolder value */
  color: var(--text); /* Use theme text color */
}

.value-suffix {
  font-size: 1.2rem; /* Size for star/emoji suffix */
  color: var(--text);
  opacity: 0.8;
}

.label {
  font-size: 0.9rem; /* Smaller label */
  color: var(--text-secondary); /* Greyish color for labels */
  margin-top: 0.2rem;
}

.sub-label {
  font-size: 0.8rem;
  color: var(--text-secondary);
  opacity: 0.7;
  margin-top: 0.2rem;
}
</style>