<template>
  <div class="instructor-profile-page">
    <main class="main">
      <!-- <Header title="My Profile 👤" subtitle="Manage your account details and preferences." /> -->
      <header style="color: whitesmoke;">
        <h1>My Profile 😀</h1>
        <p>Manage your account details and preferences.</p>
      </header>
      <div class="profile-layout-grid">
        <div class="profile-details-column">
          <section class="card profile-overview-card">
            <div class="profile-header">
<div class="profile-avatar-wrapper">
  <img
    v-if="user.profile_picture"
    :src="profileAvatar"
    alt="Instructor Avatar"
    class="profile-avatar"
  />
  <img
    v-else
    :src="defaultAvatar"
    alt="Default Avatar"
    class="profile-avatar"
  />
</div>

              <div class="profile-info">
                <h2>{{ user.name }}</h2>
                <div class="profile-tags"></div>
                <div class="joined-info" style="margin-top: 0.5rem; color: var(--text-secondary, #aaa); font-size: 1rem;">
                  <span class="icon">📅</span>
                  Joined: {{ joinedDate }}
                </div>
              </div>
            </div>

            <div class="contact-professional-grid">
              <div class="info-section">
                <h4>Contact Information</h4>
                <div class="info-item">
                  <span class="icon">📧</span>
                  <span>{{ user.email }}</span>
                </div>
                <!-- <div class="info-item">
                  <span class="icon">📞</span>
                  <span>Loading...</span>
                </div>
                 -->
              </div>

              <div class="info-section">
                <h4>Professional Details</h4>
                <!-- Joined field moved to profile header -->
                <div class="info-item">
                  <span class="icon">📚</span>
                  <span>Teaching Subject: {{ (user.subjects || []).join(', ') || 'N/A' }}</span>
                </div>
                <div class="info-item">
                  <span class="icon">💼</span>
                  <span>Experience: {{ instructorExperience }} years</span>
                </div>
              </div>
            </div>
          </section>

          
        </div>

        <div class="profile-actions-column">
          <section class="card actions-card">
            <h3>Settings & Actions</h3>
            <div class="actions-list">
              <button class="action-item" @click="openEditModal">
                <span class="action-icon">✏️</span>
                <div class="action-text">
                  <h4>Edit Profile</h4>
                  <p>Update your personal information</p>
                </div>
                <span class="arrow-icon">›</span>
              </button>
              <button class="action-item" @click="openPasswordModal">
                <span class="action-icon">🔒</span>
                <div class="action-text">
                  <h4>Change Password</h4>
                  <p>Update your login credentials</p>
                </div>
                <span class="arrow-icon">›</span>
              </button>
              <button @click="logout" class="action-item logout-item">
                <span class="action-icon">🚪</span>
                <div class="action-text">
                  <h4>Logout</h4>
                  <p>Sign out of your account</p>
                </div>
                <span class="arrow-icon">›</span>
              </button>
            </div>
          </section>

          <div v-if="showPasswordModal" class="modal-overlay" @click.self="showPasswordModal = false">
            <div class="modal-content">
              <h3>Change Password</h3>
              <label>
                Current Password:
                <input v-model="passwordForm.current_password" type="password" />
              </label>
              <label>
                New Password:
                <input v-model="passwordForm.new_password" type="password" />
              </label>
              <label>
                Confirm New Password:
                <input v-model="passwordForm.confirm_new_password" type="password" />
              </label>
              <div v-if="passwordError" class="error-message">
                <ul v-if="Array.isArray(passwordError)">
                  <li v-for="(err, idx) in passwordError" :key="idx">{{ err.msg }}</li>
                </ul>
                <span v-else>{{ passwordError }}</span>
              </div>
              <div class="modal-actions">
                <button @click="submitPasswordChange" class="save-btn">Change</button>
                <button @click="showPasswordModal = false" class="cancel-btn">Cancel</button>
              </div>
            </div>

          </div>
          <section class="card account-status-card">
            <h3>Account Status</h3>
            <div class="status-content">
              <span class="status-dot active"></span>
              <span class="status-text">Active & Verified</span>
            </div>
            <p class="status-description">
              Your account is in good standing with full access to all features.
            </p>
          </section>
        </div>
      </div>
    </main>

    <div v-if="showModal" class="modal-overlay" @click.self="showModal = false">
      <div class="modal-content">
        <h3>Edit Profile</h3>
        <label>
          Full Name:
          <input v-model="editForm.full_name" type="text" />
        </label>
        <label>
          Email:
          <input v-model="editForm.email" type="email" />
        </label>
        <label>
          Profile Picture:
          <input type="file" accept="image/*" @change="onEditProfilePicChange" />
        </label>
        <div v-if="editProfilePicPreview" class="profile-pic-preview">
          <img :src="editProfilePicPreview" alt="Profile Preview" style="max-width: 80px; max-height: 80px; border-radius: 50%; margin-top: 0.5rem;" />
        </div>
        <div class="modal-actions">
          <button @click="submitEdit" class="save-btn">Save</button>
          <button @click="showModal = false" class="cancel-btn">Cancel</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, computed } from 'vue';
import { useRoute, useRouter } from 'vue-router';
import Header from './Header.vue';
import MetricCard from './MetricCard.vue';
import api from '@/api';
import defaultAvatar from '../assets/avatar.jpeg';



// Change Password Modal State
const showPasswordModal = ref(false);
const passwordForm = ref({
  current_password: '',
  new_password: '',
  confirm_new_password: ''
});
const passwordError = ref('');

const openPasswordModal = () => {
  passwordForm.value.current_password = '';
  passwordForm.value.new_password = '';
  passwordForm.value.confirm_new_password = '';
  passwordError.value = '';
  showPasswordModal.value = true;
};

const submitPasswordChange = async () => {
  passwordError.value = '';
  if (passwordForm.value.new_password !== passwordForm.value.confirm_new_password) {
    passwordError.value = 'New passwords do not match.';
    return;
  }
  try {
    await api.post('/user/change-password', {
      current_password: passwordForm.value.current_password,
      new_password: passwordForm.value.new_password
    });
    showPasswordModal.value = false;
    alert('Password changed successfully.');
  } catch (error) {
    // Try to parse FastAPI validation errors (array of objects with .msg)
    const detail = error.response?.data?.detail;
    if (Array.isArray(detail)) {
      passwordError.value = detail;
    } else {
      passwordError.value = detail || 'Failed to change password.';
    }
  }
};

const route = useRoute();
const router = useRouter();
const teacherId = route.params.teacher_id;

const user = ref({
  name: 'Loading...',
  email: 'loading@example.com',
  subjects: [], // Initialized as an array
  role: 'Loading...',
  profile_picture: null,
  joined: null,
});
const dashboardData = ref({});

const showModal = ref(false);
const editForm = ref({ full_name: '', email: '' });
const editProfilePicFile = ref(null);
const editProfilePicPreview = ref('');

function onEditProfilePicChange(e) {
  const file = e.target.files[0];
  if (file) {
    editProfilePicFile.value = file;
    const reader = new FileReader();
    reader.onload = (ev) => {
      editProfilePicPreview.value = ev.target.result;
    };
    reader.readAsDataURL(file);
  } else {
    editProfilePicFile.value = null;
    editProfilePicPreview.value = '';
  }
}

const instructorExperience = ref(null);

const profileAvatar = computed(() => {
  const pic = user.value.profile_picture;
  if (!pic) return '';
  // If already absolute (starts with http), return as is
  if (/^https?:\/\//.test(pic)) return pic;
  // Otherwise, prepend backend base URL
  return `http://localhost:8000${pic}` || defaultAvatar;
});

const joinedDate = computed(() => {
  if (user.value.joined) {
    // Handles both ISO string and date-only string
    const date = new Date(user.value.joined);
    if (!isNaN(date)) {
      // Format as YYYY-MM-DD
      const year = date.getFullYear();
      const month = String(date.getMonth() + 1).padStart(2, '0');
      const day = String(date.getDate()).padStart(2, '0');
      return `${year}-${month}-${day}`;
    }
  }
  return 'N/A';
});

const fetchProfileAndDashboardData = async () => {
  try {
    const profileResponse = await api.get(`/teacher/${teacherId}/profile`);
    if (profileResponse.status === 200) {
      console.log('Profile API response:', profileResponse.data); // DEBUG: See what is returned
      user.value = { 
        ...profileResponse.data, 
        name: profileResponse.data.name,
        email: profileResponse.data.email,
        subjects: profileResponse.data.subjects || [], // Ensure subjects is an array
        role: profileResponse.data.role,
        profile_picture: profileResponse.data.profile_picture,
        joined: profileResponse.data.joined
      };
      instructorExperience.value = profileResponse.data.experience ?? null;
    }

    const dashboardResponse = await api.get(`/teacher/${teacherId}/dashboard`);
    if (dashboardResponse.status === 200) {
      dashboardData.value = dashboardResponse.data;
    }

  } catch (error) {
    console.error('Failed to fetch profile or dashboard data:', error);
    
    

    
  }
};

const openEditModal = () => {
  if (user.value) {
    editForm.value.full_name = user.value.name;
    editForm.value.email = user.value.email;
    editProfilePicFile.value = null;
    editProfilePicPreview.value = user.value.profile_picture || '';
    showModal.value = true;
  }
};

const submitEdit = async () => {
  try {
    const formData = new FormData();
    formData.append('name', editForm.value.full_name);
    formData.append('full_name', editForm.value.full_name);
    formData.append('email', editForm.value.email);
    if (editProfilePicFile.value) {
      formData.append('profile_pic', editProfilePicFile.value);
    }
    const config = { headers: { 'Content-Type': 'multipart/form-data' } };
    const response = await api.put(`/teacher/${teacherId}/editprofile`, formData, config);
    if (response?.data?.profile_picture) {
      user.value.profile_picture = response.data.profile_picture;
    }
    user.value.name = editForm.value.full_name;
    user.value.email = editForm.value.email;
    showModal.value = false;
    alert('Profile updated successfully');
  } catch (error) {
    console.error('Failed to update profile:', error.response?.data || error);
    alert('Failed to update profile');
  }
};

const logout = () => {
  localStorage.clear();
  router.push('/login');
};

function getInitials(name) {
  if (!name) return '';
  const parts = name.split(' ');
  if (parts.length === 1) return parts[0].charAt(0).toUpperCase();
  return (parts[0].charAt(0) + parts[parts.length - 1].charAt(0)).toUpperCase();
}

function getAvatarBg(name) {
  const colors = ['#FF6F61', '#6B5B95', '#88B04B', '#F7CAC9', '#92A8D1', '#FFD700', '#DAF7A6'];
  let hash = 0;
  for (let i = 0; i < name.length; i++) {
    hash = name.charCodeAt(i) + ((hash << 5) - hash);
  }
  return colors[Math.abs(hash) % colors.length];
}

onMounted(() => {
  fetchProfileAndDashboardData();
});
</script>

<style scoped>
.instructor-profile-page {
  min-height: 100vh;
}

.main {
  
  color: var(--text);
  background: transparent;
  flex: 1;
}

.profile-layout-grid {
  display: grid;
  grid-template-columns: 2fr 1fr;
  gap: 2rem;
  margin-top: 2rem;
  align-items: flex-start;
}

.profile-details-column {
  display: flex;
  flex-direction: column;
  gap: 2rem;
}

.profile-actions-column {
  display: flex;
  flex-direction: column;
  gap: 2rem;
}

.card {
  background-color: var(--card);
  padding: 1.5rem;
  border-radius: 12px;
  box-shadow: var(--shadow);
  border: 1px solid var(--border);
  color: var(--text);
}

.card h3 {
  margin-top: 0;
  margin-bottom: 1.5rem;
  font-size: 1.5rem;
  font-weight: 600;
  color: var(--primary);
}

.profile-overview-card {
}

.profile-header {
  display: flex;
  align-items: center;
  gap: 1.5rem;
  padding-bottom: 1.5rem;
  border-bottom: 1px solid var(--border);
  margin-bottom: 1.5rem;
  flex-wrap: wrap;
}

.profile-avatar-wrapper {
  position: relative;
  flex-shrink: 0;
}

.profile-avatar {
  width: 90px;
  height: 90px;
  border-radius: 50%;
  object-fit: cover;
  border: 4px solid var(--primary);
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
}

.avatar-initials {
  /* This style applies when profile_picture is null/empty */
  width: 90px;
  height: 90px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 2.5rem;
  font-weight: bold;
  color: white;
  background-color: #6B5B95; /* Default color for initials if no avatar */
  /* Remove absolute positioning and z-index if it's the sole content */
  /* position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  z-index: 1; */
}

.camera-icon {
  position: absolute;
  bottom: 5px;
  right: 5px;
  background-color: var(--card);
  border-radius: 50%;
  padding: 5px;
  font-size: 1.2rem;
  cursor: pointer;
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
}

.profile-info {
  flex-grow: 1;
}

.profile-info h2 {
  font-size: 1.8rem;
  font-weight: 700;
  color: var(--text);
  margin: 0 0 0.5rem 0;
  border-bottom: none;
  padding-bottom: 0;
}

.profile-tags {
  display: flex;
  flex-wrap: wrap;
  gap: 0.5rem;
  margin-bottom: 0.8rem;
}

.profile-tag {
  background-color: var(--secondary);
  color: var(--text);
  padding: 5px 10px;
  border-radius: 15px;
  font-size: 0.85rem;
  font-weight: 500;
  white-space: nowrap;
}

.subject-tag {
  background-color: #e0f2fe;
  color: #0284c7;
}

.experience-tag {
  background-color: #dcfce7;
  color: #166534;
}

.profile-description {
  font-size: 0.95rem;
  color: var(--text-secondary);
  line-height: 1.5;
  margin: 0;
}

.contact-professional-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 1.5rem;
}

.info-section {
}

.info-section h4 {
  font-size: 1rem;
  font-weight: 600;
  color: var(--primary);
  margin-bottom: 1rem;
}

.info-item {
  display: flex;
  align-items: center;
  gap: 0.75rem;
  margin-bottom: 0.75rem;
  font-size: 0.95rem;
  color: var(--text-secondary);
}

.info-item .icon {
  font-size: 1.2rem;
  color: var(--primary);
  flex-shrink: 0;
}

.metrics-summary-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
  gap: 1rem;
}

.metrics-summary-grid .metric-card {
  padding: 1rem;
  align-items: flex-start;
  flex-direction: column;
  gap: 0.5rem;
}

.metrics-summary-grid .metric-card .icon {
  font-size: 1.8rem;
  padding: 0.5rem;
  border-radius: 8px;
  color: white;
}

.metrics-summary-grid .metric-card .value {
  font-size: 1.5rem;
  font-weight: 700;
  color: var(--text);
}

.metrics-summary-grid .metric-card .label {
  font-size: 0.85rem;
  color: var(--text-secondary);
}

.actions-card {
}

.actions-list {
  display: flex;
  flex-direction: column;
  gap: 1rem;
}

.action-item {
  display: flex;
  align-items: center;
  gap: 1rem;
  background-color: var(--bg);
  padding: 1rem;
  border-radius: 10px;
  border: 1px solid var(--border);
  cursor: pointer;
  transition: all 0.2s ease;
  color: var(--text);
  text-align: left;
  width: 100%;
}

.action-item:hover {
  background-color: var(--primary-light-hover);
  border-color: var(--primary);
  box-shadow: 0 2px 8px rgba(79, 70, 229, 0.1);
}

.action-item .action-icon {
  font-size: 1.5rem;
  color: var(--primary);
  flex-shrink: 0;
}

.action-item .action-text {
  flex-grow: 1;
}

.action-item .action-text h4 {
  margin: 0;
  font-size: 1rem;
  font-weight: 600;
  color: var(--text);
}

.action-item .action-text p {
  margin: 0.2rem 0 0 0;
  font-size: 0.85rem;
  color: var(--text-secondary);
}

.action-item .arrow-icon {
  font-size: 1.5rem;
  color: var(--text-secondary);
  flex-shrink: 0;
}

.action-item.logout-item .action-icon,
.action-item.logout-item .action-text h4,
.action-item.logout-item .action-text p,
.action-item.logout-item .arrow-icon {
  color: #ef4444;
}

.action-item.logout-item:hover {
  background-color: #ef4444;
  color: white;
}
.action-item.logout-item:hover .action-icon,
.action-item.logout-item:hover .action-text h4,
.action-item.logout-item:hover .action-text p,
.action-item.logout-item:hover .arrow-icon {
  color: white;
}

.account-status-card {
}

.status-content {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  margin-bottom: 0.5rem;
}

.status-dot {
  width: 12px;
  height: 12px;
  border-radius: 50%;
  background-color: #22c55e;
  flex-shrink: 0;
}

.status-text {
  font-size: 1rem;
  font-weight: 600;
  color: var(--text);
}

.status-description {
  font-size: 0.9rem;
  color: var(--text-secondary);
  line-height: 1.4;
}

.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.4);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
}

.modal-content {
  background: var(--card);
  padding: 1.5rem;
  border-radius: 10px;
  width: 90%;
  max-width: 380px;
  box-shadow: 0 6px 18px rgba(0, 0, 0, 0.15);
  color: var(--text);
}

.modal-content h3 {
  font-size: 1.2rem;
  font-weight: 700;
  color: var(--primary);
  margin-bottom: 1rem;
  border-bottom: 1px solid var(--border);
  padding-bottom: 0.7rem;
}

.modal-content label {
  display: block;
  margin-bottom: 0.7rem;
  font-weight: 500;
  font-size: 0.9rem;
}

.modal-content input {
  width: calc(100% - 14px);
  padding: 0.6rem 7px;
  border-radius: 5px;
  border: 1px solid var(--border);
  background-color: var(--bg);
  color: var(--text);
  font-size: 0.9rem;
  margin-top: 0.3rem;
  transition: border-color 0.2s ease, box-shadow 0.2s ease;
}

.modal-content input:focus {
  border-color: var(--primary);
  outline: none;
  box-shadow: 0 0 0 2px rgba(79, 70, 229, 0.2);
}

.modal-actions {
  display: flex;
  justify-content: flex-end;
  gap: 0.6rem;
  margin-top: 1.2rem;
}

.save-btn, .cancel-btn {
  padding: 0.6rem 1.2rem;
  border: none;
  border-radius: 6px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.2s ease;
  box-shadow: 0 1px 5px rgba(0, 0, 0, 0.05);
}
  .save-btn { background: #27ae60; color: #fff; }
  .cancel-btn { background: var(--secondary); color: var(--text); }
  .save-btn:hover { background-color: #219150; transform: translateY(-1px); box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
.cancel-btn:hover { background-color: var(--bg); color: var(--primary); transform: translateY(-1px); box-shadow: 0 2px 8px rgba(0,0,0,0.1); }


@media (max-width: 1024px) {
  .profile-layout-grid {
    grid-template-columns: 1fr;
  }
  .contact-professional-grid {
    grid-template-columns: 1fr;
  }
}

@media (max-width: 768px) {
  .main {
    padding: 1rem;
  }
  .profile-overview-card {
    padding: 1rem;
  }
  .profile-header {
    flex-direction: column;
    align-items: flex-start;
    gap: 1rem;
  }
  .profile-info h2 {
    font-size: 1.5rem;
  }
  .profile-tags {
    margin-top: 0.5rem;
  }
  .metrics-summary-grid {
    grid-template-columns: 1fr;
  }
  .action-item {
    padding: 0.8rem;
  }
  .action-item .action-icon {
    font-size: 1.2rem;
  }
  .action-item .action-text h4 {
    font-size: 0.9rem;
  }
  .action-item .action-text p {
    font-size: 0.75rem;
  }
  .action-item .arrow-icon {
    font-size: 1.2rem;
  }
  .modal-content {
    max-width: 90%;
    padding: 1rem;
  }
  .modal-content h3 {
    font-size: 1.1rem;
  }
  .modal-content label, .modal-content input {
    font-size: 0.85rem;
  }
  .save-btn, .cancel-btn {
    padding: 0.5rem 1rem;
    font-size: 0.85rem;
  }
}
</style>