<template>
  <div class="calendar-container" :class="{ 'dark-mode': isDarkMode }">
    <!-- Header Section -->
<div class="calendar-header-section">
  <div class="header-left">
    <h1 class="calendar-title">My Calendar 📅</h1>
    <p class="calendar-subtitle">
      Stay organized and never miss a task! Let's plan your awesome days together! 🌟
    </p>
  </div>

  <div class="header-right">
    <DotLottieVue
      src="https://lottie.host/27a0571c-7e06-4e42-92ba-812eb7b99fce/ilzfB0e7gS.lottie"
      class="lottie-animation"
      autoplay
      loop
    />
    <!-- <button @click="toggleTheme" class="theme-toggle">
      {{ isDarkMode ? '☀️' : '🌙' }}
    </button> -->
  </div>
</div>


    <!-- Main Calendar Section -->
    <div class="calendar-main-card">
      <!-- Calendar Navigation -->
      <div class="calendar-nav">
        <button @click="prevMonth" class="nav-btn prev-btn">
          <span class="nav-icon">⬅️</span>
          <span class="nav-text">Previous</span>
        </button>
        
        <div class="month-display">
          <h2 class="current-month">{{ currentMonthName }} {{ currentYear }}</h2>
          <div class="month-decorations">
            <span class="decoration-emoji">🗓️</span>
            <span class="decoration-emoji">✨</span>
          </div>
        </div>
        
        <button @click="nextMonth" class="nav-btn next-btn">
          <span class="nav-text">Next</span>
          <span class="nav-icon">➡️</span>
        </button>
      </div>

      <!-- Quick Add Section -->
      <!-- <div class="quick-add-section"> -->
        <!-- <h3 class="section-title">Quick Add 🚀</h3> -->
        <!-- <div class="quick-add-form"> -->
          <!-- <div class="input-group">
            <span class="input-icon">📝</span>
            <input 
              type="text" 
              v-model="newReminder" 
              placeholder="What do you want to remember? 🤔" 
              class="reminder-input"
            />
          </div>
          
          <div class="input-group">
            <span class="input-icon">📅</span>
            <input 
              type="date" 
              v-model="reminderDate" 
              class="date-input"
            />
          </div> -->
          
          <!-- <button @click="addReminder" class="add-reminder-btn">
            <span class="btn-icon">➕</span>
            <span>Add Reminder</span>
          </button> -->
        <!-- </div> -->
      <!-- </div> -->

      <!-- Calendar Grid -->
      <div class="calendar-grid-section">
        <div class="calendar-wrapper">
          <!-- Days Header -->
          <div class="calendar-days-header">
            <div v-for="day in weekDays" :key="day" class="day-header">
              <span class="day-emoji">{{ getDayEmoji(day) }}</span>
              <span class="day-name">{{ day }}</span>
            </div>
          </div>

          <!-- Calendar Body -->
          <div class="calendar-body">
            <div
              v-for="day in calendarDays"
              :key="day.date"
              class="calendar-day"
              :class="{ 
                'not-current-month': !day.isCurrentMonth,
                'today': isToday(day.date),
                'has-events': hasEvents(day.date)
              }"
              @click="openTaskModal(day.date)"
            >
              <div class="day-number">{{ day.date.getDate() }}</div>
              
              <div class="events-container">
                <div
                  v-for="event in eventsOnDate(day.date).slice(0, 2)"
                  :key="event.id"
                  class="event-dot"
                  :class="event.type || 'task'"
                  :title="event.title"
                >
                  <span class="event-emoji">{{ getEventEmoji(event.type || 'task') }}</span>
                  <span class="event-title">{{ event.title }}</span>
                </div>
                <div v-if="eventsOnDate(day.date).length > 2" class="more-events">
                  +{{ eventsOnDate(day.date).length - 2 }}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Task Modal -->
    <div v-if="showTaskModal" class="modal-overlay" @click.self="closeTaskModal">
      <div class="task-modal">
        <div class="modal-header">
          <div class="modal-title-section">
            <h3 class="modal-title">📝 Tasks for {{ formatDate(selectedDate) }}</h3>
            <div class="modal-decorations">
              <span class="decoration">🌟</span>
              <span class="decoration">✨</span>
            </div>
          </div>
          <button class="modal-close-btn" @click="closeTaskModal">
            <span>✕</span>
          </button>
        </div>

        <div class="modal-content">
          <!-- Add New Task Form -->
          <div class="new-task-section">
            <h4 class="subsection-title">🎯 Create New Task</h4>
            <form @submit.prevent="createTask" class="task-creation-form">
              <div class="form-row">
                <div class="form-group">
                  <label class="form-label">📚 Task Title:</label>
                  <input 
                    v-model="newTask.title" 
                    placeholder="What needs to be done?" 
                    required 
                    class="form-input"
                  />
                </div>
              </div>
              
              <div class="form-row">
                <div class="form-group">
                  <label class="form-label">📖 Description:</label>
                  <textarea 
                    v-model="newTask.description" 
                    placeholder="Tell me more about this task..." 
                    class="form-textarea"
                    rows="3"
                  ></textarea>
                </div>
              </div>
              
              <div class="form-row">
                <div class="form-group">
                  <label class="form-label">⏰ Due Date & Time:</label>
                  <input 
                    type="datetime-local" 
                    v-model="newTask.due_date" 
                    required 
                    class="form-input"
                  />
                </div>
              </div>
              
              <button type="submit" class="create-task-btn">
                <span class="btn-icon">🚀</span>
                <span>Create Awesome Task!</span>
              </button>
            </form>
          </div>

          <!-- Divider -->
          <div class="section-divider">
            <span class="divider-emoji">🌈</span>
          </div>

          <!-- Existing Tasks -->
          <div class="existing-tasks-section">
            <h4 class="subsection-title">📋 Your Tasks</h4>
            
            <div v-if="tasksOnDate.length" class="tasks-list">
              <div 
                v-for="(task, index) in tasksOnDate" 
                :key="task.id" 
                class="task-item"
                :class="{ 'completed': task.status === 'complete' }"
              >
                <div class="task-status-indicator">
                  <span class="status-emoji">{{ task.status === 'complete' ? '✅' : '⏳' }}</span>
                </div>
                
                <div class="task-details">
                  <template v-if="task.editing">
                    <input v-model="task.title" class="edit-input" placeholder="Task title" />
                    <textarea v-model="task.description" class="edit-textarea" placeholder="Description"></textarea>
                    <input type="datetime-local" v-model="task.due_date" class="edit-input" />
                  </template>
                  <template v-else>
                    <h5 class="task-title">{{ task.title }}</h5>
                    <p class="task-description" v-if="task.description">{{ task.description }}</p>
                    <div class="task-meta">
                      <span class="task-time">🕒 {{ formatDateTime(task.due_date) }}</span>
                      <span class="task-status-badge" :class="task.status">
                        {{ task.status === 'complete' ? '🎉 Done!' : '⏰ Pending' }}
                      </span>
                    </div>
                  </template>
                </div>

                <div class="task-actions">
                  <button 
                    @click="toggleTask(index)" 
                    class="action-btn toggle-btn"
                    :class="task.status"
                  >
                    {{ task.status === 'complete' ? '↩️ Undo' : '✅ Done' }}
                  </button>
                  
                  <button 
                    @click="toggleEdit(index)" 
                    class="action-btn edit-btn"
                  >
                    {{ task.editing ? '💾 Save' : '✏️ Edit' }}
                  </button>
                  
                  <button 
                    @click="deleteTask(task.id)" 
                    class="action-btn delete-btn"
                  >
                    🗑️
                  </button>
                </div>
              </div>
            </div>
            
            <div v-else class="no-tasks">
              <div class="no-tasks-illustration">
                <span class="illustration-emoji">🏖️</span>
              </div>
              <p class="no-tasks-text">No tasks for this day! Time to relax or add something fun to do! 😊</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import Header from '../components/Header.vue'
import api from '../api'
import { store } from '../store'
import { useRoute } from 'vue-router'
import { DotLottieVue } from '@lottiefiles/dotlottie-vue'
const route = useRoute()
const userId = store.userId 
const isDarkMode = ref(false)

// Data
const assignments = ref([])
const reminders = ref([])
const newReminder = ref('')
const reminderDate = ref('')
const today = new Date()
const currentYear = ref(today.getFullYear())
const currentMonth = ref(today.getMonth())
const weekDays = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']
const tasks = ref([])
const showTaskModal = ref(false)
const selectedDate = ref(null)
const newTask = ref({
  title: '',
  description: '',
  due_date: ''
})

// Calendar utils
const getMonthDays = (year, month) => {
  const first = new Date(year, month, 1)
  const last = new Date(year, month + 1, 0)
  const days = []
  const startOffset = first.getDay()
  const total = last.getDate()
  const slots = Math.ceil((startOffset + total) / 7) * 7
  for (let i = 0; i < slots; i++) {
    const day = new Date(year, month, i - startOffset + 1)
    days.push({ date: day, isCurrentMonth: day.getMonth() === month })
  }
  return days
}

const calendarDays = computed(() => getMonthDays(currentYear.value, currentMonth.value))
const currentMonthName = computed(() =>
  new Date(currentYear.value, currentMonth.value).toLocaleString('default', { month: 'long' })
)
const allEvents = computed(() => [...assignments.value, ...reminders.value, ...tasks.value])
const tasksOnDate = computed(() =>
  tasks.value.filter(t => new Date(t.due_date).toDateString() === selectedDate.value.toDateString())
)
const eventsOnDate = date =>
  allEvents.value.filter(e => new Date(e.date || e.due_date).toDateString() === date.toDateString())

// New helper functions
const toggleTheme = () => {
  isDarkMode.value = !isDarkMode.value
  localStorage.setItem('darkMode', isDarkMode.value)
}

const getDayEmoji = (day) => {
  const emojis = {
    'Sun': '☀️',
    'Mon': '💼',
    'Tue': '🚀',
    'Wed': '🌟',
    'Thu': '⚡',
    'Fri': '🎉',
    'Sat': '🏖️'
  }
  return emojis[day] || '📅'
}

const getEventEmoji = (type) => {
  const emojis = {
    'task': '📝',
    'assignment': '📚',
    'reminder': '🔔',
    'exam': '📋',
    'project': '🎯'
  }
  return emojis[type] || '📝'
}

const isToday = (date) => {
  const today = new Date()
  return date.toDateString() === today.toDateString()
}

const hasEvents = (date) => {
  return eventsOnDate(date).length > 0
}

const prevMonth = () => {
  currentMonth.value = currentMonth.value === 0 ? 11 : currentMonth.value - 1
  if (currentMonth.value === 11) currentYear.value--
}

const nextMonth = () => {
  currentMonth.value = currentMonth.value === 11 ? 0 : currentMonth.value + 1
  if (currentMonth.value === 0) currentYear.value++
}

const openTaskModal = date => {
  selectedDate.value = date
  showTaskModal.value = true
  let newDate = new Date(date);
  newDate.setDate(newDate.getDate() + 1);
  newTask.value.due_date = newDate.toISOString().slice(0, 16);
  document.body.style.overflow = 'hidden';
  fetchTasks()
}

const closeTaskModal = () => {
  showTaskModal.value = false
  document.body.style.overflow = ''
}

onMounted(() => {
  isDarkMode.value = localStorage.getItem('darkMode') === 'true'
  fetchTasks()
})

// Task actions
async function fetchTasks() {
  try {
    const res = await api.get(`/student/${userId}/calendar`)
    tasks.value = res.data.map(t => ({
      ...t,
      editing: false,
      due_date: t.due_date?.slice(0, 16) || ''
    }))
  } catch (err) {
    console.error(err)
  }
}

async function createTask() {
  try {
    await api.post(`/student/${userId}/calendar`, {
      title: newTask.value.title,
      description: newTask.value.description,
      due_date: newTask.value.due_date
    })
    await fetchTasks()
    newTask.value = { title: '', description: '', due_date: selectedDate.value.toISOString().slice(0, 16) }
  } catch (err) {
    console.error(err)
  }
}

async function toggleTask(index) {
  const task = tasksOnDate.value[index]
  const newStatus = task.status === 'complete' ? 'pending' : 'complete'
  try {
    await api.put(`/student/${userId}/calendar/${task.id}`, {
      ...task,
      status: newStatus
    })
    fetchTasks()
  } catch (err) {
    console.error(err)
  }
}

async function toggleEdit(index) {
  const task = tasksOnDate.value[index]
  if (task.editing) {
    try {
      await api.put(`/student/${userId}/calendar/${task.id}`, task)
    } catch (err) {
      console.error(err)
    }
  }
  task.editing = !task.editing
}

async function deleteTask(id) {
  try {
    await api.delete(`/student/${userId}/calendar/${id}`)
    fetchTasks()
  } catch (err) {
    console.error(err)
  }
}

function addReminder() {
  if (newReminder.value && reminderDate.value) {
    reminders.value.push({
      id: Date.now(),
      title: newReminder.value,
      date: reminderDate.value,
      type: 'reminder'
    })
    newReminder.value = ''
    reminderDate.value = ''
  }
}

function formatDate(date) {
  return date.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })
}

function formatDateTime(dateStr) {
  const date = new Date(dateStr)
  return date.toLocaleString('en-IN', {
    day: '2-digit', month: 'short', year: 'numeric',
    hour: '2-digit', minute: '2-digit', hour12: true
  })
}
</script>

<style scoped>
/* CSS Variables for theming */
.calendar-container {
  --bg-primary:   linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  --bg-card: rgba(255, 255, 255, 0.95);
  --bg-secondary: rgba(255, 255, 255, 0.1);
  --text-primary: #1F2937;
  --text-secondary: #6B7280;
  --text-white: #FFFFFF;
  --border: rgba(139, 92, 246, 0.2);
  --shadow: rgba(0, 0, 0, 0.1);
  --accent-purple: #8B5CF6;
  --accent-green: #10B981;
  --accent-red: #EF4444;
  --accent-orange: #F59E0B;
  --accent-blue: #3B82F6;
}

.calendar-container.dark-mode {
  --bg-primary: linear-gradient(135deg, #1E1B4B 0%, #312E81 50%, #3730A3 100%);
  --bg-card: rgba(30, 27, 75, 0.95);
  --text-primary: #F9FAFB;
  --text-secondary: #D1D5DB;
  --border: rgba(139, 92, 246, 0.3);
  --shadow: rgba(0, 0, 0, 0.3);
}

.calendar-container {
  min-height: 100vh;
  background: var(--bg-primary);
  padding: 2rem;
  color: var(--text-primary);
  font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
}

/* Header Section */
.calendar-header-section {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 3rem;
}

.calendar-title {
  font-size: 2.5rem;
  font-weight: 700;
  color: var(--text-white);
  margin: 0 0 0.5rem 0;
  text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.2);
}

.calendar-subtitle {
  font-size: 1.1rem;
  color: rgba(255, 255, 255, 0.8);
  margin: 0;
}

.theme-toggle {
  background: var(--bg-secondary);
  backdrop-filter: blur(20px);
  border: 1px solid var(--border);
  border-radius: 12px;
  padding: 0.75rem;
  color: var(--text-white);
  cursor: pointer;
  font-size: 1.2rem;
  transition: all 0.3s ease;
}

.theme-toggle:hover {
  transform: translateY(-2px);
  box-shadow: 0 8px 25px var(--shadow);
}

/* Main Calendar Card */
.calendar-main-card {
  background: var(--bg-card);
  backdrop-filter: blur(20px);
  border: 1px solid var(--border);
  border-radius: 24px;
  padding: 3rem;
  box-shadow: 0 20px 40px var(--shadow);
}

/* Calendar Navigation */
.calendar-nav {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 3rem;
  padding: 0 1rem;
}

.nav-btn {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  background: var(--bg-secondary);
  border: 1px solid var(--border);
  border-radius: 12px;
  padding: 1rem 1.5rem;
  cursor: pointer;
  color: var(--text-primary);
  font-weight: 600;
  transition: all 0.3s ease;
}

.nav-btn:hover {
  transform: translateY(-2px);
  box-shadow: 0 8px 25px var(--shadow);
  background: var(--accent-purple);
  color: white;
}

.nav-icon {
  font-size: 1.2rem;
}

.month-display {
  text-align: center;
  position: relative;
}

.current-month {
  font-size: 2rem;
  font-weight: 700;
  color: var(--text-primary);
  margin: 0;
}

.month-decorations {
  display: flex;
  justify-content: center;
  gap: 1rem;
  margin-top: 0.5rem;
}

.decoration-emoji {
  font-size: 1.5rem;
  animation: float 3s ease-in-out infinite;
}

.decoration-emoji:nth-child(2) {
  animation-delay: 1s;
}

/* Quick Add Section */
.quick-add-section {
  background: var(--bg-secondary);
  border-radius: 16px;
  padding: 2rem;
  margin-bottom: 3rem;
  border: 1px solid var(--border);
}

.section-title {
  font-size: 1.3rem;
  font-weight: 600;
  color: var(--text-primary);
  margin-bottom: 1.5rem;
  text-align: center;
}

.quick-add-form {
  display: grid;
  grid-template-columns: 1fr 1fr auto;
  gap: 1rem;
  align-items: end;
}

.input-group {
  position: relative;
  display: flex;
  align-items: center;
  background: var(--bg-card);
  border-radius: 12px;
  border: 1px solid var(--border);
  overflow: hidden;
}

.input-icon {
  padding: 1rem;
  font-size: 1.2rem;
  background: var(--accent-purple);
  color: white;
}

.reminder-input,
.date-input {
  flex: 1;
  padding: 1rem;
  border: none;
  background: transparent;
  color: var(--text-primary);
  font-size: 1rem;
  outline: none;
}

.reminder-input::placeholder {
  color: var(--text-secondary);
}

.add-reminder-btn {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  background: linear-gradient(135deg, var(--accent-purple), #A855F7);
  color: white;
  border: none;
  border-radius: 12px;
  padding: 1rem 1.5rem;
  cursor: pointer;
  font-weight: 600;
  transition: all 0.3s ease;
}

.add-reminder-btn:hover {
  transform: translateY(-2px);
  box-shadow: 0 8px 25px rgba(139, 92, 246, 0.4);
}

/* Calendar Grid */
.calendar-grid-section {
  background: var(--bg-secondary);
  border-radius: 20px;
  padding: 2rem;
  border: 1px solid var(--border);
}

.calendar-wrapper {
  background: var(--bg-card);
  border-radius: 16px;
  overflow: hidden;
  border: 1px solid var(--border);
}

.calendar-days-header {
  display: grid;
  grid-template-columns: repeat(7, 1fr);
  background: var(--accent-purple);
  color: white;
}

.day-header {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 0.25rem;
  padding: 1rem 0.5rem;
  font-weight: 600;
  border-right: 1px solid rgba(255, 255, 255, 0.2);
}

.day-header:last-child {
  border-right: none;
}

.day-emoji {
  font-size: 1.2rem;
}

.day-name {
  font-size: 0.9rem;
}

.calendar-body {
  display: grid;
  grid-template-columns: repeat(7, 1fr);
}

.calendar-day {
  min-height: 120px;
  padding: 1rem;
  border-right: 1px solid var(--border);
  border-bottom: 1px solid var(--border);
  cursor: pointer;
  transition: all 0.3s ease;
  background: var(--bg-card);
  position: relative;
}

.calendar-day:hover {
  background: var(--bg-secondary);
  transform: scale(1.02);
  z-index: 10;
  box-shadow: 0 8px 25px var(--shadow);
}

.calendar-day:nth-child(7n) {
  border-right: none;
}

.calendar-day.not-current-month {
  background: var(--bg-secondary);
  opacity: 0.5;
}

.calendar-day.today {
  background: linear-gradient(135deg, rgba(139, 92, 246, 0.1), rgba(168, 85, 247, 0.1));
  border: 2px solid var(--accent-purple);
}

.calendar-day.has-events {
  background: linear-gradient(135deg, rgba(16, 185, 129, 0.05), rgba(34, 197, 94, 0.05));
}

.day-number {
  font-size: 1.1rem;
  font-weight: 600;
  color: var(--text-primary);
  margin-bottom: 0.5rem;
}

.events-container {
  display: flex;
  flex-direction: column;
  gap: 0.25rem;
}

.event-dot {
  display: flex;
  align-items: center;
  gap: 0.25rem;
  font-size: 0.75rem;
  padding: 0.25rem 0.5rem;
  border-radius: 8px;
  color: white;
  font-weight: 500;
}

.event-dot.task {
  background: var(--accent-blue);
}

.event-dot.assignment {
  background: var(--accent-orange);
}

.event-dot.reminder {
  background: var(--accent-green);
}

.event-emoji {
  font-size: 14px;
  line-height: 1;
  display: inline-block;
  font-family: "Apple Color Emoji", "Segoe UI Emoji", "Noto Color Emoji", "EmojiOne Color", "Twemoji Mozilla", sans-serif;
}


.more-events {
  font-size: 0.7rem;
  color: var(--text-secondary);
  font-weight: 600;
  text-align: center;
  padding: 0.25rem;
  background: var(--bg-secondary);
  border-radius: 4px;
}

/* Modal Styles */
.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
  backdrop-filter: blur(5px);
}

.task-modal {
  background: var(--bg-card);
  border-radius: 24px;
  width: 95%;
  max-width: 800px;
  max-height: 90vh;
  overflow-y: auto;
  box-shadow: 0 25px 50px rgba(0, 0, 0, 0.25);
  border: 1px solid var(--border);
}

.modal-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 2rem;
  border-bottom: 1px solid var(--border);
  background: linear-gradient(135deg, var(--accent-purple), #A855F7);
  border-radius: 24px 24px 0 0;
  color: white;
}

.modal-title-section {
  display: flex;
  align-items: center;
  gap: 1rem;
}

.modal-title {
  font-size: 1.5rem;
  font-weight: 600;
  margin: 0;
}

.modal-decorations {
  display: flex;
  gap: 0.5rem;
}

.decoration {
  font-size: 1.2rem;
  animation: sparkle 2s ease-in-out infinite;
}

.decoration:nth-child(2) {
  animation-delay: 1s;
}

.modal-close-btn {
  background: rgba(255, 255, 255, 0.2);
  border: none;
  border-radius: 50%;
  width: 40px;
  height: 40px;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  color: white;
  font-size: 1.2rem;
  transition: all 0.3s ease;
}

.modal-close-btn:hover {
  background: rgba(255, 255, 255, 0.3);
  transform: scale(1.1);
}

.modal-content {
  padding: 2rem;
}

/* Form Sections */
.new-task-section,
.existing-tasks-section {
  margin-bottom: 2rem;
}

.subsection-title {
  font-size: 1.2rem;
  font-weight: 600;
  color: var(--text-primary);
  margin-bottom: 1.5rem;
  text-align: center;
}

.task-creation-form {
  background: var(--bg-secondary);
  border-radius: 16px;
  padding: 2rem;
  border: 1px solid var(--border);
}

.form-row {
  margin-bottom: 1.5rem;
}

.form-group {
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
}

.form-label {
  font-weight: 600;
  color: var(--text-primary);
  font-size: 1rem;
}

.form-input,
.form-textarea {
  padding: 1rem;
  border: 1px solid var(--border);
  border-radius: 12px;
  background: var(--bg-card);
  color: var(--text-primary);
  font-size: 1rem;
  transition: all 0.3s ease;
}

.form-input:focus,
.form-textarea:focus {
  outline: none;
  border-color: var(--accent-purple);
  box-shadow: 0 0 0 3px rgba(139, 92, 246, 0.1);
}

.form-textarea {
  resize: vertical;
  font-family: inherit;
}

.create-task-btn {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 0.5rem;
  width: 100%;
  background: linear-gradient(135deg, var(--accent-green), #059669);
  color: white;
  border: none;
  border-radius: 12px;
  padding: 1rem 2rem;
  cursor: pointer;
  font-weight: 600;
  font-size: 1rem;
  transition: all 0.3s ease;
}

.create-task-btn:hover {
  transform: translateY(-2px);
  box-shadow: 0 8px 25px rgba(16, 185, 129, 0.4);
}

/* Section Divider */
.section-divider {
  display: flex;
  justify-content: center;
  align-items: center;
  margin: 2rem 0;
  position: relative;
}

.section-divider::before {
  content: '';
  position: absolute;
  left: 0;
  right: 0;
  height: 1px;
  background: var(--border);
}

.divider-emoji {
  background: var(--bg-card);
  padding: 0 1rem;
  font-size: 1.5rem;
  z-index: 1;
}

/* Tasks List */
.tasks-list {
  display: flex;
  flex-direction: column;
  gap: 1rem;
}

.task-item {
  display: flex;
  align-items: flex-start;
  gap: 1rem;
  background: var(--bg-secondary);
  border-radius: 16px;
  padding: 1.5rem;
  border: 1px solid var(--border);
  transition: all 0.3s ease;
}

.task-item:hover {
  transform: translateY(-2px);
  box-shadow: 0 8px 25px var(--shadow);
}

.task-item.completed {
  opacity: 0.7;
  background: linear-gradient(135deg, rgba(16, 185, 129, 0.1), rgba(34, 197, 94, 0.1));
}

.task-status-indicator {
  flex-shrink: 0;
  font-size: 1.5rem;
  width: 40px;
  height: 40px;
  display: flex;
  align-items: center;
  justify-content: center;
  background: var(--bg-card);
  border-radius: 50%;
  border: 2px solid var(--border);
}

.task-details {
  flex: 1;
}

.task-title {
  font-size: 1.1rem;
  font-weight: 600;
  color: var(--text-primary);
  margin: 0 0 0.5rem 0;
}

.task-description {
  font-size: 0.95rem;
  color: var(--text-secondary);
  margin: 0 0 1rem 0;
  line-height: 1.5;
}

.task-meta {
  display: flex;
  gap: 1rem;
  align-items: center;
  flex-wrap: wrap;
}

.task-time {
  font-size: 0.85rem;
  color: var(--text-secondary);
}

.task-status-badge {
  padding: 0.25rem 0.75rem;
  border-radius: 20px;
  font-size: 0.8rem;
  font-weight: 600;
}

.task-status-badge.complete {
  background: var(--accent-green);
  color: white;
}

.task-status-badge.pending {
  background: var(--accent-orange);
  color: white;
}

.task-actions {
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
  flex-shrink: 0;
}

.action-btn {
  padding: 0.5rem 1rem;
  border: none;
  border-radius: 8px;
  cursor: pointer;
  font-size: 0.85rem;
  font-weight: 600;
  transition: all 0.3s ease;
  min-width: 80px;
}

.toggle-btn.complete {
  background: var(--accent-orange);
  color: white;
}

.toggle-btn.pending {
  background: var(--accent-green);
  color: white;
}

.edit-btn {
  background: var(--accent-blue);
  color: white;
}

.delete-btn {
  background: var(--accent-red);
  color: white;
}

.action-btn:hover {
  transform: translateY(-2px);
  opacity: 0.9;
}

/* Edit inputs */
.edit-input,
.edit-textarea {
  width: 100%;
  padding: 0.5rem;
  border: 1px solid var(--border);
  border-radius: 8px;
  background: var(--bg-card);
  color: var(--text-primary);
  margin-bottom: 0.5rem;
}

.edit-textarea {
  resize: vertical;
  min-height: 60px;
}

/* No Tasks */
.no-tasks {
  text-align: center;
  padding: 3rem;
  background: var(--bg-secondary);
  border-radius: 16px;
  border: 1px solid var(--border);
}

.no-tasks-illustration {
  margin-bottom: 1rem;
}

.illustration-emoji {
  font-size: 3rem;
  animation: float 3s ease-in-out infinite;
}

.no-tasks-text {
  font-size: 1.1rem;
  color: var(--text-secondary);
  margin: 0;
}

/* Animations */
@keyframes float {
  0%, 100% { transform: translateY(0px); }
  50% { transform: translateY(-10px); }
}

@keyframes sparkle {
  0%, 100% { transform: scale(1) rotate(0deg); }
  50% { transform: scale(1.2) rotate(180deg); }
}

/* Responsive Design */
@media (max-width: 1024px) {
  .calendar-container {
    padding: 1.5rem;
  }
  
  .calendar-main-card {
    padding: 2rem;
  }
  
  .quick-add-form {
    grid-template-columns: 1fr;
    gap: 1rem;
  }
  
  .task-item {
    flex-direction: column;
    align-items: stretch;
  }
  
  .task-actions {
    flex-direction: row;
    justify-content: flex-end;
  }
}

@media (max-width: 768px) {
  .calendar-container {
    padding: 1rem;
  }
  
  .calendar-title {
    font-size: 2rem;
  }
  
  .calendar-header-section {
    flex-direction: column;
    gap: 1rem;
    text-align: center;
  }
  
  .calendar-nav {
    flex-direction: column;
    gap: 1rem;
  }
  
  .nav-btn {
    width: 100%;
    justify-content: center;
  }
  
  .calendar-day {
    min-height: 80px;
    padding: 0.5rem;
  }
  
  .day-number {
    font-size: 1rem;
  }
  
  .task-modal {
    margin: 1rem;
    max-width: none;
  }
  
  .modal-content {
    padding: 1.5rem;
  }
}

@media (max-width: 480px) {
  .calendar-body {
    grid-template-columns: repeat(7, 1fr);
    gap: 1px;
  }
  
  .calendar-day {
    min-height: 60px;
    padding: 0.25rem;
  }
  
  .day-header {
    padding: 0.5rem 0.25rem;
  }
  
  .day-name {
    font-size: 0.7rem;
  }
  
  .day-emoji {
    display: none;
  }
  
  .task-actions {
    gap: 0.25rem;
  }
  
  .action-btn {
    padding: 0.4rem 0.6rem;
    font-size: 0.75rem;
    min-width: 60px;
  }
}
.calendar-header-section {
  display: flex !important;
  justify-content: space-between !important;
  align-items: center !important;
  padding: 2rem !important;
  /* background: linear-gradient(90deg, #6a76ec, #6e62dd) !important; */
  background: transparent;
  border-radius: 12px !important;
  flex-wrap: wrap !important;
  gap: 1.5rem !important;
}

.header-left {
  flex: 1 !important;
  min-width: 250px !important;
}

.calendar-title {
  font-size: 2rem !important;
  font-weight: bold !important;
  margin: 0 !important;
  color: white !important;
}

.calendar-subtitle {
  font-size: 1rem !important;
  margin-top: 0.5rem !important;
  color: white !important;
}

.header-right {
  display: flex !important;
  align-items: center !important;
  gap: 1rem !important;
}

.lottie-animation {
  width: 110px !important;
  height: 110px !important;
  pointer-events: none !important;
}

.theme-toggle {
  font-size: 1.5rem !important;
  padding: 0.5rem !important;
  border: 2px solid #fff !important;
  border-radius: 12px !important;
  background: transparent !important;
  color: white !important;
  cursor: pointer !important;
}

</style>