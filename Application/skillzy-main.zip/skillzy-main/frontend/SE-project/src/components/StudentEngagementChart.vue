<template>
  <div class="chart-container">
    <canvas ref="chartCanvas"></canvas>
  </div>
</template>

<script setup>
import { ref, onMounted, watch } from 'vue';
import Chart from 'chart.js/auto';
import { store } from '../store.js';
import axios from 'axios';

const props = defineProps({
  teacherId: Number,
});

let chartInstance = null;
const chartCanvas = ref(null);

const fetchEngagementData = async () => {
  try {
    const res = await axios.get(`/teacher/${props.teacherId}/dashboard`);
    const engagement = res.data.student_engagement;

    // Categorize students by engagement levels (example thresholds)
    const categories = { HighlyActive: 0, ModeratelyActive: 0, Inactive: 0 };
    engagement.forEach(s => {
      if (s.completed_tasks >= 10) categories.HighlyActive++;
      else if (s.completed_tasks >= 5) categories.ModeratelyActive++;
      else categories.Inactive++;
    });

    return {
      labels: ['Highly Active', 'Moderately Active', 'Inactive'],
      data: [categories.HighlyActive, categories.ModeratelyActive, categories.Inactive],
    };
  } catch (error) {
    console.error('Failed to load student engagement:', error);
    return { labels: [], data: [] };
  }
};

const createChart = async () => {
  if (chartInstance) {
    chartInstance.destroy();
  }
  if (!chartCanvas.value) return;

  const { labels, data } = await fetchEngagementData();

  const textColor = getComputedStyle(chartCanvas.value).getPropertyValue('--text').trim();

  chartInstance = new Chart(chartCanvas.value, {
    type: 'doughnut',
    data: {
      labels,
      datasets: [
        {
          label: 'Number of Students',
          data,
          backgroundColor: ['#10b981', '#f97316', '#ef4444'],
          borderColor: 'var(--card)',
          borderWidth: 2,
        },
      ],
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          position: 'bottom',
          labels: {
            color: textColor,
            boxWidth: 12,
            padding: 20,
          },
        },
        title: { display: false },
      },
      cutout: '70%',
    },
  });
};

onMounted(() => {
  createChart();
});

watch(() => [store.isDarkMode, props.teacherId], () => {
  createChart();
});
</script>

<style scoped>
.chart-container {
  position: relative;
  width: 100%;
  height: 100%;
  min-height: 300px;
}
</style>
