<template>
  <div class="resource-container">
    <h2 class="title"> Knowledge Base</h2>
    <!-- search text -->
     <h2 class="search-title" style="color: whitesmoke;">Search Resources Shared by your Teacher...</h2>
        <input
      v-model="searchQuery"
      type="text"
      placeholder="Search by title or description..."
      class="search-bar"
    />

    <div v-if="loading" class="loading">Loading resources...</div>
    <div v-else-if="error" class="error">❌ {{ error }}</div>
    <div v-else-if="resources.length === 0" class="empty">No resources found.</div>
    <div v-else class="grid">
<div
  v-for="res in filteredResources"
  :key="res.id"
  class="resource-card"
>
  <h3>Resource title: <p>{{ res.title }}</p></h3>
  <!-- <p class="category">Category: {{ res.category }}</p> -->
  <p>Description: <p>{{ res.description }}</p></p>
  <a :href="res.url" target="_blank" class="link">Open Resource 🔗</a>
</div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import api from '../api'
import { store } from '../store.js'
import { DotLottieVue } from '@lottiefiles/dotlottie-vue'

import { useRoute } from 'vue-router'
const route = useRoute()
const userId = store.userId

const resources = ref([])
const loading = ref(true)
const error = ref(null)
const searchQuery = ref('')

const fetchResources = async () => {
  try {
    const res = await api.get(`/student/${userId}/resources`)
    resources.value = res.data
    console.log('Resources fetched:', resources.value)
  } catch (err) {
    error.value = err.response?.data?.detail || 'Failed to fetch resources.'
  } finally {
    loading.value = false
  }
}
// const filteredResources = computed(() =>
//   resources.value.filter(r => r.category.toLowerCase() !== 'instructor')
// )

onMounted(() => {
  fetchResources()
})

const BACKEND_URL = 'http://localhost:8000/'  // Change to your backend domain if different

const filteredResources = computed(() => {
  return resources.value
    .filter(r => r.category.toLowerCase() !== 'instructor')
    .map(r => {
      let finalUrl = r.url
      if (!r.url.startsWith('http')) {
        // Ensure the URL is absolute by prepending backend base URL
        finalUrl = BACKEND_URL + r.url.replace(/^\/?static\//, 'static/')
      }
      return { ...r, url: finalUrl }
    })
    .filter(r => {
      const q = searchQuery.value.toLowerCase()
      return (
        r.title.toLowerCase().includes(q) ||
        r.description.toLowerCase().includes(q)
      )
    })
})

</script>

<style scoped>


.search-bar {
  width: 100%;
  padding: 10px;
  margin: 1rem 0;
  font-size: 16px;
  border: 1px solid #ccc;
  border-radius: 5px;
}


.resource-container {
  min-height: 100vh;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  padding: 2rem;
  /* margin-top: 5px; */
  margin: 0;
  max-width: none;
}

.title {
  color: white;
  font-size: 2.5rem;
  font-weight: bold;
  margin-bottom: 2rem;
  text-shadow: 0 2px 4px rgba(0,0,0,0.3);
  /* text-align: center; */
  font-family: 'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
}

.loading,
.error,
.empty {
  text-align: center;
  font-size: 1.2rem;
  color: white;
  background: rgba(255,255,255,0.1);
  padding: 2rem;
  border-radius: 20px;
  margin: 2rem auto;
  max-width: 400px;
  backdrop-filter: blur(10px);
  box-shadow: 0 8px 32px rgba(0,0,0,0.1);
}

.grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
  gap: 1.5rem;
  max-width: 1200px;
  margin: 0 auto;
}

.resource-card {
  background: rgba(255,255,255,0.95);
  padding: 1.5rem;
  border-radius: 20px;
  box-shadow: 0 8px 32px rgba(0,0,0,0.1);
  border: 1px solid rgba(255,255,255,0.2);
  backdrop-filter: blur(10px);
  transition: all 0.3s ease;
  position: relative;
  overflow: hidden;
}

.resource-card::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  height: 4px;
  background: linear-gradient(90deg, #ff6b6b, #4ecdc4, #45b7d1, #96ceb4);
}

.resource-card:hover {
  transform: translateY(-5px);
  box-shadow: 0 15px 45px rgba(0,0,0,0.15);
}

.resource-card h3 {
  margin: 0 0 1rem 0;
  color: #2c3e50;
  font-size: 1.1rem;
  font-weight: 600;
  display: flex;
  align-items: center;
  gap: 0.5rem;
}

.resource-card h3::before {
  content: '📄';
  font-size: 1.2rem;
}

.resource-card h3 p {
  margin: 0;
  color: #34495e;
  font-weight: 700;
  font-size: 1.2rem;
}

.resource-card > p {
  color: #6c757d;
  font-size: 0.95rem;
  line-height: 1.6;
  margin-bottom: 1.5rem;
  display: flex;
  align-items: flex-start;
  gap: 0.5rem;
}

.resource-card > p::before {
  content: '📝';
  font-size: 1rem;
  margin-top: 0.1rem;
}

.resource-card > p p {
  margin: 0;
  flex: 1;
}

.link {
  display: inline-flex;
  align-items: center;
  gap: 0.5rem;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  font-weight: 600;
  text-decoration: none;
  padding: 0.75rem 1.5rem;
  border-radius: 25px;
  transition: all 0.3s ease;
  box-shadow: 0 4px 15px rgba(102, 126, 234, 0.3);
}

.link:hover {
  transform: translateY(-2px);
  box-shadow: 0 6px 20px rgba(102, 126, 234, 0.4);
  text-decoration: none;
}

@media (max-width: 768px) {
  .resource-container {
    padding: 1rem;
  }
  
  .title {
    font-size: 2rem;
  }
  
  .grid {
    grid-template-columns: 1fr;
    gap: 1rem;
  }
  
  .resource-card {
    padding: 1rem;
  }
}

@media (max-width: 480px) {
  .resource-container {
    padding: 0.5rem;
  }
  
  .title {
    font-size: 1.8rem;
    margin-bottom: 1.5rem;
  }
  
  .resource-card {
    border-radius: 15px;
  }
}
</style>
