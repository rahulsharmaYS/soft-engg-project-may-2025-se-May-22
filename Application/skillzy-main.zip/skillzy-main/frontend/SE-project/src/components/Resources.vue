<template>
  <div class="main">
  <!-- <Header title="Resources Hub" subtitle="Explore curated materials for learning and teaching" /> -->
  <header style="color: whitesmoke;">
    <h1>Resources Hub 📚</h1>
    <p>Explore curated materials for learning and teaching</p>
  </header>
  <div class="resources-bg">
      <div class="resources-content-grid">
        <!-- Add Resource Form (Instructor Only) -->
        <div v-if="isInstructorView" class="add-resource-card resource-card">
          <div class="card-header">
            <span class="header-icon">🔗</span>
            <h3 class="card-title">Add New Resource</h3>
          </div>
          <p class="card-subtitle">For Instructor Use Only</p>
          <form @submit.prevent="addResource" class="add-resource-form">
            <div class="input-group">
              <label>Resource Title</label>
              <input type="text" v-model="newResource.title" placeholder="Enter resource title" required />
            </div>
            <div class="input-group">
              <label>Description</label>
              <input type="text" v-model="newResource.description" placeholder="Describe the resource" required />
            </div>
            <div class="input-group">
              <label>Resource Type</label>
              <select v-model="resourceInputType" required>
                <option value="url">URL</option>
                <option value="file">File Upload</option>
              </select>
            </div>
            <div v-if="resourceInputType === 'url'" class="input-group">
              <label>URL</label>
              <input type="url" v-model="newResource.url" placeholder="Resource URL" :required="resourceInputType === 'url'" />
            </div>
            <div v-if="resourceInputType === 'file'" class="input-group">
              <label>Upload File</label>
              <input type="file" @change="handleFileUpload" :required="resourceInputType === 'file'" />
            </div>
            <div class="select-group">
              <label for="resourceCategory">Category</label>
              <select v-model="newResource.category" id="resourceCategory" required>
                <option value="" disabled>Select category</option>
                <option value="student">Student Resource</option>
                <option value="instructor">Instructor Tool</option>
              </select>
            </div>
            <button type="submit" class="add-btn">Add Resource</button>
          </form>
        </div>
        <div class="resources-list-section">
          <!-- Student Resources -->
    <div class="resource-card">
            <div class="card-header">
              <span class="header-icon">📘</span>
              <h3 class="card-title">Student Resources</h3>
            </div>
            <div class="resource-list">
              <div v-for="resource in studentResources" :key="resource.id" class="resource-item-card">
                <div class="resource-item-header">
                  <span class="resource-icon">📄</span>
                  <h4>{{ resource.title }}</h4>
                  <span class="file-type-badge">
                    {{ resource.url && resource.url.startsWith('static/resources/') ? 'Document' : 'URL' }}
                  </span>
                </div>
                <p class="resource-desc">{{ resource.description }}</p>
                <div class="resource-meta">
            <a v-if="resource.url && resource.url.startsWith('static/resources/')"
              :href="getResourceUrl(resource.url)" class="download-btn" target="_blank">⬇️ View Document</a>
            <a v-else :href="resource.url" target="_blank" class="download-btn">🔗 View resource</a>
                </div>
              </div>
            </div>
          </div>
          <!-- Instructor Tools (Instructor Only) -->
    <div v-if="isInstructorView" class="resource-card">
            <div class="card-header">
              <span class="header-icon">🧑‍🏫</span>
              <h3 class="card-title">Instructor Tools</h3>
            </div>
            <div class="resource-list">
              <div v-for="tool in instructorTools" :key="tool.id" class="resource-item-card">
                <div class="resource-item-header">
                  <span class="resource-icon">📄</span>
                  <h4>{{ tool.title }}</h4>
                  <span class="file-type-badge document">
                    {{ tool.url && tool.url.startsWith('static/resources/') ? 'Document' : 'URL' }}
                  </span>
                </div>
                <p class="resource-desc">{{ tool.description }}</p>
                <div class="resource-meta">
            <a v-if="tool.url && tool.url.startsWith('static/resources/')"
              :href="getResourceUrl(tool.url)" class="download-btn" target="_blank">⬇️ View Document</a>
            <a v-else :href="tool.url" target="_blank" class="download-btn">🔗 View resource</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, computed } from 'vue';
import { useRoute } from 'vue-router';
import Header from './Header.vue';
import api from '@/api';

// Helper to get absolute URL for static resources
function getResourceUrl(url) {
  if (url && url.startsWith('static/resources/')) {
    return `http://localhost:8000/${url}`;
  }
  return url;
}

const route = useRoute();
const teacherId = route.params.teacher_id;

const isInstructorView = computed(() => route.path.startsWith('/teacher'));


const studentResources = ref([]);
const instructorTools = ref([]);
const newResource = ref({ title: '', description: '', url: '', category: 'student', resourceType: 'url', fileType: '' });
const resourceInputType = ref('url');
const fileToUpload = ref(null);

async function fetchResources() {
  if (isInstructorView.value) {
    const resS = await api.get(`/teacher/${teacherId}/resources?category=student`);
    const resI = await api.get(`/teacher/${teacherId}/resources?category=instructor`);
    studentResources.value = resS.data;
    instructorTools.value = resI.data;
  } else {
    const resS = await api.get(`/teacher/${teacherId}/resources?category=student`);
    studentResources.value = resS.data;
  }
}


function handleFileUpload(e) {
  const file = e.target.files[0];
  if (file) {
    fileToUpload.value = file;
    newResource.value.url = '';
    newResource.value.fileType = file.type.split('/').pop().toUpperCase();
    newResource.value.resourceType = 'file';
  }
}

async function addResource() {
  let payload;
  if (resourceInputType.value === 'file' && fileToUpload.value) {
    // Prepare FormData for file upload (backend integration needed)
    payload = new FormData();
    payload.append('title', newResource.value.title);
    payload.append('description', newResource.value.description);
    payload.append('category', newResource.value.category);
    payload.append('resourceType', 'file');
    payload.append('file', fileToUpload.value);
    payload.append('fileType', newResource.value.fileType);
  } else {
    payload = { ...newResource.value, resourceType: 'url', fileType: '' };
  }
  try {
    const response = await api.post(`/teacher/${teacherId}/resources`, payload, resourceInputType.value === 'file' ? { headers: { 'Content-Type': 'multipart/form-data' } } : {});
    const resource = response.data.resource;
    if (resource.category === 'student') studentResources.value.unshift(resource);
    else instructorTools.value.unshift(resource);
    newResource.value = { title: '', description: '', url: '', category: 'student', resourceType: 'url', fileType: '' };
    resourceInputType.value = 'url';
    fileToUpload.value = null;
  } catch (err) {
    console.error('Failed to add resource:', err);
    alert('Oops, could not add!');
  }
}

onMounted(fetchResources);
</script>

<style scoped>

.main{
  padding: 2rem;
}
.resources-bg {
  min-height: 100vh;
  
  box-sizing: border-box;
  
}

.resources-content-grid {
  display: grid;
  grid-template-columns: 1fr 2fr;
  gap: 2rem;
  align-items: flex-start;
}

.resource-card {
  background: var(--card);
  border-radius: 24px;
  box-shadow: var(--shadow);
  padding: 2rem 1.5rem;
  margin-bottom: 2rem;
  color: var(--text);
  border: 1px solid var(--border);
}
.add-resource-card {
  min-width: 320px;
  max-width: 400px;
}
.card-header {
  display: flex;
  align-items: center;
  gap: 0.7rem;
  margin-bottom: 0.5rem;
}
.card-title {
  font-size: 1.3rem;
  font-weight: 700;
  color: var(--text);
}
.card-subtitle {
  font-size: 1rem;
  color: var(--text-secondary);
  margin-bottom: 1.5rem;
}
.add-resource-form {
  margin-top: 1rem;
}
.input-group, .select-group {
  margin-bottom: 1.2rem;
}
.input-group label, .select-group label {
  font-size: 1rem;
  color: var(--text-secondary);
  margin-bottom: 6px;
  display: block;
}
.input-group input, .select-group select {
  width: 100%;
  padding: 10px;
  font-size: 1rem;
  color: var(--text);
  border: 1px solid var(--border);
  border-radius: 8px;
  background: var(--bg);
  box-sizing: border-box;
}
.input-group input:focus, .select-group select:focus {
  outline: none;
  border-color: var(--primary);
}
.add-btn {
  width: 100%;
  padding: 0.8rem;
  border: none;
  border-radius: 10px;
  background: linear-gradient(90deg, #a020f0 0%, #ff6a9f 100%);
  color: white;
  font-weight: 600;
  font-size: 1rem;
  cursor: pointer;
  transition: all 0.3s ease;
  margin-top: 0.5rem;
}
.add-btn:hover {
  background: linear-gradient(90deg, #ff6a9f 0%, #a020f0 100%);
  transform: translateY(-2px);
}
.resources-list-section {
  display: flex;
  flex-direction: column;
  gap: 2rem;
}
.resource-list {
  display: flex;
  flex-wrap: wrap;
  gap: 1.5rem;
}
.resource-item-card {
  background: var(--bg);
  border-radius: 16px;
  box-shadow: var(--shadow);
  padding: 1.2rem 1rem;
  margin-bottom: 1rem;
  min-width: 320px;
  flex: 1 1 320px;
  border: 1px solid var(--border);
  color: var(--text);
}
.resource-item-header {
  display: flex;
  align-items: center;
  gap: 0.7rem;
  margin-bottom: 0.3rem;
}
.resource-icon {
  font-size: 1.5rem;
}
.file-type-badge {
  background: #e3e3ff;
  color: #3b3bff;
  font-size: 0.9rem;
  font-weight: 600;
  padding: 2px 12px;
  border-radius: 12px;
  margin-left: auto;
}
.file-type-badge.document {
  background: #e3ffe3;
  color: #1bbf1b;
}
.resource-desc {
  font-size: 1rem;
  color: var(--text-secondary);
  margin-bottom: 0.7rem;
}
.resource-meta {
  display: flex;
  align-items: center;
  gap: 1.2rem;
  font-size: 0.95rem;
  color: var(--text-secondary);
}
.download-btn {
  margin-left: auto;
  padding: 7px 18px;
  border-radius: 8px;
  background: #fffbe6;
  color: #222;
  font-weight: 600;
  font-size: 1rem;
  border: 1px solid #ffe0a3;
  box-shadow: 0 1px 4px rgba(160,32,240,0.04);
  text-decoration: none;
  transition: background 0.2s, color 0.2s;
  display: flex;
  align-items: center;
  gap: 0.5rem;
}
.download-btn:hover {
  background: #ffe0a3;
  color: #a020f0;
}
</style>