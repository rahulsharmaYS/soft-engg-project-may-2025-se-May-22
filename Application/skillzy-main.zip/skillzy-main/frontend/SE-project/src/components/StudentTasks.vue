<!-- 
 


NO USE OF THIS FILE.




-->








<template>
  <div class="task-manager">
    <h2>📚 Task Management</h2>

    <form @submit.prevent="createTask" class="task-form">
      <input v-model="newTask.title" placeholder="Task title" required />
      <input v-model="newTask.description" placeholder="Description" />
       <input type="datetime-local" v-model="newTask.due_date" required />
      <button type="submit">➕ Add Task</button>
    </form>

    <div class="task-list">
      <div
        class="task-card"
        v-for="(task, index) in tasks"
        :key="task.id"
        :class="['task-card', task.status]"
      >
        <div class="task-info">
          <template v-if="task.editing">
            <input v-model="task.title" />
            <input v-model="task.description" />
             <input type="datetime-local" v-model="task.due_date" />
          </template>
          <template v-else>
            <h3>{{ task.title }}</h3>
            <p>{{ task.description }}</p>
            <small>🕒 Due: {{ formatDate(task.due_date) }}</small>
          </template>
        </div>

         <div class="task-actions">
    <span class="badge" :class="task.status">
      {{ task.status.charAt(0).toUpperCase() + task.status.slice(1) }}
    </span>

    <button @click="toggleTask(index)">
      {{ task.status === 'complete' ? 'Undo' : 'Mark Done' }}
    </button>

    <button @click="toggleEdit(index)">
      {{ task.editing ? 'Save' : 'Edit' }}
    </button>

    <button @click="deleteTask(task.id)">🗑 Delete</button>
  </div>
      </div>
    </div>
  </div>
</template>


<script setup>
import { ref, onMounted } from 'vue';
import { useRoute } from 'vue-router';
import api from '../api';
import { useFocusStore } from '../stores/focusStores';

const route = useRoute();
const userId = route.params.id;

const tasks = ref([]);
const newTask = ref({
  title: '',
  description: '',
  due_date: ''
});

const focus = useFocusStore();

function formatDate(dueDateStr) {
  if (!dueDateStr) return "No due date";

  // Parse without timezone shift
  const [datePart, timePart] = dueDateStr.split("T");
  const [year, month, day] = datePart.split("-");
  const [hour, minute] = timePart.split(":");

  // Create a local date from parts
  const date = new Date(
    parseInt(year),
    parseInt(month) - 1,
    parseInt(day),
    parseInt(hour),
    parseInt(minute)
  );

  return date.toLocaleString("en-IN", {
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    hour12: true,
  });
}




async function fetchTasks() {
  try {
    const res = await api.get(`/student/${userId}/tasks`);
    tasks.value = res.data.map(task => ({
      ...task, 
      editing: false,
     due_date: task.due_date?.slice(0, 16) || ''
    }));
  } catch (err) {
    console.error("Error fetching tasks", err);
  }
}

async function toggleTask(index) {
  const task = tasks.value[index];
  const updatedStatus = task.completed ? 'pending' : 'complete';

  try {
    const res = await api.put(`/student/${userId}/tasks/${task.id}`, {
      title: task.title,
      description: task.description,
      due_date: task.due_date,
      status: updatedStatus
    });

    task.status = updatedStatus;
    task.completed = updatedStatus === 'complete';

  } catch (err) {
    console.error("Failed to update task", err);
    task.completed = !task.completed;
  }
}


async function toggleEdit(index) {
  const task = tasks.value[index];
  if (task.editing) {
    try {
      await api.put(`/student/${userId}/tasks/${task.id}`, {
        title: task.title,
        description: task.description,
        due_date: task.due_date,
        status: task.completed ? 'complete' : 'pending'
      });
    } catch (err) {
      console.error("Failed to save task", err);
    }
  }
  task.editing = !task.editing;
}

async function createTask() {
  try {
    await api.post(`/student/${userId}/tasks`, {
      title: newTask.value.title,
      description: newTask.value.description,
      due_date: newTask.value.due_date
    });

    // Refresh list
    await fetchTasks();

    newTask.value = { title: '', description: '', due_date: '' };
  } catch (err) {
    console.error("Failed to create task", err);
  }
}

async function deleteTask(taskId) {
  try {
    await api.delete(`/student/${userId}/tasks/${taskId}`);
    tasks.value = tasks.value.filter(t => t.id !== taskId);
  } catch (err) {
    console.error("Failed to delete task", err);
  }
}

onMounted(fetchTasks);
</script>


<style scoped>
.task-manager {
  background-color: var(--card-bg);
  color: var(--text);
  padding: 1.5rem;
  border-radius: 1rem;
  margin-top: 2rem;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.07);
  transition: all 0.3s ease;
}

.task-manager h2 {
  font-size: 1.5rem;
  margin-bottom: 1rem;
}

.task-list {
  display: flex;
  flex-direction: column;
  gap: 1rem;
}

.task-card {
  background: var(--surface);
  border-radius: 0.75rem;
  padding: 1rem 1.25rem;
  display: flex;
  justify-content: space-between;
  align-items: center;
  border: 1px solid var(--border);
  transition: background 0.3s ease;
}

.task-card.completed {
  opacity: 0.7;
}

.task-info h3 {
  margin: 0;
  font-size: 1.1rem;
  font-weight: 600;
}

.task-info p {
  margin: 0.25rem 0 0;
  color: var(--muted-text);
  font-size: 0.875rem;
}

.task-actions {
  text-align: right;
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
  align-items: flex-end;
}

.task-actions button {
  background-color: var(--button-bg);
  color: var(--button-text);
  border: none;
  padding: 0.4rem 0.8rem;
  border-radius: 0.5rem;
  cursor: pointer;
  font-size: 0.875rem;
  font-weight: 500;
  transition: background-color 0.2s ease;
}

.task-actions button:hover {
  background-color: var(--button-hover);
}

.badge {
  font-size: 0.75rem;
  padding: 0.25rem 0.6rem;
  border-radius: 1rem;
  font-weight: 600;
  text-transform: uppercase;
}

.badge.pending {
  background-color: #fde68a;
  color: #92400e;
}

.badge.done {
  background-color: #6ee7b7;
  color: #065f46;
}

/* Light and Dark Theme Variables */
:root {
  --text: #1f2937;
  --muted-text: #6b7280;
  --card-bg: #ffffff;
  --surface: #f9fafb;
  --border: #e5e7eb;
  --button-bg: #3b82f6;
  --button-text: #ffffff;
  --button-hover: #2563eb;
}

.dark {
  --text: #f3f4f6;
  --muted-text: #9ca3af;
  --card-bg: #1f2937;
  --surface: #374151;
  --border: #4b5563;
  --button-bg: #4f46e5;
  --button-text: #ffffff;
  --button-hover: #4338ca;
}
</style>
