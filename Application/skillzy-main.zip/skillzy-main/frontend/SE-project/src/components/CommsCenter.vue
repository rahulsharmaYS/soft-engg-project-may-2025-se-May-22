<template>
  <div class="main-view">
    <!-- <Header :title="isInstructorView ? 'Instructor Comms Center' : 'Parent Comms Center'"
      subtitle="Direct and secure messaging" /> -->
    <header style="color: whitesmoke;">
      <h1>{{ isInstructorView ? 'Instructor Comms Center' : 'Parent Comms Center' }}</h1>
      <p>Direct and secure messaging</p>
    </header>
    <div class="comms-center-layout">
      <aside class="conversation-list">
        <header class="list-header">
          <h2>Chats</h2>
        </header>
        <ul class="chat-items">
          <li v-for="convo in displayedConversations" :key="convo.id" @click="selectConversation(convo.id)"
            :class="{ active: activeConversation && activeConversation.id === convo.id }" class="chat-item">
            <img :src="getParticipant(convo).avatar" alt="Avatar" class="avatar" />
            <div class="chat-info">
              <span class="chat-name">{{ getParticipant(convo).name }}</span>
              <span class="chat-subtitle" v-if="isInstructorView && getParticipant(convo).role === 'parent'">
                Parent of {{ getParticipant(convo).student_name }}
              </span>
              <span class="chat-subtitle" v-else-if="!isInstructorView && getParticipant(convo).role === 'teacher'">
                {{ getParticipant(convo).subject }}
              </span>
            </div>
          </li>
        </ul>
      </aside>

      <main class="chat-window">
        <template v-if="activeConversation">
          <header class="chat-header">
            <div class="participant-info">
              <img :src="getParticipant(activeConversation).avatar" alt="Avatar" class="avatar" />
              <div class="chat-info">
                <span class="chat-name header-name">{{ getParticipant(activeConversation).name }}</span>
                <span class="chat-subtitle"
                  v-if="isInstructorView && getParticipant(activeConversation).role === 'parent'">
                Parent of {{ getParticipant(activeConversation).student_name }}
                </span>
                <span class="chat-subtitle"
                  v-else-if="!isInstructorView && getParticipant(activeConversation).role === 'instructor'">
                  {{ getParticipant(activeConversation).subject }}
                </span>
              </div>
            </div>
            <!-- <button v-if="isInstructorView" @click="viewChildDetails" class="view-details-btn">
              View Child Details
            </button> -->
          </header>
          <div class="message-area">
            <div v-for="message in activeConversation.messages" :key="message.timestamp" class="message-bubble"
              :class="{ sent: message.senderId === currentUser.id, received: message.senderId !== currentUser.id }">
              <p>{{ message.text }}</p>
            </div>
          </div>
          <footer class="message-input-area">
            <input v-model="newMessageText" @keyup.enter="sendMessage" type="text" placeholder="Type a message..." />
            <button @click="sendMessage">Send</button>
          </footer>
        </template>
        <template v-else>
          <div class="no-chat-selected">
            <p>Select a chat to start messaging</p>
          </div>
        </template>
      </main>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import Header from './Header.vue'
import api from '../api'
import { store } from '../store.js'

// Router / route refs
const router = useRouter()
const route = useRoute()

// State
const conversations = ref([])
const participantsMap = ref({}) // user details keyed by ID
const storedUser = JSON.parse(localStorage.getItem('user') || '{}')
const currentUser = computed(() => store.user)
const isInstructorView = computed(() => store.user?.role === 'teacher')
const displayedConversations = computed(() => conversations.value)
const token = localStorage.getItem('token')
const selectedConversationId = ref(null)
const newMessageText = ref('')

// Polling state
let lastTimestamp = 0
let pollingTimeout = null

// Computed: active conversation
const activeConversation = computed(() => {
  if (!selectedConversationId.value) return null
  return displayedConversations.value.find(
    (c) => c.id === selectedConversationId.value
  )
})

// Helpers
function getParticipant(convo) {
  const participantId = convo.participants.find(
    (pId) => pId !== currentUser.value.id
  )
  return participantsMap.value[participantId] || {}
}

// Conversation selection — starts polling loop
function selectConversation(id) {
  selectedConversationId.value = id
  const convo = displayedConversations.value.find((c) => c.id === id)
  const participantId = convo.participants.find(
    (p) => p !== currentUser.value.id
  )
  lastTimestamp = 0
  startPolling(participantId)
}

// Send message via HTTP POST
async function sendMessage() {
  if (!newMessageText.value.trim()) return
  const convo = activeConversation.value
  if (!convo) return

  const participantId = convo.participants.find(
    (p) => p !== currentUser.value.id
  )

  try {
    await api.post('/chat/send_message', null, {
      params: {
        token,
        receiver_id: participantId,
        content: newMessageText.value.trim()
      }
    })
    newMessageText.value = ''
    // Message will appear locally when poller returns it
  } catch (err) {
    console.error('Send message error:', err)
  }
}

// Poll messages loop
async function startPolling(participantId) {
  try {
    const res = await api.get('/chat/poll_messages', {
      params: {
        token,
        receiver_id: participantId,
        since: lastTimestamp
      }
    })

    if (res.data.messages && res.data.messages.length) {
      // Find the conversation for this participant
      const convo = conversations.value.find(c =>
        c.participants.includes(participantId) &&
        c.participants.includes(currentUser.value.id)
      )

      if (convo) {
        if (res.data.messages && res.data.messages.length) {
          // sort to make sure we pick the latest timestamp
          res.data.messages.forEach(msg => {
            const exists = convo.messages.some(
              m =>
                m.senderId === msg.sender_id &&
                m.text === msg.content &&
                m.timestamp === msg.timestamp
            )
            if (!exists) {
              convo.messages.push({
                senderId: msg.sender_id,
                text: msg.content,
                timestamp: msg.timestamp
              })
            }
          })
          // Set lastTimestamp to the latest message's timestamp (in seconds)
          const latest = res.data.messages[res.data.messages.length - 1]
          lastTimestamp = Date.parse(latest.timestamp) / 1000
        }
      }
    }
    pollingTimeout = setTimeout(() => startPolling(participantId), 2000)
  } catch (err) {
    console.error('Polling error:', err)
  }
}


// View child details (alert demo)
function viewChildDetails() {
  const participant = getParticipant(activeConversation.value)
  alert(
    `Viewing details for ${participant.student_name || participant.childName}.`
  )
}

// Fetch conversation list
async function fetchConversations() {
  const userId = currentUser.value.id
  try {
    if (isInstructorView.value) {
      const res = await api.get(`chat/conversations/${userId}`)
      console.log('Conversations fetched:', res.data)
      conversations.value = res.data.conversations.map((conv) => {
        conv.participants.forEach((p) => {
          participantsMap.value[p.id] = {
            id: p.id,
            name: p.full_name || p.name,
            role: p.role_name || p.role,
            subject: p.subject,
            student_name: p.student_name,
            avatar:
              p.avatar ||
              'https://avatar.iran.liara.run/public/boy?username=' +
              (p.full_name || p.name)
          }
        })
        return {
          id: `conv_${conv.participants.find((p) => p.id !== userId).id}`,
          participants: conv.participants.map((p) => p.id),
          messages: []
        }
      })
    } else {
      const res = await api.get(`chat/parent/${userId}/contact`)
      console.log('Conversations fetched:', res.data)
      const teacherData = {
        id: res.data.user_id,
        name: res.data.full_name,
        role: res.data.role_name,
        student_name: res.data.student_name,
        email: res.data.email,
        avatar:
          res.data.avatar ||
          'https://avatar.iran.liara.run/public/boy?username=' +
          res.data.full_name
      }

      participantsMap.value[teacherData.id] = teacherData
      conversations.value = [
        {
          id: `conv_${teacherData.id}`,
          participants: [userId, teacherData.id],
          messages: []
        }
      ]
    }

    if (conversations.value.length > 0) {
      selectConversation(conversations.value[0].id)
    }
  } catch (e) {
    console.error('Failed to fetch conversations:', e)
  }
}

// Auto-run on mount
onMounted(async () => {
  await fetchConversations()
})
</script>

<style scoped>
.main-view{
  min-width: 100vh;
    min-height: 100vh;
  /* background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); */
  background: linear-gradient(135deg, #B12BE2, #1F6CF3);
  padding: 2rem;
  font-family: 'Inter', sans-serif;
}
/* Layout Container */
.comms-center-layout {
  display: flex;
  height: calc(100vh - 10rem);
  background: linear-gradient(135deg, #c4b5fd, #a5b4fc);
  border-radius: 16px;
  overflow: hidden;
  margin-top: 2rem;
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.1);
  
}

/* Sidebar: Conversations */
.conversation-list {
  width: 320px;
  background-color: var(--card);
  border-right: 1px solid var(--border);
  display: flex;
  flex-direction: column;
}

.list-header {
  padding: 1.5rem 1rem;
  border-bottom: 1px solid var(--border);
}

.list-header h2 {
  margin: 0;
  font-weight: 700;
  color: var(--primary);
  font-size: 1.25rem;
}

/* Chat Items */
.chat-items {
  list-style: none;
  padding: 0;
  margin: 0;
  overflow-y: auto;
  flex-grow: 1;
}

.chat-item {
  display: flex;
  align-items: center;
  gap: 1rem;
  padding: 1rem;
  cursor: pointer;
  border-bottom: 1px solid var(--border);
  transition: background 0.2s ease;
}

.chat-item:hover {
  background-color: #f3f0ff;
}

.chat-item.active {
  background-color: var(--primary-light);
}

.avatar {
  width: 48px;
  height: 48px;
  border-radius: 50%;
  background-color: #eee;
}

.chat-info {
  display: flex;
  flex-direction: column;
  line-height: 1.3;
}

.chat-name {
  font-weight: 600;
  color: var(--text);
}

.chat-subtitle {
  font-size: 0.75rem;
  color: #888;
}

/* Chat Window */
.chat-window {
  flex-grow: 1;
  background-color: var(--card);
  display: flex;
  flex-direction: column;
  border-left: 1px solid var(--border);
}

/* Chat Header */
.chat-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 1rem 1.5rem;
  border-bottom: 1px solid var(--border);
  background-color: var(--bg);
}

.participant-info {
  display: flex;
  align-items: center;
  gap: 1rem;
}

.header-name {
  font-size: 1.1rem;
  font-weight: 600;
  color: var(--primary);
}

.view-details-btn {
  padding: 0.5rem 1rem;
  border: none;
  background-color: var(--primary-light);
  color: var(--primary);
  border-radius: 12px;
  font-weight: 500;
  cursor: pointer;
  transition: background 0.2s ease;
}

.view-details-btn:hover {
  background-color: #ddd6fe;
}

/* Messages */
.message-area {
  flex-grow: 1;
  padding: 1.5rem;
  overflow-y: auto;
  display: flex;
  flex-direction: column;
  gap: 1rem;
  background-color: #f9f8ff;
}

.message-bubble {
  max-width: 65%;
  padding: 0.75rem 1.25rem;
  border-radius: 18px;
  font-size: 0.95rem;
  line-height: 1.4;
  word-wrap: break-word;
}

.message-bubble.sent {
  background-color: var(--primary);
  color: white;
  border-bottom-right-radius: 4px;
  align-self: flex-end;
  box-shadow: 0 3px 8px rgba(117, 81, 233, 0.2);
}

.message-bubble.received {
  background-color: white;
  color: var(--text);
  border: 1px solid var(--border);
  border-bottom-left-radius: 4px;
  align-self: flex-start;
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.05);
}

/* Message Input */
.message-input-area {
  display: flex;
  padding: 1rem 1.5rem;
  gap: 1rem;
  border-top: 1px solid var(--border);
  background-color: var(--card);
}

.message-input-area input {
  flex-grow: 1;
  padding: 0.75rem 1.25rem;
  border-radius: 24px;
  border: 1px solid var(--border);
  background-color: var(--bg);
  color: var(--text);
  font-size: 1rem;
  outline: none;
}

.message-input-area button {
  padding: 0.75rem 1.5rem;
  border: none;
  background-color: var(--primary);
  color: white;
  border-radius: 24px;
  cursor: pointer;
  font-weight: 600;
  transition: background 0.2s ease;
}

.message-input-area button:hover {
  background-color: #6244d3;
}

/* Empty State */
.no-chat-selected {
  display: flex;
  align-items: center;
  justify-content: center;
  height: 100%;
  color: #888;
  font-size: 1rem;
  font-weight: 500;
}

</style>