<template>
  <div class="card" :style="{ backgroundColor: color }">
    <div class="card-content">
      <span class="icon">{{ icon }}</span>
      <h3 class="title">{{ title }}</h3>
    </div>
    <div v-if="value !== undefined" class="card-value">{{ value }}</div>
  </div>
</template>

<script setup>
defineProps(['title', 'color', 'icon', 'value'])
</script>

<style scoped>
.card {
  border-radius: var(--card-radius);
  padding: 1rem;
  width: 200px;
  min-height: 100px;
  text-align: center;
  font-weight: bold;
  box-shadow: var(--shadow);
  display: flex;
  flex-direction: column;
  justify-content: flex-end;
  align-items: center;
  background: var(--card, #fff);
}
.card-content {
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
}
.icon {
  font-size: 2rem;
  margin-bottom: 0.5rem;
}
.title {
  margin: 0;
  font-size: 1.1rem;
  font-weight: bold;
}
.card-value {
  font-size: 2.0rem;
  margin-bottom: 0.2rem;
  font-weight: normal;
}
</style>