<template>
  <div class="grading-bg">
    <main class="main">
      <!-- <Header title="Response & Evaluation 📝" subtitle="Review and evaluate student responses to subjective assignments" /> -->
      <header style="color: whitesmoke;">
        <h1>Response & Evaluation 📝</h1>
        <p>Review and evaluate student responses to subjective assignments</p>
      </header>
      <!-- Status Summary Cards -->
      <div class="grading-status-cards">
        <div class="status-card pending">
          <span class="status-count">{{ summary.pending }}</span>
          <span class="status-label">Pending Review</span>
        </div>
        
        <div class="status-card evaluated">
          <span class="status-count">{{ summary.evaluated }}</span>
          <span class="status-label">Evaluated</span>
        </div>
        
      </div>

      <!-- Student Responses List -->
      <div class="grading-responses-section">
        <div class="responses-header">
          <input type="text" v-model="search" placeholder="Search by student name, assignment, or subject..." class="search-input" />
          <select v-model="statusFilter" class="status-filter">
            <option value="">All Status</option>
            <option value="pending">Pending Review</option>
            <option value="evaluated">Evaluated</option>
          </select>
        </div>
        <div v-if="loading" style="text-align:center;padding:2rem;">Loading...</div>
        <div v-else>
          <div v-for="response in filteredResponses" :key="response.id" class="response-card">
            <div class="response-header">
              <div>
                <div class="assignment-title"><strong>Assignment Title:</strong> {{ response.assignment_title }}</div>
                <div class="student-name"><strong>Student Name:</strong> {{ response.student_name }}</div>
                <div class="meta">
                  <span>{{ response.subject }}</span>
                  <span>{{ formatDate(response.submitted_at) }}</span>
                </div>
              </div>
              <div class="response-status">
                <span :class="['status-badge', response.status]">{{ statusLabel(response.status) }}</span>
                <span v-if="response.score !== null" class="score-badge">{{ response.score }}/100</span>
              </div>
            </div>
            <div class="response-actions">
              <button
                v-if="response.status === 'pending'"
                @click="openEvaluation(response)"
                class="evaluate-btn"
              >Start Evaluation</button>
              <button
                v-else-if="response.status === 'evaluated'"
                @click="openEvaluation(response)"
                class="evaluate-btn"
              >Show Evaluation</button>
              <button
                v-else
                @click="openEvaluation(response)"
                class="evaluate-btn"
              >View/Edit Evaluation</button>
            </div>
          </div>
          <div v-if="filteredResponses.length === 0" style="text-align:center;color:#888;padding:2rem;">No responses found.</div>
        </div>
      </div>

      <!-- Evaluation Modal -->
      <div v-if="showModal" class="modal-overlay">
        <div class="modal-card">
          <div class="modal-header">
            <h3 v-if="!isReadOnly">Evaluate Response - {{ selectedResponse.student_name }}</h3>
            <h3 v-else>Student - {{ selectedResponse.student_name }}</h3>
            <button class="close-btn" @click="closeModal">×</button>
          </div>
          <div class="modal-content">
            <div class="modal-assignment-title">Assignment Title: {{ selectedResponse.assignment_title }}</div>
            <div class="modal-meta">
              <span>{{ selectedResponse.subject }}</span>
              
            </div>
            <div class="modal-section">
              <h4>Student Response</h4>
              <div class="modal-response-text">{{ selectedResponse.full_answer }}</div>
            </div>
            <div v-if="isReadOnly" class="modal-section">
              <h4>Total Score</h4>
              <div class="modal-score-text">{{ selectedResponse.score !== undefined && selectedResponse.score !== null ? selectedResponse.score : 'N/A' }}/100</div>
            </div>
            <div v-if="!isReadOnly" class="modal-section">
              <h4>Rubric Scoring (0-100 each):</h4>
              <div class="rubric-grid">
                <div v-for="rubric in rubricFields" :key="rubric.key" class="rubric-item">
                  <label>{{ rubric.label }}</label>
                  <input
                    type="number"
                    v-model.number="rubricScores[rubric.key]"
                    min="0"
                    max="100"
                    placeholder="Score (0-100)"
                  />
                </div>
              </div>
              <div class="total-score">
                <label>Total Score (average):</label>
                <input type="number" :value="totalScore" readonly />
              </div>
            </div>
            <div class="modal-section">
              <h4>Feedback for Student</h4>
              <textarea v-model="feedbackText" :readonly="isReadOnly" placeholder="Provide constructive feedback for the student..." />
            </div>
            <div v-if="validationError" class="error-msg">{{ validationError }}</div>
          </div>
          <div class="modal-actions" v-if="!isReadOnly">
            <button class="save-btn" @click="saveEvaluation" :disabled="saving">Save Evaluation</button>
            <button class="cancel-btn" @click="closeModal">Cancel</button>
          </div>
          <div class="modal-actions" v-else>
            <button class="cancel-btn" @click="closeModal">Close</button>
          </div>
        </div>
      </div>

      <!-- Confirmation Modal -->
      <div v-if="showConfirmModal" class="modal-overlay">
        <div class="modal-card">
          <div class="modal-header">
            <h3>Confirm Evaluation</h3>
          </div>
          <div class="modal-content">
            <p><strong>Content Knowledge:</strong> {{ rubricScores.content }}</p>
            <p><strong>Organization:</strong> {{ rubricScores.organization }}</p>
            <p><strong>Writing Quality:</strong> {{ rubricScores.writing }}</p>
            <p><strong>Critical Thinking:</strong> {{ rubricScores.critical }}</p>
            <p><strong>Total Score (average):</strong> {{ totalScore }}</p>
            <p><strong>Feedback:</strong> {{ feedbackText }}</p>
            <div style="color: #d00; margin-top: 1rem;">Once confirmed, this evaluation cannot be edited.</div>
          </div>
          <div class="modal-actions">
            <button class="save-btn" @click="confirmSaveEvaluation" :disabled="saving">Confirm & Save</button>
            <button class="cancel-btn" @click="showConfirmModal = false">Edit</button>
          </div>
        </div>
      </div>
    </main>
  </div>
</template>

<script setup>
import Header from './Header.vue'
import { ref, computed, onMounted } from 'vue'
import { useRoute } from 'vue-router'
import api from '@/api'

const route = useRoute()
const teacher_id = route.params.teacher_id

const summary = ref({
  pending: 0,
  in_progress: 0,
  evaluated: 0,
  feedback_sent: 0
})

const responses = ref([])
const loading = ref(false)
const saving = ref(false)
const search = ref('')
const statusFilter = ref('')

const rubricFields = [
  { key: 'content', label: 'Content Knowledge' },
  { key: 'organization', label: 'Organization' },
  { key: 'writing', label: 'Writing Quality' },
  { key: 'critical', label: 'Critical Thinking' }
]

const rubricScores = ref({
  content: 0,
  organization: 0,
  writing: 0,
  critical: 0
})
const feedbackText = ref('')
const validationError = ref('')

const totalScore = computed(() => {
  const vals = Object.values(rubricScores.value)
  return Math.round(vals.reduce((a, b) => a + b, 0) / vals.length)
})

const showModal = ref(false)
const showConfirmModal = ref(false)
const selectedResponse = ref({})
const isReadOnly = ref(false)

function statusLabel(status) {
  if (status === 'pending') return 'Pending Review'
  if (status === 'in_progress') return 'In Progress'
  if (status === 'evaluated') return 'Evaluated'
  if (status === 'feedback_sent') return 'Feedback Sent'
  return status
}

function formatDate(dateStr) {
  if (!dateStr) return ''
  const d = new Date(dateStr)
  return d.toLocaleString('en-US', { dateStyle: 'short', timeStyle: 'short' })
}

function getAnswerPreview(answer) {
  if (!answer) return ''
  return answer.length > 80 ? answer.slice(0, 80) + '...' : answer
}

async function fetchResponses() {
  loading.value = true
  try {
    const res = await api.get(`/teacher/teacher/${teacher_id}/evaluations`)
    responses.value = res.data.map(sub => ({
      id: sub.id,
      student_name: sub.student_name || 'Unknown',
      assignment_title: sub.assignment?.title || 'Untitled',
      subject: sub.assignment?.subject?.name
        ? `${sub.assignment.subject.name} • ${sub.assignment.question_type === 'text' ? 'Essay' : 'Objective'}`
        : '',  
      submitted_at: sub.created_at,
      status: sub.status,
      score: sub.score?.score ?? null,
      answer_preview: getAnswerPreview(sub.answer),
      full_answer: sub.answer,
      rubric: sub.score?.rubric || {},
      feedback: sub.score?.feedback || ''
    }))
    updateSummary()
  } catch (e) {
    alert('Failed to load responses')
  }
  loading.value = false
}

function updateSummary() {
  const counts = { pending: 0, in_progress: 0, evaluated: 0, feedback_sent: 0 }
  for (const r of responses.value) {
    if (r.status === 'pending') counts.pending++
    else if (r.status === 'in_progress') counts.in_progress++
    else if (r.status === 'evaluated') counts.evaluated++
    else if (r.status === 'feedback_sent') counts.feedback_sent++
  }
  summary.value = counts
}

const filteredResponses = computed(() => {
  let list = responses.value
  if (search.value) {
    const s = search.value.toLowerCase()
    list = list.filter(r =>
      r.student_name.toLowerCase().includes(s) ||
      r.assignment_title.toLowerCase().includes(s) ||
      (r.subject && r.subject.toLowerCase().includes(s))
    )
  }
  if (statusFilter.value) {
    list = list.filter(r => r.status === statusFilter.value)
  }
  return list
})

function validateRubric() {
  for (const key of Object.keys(rubricScores.value)) {
    const val = rubricScores.value[key]
    if (val < 0 || val > 100 || isNaN(val)) {
      validationError.value = 'Each rubric score must be between 0 and 100.'
      return false
    }
  }
  validationError.value = ''
  return true
}

async function openEvaluation(response) {
  if (response.status === 'evaluated') {
    try {
      // Fetch evaluation details from the correct endpoint
      const res = await api.get(`/teacher/submission/${response.id}/evaluation`);
      selectedResponse.value = {
        ...response,
        full_answer: res.data.student_answer,
        score: res.data.score,
        feedback: res.data.feedback,
        status: res.data.status
      };
      // If rubric details are available, set them here (else set to 0)
      rubricScores.value = {
        content: 0,
        organization: 0,
        writing: 0,
        critical: 0
      };
      feedbackText.value = res.data.feedback || '';
      showModal.value = true;
      isReadOnly.value = true;
    } catch (e) {
      alert('Failed to load evaluation details');
    }
  } else {
    try {
      const res = await api.get(`/teacher/submission/${response.id}/details`)
      selectedResponse.value = {
        ...response,
        full_answer: res.data.submission.answer,
      }
      rubricScores.value = {
        content: 0,
        organization: 0,
        writing: 0,
        critical: 0
      }
      feedbackText.value = response.feedback || ''
      showModal.value = true
      isReadOnly.value = false
    } catch (e) {
      alert('Failed to load submission details')
    }
  }
}

function closeModal() {
  showModal.value = false
  showConfirmModal.value = false
  validationError.value = ''
}

async function saveEvaluation() {
  if (!validateRubric()) return
  showConfirmModal.value = true
}

async function confirmSaveEvaluation() {
  saving.value = true
  try {
    await api.post(
      `/teacher/submission/${selectedResponse.value.id}/evaluate?score=${totalScore.value}&feedback=${encodeURIComponent(feedbackText.value)}&teacher_id=${teacher_id}`
    )
    showModal.value = false
    showConfirmModal.value = false // <-- Ensure confirmation modal is closed
    await fetchResponses()
  } catch (e) {
    alert('Failed to save evaluation')
  }
  saving.value = false
}

async function sendFeedback(response) {
  // If you want a feedback endpoint, implement it in backend.
  alert('Feedback sent! (Implement feedback endpoint if needed)')
}

onMounted(fetchResponses)
</script>

<style>
:root {
  --bg: #f5f5fa;
  --card: #fff;
  --text: #222;
  --text-secondary: #444;
  --primary: #a020f0;
  --primary-hover: #7c1bb3;
  --border: #e0e0e0;
  --shadow: 0 4px 24px rgba(160,32,240,0.08);
}

.dark-mode {
  --bg: #181824;
  --card: #23233a;
  --text: #f3f3f3;
  --text-secondary: #bdbdbd;
  --primary: #a020f0;
  --primary-hover: #7c1bb3;
  --border: #333;
  --shadow: 0 4px 24px rgba(160,32,240,0.18);
}

.grading-bg {
  min-height: 100vh;
  background:transparent;
}

.main {
  color: var(--text);
  background:transparent;
  padding: 2rem;
}

.grading-status-cards {
  display: flex;
  gap: 1.5rem;
  margin-bottom: 2rem;
}
.status-card {
  background: var(--card);
  color: var(--text);
  border-radius: 16px;
  box-shadow: var(--shadow);
  padding: 1.2rem 2rem;
  display: flex;
  flex-direction: column;
  align-items: center;
  min-width: 140px;
  font-weight: 600;
}
.status-count {
  font-size: 2rem;
  font-weight: 700;
}
.status-label {
  font-size: 1rem;
  color: var(--text-secondary);
  margin-top: 0.3rem;
}

.grading-responses-section {
  margin-top: 1.5rem;
}
.responses-header {
  display: flex;
  gap: 1rem;
  margin-bottom: 1.2rem;
}
.search-input {
  flex: 1;
  padding: 0.7rem 1rem;
  border-radius: 8px;
  border: 1px solid var(--border);
  background: var(--card);
  color: var(--text);
  font-size: 1rem;
}
.status-filter {
  padding: 0.7rem 1rem;
  border-radius: 8px;
  border: 1px solid var(--border);
  background: var(--card);
  color: var(--text);
  font-size: 1rem;
}

.response-card {
  background: var(--card);
  color: var(--text);
  border-radius: 16px;
  box-shadow: var(--shadow);
  padding: 1.2rem 1.5rem;
  margin-bottom: 1.2rem;
  border: 1px solid var(--border);
}
.response-header {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  margin-bottom: 0.7rem;
}
.student-name {
  font-weight: 700;
  font-size: 1.1rem;
}
.assignment-title {
  font-weight: 600;
  font-size: 1rem;
  margin-top: 0.2rem;
}
.meta {
  font-size: 0.95rem;
  color: var(--text-secondary);
  margin-top: 0.2rem;
  display: flex;
  gap: 1.2rem;
}
.response-status {
  display: flex;
  flex-direction: column;
  align-items: flex-end;
  gap: 0.3rem;
}
.status-badge {
  padding: 3px 12px;
  border-radius: 12px;
  font-size: 0.95rem;
  font-weight: 600;
  background: #ffe0a3;
  color: #a020f0;
}
.status-badge.pending { background: #ffe0a3; color: #a020f0; }
.status-badge.in_progress { background: #e0e7ff; color: #3b3bff; }
.status-badge.evaluated { background: #e3ffe3; color: #1bbf1b; }
.status-badge.feedback_sent { background: #ffb3c6; color: #d72660; }
.score-badge {
  background: #e0e7ff;
  color: #3b3bff;
  border-radius: 10px;
  padding: 2px 10px;
  font-size: 0.95rem;
  font-weight: 600;
}

.response-body {
  margin-bottom: 0.7rem;
  color: var(--text-secondary);
}
.response-actions {
  display: flex;
  gap: 1rem;
}
.evaluate-btn, .feedback-btn {
  padding: 0.6rem 1.2rem;
  border-radius: 8px;
  border: none;
  font-weight: 600;
  font-size: 1rem;
  cursor: pointer;
  background: blue;
  color: #fff;
  transition: background 0.2s;
}
.feedback-btn {
  background: #ffe0a3;
  color: #a020f0;
}
.evaluate-btn:hover {
  background: var(--primary-hover);
}
.feedback-btn:hover {
  background: #ffd580;
}

.modal-overlay {
  position: fixed;
  top: 0; left: 0; right: 0; bottom: 0;
  background: rgba(0,0,0,0.45);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
}
.modal-card {
  background: var(--card);
  color: var(--text);
  border-radius: 18px;
  box-shadow: 0 8px 32px rgba(160,32,240,0.18);
  padding: 2rem 2.5rem;
  min-width: 420px;
  max-width: 540px;
  position: relative;
}
.modal-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 1.2rem;
}
.close-btn {
  background: none;
  border: none;
  font-size: 2rem;
  color: var(--primary);
  cursor: pointer;
}
.modal-assignment-title {
  font-weight: 700;
  font-size: 1.1rem;
  margin-bottom: 0.2rem;
}
.modal-meta {
  font-size: 0.95rem;
  color: var(--text-secondary);
  margin-bottom: 1rem;
  display: flex;
  gap: 1.2rem;
}
.modal-section {
  margin-bottom: 1.2rem;
}
.modal-response-text {
  background: var(--bg);
  color: var(--text);
  border-radius: 8px;
  padding: 1rem;
  font-size: 1rem;
  margin-top: 0.3rem;
}
.rubric-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 1rem;
  margin-bottom: 1rem;
}
.rubric-item label {
  font-weight: 600;
  font-size: 1rem;
  margin-bottom: 0.2rem;
  display: block;
}
.rubric-item input {
  width: 100%;
  padding: 0.5rem;
  border-radius: 8px;
  border: 1px solid var(--border);
  background: var(--bg);
  color: var(--text);
  font-size: 1rem;
}
.total-score {
  margin-top: 0.5rem;
}
.total-score label {
  font-weight: 600;
  margin-right: 0.7rem;
}
.total-score input {
  width: 80px;
  padding: 0.5rem;
  border-radius: 8px;
  border: 1px solid var(--border);
  background: var(--bg);
  color: var(--text);
  font-size: 1rem;
}
.modal-section textarea {
  width: 100%;
  min-height: 60px;
  border-radius: 8px;
  border: 1px solid var(--border);
  background: var(--bg);
  color: var(--text);
  font-size: 1rem;
  padding: 0.7rem;
}
.modal-actions {
  display: flex;
  gap: 1rem;
  justify-content: flex-end;
  margin-top: 1.2rem;
}
.save-btn, .cancel-btn {
  padding: 0.7rem 1.5rem;
  border-radius: 8px;
  border: none;
  font-weight: 600;
  font-size: 1rem;
  cursor: pointer;
}
.save-btn {
  background: var(--primary);
  color: #fff;
}
.save-btn:hover {
  background: var(--primary-hover);
}
.cancel-btn {
  background: #eee;
  color: var(--text);
}
.cancel-btn:hover {
  background: #ddd;
}
.error-msg {
  color: #d00;
  font-size: 0.9rem;
  margin-top: 0.5rem;
}
</style>