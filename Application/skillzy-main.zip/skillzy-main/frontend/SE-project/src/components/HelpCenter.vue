<template>
  <div class="help-center-page">
    <main class="main">
      <header class="header">
        <h1>Help Center</h1>
        <p>Support tickets from users</p>
      </header>
      <section class="overview-metrics-grid">
        <MetricCard icon="📊" :value="totalTickets" label="Total Tickets"  iconBg="linear-gradient(135deg, #6a11cb 0%, #2575fc 100%)"  />
        <MetricCard icon="🚨" :value="openTickets" label="Open Tickets"  iconBg="linear-gradient(135deg, #a020f0 0%, #f72585 100%)"/>
        <MetricCard icon="✅" :value="resolvedToday" label="Resolved Today"  iconBg="linear-gradient(135deg, #FF6B6B 0%, #FFD166 100%)" />
        <!-- <MetricCard icon="⏱️" :value="avgResponse" label="Pending Requests"  iconBg="linear-gradient(135deg, #4ef013 0%, #00bc40 100%)" /> -->
      </section>



      <section class="support-tickets-card">
        <div class="card-header">
          <h3>Support Tickets</h3>
          <div class="controls">
            <input
              type="text"
              v-model="searchQuery"
              placeholder="Search tickets by subject or user"
              class="search-input"
            />
            <select v-model="statusFilter" class="filter-select">
              <option value="">All Status</option>
              <option value="open">Open</option>
              <!-- <option value="closed">Closed</option> -->
              <option value="resolved">Resolved</option>
            </select>
            <select v-model="priorityFilter" class="filter-select">
              <option value="">All Priority</option>
              <option value="high">High</option>
              <option value="medium">Medium</option>
              <option value="low">Low</option>
            </select>
          </div>
        </div>

        <div class="ticket-list">
          <div v-if="paginatedTickets.length === 0" class="no-tickets-message">
            <strong>No support tickets found.........</strong>
          </div>

          <div
            v-for="ticket in paginatedTickets"
            :key="ticket.id"
            class="ticket"
            :class="{ expanded: expandedTicketId === ticket.id }"
          >

            <div class="ticket-summary" @click="toggleExpand(ticket.id)">
              <div class="info">
                <span class="type-label">{{ roleCategoryCode(ticket.user?.role_name || 'user', ticket.type || 'Admin') }}</span>
                <span class="subject">{{ ticket.title }}</span>
                <span :class="['status-pill', ticket.status || 'open']">{{ ticket.status || 'open' }}</span>
                <span :class="['priority-pill', getPriority(ticket)]">{{ getPriority(ticket) }}</span>
              </div>
              <div class="meta">
                <span class="time">{{ formatTime(ticket.created_at) }}</span>
                <button class="view-icon-btn">
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-eye"><path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/></svg>
                </button>
              </div>
            </div>

            <div v-if="expandedTicketId === ticket.id" class="ticket-details">
              
<p><strong>From (unique_username):</strong> {{ ticket.user?.username || 'Unknown' }} (role: {{ ticket.user?.role_name || 'user' }})</p>
<p><strong>Email:</strong> {{ ticket.user?.email || 'N/A' }}</p>
<p><strong>Reported User:</strong> {{ parseContent(ticket.content).reportedUser }}</p>
<p><strong>Message:</strong></p>
<p class="message">{{ parseContent(ticket.content).message }}</p>


              <div class="ticket-actions-row">
                <button @click.stop="viewProfile(ticket.user_id)" class="action-btn icon-text-btn">
                  <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-check-circle"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><path d="m9 11 3 3L22 4"/></svg>
                  View Profile</button>
                
                 <button
                   v-if="ticket.status !== 'resolved'"
                   @click.stop="markAsResolved(ticket.id)"
                   class="action-btn success-btn icon-text-btn">
                  <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-check-circle"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><path d="m9 11 3 3L22 4"/></svg>
                  Resolve
                </button>
                
              </div>
            </div>
          </div>
        </div>

        <div class="table-footer">
          <div class="results-summary">
            Showing {{ (currentPage - 1) * itemsPerPage + 1 }} - {{ Math.min(currentPage * itemsPerPage, filteredTickets.length) }} of {{ filteredTickets.length }} tickets
          </div>
          <div class="pagination">
            <button @click="prevPage" :disabled="currentPage === 1">Previous</button>
            <button
              v-for="page in totalPages"
              :key="page"
              @click="goToPage(page)"
              :class="{ active: currentPage === page }"
            >
              {{ page }}
            </button>
            <button @click="nextPage" :disabled="currentPage === totalPages">Next</button>
          </div>
        </div>
      </section>

      <div v-if="selectedUser" class="modal-overlay" @click.self="closeModal">
        <div class="modal">
          <div class="modal-header">
            <h3>User Profile</h3>
            <button class="close-btn" @click="selectedUser = null">✖</button>
          </div>
          <div class="modal-body">
            
            <p><strong>ID:</strong> {{ selectedUser.id }}</p>
            <p><strong>Name:</strong> {{ selectedUser.full_name }}</p>
            <p><strong>Email:</strong> {{ selectedUser.email }}</p>
            <p><strong>Username:</strong> {{ selectedUser.username }}</p>
            <p><strong>Status:</strong> {{ selectedUser.banned ? 'Banned' : 'Active' }}</p>
          </div>
        </div>
      </div>
    </main>
  </div>
</template>

<script setup>
import { ref, computed, onMounted} from 'vue';
import api from '../api';
import { store } from '@/store'
import MetricCard from '@/components/MetricCard.vue';  

const tickets = ref([]);
const searchQuery = ref('');
const statusFilter = ref('');
const priorityFilter = ref('');
const currentPage = ref(1);
const itemsPerPage = 6;
const expandedTicketId = ref(null);
const selectedUser = ref(null);


const fetchReportsData = async () => {
  try {
    const response = await api.get('/admin/reports/dashboard');
    const data = response.data;  // Extract data from Axios response
    tickets.value = data.reports || [];
    console.log('Final tickets:', tickets.value);
  } catch (error) {
    console.error('Error fetching reports:', error);
  }
};
// Helper functions
const getPriority = (report) => {
  if (report.type === 'Safety' || report.type === 'Behavioral') return 'high';
  if (report.type === 'Academic') return 'medium';
  return 'low';
};

const formatTime = (dateString) => {
  if (!dateString) return 'N/A';
  const now = new Date();
  const date = new Date(dateString);
  const diff = now - date;
  const minutes = Math.floor(diff / 60000);
  const hours = Math.floor(minutes / 60);
  const days = Math.floor(hours / 24);
  
  if (minutes < 60) return `${minutes} minutes ago`;
  if (hours < 24) return `${hours} hours ago`;
  if (days < 7) return `${days} days ago`;
  return `${Math.floor(days / 7)} weeks ago`;
};

const roleCategoryCode = (role, category) => {
  const roleCode = role?.charAt(0)?.toUpperCase() || 'U';
  const categoryCode = category?.charAt(0)?.toUpperCase() || 'G';
  return `${roleCode}-${categoryCode}`;
};

// Computed properties
const totalTickets = computed(() => tickets.value.length);
const openTickets = computed(() => tickets.value.filter(r => (r.status || 'open') !== 'resolved').length);
const resolvedToday = computed(() => {
  const today = new Date().toDateString();
  return tickets.value.filter(r => 
    r.resolved_at && new Date(r.resolved_at).toDateString() === today
  ).length;
});
const avgResponse = computed(() => tickets.value.filter(r => (r.status || 'open') === 'pending').length);

const filteredTickets = computed(() => {
  return tickets.value.filter(ticket => {
    const matchesSearch =
      ticket.title?.toLowerCase().includes(searchQuery.value.toLowerCase()) ||
      ticket.content?.toLowerCase().includes(searchQuery.value.toLowerCase());
    const matchesStatus = !statusFilter.value || (ticket.status || 'open') === statusFilter.value;
    const matchesPriority = !priorityFilter.value || getPriority(ticket) === priorityFilter.value;
    return matchesSearch && matchesStatus && matchesPriority;
  });
});

const totalPages = computed(() =>
  Math.max(1, Math.ceil(filteredTickets.value.length / itemsPerPage))
);

const paginatedTickets = computed(() => {
  const start = (currentPage.value - 1) * itemsPerPage;
  return filteredTickets.value.slice(start, start + itemsPerPage);
});

// Action methods
const toggleExpand = (ticketId) => {
  expandedTicketId.value = expandedTicketId.value === ticketId ? null : ticketId;
};

const viewProfile = async (userId) => {
  try {
    const user = await api.get(`/admin/user/search?user_id=${userId}`);
    selectedUser.value = user.data;
  } catch (error) {
    console.error('Error fetching user:', error);
  }
};

const messageUser = (userId) => {
  const message = prompt('Enter message:');
  if (message) {
    // Store message in localStorage for later sending
    const messages = JSON.parse(localStorage.getItem('pending_messages') || '[]');
    messages.push({
      userId,
      message,
      timestamp: new Date().toISOString()
    });
    localStorage.setItem('pending_messages', JSON.stringify(messages));
    alert(`Message queued for user ${userId}`);
  }
};

const parseContent = (content = '') => {
  const lines = content.split('\n');
  const reportedLine = lines.find(line => line.toLowerCase().includes('reported user'));
  const reportedUser = reportedLine?.split(':')[1]?.trim() || 'Unknown';

  const message = lines
    .filter(line => !line.toLowerCase().includes('reported user'))
    .join('\n')
    .trim();

  return { reportedUser, message };
};


const banUser = async (userId) => {
  if (confirm('Ban this user?')) {
    try {
      await api.put(`/admin/user/${userId}/block`);
      alert('User banned');
      await fetchReportsData();
    } catch (error) {
      console.error('Error banning user:', error);
    }
  }
};

const markAsResolved = async (reportId) => {
  if (confirm('Mark as resolved?')) {
    try {
      await api.put(`/admin/report/${reportId}/resolve`);
      alert('Report resolved');
      
      // Update local storage with resolved report
      const resolvedReports = JSON.parse(localStorage.getItem('resolved_reports') || '[]');
      resolvedReports.push({
        reportId,
        resolvedAt: new Date().toISOString(),
        resolvedBy: store.user?.id || 'admin'
      });
      localStorage.setItem('resolved_reports', JSON.stringify(resolvedReports));
      
      await fetchReportsData();
    } catch (error) {
      console.error('Error resolving report:', error);
    }
  }
};

const replyToTicket = async (reportId) => {
  const message = prompt('Enter reply:');
  if (message) {
    try {
      await api.post(`/admin/report/${reportId}/reply`, { message });
      alert('Reply sent');
      
      // Store reply in localStorage
      const replies = JSON.parse(localStorage.getItem('admin_replies') || '[]');
      replies.push({
        reportId,
        message,
        timestamp: new Date().toISOString(),
        adminId: store.user?.id || 'admin'
      });
      localStorage.setItem('admin_replies', JSON.stringify(replies));
      
    } catch (error) {
      console.error('Error sending reply:', error);
    }
  }
};

const closeModal = () => {
  selectedUser.value = null;
};

// Pagination
const prevPage = () => {
  if (currentPage.value > 1) {
    currentPage.value--;
    // Save pagination state
    localStorage.setItem('reports_current_page', currentPage.value.toString());
  }
};

const nextPage = () => {
  if (currentPage.value < totalPages.value) {
    currentPage.value++;
    // Save pagination state
    localStorage.setItem('reports_current_page', currentPage.value.toString());
  }
};

const goToPage = (page) => {
  currentPage.value = page;
  // Save pagination state
  localStorage.setItem('reports_current_page', page.toString());
};

// Initialize
onMounted(() => {
  // Restore pagination state
  const savedPage = localStorage.getItem('reports_current_page');
  if (savedPage) {
    currentPage.value = parseInt(savedPage);
  }
  
  // Restore filter states
  const savedFilters = JSON.parse(localStorage.getItem('reports_filters') || '{}');
  if (savedFilters.status) statusFilter.value = savedFilters.status;
  if (savedFilters.priority) priorityFilter.value = savedFilters.priority;
  if (savedFilters.search) searchQuery.value = savedFilters.search;
  
  fetchReportsData();
});

// Save filters to localStorage when they change
const saveFilters = () => {
  const filters = {
    status: statusFilter.value,
    priority: priorityFilter.value,
    search: searchQuery.value
  };
  localStorage.setItem('reports_filters', JSON.stringify(filters));
};

// Watch for filter changes
import { watch } from 'vue';
watch([searchQuery, statusFilter, priorityFilter], saveFilters);

</script>

<style scoped>
.help-center-page {
  /* No background here */
}

.main {
  flex: 1;
  padding: 2rem;
  color: var(--text);
  background: linear-gradient(135deg, #427eff, #b72eff);

  width: 100%;
  min-height: calc(100vh - 2rem); /* Adjust for top padding */
  box-sizing: border-box;
  position: relative;
  z-index: 1;
}

.overview-metrics-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
  gap: 1.5rem;
  margin-bottom: 2rem;
  background: transparent;
  padding: 1 rem;
  border-radius: 12px;
}

.support-tickets-card {
  background-color: var(--card);
  padding: 1.5rem 2rem;
  border-radius: 12px;
  box-shadow: var(--shadow);
  border: 1px solid var(--border);
}

.support-tickets-card .card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 1.5rem;
  flex-wrap: wrap;
  gap: 1rem;
}

.support-tickets-card h3 {
  margin: 0;
  font-size: 1.5rem;
  font-weight: 600;
  color: var(--text);
}

.support-tickets-card .controls {
  display: flex;
  gap: 1rem;
  align-items: center;
  flex-wrap: wrap;
}

.search-input,
.filter-select {
  padding: 0.75rem 1rem;
  font-size: 0.95rem;
  border-radius: 8px;
  border: 1px solid var(--border);
  background-color: var(--bg);
  color: var(--text);
  transition: border-color 0.2s ease, box-shadow 0.2s ease;
}

.search-input:focus,
.filter-select:focus {
  outline: none;
  border-color: var(--primary);
  box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.2);
}

.ticket-list {
  display: flex;
  flex-direction: column;
  gap: 0.8rem;
}
.ticket {
  background: var(--bg);
  border-radius: 8px;
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.03);
  cursor: pointer;
  padding: 1rem;
  transition: all 0.2s ease;
  border: 1px solid var(--border);
}
.ticket:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.08);
}
.ticket.expanded {
  border-color: var(--primary);
}
.ticket-summary {
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.ticket .info {
  display: flex;
  align-items: center;
  gap: 0.75rem;
}
.ticket .type-label {
  font-weight: 600;
  background: #a78bfa;
  color: white;
  padding: 4px 8px;
  border-radius: 6px;
  font-size: 0.8rem;
  min-width: 60px;
  text-align: center;
}
.ticket .subject {
  flex-grow: 1;
  font-size: 1rem;
  font-weight: 500;
  color: var(--text);
}

.status-pill, .priority-pill {
  display: inline-block;
  padding: 3px 10px;
  border-radius: 15px;
  font-size: 0.75rem;
  font-weight: 600;
  text-transform: capitalize;
  text-align: center;
  white-space: nowrap;
  margin-left: 0.5rem;
}

.status-pill.open { background-color: #e0f2fe; color: #0284c7; }
.status-pill.closed { background-color: #dcfce7; color: #166534; }
.status-pill.resolved { background-color: #d1fae5; color: #065f46; }

.priority-pill.high { background-color: #fee2e2; color: #991b1b; }
.priority-pill.medium { background-color: #fefce8; color: #854d0e; }
.priority-pill.low { background-color: #dcfce7; color: #166534; }

.ticket-summary .meta {
  display: flex;
  align-items: center;
  gap: 0.5rem;
}
.ticket .time {
  font-size: 0.8rem;
  color: var(--text-secondary);
}
.view-icon-btn {
  background: none;
  border: none;
  color: var(--text-secondary);
  cursor: pointer;
  padding: 0;
  display: flex;
  align-items: center;
  transition: color 0.2s ease;
}
.view-icon-btn:hover {
  color: var(--primary);
}

.ticket-details {
  margin-top: 1rem;
  border-top: 1px solid var(--border);
  padding-top: 1rem;
  font-size: 0.9rem;
  color: var(--text-secondary);
}
.ticket-details p {
  margin-bottom: 0.5rem;
}
.ticket-details strong {
  font-weight: 600;
  color: var(--text);
}
.ticket-details .message {
  background: var(--card);
  padding: 0.8rem;
  border-radius: 8px;
  margin-top: 0.75rem;
  white-space: pre-wrap;
  font-size: 0.95rem;
  border: 1px solid var(--border);
  color: var(--text);
}

.ticket-actions-row {
  display: flex;
  flex-wrap: wrap;
  gap: 0.75rem;
  margin-top: 1.5rem;
}

.action-btn {
  padding: 0.5rem 1rem;
  border: none;
  border-radius: 8px;
  font-size: 0.85rem;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.2s ease;
  display: flex;
  align-items: center;
  gap: 0.4rem;
}

.action-btn.primary-btn { background-color: var(--primary); color: white; }
.action-btn.warning-btn { background-color: #f97316; color: white; }
.action-btn.success-btn { background-color: #22c55e; color: white; }
.action-btn.icon-text-btn { background-color: var(--bg); color: var(--text); border: 1px solid var(--border); }

.action-btn:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
}
.action-btn.primary-btn:hover { background-color: var(--primary-hover); }
.action-btn.warning-btn:hover { background-color: #ea580c; }
.action-btn.success-btn:hover { background-color: #16a34a; }
.action-btn.icon-text-btn:hover { background-color: var(--primary); color: white; border-color: var(--primary); }

.table-footer {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding-top: 1.5rem;
  border-top: 1px solid var(--border);
  margin-top: 1.5rem;
  flex-wrap: wrap;
  gap: 1rem;
}
.results-summary {
  font-size: 0.9rem;
  color: var(--text-secondary);
}
.pagination {
  display: flex;
  gap: 0.5rem;
}
.pagination button {
  padding: 0.5rem 1rem;
  border: 1px solid var(--border);
  border-radius: 6px;
  background-color: var(--bg);
  color: var(--text);
  cursor: pointer;
  transition: all 0.2s ease;
  font-weight: 500;
}
.pagination button:hover:not(:disabled),
.pagination button.active {
  background-color: var(--primary);
  color: white;
  border-color: var(--primary);
}
.pagination button:disabled {
  opacity: 0.6;
  cursor: not-allowed;
}

.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.5);
  z-index: 1000;
  display: flex;
  align-items: center;
  justify-content: center;
}
.modal {
  background: var(--card);
  padding: 2rem;
  border-radius: 8px;
  width: 90%;
  max-width: 400px;
  animation: fadeIn 0.3s ease;
  box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
  color: var(--text);
}
.modal-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 1rem;
}
.close-btn {
  background: transparent;
  border: none;
  font-size: 1.2rem;
  cursor: pointer;
  color: var(--text);
}
.modal-body {
  text-align: center;
}
.modal-pic {
  width: 80px;
  height: 80px;
  border-radius: 50%;
  margin-bottom: 1rem;
}
@keyframes fadeIn {
  from {
    opacity: 0;
    transform: scale(0.96);
  }
  to {
    opacity: 1;
    transform: scale(1);
  }
}

@media (max-width: 900px) {
  .support-tickets-card .card-header {
    flex-direction: column;
    align-items: flex-start;
  }
  .support-tickets-card .controls {
    width: 100%;
    justify-content: space-between;
  }
  .search-input, .filter-select {
    flex-grow: 1;
  }
  .ticket-list {
    gap: 0.6rem;
  }
  .ticket {
    padding: 0.8rem;
  }
  .ticket .info {
    flex-direction: column;
    align-items: flex-start;
    gap: 0.4rem;
  }
  .ticket .subject {
    font-size: 0.9rem;
  }
  .status-pill, .priority-pill, .type-label {
    font-size: 0.7rem;
    padding: 2px 6px;
  }
  .ticket-details {
    font-size:0.85rem;
}
.ticket-actions-row {
gap: 0.5rem;
}
.action-btn {
padding: 0.4rem 0.8rem;
font-size: 0.75rem;
}
}

@media (max-width: 600px) {
.main {
padding: 1rem;
}
.overview-metrics-grid {
grid-template-columns: 1fr;
}
.support-tickets-card {
padding: 1rem;
}
.support-tickets-card .controls {
flex-direction: column;
gap: 0.8rem;
}
.search-input, .filter-select {
width: 100%;
}
.ticket {
padding: 0.6rem;
}
.ticket .info {
flex-direction: column;
gap: 0.3rem;
}
.ticket .subject {
font-size: 0.85rem;
}
.ticket-details {
font-size: 0.8rem;
}
.ticket-actions-row {
flex-direction: column;
gap: 0.4rem;
}
.action-btn {
width: 100%;
padding: 0.3rem;
font-size: 0.7rem;
}
.table-footer {
flex-direction: column;
align-items: center;
gap: 0.8rem;
}
}

.header{
  color: white;
}
</style>