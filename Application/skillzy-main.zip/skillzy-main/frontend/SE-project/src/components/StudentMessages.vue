<template>
  <div>
    <Header title="Messages & Feedback" subtitle="Stay updated with important notifications and feedback." />

    <section class="messages-container">
      <div v-for="message in messages" :key="message.id" class="message-card">
        <div class="message-header">
          <h3>{{ message.title }}</h3>
          <span class="tag" :class="message.type">{{ message.type }}</span>
        </div>
        <p class="message-body">{{ message.content }}</p>
        <small class="message-meta">From: {{ message.sender }} • {{ formatDate(message.date) }}</small>
      </div>
    </section>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import Header from '../components/Header.vue'

// NOTE: Sidebar, router, and navLinks are removed to use the main StudentLayout.
// All message-specific data and functions are preserved.

const messages = ref([
  {
    id: 1,
    title: 'Assignment Feedback: Essay on Climate Change',
    content: 'Great structure and strong arguments. You’ve shown excellent improvement in forming cohesive paragraphs.',
    sender: 'Mrs. Sharma',
    type: 'feedback',
    date: '2025-06-09',
  },
  {
    id: 2,
    title: 'Upcoming Workshop: Debate & Public Speaking',
    content: 'You are enrolled for the debate skills workshop scheduled this weekend. Be prepared!',
    sender: 'Admin Team',
    type: 'notification',
    date: '2025-06-07',
  },
  {
    id: 3,
    title: 'New Assignment Posted: Math Practice Set 5',
    content: 'Please complete the algebra and geometry sections before Friday. Let me know if you face any doubts.',
    sender: 'Mr. Verma',
    type: 'announcement',
    date: '2025-06-06',
  },
  {
    id: 4,
    title: 'Participation Feedback: Science Fair',
    content: 'Your model was well-constructed and creative. Excellent effort in explaining the concept to the visitors.',
    sender: 'Dr. Rao',
    type: 'feedback',
    date: '2025-06-03',
  },
])

function formatDate(date) {
  return new Date(date).toLocaleDateString('en-IN', { weekday: 'short', day: 'numeric', month: 'short' })
}
</script>

<style scoped>
/* Scoped styles are preserved, with the top-level container class removed */
.messages-container {
  display: flex;
  flex-direction: column;
  gap: 1.25rem;
  margin-top: 2rem;
}

.message-card {
  background: var(--card);
  padding: 1.25rem 1.5rem;
  border-radius: 1rem;
  box-shadow: var(--shadow);
  transition: transform 0.2s ease;
}

.message-card:hover {
  transform: translateY(-2px);
}

.message-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 0.5rem;
}

.message-header h3 {
  font-size: 1.1rem;
  margin: 0;
}

.message-body {
  font-size: 0.95rem;
  margin-bottom: 0.5rem;
  color: var(--text-light);
}

.message-meta {
  font-size: 0.75rem;
  color: gray;
}

.tag {
  padding: 0.2rem 0.6rem;
  border-radius: 0.5rem;
  font-size: 0.75rem;
  font-weight: bold;
  text-transform: capitalize;
  color: white;
}

.tag.feedback { background: #10b981; }
.tag.notification { background: #3b82f6; }
.tag.announcement { background: #f59e0b; }
</style>