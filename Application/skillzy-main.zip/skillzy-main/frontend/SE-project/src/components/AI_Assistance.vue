<template>
  <div class="ai-assistance-page">
    <!-- Header -->
    <!-- <Header 
      title="AI Assistance Hub" 
      subtitle="Your intelligent study companion and task management assistant"
    /> -->

    <header class="ai-header" style="color: whitesmoke;">
      <h1>AI Assistance Hub</h1>
      <p>Your intelligent study companion and task management assistant</p>
    </header>
    <div class="ai-container">
      <!-- Main Content -->
      <div class="ai-main-content">
        <!-- Role-based Tab Navigation -->
        <div class="ai-tabs-container">
          <div v-if="userRole === 'student'" class="ai-tabs">
            <button 
              :class="['tab-btn', { active: activeTab === 'chatbot' }]" 
              @click="activeTab = 'chatbot'"
            >
              <span class="tab-icon">💬</span>
              <span class="tab-text">AI Chat Bot</span>
              <span class="tab-badge">Smart Helper</span>
            </button>
            <button 
              :class="['tab-btn', { active: activeTab === 'taskagent' }]" 
              @click="activeTab = 'taskagent'"
            >
              <span class="tab-icon">⚡</span>
              <span class="tab-text">Task Agent</span>
              <span class="tab-badge">Organizer</span>
            </button>
          </div>
          
          <!-- Single tab for teachers/parents -->
          <div v-else class="ai-tabs single-tab">
            <div class="tab-btn active">
              <span class="tab-icon">💬</span>
              <span class="tab-text">AI Chat Bot</span>
              <span class="tab-badge">Assistant</span>
            </div>
          </div>
        </div>

        <!-- Content Area -->
        <div class="ai-content-area">
          <!-- Chatbot Section -->
          <div v-if="activeTab === 'chatbot'" class="chat-section">
            <div class="section-grid">
              <!-- Chat Interface -->
              <div class="chat-panel">
                <div class="chat-header">
                  <div class="header-info">
                    <h3>
                      <span class="header-icon">🤖</span>
                      AI Study Buddy
                    </h3>
                    <p>Your friendly AI assistant for learning and homework help</p>
                  </div>
                  <div class="header-controls">
                    <button class="control-btn" @click="toggleDarkMode" :title="isDarkMode ? 'Light Mode' : 'Dark Mode'">
                      {{ isDarkMode ? '☀️' : '🌙' }}
                    </button>
                     <button 
    class="control-btn" 
    @click="toggleAudio" 
    :title="audioEnabled ? 'Disable Audio' : 'Enable Audio'"
    :class="{ 'audio-enabled': audioEnabled }"
  >
    {{ audioEnabled ? '🔊' : '🔇' }}
  </button>
                    <div class="status-indicator">
                      <div class="status-dot" :class="{ listening: isListening && currentMode === 'chatbot' }"></div>
                      <span>{{ isListening && currentMode === 'chatbot' ? 'Listening...' : 'Online' }}</span>
                    </div>
                  </div>
                </div>
                
                <div class="messages-container" ref="chatbotMessages" :class="{ 'dark-mode': isDarkMode }">
                  <div v-for="(msg, index) in chatbotConversation" :key="index" :class="['message', msg.sender]">
                    <div class="message-avatar">
                      {{ msg.sender === 'user' ? getUserAvatar() : '🤖' }}
                    </div>
                    <div class="message-content">
                      <div class="message-text">{{ msg.text }}</div>
                      <div class="message-time">{{ msg.time }}</div>
                    </div>
                  </div>
                </div>
                
                <div class="input-section" :class="{ 'dark-mode': isDarkMode }">
                  <div class="input-container">
                    <textarea 
                      v-model="chatbotInput" 
                      :placeholder="getChatPlaceholder()"
                      @keydown.enter.exact.prevent="sendChatbotMessage"
                      @keydown.enter.shift.exact="handleNewLine"
                      rows="1"
                      ref="chatbotTextarea"
                    ></textarea>
                    <div class="input-actions">
                      <button 
                        class="voice-btn" 
                        :class="{ listening: isListening && currentMode === 'chatbot' }"
                        @click="toggleVoiceInput('chatbot')"
                        :title="isListening && currentMode === 'chatbot' ? 'Stop Listening' : 'Start Voice Input'"
                      >
                        🎤
                      </button>
                      <button class="send-btn" @click="sendChatbotMessage" :disabled="!chatbotInput.trim()">
                        ➤
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              <!-- Chat Features Sidebar -->
              <div class="features-sidebar">
                <div class="feature-card">
                  <h4>🎯 Quick Actions</h4>
                  <div class="quick-actions">
                    <button class="quick-btn" @click="insertQuickMessage('help with math homework')">
                      📊 Math Help
                    </button>
                    <button class="quick-btn" @click="insertQuickMessage('explain this science concept')">
                      🔬 Science Help
                    </button>
                    <button class="quick-btn" @click="insertQuickMessage('help me write an essay')">
                      ✍️ Writing Help
                    </button>
                    <button class="quick-btn" @click="insertQuickMessage('study tips for exam')">
                      📚 Study Tips
                    </button>
                  </div>
                </div>

                <div class="feature-card">
                  <h4>💡 Tips</h4>
                  <div class="tips-list">
                    <div class="tip-item">
                      <span class="tip-icon">🗣️</span>
                      <span>Use voice input for hands-free interaction</span>
                    </div>
                    <div class="tip-item">
                      <span class="tip-icon">❓</span>
                      <span>Ask specific questions for better help</span>
                    </div>
                    <div class="tip-item">
                      <span class="tip-icon">📝</span>
                      <span>Share your homework for detailed guidance</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!-- Task Agent Section (Student Only) -->
          <div v-if="activeTab === 'taskagent' && userRole === 'student'" class="task-section">
            <div class="section-grid">
              <!-- Task Interface -->
              <div class="task-panel">
                <div class="task-header">
                  <div class="header-info">
                    <h3>
                      <span class="header-icon">⚡</span>
                      Task Agent
                    </h3>
                    <p>Organize and manage your tasks efficiently with AI assistance</p>
                  </div>
                  <div class="header-controls">
                    <div class="task-stats">
                      <span class="stat-item">
                        <span class="stat-number">{{ getTaskCount() }}</span>
                        <span class="stat-label">Tasks Created</span>
                      </span>
                    </div>
                    <div class="status-indicator">
                      <div class="status-dot" :class="{ listening: isListening && currentMode === 'task' }"></div>
                      <span>{{ isListening && currentMode === 'task' ? 'Listening...' : 'Ready' }}</span>
                    </div>
                  </div>
                </div>
                
                <div class="messages-container" ref="taskMessages" :class="{ 'dark-mode': isDarkMode }">
                  <div v-for="(msg, index) in taskConversation" :key="index" :class="['message', msg.sender]">
                    <div class="message-avatar">
                      {{ msg.sender === 'user' ? '👨‍🎓' : '⚡' }}
                    </div>
                    <div class="message-content">
                      <div class="message-text">{{ msg.text }}</div>
                      <div class="message-time">{{ msg.time }}</div>
                      <div v-if="msg.taskData" class="task-data">
                        <div class="task-item">
                          <div class="task-header-item">
                            <span class="task-title">{{ msg.taskData.title }}</span>
                            <span class="task-priority" :class="msg.taskData.priority">{{ msg.taskData.priority }}</span>
                          </div>
                          <div class="task-details">
                            <span class="task-subject">📚 {{ msg.taskData.subject }}</span>
                            <span class="task-due">📅 Due: {{ msg.taskData.dueDate }}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div class="input-section" :class="{ 'dark-mode': isDarkMode }">
                  <div class="input-container">
                    <textarea 
                      v-model="taskInput" 
                      placeholder="Describe your task: 'Math homework due tomorrow' or 'Science project for next week'..."
                      @keydown.enter.exact.prevent="sendTaskMessage"
                      @keydown.enter.shift.exact="handleNewLine"
                      rows="1"
                      ref="taskTextarea"
                    ></textarea>
                    <div class="input-actions">
                      <button 
                        class="voice-btn" 
                        :class="{ listening: isListening && currentMode === 'task' }"
                        @click="toggleVoiceInput('task')"
                        :title="isListening && currentMode === 'task' ? 'Stop Listening' : 'Start Voice Input'"
                      >
                        🎤
                      </button>
                      <button class="send-btn" @click="sendTaskMessage" :disabled="!taskInput.trim()">
                        ➤
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              <!-- Task Management Sidebar -->
              <div class="task-sidebar">
                <div class="feature-card">
                  <h4>📝 Task Examples</h4>
                  <div class="task-examples">
                    <button class="example-btn" @click="insertTaskExample('Math homework chapter 5 due tomorrow')">
                      📊 Math homework chapter 5 due tomorrow
                    </button>
                    <button class="example-btn" @click="insertTaskExample('Science project about plants due next Friday')">
                      🔬 Science project about plants due next Friday
                    </button>
                    <button class="example-btn" @click="insertTaskExample('English essay 500 words due Monday')">
                      ✍️ English essay 500 words due Monday
                    </button>
                    <button class="example-btn" @click="insertTaskExample('History test preparation for Wednesday')">
                      📚 History test preparation for Wednesday
                    </button>
                  </div>
                </div>

                <div class="feature-card">
                  <h4>🎯 Task Tips</h4>
                  <div class="tips-list">
                    <div class="tip-item">
                      <span class="tip-icon">📅</span>
                      <span>Include due dates for better organization</span>
                    </div>
                    <div class="tip-item">
                      <span class="tip-icon">📚</span>
                      <span>Mention the subject for categorization</span>
                    </div>
                    <div class="tip-item">
                      <span class="tip-icon">⚡</span>
                      <span>Use keywords like 'urgent' for priority</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, nextTick, computed, watch } from 'vue';
import Header from './Header.vue';
import { useRoute, useRouter } from 'vue-router';
import api from '../api'

const route = useRoute();
const router = useRouter();
const userRole = ref('student');
const userId = ref(null); // Get from route or auth store
const currentSessionId = ref(null);
const audioEnabled = ref(true);

// Get user ID from route params
onMounted(() => {
  userId.value = route.params.user_id || route.params.id || localStorage.getItem('user_id');
});

watch(() => route.path, (newPath) => {
  if (newPath.includes('/student/')) userRole.value = 'student';
  else if (newPath.includes('/teacher/')) userRole.value = 'teacher';
  else if (newPath.includes('/parent/')) userRole.value = 'parent';
  else userRole.value = 'student';
  
  // Update user ID from route
  userId.value = route.params.user_id || route.params.id || localStorage.getItem('user_id');
}, { immediate: true });

// Utility functions first
function getCurrentTime() {
  return new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

// Component state
const activeTab = ref('chatbot');
const isDarkMode = ref(false);
const isListening = ref(false);
const currentMode = ref('');
const isProcessing = ref(false);

// Input states
const chatbotInput = ref('');
const taskInput = ref('');

// Voice recognition
let recognition = null;

// References
const chatbotMessages = ref(null);
const taskMessages = ref(null);
const chatbotTextarea = ref(null);
const taskTextarea = ref(null);

// Conversations - initialize with empty arrays first
const chatbotConversation = ref([]);
const taskConversation = ref([]);

// Initialize conversations after component is ready
function initializeConversations() {
  chatbotConversation.value = [
    {
      sender: 'bot',
      text: "Hi there! 👋 I'm your friendly AI buddy! I love helping students learn! 🤓✨",
      time: getCurrentTime()
    }
  ];

  taskConversation.value = [
    {
      sender: 'bot',
      text: "Welcome to Task Agent! ⚡ Tell me about any tasks you need to complete and I'll help you organize them. Just describe what you need to do!",
      time: getCurrentTime()
    }
  ];
}


function getUserAvatar() {
  if (userRole.value === 'student') return '👨‍🎓';
  if (userRole.value === 'teacher') return '👩‍🏫';
  if (userRole.value === 'parent') return '👨‍👩‍👧‍👦';
  return '👤';
}

function getChatPlaceholder() {
  if (userRole.value === 'student') return "Ask me anything on improving communication";
  if (userRole.value === 'teacher') return "How can I help with your teaching today? 📚";
  if (userRole.value === 'parent') return "How can I support your child's education? 👨‍👩‍👧‍👦";
  return "How can I help you today?";
}

function getTaskCount() {
  return taskConversation.value.filter(msg => msg.taskData).length;
}

function insertQuickMessage(message) {
  if (activeTab.value === 'chatbot') {
    chatbotInput.value = message;
    nextTick(() => {
      if (chatbotTextarea.value) {
        chatbotTextarea.value.focus();
      }
    });
  }
}
function insertTaskExample(example) {
  taskInput.value = example;
  nextTick(() => {
    if (taskTextarea.value) {
      taskTextarea.value.focus();
    }
  });
}

function toggleDarkMode() {
  isDarkMode.value = !isDarkMode.value;
}

function handleNewLine() {
  // Allow Shift+Enter for new lines
}

function scrollToBottom(type = null) {
  const container = type === 'task' ? taskMessages.value : 
                  type === 'chatbot' ? chatbotMessages.value :
                  activeTab.value === 'taskagent' ? taskMessages.value : chatbotMessages.value;
  
  if (container) {
    container.scrollTop = container.scrollHeight;
  }
}


async function getChatHistory() {
  if (!currentSessionId.value) return;
  
  try {
    const response = await api.get(`/student/${userId.value}/chat-history/${currentSessionId.value}`);
    if (response.data.success && response.data.messages) {
      // Convert API messages to UI format
      chatbotConversation.value = response.data.messages.map(msg => ({
        sender: msg.role === 'user' ? 'user' : 'bot',
        text: msg.content,
        time: new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        audio_url: msg.audio_path
      }));
    }
  } catch (error) {
    console.error('Error getting chat history:', error);
  }
}

async function getChatbotHelp() {
  try {
    const response = await api.get(`/student/${userId.value}/chat-help`);
    console.log('Chatbot capabilities:', response.data);
    return response.data;
  } catch (error) {
    console.error('Error getting chatbot help:', error);
  }
}

// Replace your existing sendChatbotMessage function with this:
async function sendChatbotMessage() {
  if (!chatbotInput.value.trim() || isProcessing.value) return;
  
  if (!userId.value) {
    alert('User ID not found. Please login again.');
    return;
  }
  
  const userMessage = {
    sender: 'user',
    text: chatbotInput.value.trim(),
    time: getCurrentTime()
  };
  
  chatbotConversation.value.push(userMessage);
  
  // Show processing state
  isProcessing.value = true;
  const messageText = chatbotInput.value.trim();
  chatbotInput.value = '';
  
  // Add loading message
  const loadingMessage = {
    sender: 'bot',
    text: '🤔 Let me think about that...',
    time: getCurrentTime(),
    isLoading: true
  };
  chatbotConversation.value.push(loadingMessage);
  
  // Scroll to bottom
  nextTick(() => scrollToBottom('chatbot'));
  
  try {
    // Call chatbot API with audio generation enabled
    const response = await api.post(`/student/${userId.value}/chat`, {
      message: messageText,
      session_id: currentSessionId.value,
      generate_audio: audioEnabled.value  // This was already in your code
    });
    
    // Remove loading message
    chatbotConversation.value = chatbotConversation.value.filter(msg => !msg.isLoading);
    
    if (response.data.success) {
      // Update session ID
      currentSessionId.value = response.data.session_id;
      
      const botResponse = {
        sender: 'bot',
        text: response.data.response_text,
        time: getCurrentTime(),
        audio_url: response.data.audio_url,
        suggested_actions: response.data.suggested_actions
      };
      
      chatbotConversation.value.push(botResponse);
      
      // IMPORTANT: Play audio if available
      if (response.data.audio_url && audioEnabled.value) {
        await playAudio(response.data.audio_url);  // Make this async
      }
      
      // Show suggested actions (optional UI enhancement)
      if (response.data.suggested_actions) {
        showSuggestedActions(response.data.suggested_actions);
      }
      
    } else {
      // Handle API errors
      chatbotConversation.value.push({
        sender: 'bot',
        text: `❌ ${response.data.message}`,
        time: getCurrentTime()
      });
    }
  } catch (error) {
    console.error('Chatbot API Error:', error);
    
    // Remove loading message
    chatbotConversation.value = chatbotConversation.value.filter(msg => !msg.isLoading);
    
    let errorMessage = '❌ Sorry, I encountered an error. Please try again.';
    
    if (error.response?.status === 401) {
      errorMessage = '❌ Authentication failed. Please login again.';
    } else if (error.response?.data?.message) {
      errorMessage = `❌ ${error.response.data.message}`;
    }
    
    chatbotConversation.value.push({
      sender: 'bot',
      text: errorMessage,
      time: getCurrentTime()
    });
  } finally {
    isProcessing.value = false;
    nextTick(() => scrollToBottom('chatbot'));
  }
}

async function sendVoiceChatbotMessage(audioBase64) {
  if (!userId.value) {
    alert('User ID not found. Please login again.');
    return;
  }
  
  // Add voice message indicator
  const voiceMessage = {
    sender: 'user',
    text: '🎤 Voice message',
    time: getCurrentTime()
  };
  chatbotConversation.value.push(voiceMessage);
  
  // Add processing message
  const loadingMessage = {
    sender: 'bot',
    text: '🎧 Processing your voice message...',
    time: getCurrentTime(),
    isLoading: true
  };
  chatbotConversation.value.push(loadingMessage);
  
  nextTick(() => scrollToBottom('chatbot'));
  
  try {
    const response = await api.post(`/student/${userId.value}/voice-chat`, {
      audio_data: audioBase64,
      session_id: currentSessionId.value
    });
    
    // Remove loading message
    chatbotConversation.value = chatbotConversation.value.filter(msg => !msg.isLoading);
    
    if (response.data.success) {
      // Update session ID
      currentSessionId.value = response.data.session_id;
      
      // Update the voice message with transcribed text if available
      const lastUserMessage = chatbotConversation.value.findLast(msg => msg.sender === 'user');
      if (lastUserMessage) {
        lastUserMessage.text = `🎤 "${response.data.transcribed_text || 'Voice message'}"`;
      }
      
      const botResponse = {
        sender: 'bot',
        text: response.data.response_text,
        time: getCurrentTime(),
        audio_url: response.data.audio_url
      };
      
      chatbotConversation.value.push(botResponse);
      
      // Play audio response
      if (response.data.audio_url) {
        playAudio(response.data.audio_url);
      }
      
    } else {
      chatbotConversation.value.push({
        sender: 'bot',
        text: `❌ ${response.data.message}`,
        time: getCurrentTime()
      });
    }
  } catch (error) {
    console.error('Voice Chat API Error:', error);
    
    // Remove loading message
    chatbotConversation.value = chatbotConversation.value.filter(msg => !msg.isLoading);
    
    chatbotConversation.value.push({
      sender: 'bot',
      text: '❌ Sorry, I had trouble processing your voice message. Please try again.',
      time: getCurrentTime()
    });
  } finally {
    nextTick(() => scrollToBottom('chatbot'));
  }
}


async function sendTaskMessage() {
  if (!taskInput.value.trim() || isProcessing.value) return;
  
  if (!userId.value) {
    alert('User ID not found. Please login again.');
    return;
  }
  
  const userMessage = {
    sender: 'user',
    text: taskInput.value.trim(),
    time: getCurrentTime()
  };
  
  taskConversation.value.push(userMessage);
  
  // Show processing state
  isProcessing.value = true;
  const messageText = taskInput.value.trim();
  taskInput.value = '';
  
  // Add loading message
  const loadingMessage = {
    sender: 'bot',
    text: '🤔 Processing your request...',
    time: getCurrentTime(),
    isLoading: true
  };
  taskConversation.value.push(loadingMessage);
  
  // Scroll to bottom
  nextTick(() => scrollToBottom('task'));
  
  try {
    // Call your FastAPI backend
    const response = await api.post(`/student/${userId.value}/ai-task`, {
      message: messageText
    });
    
    // Remove loading message
    taskConversation.value = taskConversation.value.filter(msg => !msg.isLoading);
    
    if (response.data.success) {
      const botResponse = {
        sender: 'bot',
        text: response.data.message,
        time: getCurrentTime()
      };
      
      // If task was created, add task data
      if (response.data.task_data) {
        botResponse.taskData = {
          title: response.data.task_data.title,
          subject: extractSubject(response.data.task_data.description || messageText),
          priority: extractPriority(messageText),
          dueDate: formatDueDate(response.data.task_data.due_date)
        };
      }
      
      // If tasks were retrieved, format them
      if (response.data.tasks && response.data.tasks.length > 0) {
        botResponse.text += `\n\n📋 Your tasks:`;
        response.data.tasks.forEach((task, index) => {
          botResponse.text += `\n${index + 1}. ${task.title} - ${task.status} (Due: ${formatDueDate(task.due_date)})`;
        });
      }
      
      taskConversation.value.push(botResponse);
    } else {
      // Handle API errors
      taskConversation.value.push({
        sender: 'bot',
        text: `❌ ${response.data.message}`,
        time: getCurrentTime()
      });
    }
  } catch (error) {
    console.error('Task API Error:', error);
    
    // Remove loading message
    taskConversation.value = taskConversation.value.filter(msg => !msg.isLoading);
    
    let errorMessage = '❌ Sorry, I encountered an error processing your request.';
    
    if (error.response?.status === 401) {
      errorMessage = '❌ Authentication failed. Please login again.';
    } else if (error.response?.status === 404) {
      errorMessage = '❌ Student account not found.';
    } else if (error.response?.data?.message) {
      errorMessage = `❌ ${error.response.data.message}`;
    }
    
    taskConversation.value.push({
      sender: 'bot',
      text: errorMessage,
      time: getCurrentTime()
    });
  } finally {
    isProcessing.value = false;
    nextTick(() => scrollToBottom('task'));
  }
}

async function clearChatSession() {
  if (!currentSessionId.value) return;
  
  try {
    await api.delete(`/student/${userId.value}/chat-session/${currentSessionId.value}`);
    currentSessionId.value = null;
    
    // Reset conversation
    chatbotConversation.value = [
      {
        sender: 'bot',
        text: "Hi there! 👋 I'm your friendly AI study buddy! I love helping students learn! 🤓✨",
        time: getCurrentTime()
      }
    ];
    
  } catch (error) {
    console.error('Error clearing session:', error);
  }
}

// Helper functions for task data formatting
function extractSubject(text) {
  const lowerText = text.toLowerCase();
  const subjects = {
    'math': 'Mathematics',
    'science': 'Science',
    'english': 'English',
    'history': 'History',
    'physics': 'Physics',
    'chemistry': 'Chemistry',
    'biology': 'Biology',
    'geography': 'Geography',
    'art': 'Art',
    'music': 'Music'
  };
  
  for (const [key, value] of Object.entries(subjects)) {
    if (lowerText.includes(key)) {
      return value;
    }
  }
  return 'General';
}

// Replace your existing playAudio function with this:
async function playAudio(audioUrl) {
  if (!audioEnabled.value) return;
  
  try {
    console.log('Playing audio:', audioUrl);
    
    // Construct full URL if needed
    const fullUrl = audioUrl.startsWith('http') ? audioUrl : `${api.defaults.baseURL}${audioUrl}`;
    
    const audio = new Audio(fullUrl);
    
    // Add error handling
    audio.onerror = (e) => {
      console.error('Audio playback error:', e);
    };
    
    audio.onloadstart = () => {
      console.log('Audio loading started...');
    };
    
    audio.oncanplay = () => {
      console.log('Audio can start playing');
    };
    
    // Play the audio
    await audio.play();
    console.log('Audio playing successfully');
    
  } catch (error) {
    console.error('Audio play failed:', error);
    // Show user-friendly message if needed
    if (error.name === 'NotAllowedError') {
      console.log('Audio autoplay blocked by browser. User interaction required.');
      // You could show a "Click to play audio" button here
    }
  }
}

function toggleAudio() {
  audioEnabled.value = !audioEnabled.value;
  console.log('Audio', audioEnabled.value ? 'enabled' : 'disabled');
}

function showSuggestedActions(actions) {
  console.log('Suggested actions:', actions);
}

function extractPriority(text) {
  const lowerText = text.toLowerCase();
  if (lowerText.includes('urgent') || lowerText.includes('important')) return 'high';
  if (lowerText.includes('soon') || lowerText.includes('quick')) return 'medium';
  return 'medium';
}

function formatDueDate(dateString) {
  if (!dateString) return 'Not specified';
  
  try {
    const date = new Date(dateString);
    const today = new Date();
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);
    
    if (date.toDateString() === today.toDateString()) {
      return 'Today';
    } else if (date.toDateString() === tomorrow.toDateString()) {
      return 'Tomorrow';
    } else {
      return date.toLocaleDateString('en-US', { 
        weekday: 'short', 
        month: 'short', 
        day: 'numeric' 
      });
    }
  } catch (error) {
    return dateString;
  }
}

function generateChatbotResponse(message) {
  const responses = [
    "That's a great question! Let me think about that... 🤔",
    "I'm here to help! Can you tell me more about what you're working on?",
    "Interesting! That reminds me of a concept we can explore together. 📚",
    "You're doing great! Keep asking questions - that's how we learn best! 🌟",
    "Let's break that down step by step. What part would you like to focus on first?",
    "That's a smart approach! Have you considered trying it this way...? 💡",
    "I love your curiosity! Learning is all about exploring new ideas. ✨",
    "Good thinking! That shows you're really understanding the material. 👏"
  ];
  
  // Simple keyword-based responses
  const lowerMessage = message.toLowerCase();
  
  if (lowerMessage.includes('math') || lowerMessage.includes('mathematics')) {
    return "Math can be fun! 🧮 What specific topic are you working on? Algebra, geometry, or something else?";
  }
  if (lowerMessage.includes('science')) {
    return "Science is amazing! 🔬 Are you exploring biology, chemistry, physics, or earth science?";
  }
  if (lowerMessage.includes('english') || lowerMessage.includes('writing')) {
    return "English and writing are powerful tools! ✍️ Are you working on an essay, reading comprehension, or grammar?";
  }
  if (lowerMessage.includes('help') || lowerMessage.includes('stuck')) {
    return "Don't worry, everyone gets stuck sometimes! 💪 Let's work through this together. What exactly is challenging you?";
  }
  
  return responses[Math.floor(Math.random() * responses.length)];
}

function generateTaskResponse(message, taskData) {
  if (taskData) {
    return {
      text: `Great! I've organized your task for you. Here's what I understood:`,
      taskData: taskData
    };
  } else {
    const responses = [
      "I understand you have a task to complete. Can you be more specific about what needs to be done and when it's due?",
      "Got it! To help you better, could you tell me: What exactly needs to be done and when is the deadline?",
      "I'm here to help organize your tasks! Please provide more details like the task name, subject, and due date.",
      "Let me help you structure this task. What's the main goal and when do you need to complete it by?"
    ];
    
    return {
      text: responses[Math.floor(Math.random() * responses.length)]
    };
  }
}

function extractTaskData(message) {
  // Simple task extraction logic
  const lowerMessage = message.toLowerCase();
  
  // Look for task indicators
  const taskKeywords = ['homework', 'assignment', 'project', 'study', 'test', 'exam', 'essay', 'report'];
  const subjectKeywords = ['math', 'science', 'english', 'history', 'art', 'music'];
  const priorityKeywords = { 'urgent': 'high', 'important': 'high', 'soon': 'medium', 'later': 'low' };
  
  let hasTask = taskKeywords.some(keyword => lowerMessage.includes(keyword));
  
  if (hasTask) {
    let title = "New Task";
    let subject = "General";
    let priority = "medium";
    let dueDate = "Not specified";
    
    // Extract subject
    for (let subj of subjectKeywords) {
      if (lowerMessage.includes(subj)) {
        subject = subj.charAt(0).toUpperCase() + subj.slice(1);
        break;
      }
    }
    
    // Extract priority
    for (let [keyword, level] of Object.entries(priorityKeywords)) {
      if (lowerMessage.includes(keyword)) {
        priority = level;
        break;
      }
    }
    
    // Try to extract a more specific title
    if (lowerMessage.includes('homework')) title = `${subject} Homework`;
    if (lowerMessage.includes('project')) title = `${subject} Project`;
    if (lowerMessage.includes('test') || lowerMessage.includes('exam')) title = `${subject} Test`;
    if (lowerMessage.includes('essay')) title = `${subject} Essay`;
    
    // Simple due date extraction
    if (lowerMessage.includes('tomorrow')) dueDate = 'Tomorrow';
    else if (lowerMessage.includes('today')) dueDate = 'Today';
    else if (lowerMessage.includes('next week')) dueDate = 'Next Week';
    else if (lowerMessage.includes('monday')) dueDate = 'Monday';
    else if (lowerMessage.includes('friday')) dueDate = 'Friday';
    
    return { title, subject, priority, dueDate };
  }
  
  return null;
}

function toggleVoiceInput(mode) {
  if (isListening.value && currentMode.value === mode) {
    stopVoiceInput();
  } else {
    startVoiceInput(mode);
  }
}

// Update your startVoiceInput function to handle both modes:
function startVoiceInput(mode) {
  if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
    alert('Speech recognition is not supported in your browser. Please use Chrome or Edge.');
    return;
  }
  
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  recognition = new SpeechRecognition();
  
  recognition.continuous = false;
  recognition.interimResults = false;
  recognition.lang = 'en-US';
  
  recognition.onstart = () => {
    isListening.value = true;
    currentMode.value = mode;
  };
  
  recognition.onresult = (event) => {
    const transcript = event.results[0][0].transcript;
    
    if (mode === 'chatbot') {
      // Option 1: Set text in input (current behavior)
      chatbotInput.value = transcript;
      
      // Option 2: Send directly as voice message (uncomment if preferred)
      // sendVoiceChatbotMessage(audioBase64); // You'd need to implement audio recording
    } else if (mode === 'task') {
      taskInput.value = transcript;
    }
  };
  
  recognition.onerror = (event) => {
    console.error('Speech recognition error:', event.error);
    stopVoiceInput();
  };
  
  recognition.onend = () => {
    stopVoiceInput();
  };
  
  recognition.start();
}


function stopVoiceInput() {
  if (recognition) {
    recognition.stop();
  }
  isListening.value = false;
  currentMode.value = '';
}

// Watch for tab changes to scroll to bottom
watch(activeTab, () => {
  nextTick(() => scrollToBottom());
});

// Initialize
onMounted(() => {
  // Initialize conversations after component is mounted
  console.log('Initializing conversations...');
  console.log('User role:', userRole.value);
  console.log('User ID:', userId.value);
  initializeConversations();
  
  // Set default tab based on role
  activeTab.value = 'chatbot';
  
  nextTick(() => scrollToBottom());
});
</script>

<style scoped>
.ai-assistance-page {
  min-height: 100vh;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  padding: 2rem;
}

.ai-container {
  max-width: 1400px;
  margin: 0 auto;
  padding: 0 1rem;
}

.ai-main-content {
  margin-top: 2rem;
}

/* Tab Navigation */
.ai-tabs-container {
  margin-bottom: 2rem;
}

.ai-tabs {
  display: flex;
  gap: 1rem;
  background: rgba(255, 255, 255, 0.1);
  backdrop-filter: blur(10px);
  border-radius: 16px;
  padding: 0.5rem;
}

.ai-tabs.single-tab {
  justify-content: center;
}

.tab-btn {
  flex: 1;
  background: transparent;
  border: none;
  color: rgba(255, 255, 255, 0.8);
  padding: 1.5rem 2rem;
  border-radius: 12px;
  cursor: pointer;
  transition: all 0.3s ease;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 0.5rem;
  position: relative;
  overflow: hidden;
}

.tab-btn:hover {
  background: rgba(255, 255, 255, 0.1);
  color: white;
}

.tab-btn.active {
  background: white;
  color: #1f2937;
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
}

.tab-icon {
  font-size: 2rem;
}

.tab-text {
  font-weight: 700;
  font-size: 1.1rem;
}

.tab-badge {
  font-size: 0.8rem;
  opacity: 0.8;
  font-weight: 500;
}

.tab-btn.active .tab-badge {
  background: linear-gradient(135deg, #667eea, #764ba2);
  color: white;
  padding: 0.25rem 0.75rem;
  border-radius: 12px;
  opacity: 1;
}

/* Content Area */
.ai-content-area {
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(10px);
  border-radius: 20px;
  box-shadow: 0 20px 60px rgba(0, 0, 0, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.2);
  overflow: hidden;
}

.section-grid {
  display: grid;
  grid-template-columns: 1fr 350px;
  min-height: 600px;
}

/* Chat Panel */
.chat-panel,
.task-panel {
  display: flex;
  flex-direction: column;
  border-right: 1px solid #e2e8f0;
}

.chat-header,
.task-header {
  padding: 2rem;
  background: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%);
  border-bottom: 1px solid #e2e8f0;
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
}

.header-info h3 {
  margin: 0 0 0.5rem 0;
  font-size: 1.5rem;
  font-weight: 700;
  color: #1f2937;
  display: flex;
  align-items: center;
  gap: 0.5rem;
}

.header-icon {
  font-size: 1.8rem;
}

.header-info p {
  margin: 0;
  color: #6b7280;
  font-size: 1rem;
}

.header-controls {
  display: flex;
  flex-direction: column;
  align-items: flex-end;
  gap: 1rem;
}

.control-btn {
  background: rgba(102, 126, 234, 0.1);
  border: 1px solid #667eea;
  color: #667eea;
  width: 40px;
  height: 40px;
  border-radius: 50%;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all 0.3s ease;
}

.control-btn:hover {
  background: #667eea;
  color: white;
}

.status-indicator {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  font-size: 0.9rem;
  color: #6b7280;
}

.status-dot {
  width: 10px;
  height: 10px;
  background: #10b981;
  border-radius: 50%;
  animation: pulse 2s infinite;
}

.status-dot.listening {
  background: #ef4444;
  animation: voicePulse 1s infinite;
}

.task-stats {
  display: flex;
  gap: 1rem;
}

.stat-item {
  display: flex;
  flex-direction: column;
  align-items: center;
  text-align: center;
}

.stat-number {
  font-size: 1.5rem;
  font-weight: 700;
  color: #667eea;
}

.stat-label {
  font-size: 0.8rem;
  color: #6b7280;
}

/* Messages Container */
.messages-container {
  flex: 1;
  overflow-y: auto;
  padding: 2rem;
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
  min-height: 0;
  background: white;
}

.messages-container.dark-mode {
  background: #1a1a1a;
}

.messages-container::-webkit-scrollbar {
  width: 8px;
}

.messages-container::-webkit-scrollbar-track {
  background: transparent;
}

.messages-container::-webkit-scrollbar-thumb {
  background: #cbd5e0;
  border-radius: 4px;
}

.message {
  display: flex;
  gap: 1rem;
  max-width: 85%;
  animation: messageSlide 0.3s ease;
}

.message.user {
  align-self: flex-end;
  flex-direction: row-reverse;
}

.message.bot {
  align-self: flex-start;
}

.message-avatar {
  width: 45px;
  height: 45px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 20px;
  flex-shrink: 0;
  background: linear-gradient(135deg, #f8fafc, #e2e8f0);
}

.message.user .message-avatar {
  background: linear-gradient(135deg, #667eea, #764ba2);
}

.message-content {
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
}

.message-text {
  background: #f1f5f9;
  padding: 1rem 1.25rem;
  border-radius: 20px;
  font-size: 1rem;
  line-height: 1.5;
  word-wrap: break-word;
}

.message.user .message-text {
  background: linear-gradient(135deg, #667eea, #764ba2);
  color: white;
  border-bottom-right-radius: 8px;
}

.message.bot .message-text {
  border-bottom-left-radius: 8px;
}

.dark-mode .message.bot .message-text {
  background: #374151;
  color: white;
}

.message-time {
  font-size: 0.8rem;
  color: #94a3b8;
  align-self: flex-start;
}

.message.user .message-time {
  align-self: flex-end;
}

/* Task Data */
.task-data {
  margin-top: 0.75rem;
}

.task-item {
  background: #f8fafc;
  border: 1px solid #e2e8f0;
  border-radius: 12px;
  padding: 1rem;
  display: flex;
  flex-direction: column;
  gap: 0.75rem;
}

.dark-mode .task-item {
  background: #2d3748;
  border-color: #4a5568;
}

.task-header-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.task-title {
  font-weight: 700;
  color: #1e293b;
  font-size: 1rem;
}

.dark-mode .task-title {
  color: white;
}

.task-priority {
  font-size: 0.8rem;
  padding: 0.25rem 0.75rem;
  border-radius: 12px;
  font-weight: 600;
}

.task-priority.high {
  background: #fef2f2;
  color: #dc2626;
}

.task-priority.medium {
  background: #fffbeb;
  color: #d97706;
}

.task-priority.low {
  background: #f0fdf4;
  color: #16a34a;
}

.task-details {
  display: flex;
  gap: 1rem;
  font-size: 0.9rem;
  color: #6b7280;
}

.dark-mode .task-details {
  color: #cbd5e0;
}

/* Input Section */
.input-section {
  padding: 2rem;
  border-top: 1px solid #e2e8f0;
  background: #f8fafc;
}

.input-section.dark-mode {
  background: #2d3748;
  border-top-color: #4a5568;
}

.input-container {
  display: flex;
  gap: 1rem;
  align-items: flex-end;
}

.input-container textarea {
  flex: 1;
  border: 2px solid #e2e8f0;
  border-radius: 12px;
  padding: 1rem 1.25rem;
  font-size: 1rem;
  font-family: inherit;
  resize: none;
  min-height: 50px;
  max-height: 150px;
  transition: border-color 0.3s ease;
  background: white;
}

.input-container textarea:focus {
  outline: none;
  border-color: #667eea;
  box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
}

.dark-mode .input-container textarea {
  background: #374151;
  border-color: #4a5568;
  color: white;
}

.input-actions {
  display: flex;
  gap: 0.75rem;
}

.voice-btn,
.send-btn {
  width: 50px;
  height: 50px;
  border: none;
  border-radius: 50%;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 20px;
  transition: all 0.3s ease;
}

.voice-btn {
  background: #f1f5f9;
  color: #64748b;
}

.voice-btn:hover {
  background: #e2e8f0;
}

.voice-btn.listening {
  background: #ef4444;
  color: white;
  animation: voicePulse 1s infinite;
}

.send-btn {
  background: linear-gradient(135deg, #667eea, #764ba2);
  color: white;
}

.send-btn:hover:not(:disabled) {
  transform: scale(1.05);
  box-shadow: 0 8px 25px rgba(102, 126, 234, 0.4);
}

.send-btn:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

/* Sidebar */
.features-sidebar,
.task-sidebar {
  background: #f8fafc;
  padding: 2rem;
  display: flex;
  flex-direction: column;
  gap: 2rem;
  overflow-y: auto;
}

.feature-card {
  background: white;
  border-radius: 12px;
  padding: 1.5rem;
  border: 1px solid #e2e8f0;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.05);
}

.feature-card h4 {
  margin: 0 0 1rem 0;
  font-size: 1.1rem;
  font-weight: 700;
  color: #1f2937;
  display: flex;
  align-items: center;
  gap: 0.5rem;
}

.quick-actions,
.task-examples {
  display: flex;
  flex-direction: column;
  gap: 0.75rem;
}

.quick-btn,
.example-btn {
  background: #f1f5f9;
  border: 1px solid #e2e8f0;
  color: #374151;
  padding: 0.75rem 1rem;
  border-radius: 8px;
  cursor: pointer;
  text-align: left;
  font-size: 0.9rem;
  transition: all 0.3s ease;
}

.quick-btn:hover,
.example-btn:hover {
  background: linear-gradient(135deg, #667eea, #764ba2);
  color: white;
  border-color: #667eea;
  transform: translateY(-2px);
}

.tips-list {
  display: flex;
  flex-direction: column;
  gap: 1rem;
}

.tip-item {
  display: flex;
  align-items: flex-start;
  gap: 0.75rem;
  font-size: 0.9rem;
  color: #6b7280;
  line-height: 1.4;
}

.tip-icon {
  font-size: 1.1rem;
  flex-shrink: 0;
  margin-top: 0.1rem;
}

/* Animations */
@keyframes messageSlide {
  from { opacity: 0; transform: translateY(20px); }
  to { opacity: 1; transform: translateY(0); }
}

@keyframes pulse {
  0%, 100% { opacity: 1; }
  50% { opacity: 0.5; }
}

@keyframes voicePulse {
  0%, 100% { transform: scale(1); }
  50% { transform: scale(1.1); }
}

/* Responsive Design */
@media (max-width: 1200px) {
  .section-grid {
    grid-template-columns: 1fr 300px;
  }
}

@media (max-width: 968px) {
  .section-grid {
    grid-template-columns: 1fr;
  }
  
  .features-sidebar,
  .task-sidebar {
    border-top: 1px solid #e2e8f0;
    max-height: 300px;
  }
  
  .chat-panel,
  .task-panel {
    border-right: none;
  }
}

@media (max-width: 768px) {
  .ai-tabs {
    flex-direction: column;
  }
  
  .tab-btn {
    flex-direction: row;
    justify-content: center;
    padding: 1rem 1.5rem;
  }
  
  .tab-text {
    font-size: 1rem;
  }
  
  .ai-container {
    padding: 0 0.5rem;
  }
  
  .header-controls {
    flex-direction: row;
    align-items: center;
  }
  
  .chat-header,
  .task-header {
    flex-direction: column;
    gap: 1rem;
    text-align: center;
  }
}

@media (max-width: 480px) {
  .messages-container {
    padding: 1rem;
  }
  
  .input-section {
    padding: 1rem;
  }
  
  .features-sidebar,
  .task-sidebar {
    padding: 1rem;
  }
  
  .voice-btn,
  .send-btn {
    width: 45px;
    height: 45px;
    font-size: 18px;
  }
}

  
  .ai-container {
    padding: 0 0.5rem;
  }
  
  .header-controls {
    flex-direction: row;
    align-items: center;
  }
  
  .chat-header,
  .task-header {
    flex-direction: column;
    gap: 1rem;
    text-align: center;
  }


@media (max-width: 480px) {
  .messages-container {
    padding: 1rem;
  }
  
  .input-section {
    padding: 1rem;
  }
  
  .features-sidebar,
  .task-sidebar {
    padding: 1rem;
  }
  
  .voice-btn,
  .send-btn {
    width: 45px;
    height: 45px;
    font-size: 18px;
  }
}

.control-btn.audio-enabled {
  background: rgba(16, 185, 129, 0.1);
  border-color: #10b981;
  color: #10b981;
}

.control-btn.audio-enabled:hover {
  background: #10b981;
  color: white;
}
</style>
