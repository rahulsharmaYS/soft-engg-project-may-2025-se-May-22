<template>
  <div class="parent-profile">
    <!-- <Header title="Parent Profile" subtitle="Your central hub for account and child information." /> -->
    <header style="color: whitesmoke;">
      <h1>Parent Profile</h1>
      <p>Your central hub for account and child information.</p>
    </header>
    <div class="profile-container">
      <div class="profile-header">
        <div class="profile-card main-profile">
          <div class="profile-banner">
            <div class="profile-info">
              <div class="avatar-section">
                <img :src="getImageUrl(parent.user?.profile_picture)" alt="Parent Avatar" class="profile-avatar" />
                <input type="file" ref="fileInput" @change="handleFileUpload" accept="image/*" style="display:none" />
              </div>
              <div class="info-details" v-if="parent.user">
                <h2><strong>Name:</strong> {{ parent.user.full_name }}</h2>
                <p class="email">Email: {{ parent.user.email }}</p>
                <span class="role-badge">Role: Parent</span>
              </div>
            </div>
            <div class="profile-actions">
              <button class="action-btn primary-btn" @click="openEditModal">
                <span class="icon">✏️</span>
                Edit Profile
              </button>
            </div>
          </div>
        </div>
      </div>

      <!-- Content Grid -->
      <div class="content-grid">
        <!-- Child Information Card -->
        <div class="profile-card child-card">
          <div class="card-header">
            <h3>👨‍👩‍👧‍👦 Child Information</h3>
          </div>
          <div class="card-content">
            <div class="child-profile" v-if="childProfile.user">
              <img :src="childProfile.profile_picture || kid_pic" alt="Child Avatar" class="child-avatar">
              <div class="child-details">
                <h4>{{ childProfile.user.full_name }}</h4>
                <p class="child-email">📧 {{ childProfile.user.email }}</p>
                <div class="child-stats">
                  <div class="stat-item">
                    <span class="stat-label">Username</span>
                    <span class="stat-value">{{ childProfile.user?.username }}</span>
                  </div>
                  <div class="stat-item">
                    <span class="stat-label">Joined At</span>
                    <span class="stat-value">{{ new Date(childProfile.user?.created_at).toLocaleDateString('en-GB', {day:'2-digit', month:'short', year:'numeric'}) }}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Parenting Tips Card -->
        <div class="profile-card tips-card">
          <div class="card-header">
            <h3>💡 Parenting Tips</h3>
            <button class="refresh-tip-btn" @click="getRandomTip">🔄</button>
          </div>
          <div class="card-content">
            <div class="tip-container">
              <div class="tip-icon">{{ currentTip.icon }}</div>
              <div class="tip-content">
                <h4>{{ currentTip.category }}</h4>
                <p>{{ currentTip.text }}</p>
              </div>
            </div>
            <div class="tip-footer">
              <small>Tip {{ currentTipIndex + 1 }} of {{ parentingTips.length }}</small>
            </div>
          </div>
        </div>

        <!-- Account Settings Card -->
        <div class="profile-card settings-card">
          <div class="card-header">
            <h3>⚙️ Account Settings</h3>
          </div>
          <div class="card-content">
            <div class="settings-list">
              <div class="setting-item">
                <span class="setting-icon">🔒</span>
                <span class="setting-label">Change Password</span>
                <button class="setting-btn" @click="openPasswordModal">Change</button>
              </div>
              <div class="setting-item">
                <span class="setting-icon">👶</span>
                <span class="setting-label">Child Status</span>
                <span class="setting-value status-active">{{ childProfile.status || 'Active' }}</span>
              </div>
              <div class="setting-item">
                <span class="setting-icon">🚪</span>
                <span class="setting-label">Logout</span>
                <button class="setting-btn danger" @click="logout">Logout</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Edit Modal -->
    <div v-if="showModal" class="modal-overlay" @click.self="showModal = false">
      <div class="modal-content">
        <div class="modal-header">
          <h3>✏️ Edit Profile</h3>
          <button class="close-btn" @click="showModal = false">×</button>
        </div>
        <div class="modal-body">
          <div class="form-group">
            <label>Full Name</label>
            <input v-model="editForm.full_name" type="text" placeholder="Enter your full name" />
          </div>
          <div class="form-group">
            <label>Email Address</label>
            <input v-model="editForm.email" type="email" placeholder="Enter your email" />
          </div>
          <div class="form-group">
            <label>Profile Picture <i>(.png preferred)</i></label>
            <input type="file" @change="handleEditFileUpload" accept="image/*" />
            <div v-if="editForm.profile_pic_preview" class="preview-image">
              <img :src="editForm.profile_pic_preview" alt="Profile Preview"
                style="max-width: 80px; max-height: 80px; border-radius: 50%; margin-top: 0.5rem;" />
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button @click="showModal = false" class="btn-cancel">Cancel</button>
          <button @click="submitEdit" class="btn-save">Save Changes</button>
        </div>
      </div>
    </div>

    <!-- Password Change Modal -->
    <div v-if="showPasswordModal" class="modal-overlay" @click.self="showPasswordModal = false">
      <div class="modal-content">
        <div class="modal-header">
          <h3>🔒 Change Password</h3>
          <button class="close-btn" @click="showPasswordModal = false">×</button>
        </div>
        <div class="modal-body">
          <div class="form-group">
            <label>Current Password</label>
            <input v-model="passwordForm.currentPassword" type="password" placeholder="Enter current password" />
          </div>
          <div class="form-group">
            <label>New Password</label>
            <input v-model="passwordForm.newPassword" type="password" placeholder="Enter new password" />
          </div>
          <div class="form-group">
            <label>Confirm New Password</label>
            <input v-model="passwordForm.confirmPassword" type="password" placeholder="Confirm new password" />
          </div>
          <div class="password-requirements">
            <small>Password must be at least 8 characters long and contain uppercase, lowercase, and numbers.</small>
          </div>
        </div>
        <div class="modal-footer">
          <button @click="showPasswordModal = false" class="btn-cancel">Cancel</button>
          <button @click="submitPasswordChange" class="btn-save">Change Password</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { useRoute, useRouter } from 'vue-router';
import Header from './Header.vue';
import api from '../api';
import { ref, computed, onMounted } from 'vue';
import defaultAvatar from '../assets/avatar.jpeg';
import kid_pic from '../assets/kid_pic.jpeg';

const router = useRouter();
const route = useRoute();

var parent = ref({});
var childProfile = ref({});

const showModal = ref(false);
const showPasswordModal = ref(false);
const fileInput = ref(null);
const currentTipIndex = ref(0);

const getImageUrl = (path) => {
  if (!path) return defaultAvatar;          // fallback image
  if (path.startsWith('http')) return path; // if backend already gives full URL
  return `http://localhost:8000${path}`;    // match FastAPI port
};


const editForm = ref({
  full_name: '',
  email: '',
  profile_pic: null,
  profile_pic_preview: null
});

const passwordForm = ref({
  currentPassword: '',
  newPassword: '',
  confirmPassword: ''
});
const handleEditFileUpload = (event) => {
  const file = event.target.files[0];
  if (file) {
    editForm.value.profile_pic = file;
    editForm.value.profile_pic_preview = URL.createObjectURL(file);
  }
};

// Parenting tips array
const parentingTips = ref([
  {
    category: "Screen Time Management",
    icon: "📱",
    text: "Set clear boundaries for screen time. Create device-free zones during meals and bedtime to encourage family interaction and better sleep habits."
  },
  {
    category: "Positive Reinforcement",
    icon: "⭐",
    text: "Praise your child's efforts, not just achievements. This builds confidence and encourages them to keep trying even when tasks are challenging."
  },
  {
    category: "Active Listening",
    icon: "👂",
    text: "Give your child your full attention when they speak. Put down devices and make eye contact to show you value their thoughts and feelings."
  },
  {
    category: "Routine & Structure",
    icon: "📅",
    text: "Establish consistent daily routines for homework, meals, and bedtime. Children thrive with predictable schedules that help them feel secure."
  },
  {
    category: "Educational Support",
    icon: "📚",
    text: "Create a dedicated study space free from distractions. Be available to help with homework but encourage independence in problem-solving."
  },
  {
    category: "Emotional Intelligence",
    icon: "❤️",
    text: "Help your child identify and express their emotions. Teach them healthy coping strategies for dealing with frustration and disappointment."
  },
  {
    category: "Physical Activity",
    icon: "🏃",
    text: "Encourage at least 1 hour of physical activity daily. Join your child in outdoor activities to model healthy habits and spend quality time together."
  },
  {
    category: "Reading Together",
    icon: "📖",
    text: "Read with your child daily, even as they get older. Discuss stories and characters to improve comprehension and critical thinking skills."
  },
  {
    category: "Healthy Eating",
    icon: "🥗",
    text: "Involve your child in meal planning and cooking. Teach them about nutrition and let them help prepare healthy snacks and meals."
  },
  {
    category: "Independence Building",
    icon: "🎯",
    text: "Give age-appropriate responsibilities and chores. This builds confidence, life skills, and helps children feel like valued family members."
  },
  {
    category: "Communication",
    icon: "💬",
    text: "Have regular one-on-one conversations with your child. Ask open-ended questions about their day, friends, and any concerns they might have."
  },
  {
    category: "Sleep Hygiene",
    icon: "😴",
    text: "Establish a calming bedtime routine. Ensure 9-11 hours of sleep for school-age children by setting consistent sleep and wake times."
  },
  {
    category: "Problem Solving",
    icon: "🧩",
    text: "When your child faces challenges, guide them to find solutions rather than solving problems for them. This develops critical thinking skills."
  },
  {
    category: "Digital Citizenship",
    icon: "🌐",
    text: "Teach online safety and digital etiquette. Monitor your child's online activities and discuss appropriate behavior in digital spaces."
  },
  {
    category: "Patience & Understanding",
    icon: "🤗",
    text: "Remember that learning takes time. Celebrate small victories and provide support during difficult moments without judgment."
  }
]);

const currentTip = computed(() => parentingTips.value[currentTipIndex.value]);

const triggerFileUpload = () => {
  fileInput.value.click();
};

const handleFileUpload = async (event) => {
  const file = event.target.files[0];
  if (file) {
    const formData = new FormData();
    formData.append('profile_picture', file);

    try {
      const userId = parent.value.user.id;
      const res = await api.post(`/parent/${userId}/upload-avatar`, formData, {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      });

      parent.value.profile_picture = res.data.profile_picture_url;
      alert('Profile picture updated successfully!');
    } catch (err) {
      console.error("Failed to upload image", err);
      alert('Failed to upload profile picture');
    }
  }
};

const getRandomTip = () => {
  currentTipIndex.value = Math.floor(Math.random() * parentingTips.value.length);
};

const openEditModal = () => {
  if (parent.value && parent.value.user) {
    editForm.value.full_name = parent.value.user.full_name;
    editForm.value.email = parent.value.user.email;
    showModal.value = true;
  }
};

const openPasswordModal = () => {
  passwordForm.value = {
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  };
  showPasswordModal.value = true;
};

const submitEdit = async () => {
  try {
    const userId = parent.value.user.id;

    const formData = new FormData();
    formData.append('full_name', editForm.value.full_name);
    formData.append('email', editForm.value.email);
    if (editForm.value.profile_pic) {
      formData.append('profile_pic', editForm.value.profile_pic);
    }

    await api.put(`/parent/${userId}/profile`, formData, {
      headers: { 'Content-Type': 'multipart/form-data' }
    });

    showModal.value = false;
    await fetchParentProfile();
    alert('Profile updated successfully');
  } catch (err) {
    console.error("Failed to update profile", err.response || err);
    if (err.response?.status === 400 || err.response?.status === 404) {
      alert(err.response?.data.detail || 'Invalid data provided.');
    } else {
      alert('Failed to update profile');
    }
  }
};

const submitPasswordChange = async () => {
  if (passwordForm.value.newPassword !== passwordForm.value.confirmPassword) {
    alert('New passwords do not match!');
    return;
  }

  if (passwordForm.value.newPassword.length < 8) {
    alert('Password must be at least 8 characters long!');
    return;
  }

  try {
    const userId = parent.value.user.id;
    await api.post(`/user/change-password`, {
      current_password: passwordForm.value.currentPassword,
      new_password: passwordForm.value.newPassword
    });

    showPasswordModal.value = false;
    alert('Password changed successfully!');
  } catch (err) {
    console.error("Failed to change password", err.response || err);
    if (err.response?.status === 400) {
      alert('Current password is incorrect!');
    } else if (err.response?.status === 422) {
      alert('Password does not meet requirements!');
    } else {
      alert('Failed to change password');
    }
  }
};

async function fetchParentProfile() {
  try {
    const parentId = computed(() => route.params.parentId);
    const res = await api.get(`parent/${parentId.value}/profile`);
    parent.value = res.data;
    console.log("Parent:", parent);
  } catch (e) {
    console.error("Error fetching profile:", e);
  }
}

async function fetchChildProfile() {
  try {
    const parentId = computed(() => route.params.parentId);
    const res = await api.get(`parent/${parentId.value}/child/profile`);
    childProfile.value = res.data;
    console.log("Child Profile:", childProfile);
  } catch (e) {
    console.error("Error fetching profile:", e);
  }
}

const logout = () => {
  router.push('/login');
};

onMounted(async () => {
  await Promise.all([
    fetchParentProfile(),
    fetchChildProfile()
  ]);
  getRandomTip(); // Initialize with a random tip
});

</script>

<style scoped>
.parent-profile {
  min-height: 100vh;
  /* background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); */
  background: linear-gradient(135deg, #B12BE2, #1F6CF3);
  padding: 2rem;
  font-family: 'Inter', sans-serif;
}

.profile-container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 1rem;
}

.profile-header {
  margin: 2rem 0;
}

.profile-card {
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(10px);
  border-radius: 20px;
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.2);
  overflow: hidden;
  transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.profile-card:hover {
  transform: translateY(-5px);
  box-shadow: 0 12px 40px rgba(0, 0, 0, 0.15);
}

.main-profile {
  background: linear-gradient(135deg, #fff 0%, #f8fafc 100%);
}

.profile-banner {
  padding: 2rem;
  display: flex;
  justify-content: space-between;
  align-items: center;
  flex-wrap: wrap;
  gap: 2rem;
}

.profile-info {
  display: flex;
  align-items: center;
  gap: 2rem;
}

.avatar-section {
  position: relative;
}

.profile-avatar {
  width: 100px;
  height: 100px;
  border-radius: 50%;
  border: 4px solid #667eea;
  object-fit: cover;
  transition: transform 0.3s ease;
}

.profile-avatar:hover {
  transform: scale(1.05);
}

.avatar-overlay {
  position: absolute;
  bottom: 0;
  right: 0;
  background: #667eea;
  border-radius: 50%;
  width: 32px;
  height: 32px;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  transition: background 0.3s ease;
}

.avatar-overlay:hover {
  background: #5a67d8;
}

.camera-icon {
  font-size: 14px;
}

.info-details h2 {
  margin: 0 0 0.5rem 0;
  font-size: 2rem;
  font-weight: 700;
  color: #2d3748;
}

.email {
  margin: 0 0 1rem 0;
  color: #718096;
  font-size: 1.1rem;
}

.role-badge {
  background: linear-gradient(135deg, #667eea, #764ba2);
  color: white;
  padding: 0.5rem 1rem;
  border-radius: 20px;
  font-size: 0.9rem;
  font-weight: 600;
}

.profile-actions {
  display: flex;
  gap: 1rem;
  flex-wrap: wrap;
}

.action-btn {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.75rem 1.5rem;
  border: none;
  border-radius: 12px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s ease;
  font-size: 1rem;
}

.primary-btn {
  background: linear-gradient(135deg, #667eea, #764ba2);
  color: white;
}

.primary-btn:hover {
  transform: translateY(-2px);
  box-shadow: 0 8px 25px rgba(102, 126, 234, 0.4);
}

.danger-btn {
  background: linear-gradient(135deg, #fc8181, #f56565);
  color: white;
}

.danger-btn:hover {
  transform: translateY(-2px);
  box-shadow: 0 8px 25px rgba(245, 101, 101, 0.4);
}

.content-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
  gap: 2rem;
  margin-top: 2rem;
}

.card-header {
  padding: 1.5rem 1.5rem 0 1.5rem;
  border-bottom: 1px solid #e2e8f0;
  margin-bottom: 1.5rem;
}

.card-header h3 {
  margin: 0 0 1rem 0;
  font-size: 1.3rem;
  font-weight: 700;
  color: #2d3748;
}

.card-content {
  padding: 0 1.5rem 1.5rem 1.5rem;
}

.child-profile {
  display: flex;
  align-items: center;
  gap: 1.5rem;
}

.child-avatar {
  width: 70px;
  height: 70px;
  border-radius: 50%;
  border: 3px solid #48bb78;
  object-fit: cover;
}

.child-details h4 {
  margin: 0 0 0.5rem 0;
  font-size: 1.3rem;
  font-weight: 600;
  color: #2d3748;
}

.grade {
  margin: 0 0 1rem 0;
  color: #718096;
  font-size: 1rem;
}

.child-stats {
  display: flex;
  gap: 1rem;
}

.stat-item {
  text-align: center;
}

.stat-label {
  display: block;
  font-size: 0.8rem;
  color: #a0aec0;
  margin-bottom: 0.25rem;
}

.stat-value {
  display: block;
  font-weight: 600;
  color: #2d3748;
  font-size: 1rem;
}

.quick-actions {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
  gap: 1rem;
}

.quick-action-btn {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 0.5rem;
  padding: 1rem;
  background: linear-gradient(135deg, #f7fafc, #edf2f7);
  border: none;
  border-radius: 12px;
  cursor: pointer;
  transition: all 0.3s ease;
  font-weight: 500;
}

.quick-action-btn:hover {
  background: linear-gradient(135deg, #667eea, #764ba2);
  color: white;
  transform: translateY(-3px);
  box-shadow: 0 8px 25px rgba(102, 126, 234, 0.3);
}

.action-icon {
  font-size: 1.5rem;
}

.settings-list {
  display: flex;
  flex-direction: column;
  gap: 1rem;
}

.setting-item {
  display: flex;
  align-items: center;
  gap: 1rem;
  padding: 1rem;
  background: #f7fafc;
  border-radius: 12px;
  transition: background 0.3s ease;
}

.setting-item:hover {
  background: #edf2f7;
}

.setting-icon {
  font-size: 1.2rem;
}

.setting-label {
  flex: 1;
  font-weight: 500;
  color: #2d3748;
}

.toggle-btn,
.setting-btn {
  padding: 0.5rem 1rem;
  border: none;
  border-radius: 8px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s ease;
}

.toggle-btn {
  background: #e2e8f0;
  color: #718096;
}

.toggle-btn.active {
  background: #48bb78;
  color: white;
}

.setting-btn {
  background: #667eea;
  color: white;
}

.setting-btn:hover,
.toggle-btn:hover {
  transform: scale(1.05);
}

/* Modal Styles */
.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.7);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
  backdrop-filter: blur(5px);
}

.modal-content {
  background: white;
  border-radius: 20px;
  width: 90%;
  max-width: 500px;
  box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
  overflow: hidden;
  animation: modalSlideIn 0.3s ease;
}

@keyframes modalSlideIn {
  from {
    opacity: 0;
    transform: translateY(-50px);
  }

  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.modal-header {
  padding: 1.5rem;
  background: linear-gradient(135deg, #667eea, #764ba2);
  color: white;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.modal-header h3 {
  margin: 0;
  font-size: 1.3rem;
  font-weight: 700;
}

.close-btn {
  background: none;
  border: none;
  color: white;
  font-size: 1.5rem;
  cursor: pointer;
  padding: 0;
  width: 30px;
  height: 30px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: background 0.3s ease;
}

.close-btn:hover {
  background: rgba(255, 255, 255, 0.2);
}

.modal-body {
  padding: 2rem;
}

.form-group {
  margin-bottom: 1.5rem;
}

.form-group label {
  display: block;
  margin-bottom: 0.5rem;
  font-weight: 600;
  color: #2d3748;
}

.form-group input {
  width: 100%;
  padding: 0.75rem;
  border: 2px solid #e2e8f0;
  border-radius: 10px;
  font-size: 1rem;
  transition: border-color 0.3s ease;
  box-sizing: border-box;
}

.form-group input:focus {
  outline: none;
  border-color: #667eea;
  box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
}

.modal-footer {
  padding: 1.5rem;
  background: #f7fafc;
  display: flex;
  justify-content: flex-end;
  gap: 1rem;
}

.btn-cancel,
.btn-save {
  padding: 0.75rem 1.5rem;
  border: none;
  border-radius: 10px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s ease;
}

.btn-cancel {
  background: #e2e8f0;
  color: #718096;
}

.btn-cancel:hover {
  background: #cbd5e0;
}

.btn-save {
  background: linear-gradient(135deg, #667eea, #764ba2);
  color: white;
}

.btn-save:hover {
  transform: translateY(-2px);
  box-shadow: 0 8px 25px rgba(102, 126, 234, 0.4);
}

/* Responsive Design */
@media (max-width: 768px) {
  .profile-banner {
    flex-direction: column;
    text-align: center;
    gap: 1.5rem;
  }

  .profile-info {
    flex-direction: column;
    text-align: center;
    gap: 1rem;
  }

  .info-details h2 {
    font-size: 1.5rem;
  }

  .content-grid {
    grid-template-columns: 1fr;
    gap: 1.5rem;
  }

  .child-profile {
    flex-direction: column;
    text-align: center;
  }

  .child-stats {
    justify-content: center;
  }

  .quick-actions {
    grid-template-columns: repeat(2, 1fr);
  }

  .profile-actions {
    width: 100%;
    justify-content: center;
  }

  .action-btn {
    flex: 1;
    max-width: 200px;
  }
}

@media (max-width: 480px) {
  .profile-container {
    padding: 0 0.5rem;
  }

  .profile-banner {
    padding: 1.5rem;
  }

  .profile-avatar {
    width: 80px;
    height: 80px;
  }

  .quick-actions {
    grid-template-columns: 1fr;
  }

  .modal-content {
    width: 95%;
  }

  .modal-body {
    padding: 1.5rem;
  }
}

.child-email {
  margin: 0.5rem 0 1rem 0;
  color: #718096;
  font-size: 0.9rem;
  display: flex;
  align-items: center;
  gap: 0.5rem;
}

.attendance-rate {
  color: #48bb78;
  font-weight: 700;
}

.tips-card {
  background: linear-gradient(135deg, #fff5f5 0%, #fed7d7 100%);
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 1.5rem 1.5rem 0 1.5rem;
  border-bottom: 1px solid #e2e8f0;
  margin-bottom: 1.5rem;
}

.refresh-tip-btn {
  background: #667eea;
  color: white;
  border: none;
  border-radius: 50%;
  width: 35px;
  height: 35px;
  cursor: pointer;
  transition: all 0.3s ease;
  display: flex;
  align-items: center;
  justify-content: center;
}

.refresh-tip-btn:hover {
  background: #5a67d8;
  transform: rotate(180deg);
}

.tip-container {
  display: flex;
  align-items: flex-start;
  gap: 1rem;
  padding: 1rem;
  background: rgba(255, 255, 255, 0.7);
  border-radius: 12px;
  border-left: 4px solid #667eea;
}

.tip-icon {
  font-size: 2rem;
  flex-shrink: 0;
}

.tip-content h4 {
  margin: 0 0 0.5rem 0;
  color: #2d3748;
  font-weight: 600;
}

.tip-content p {
  margin: 0;
  color: #4a5568;
  line-height: 1.5;
}

.tip-footer {
  text-align: center;
  margin-top: 1rem;
  color: #718096;
}

.setting-btn.danger {
  background: linear-gradient(135deg, #fc8181, #f56565);
  color: white;
}

.setting-btn.danger:hover {
  background: linear-gradient(135deg, #f56565, #e53e3e);
}

.status-active {
  color: #48bb78;
  font-weight: 600;
  background: #e6fffa;
  padding: 0.25rem 0.75rem;
  border-radius: 12px;
  font-size: 0.9rem;
}

.password-requirements {
  margin-top: 0.5rem;
  padding: 0.75rem;
  background: #f7fafc;
  border-radius: 8px;
  border-left: 3px solid #667eea;
}

.password-requirements small {
  color: #718096;
  line-height: 1.4;
}
</style>