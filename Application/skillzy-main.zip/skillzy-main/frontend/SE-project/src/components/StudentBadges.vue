<template>
  <div class="badge-system">
    <div class="container">
      <!-- Loading State -->
      <div v-if="loading" class="loading-container">
        <div class="spinner"></div>
        <p class="loading-text">Loading your achievements...</p>
      </div>

      <!-- Main Content -->
      <div v-else>
        <!-- Header Section -->
        <div class="header-section">
          <div class="header-content">
            <!-- Lottie on the left -->
            <DotLottieVue
              src="https://lottie.host/deadadf8-4e1c-4175-8d91-f28f789c7f76/qonHmNDFRr.lottie"
              class="header-lottie-animation"
              autoplay
              loop
            />

            <!-- Content on the right -->
            <div class="header-text">
              <h1 class="main-title">Achievement Center</h1>
              <p class="subtitle">Track your progress and unlock amazing badges!</p>

              <!-- Stats Cards -->
              <div class="stats-grid">
                <div class="stat-card">
                  <div class="stat-number stat-indigo">{{ userBadges.length }}</div>
                  <div class="stat-label">Badges Earned</div>
                </div>
                <div class="stat-card">
                  <div class="stat-number stat-green">{{ totalEarnedPoints }}</div>
                  <div class="stat-label">Total Points</div>
                </div>
                <div class="stat-card">
                  <div class="stat-number stat-purple">{{ progressPercentage }}%</div>
                  <div class="stat-label">Progress</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Your Badges Section -->
        <div class="section">
          <h2 class="section-title">
            <span class="medal-emoji">🏅</span>
            Your Achievements
          </h2>

          <div v-if="earnedBadges.length > 0" class="badges-grid">
            <div
              v-for="badge in earnedBadges"
              :key="badge.id"
              :class="['badge-card', 'earned', `rarity-${badge.rarity}`]"
              @click="onBadgeClick(badge)"
              style="cursor: pointer;"
            >
                
              <!-- ---- -->
              <!-- NEW: show badge image if present -->
              <img
                v-if="badge.storyImage"
                :src="badge.storyImage"
                :alt="badge.name"
                class="badge-thumb-image"
                style="width:120px; height:120px; object-fit:cover; border-radius:1rem; margin-bottom:0.6rem;"
              />

              <!-- <div :class="['badge-icon', `gradient-${badge.color}`]">
                <component :is="badge.icon" class="icon" />
              </div> -->
              <h3 class="badge-name">{{ badge.name }}</h3>
              <p class="badge-description">{{ badge.description }}</p>
              <div class="badge-points earned-points">
                +{{ badge.points }} pts
              </div>
            </div>
          </div>

          <div v-else class="no-badges">
            <div class="trophy-icon">🏆</div>
            <p class="no-badges-title">No badges earned yet</p>
            <p class="no-badges-subtitle">
              Complete assignments and tasks to unlock your first badge!
            </p>
          </div>
        </div>

        <!-- All Badges by Category -->
        <div v-for="category in categories" :key="category" class="section">
          <h2 class="section-title">
            <span class="category-emoji">{{ getCategoryEmoji(category) }}</span>
            {{ category }} Badges
          </h2>

          <!-- Category Progress Bar -->
          <div class="category-progress-bar-container">
            <DotLottieVue
              :src="getCategoryLottie(category)"
              class="category-lottie"
              autoplay
              loop
              :style="{ left: getCategoryProgress(category).percentage + '%' }"
            />
            <div class="category-progress-bar-background">
              <div
                class="category-progress-bar-fill"
                :style="{ width: getCategoryProgress(category).percentage + '%' }"
              ></div>
            </div>
          </div>

          <strong>
            <p class="category-progress-text" style="color: white;">
              {{ getCategoryProgress(category).earned }}/{{ getCategoryProgress(category).total }} badges unlocked
            </p>
          </strong>

          <!-- Single Badge Carousel -->
          <div class="carousel-single-box">
            <button
              class="arrow-btn"
              @click="prevBadge(category)"
              :disabled="currentBadgeIndexes[category] === 0"
              aria-label="Previous badge"
            >
              ←
            </button>

            <div
              class="single-story-card"
              :class="userBadges.includes(currentBadge(category).name) ? 'unlocked' : 'locked'"
              @click="onBadgeClick(currentBadge(category))"
              style="cursor: pointer;"
            >
              <!-- Story Image -->
              <div class="story-image-container">
                <img
                  :src="currentBadge(category).storyImage"
                  :alt="currentBadge(category).name"
                  class="story-image"
                />
                <span
                  v-if="!userBadges.includes(currentBadge(category).name)"
                  class="lock-overlay"
                >🔒</span>
              </div>

              <!-- Story Title -->
              <h3 :class="['story-title', userBadges.includes(currentBadge(category).name) ? '' : 'locked-text']">
                {{ currentBadge(category).name }}
              </h3>

              <!-- Story Description -->
              <p :class="['story-description', userBadges.includes(currentBadge(category).name) ? '' : 'locked-text']">
                {{ currentBadge(category).description }}
              </p>

              <!-- Status -->
              <div
                v-if="userBadges.includes(currentBadge(category).name)"
                class="story-status unlocked-text"
              >
                Story Unlocked
              </div>
              <div v-else class="story-status locked-text">
                Story Locked
              </div>
            </div>

            <button
              class="arrow-btn"
              @click="nextBadge(category)"
              :disabled="currentBadgeIndexes[category] === getBadgesByCategory(category).length - 1"
              aria-label="Next badge"
            >
              →
            </button>
          </div>
        </div>

        <!-- Progress Bar at the very bottom -->
        <div class="progress-section">
          <h3 class="progress-title">Overall Progress</h3>
          <div class="progress-bar-container">
            <div class="progress-bar" :style="{ width: `${progressPercentage}%` }"></div>
          </div>
          <p class="progress-text">
            {{ userBadges.length }} of {{ allBadges.length }} badges unlocked
          </p>
        </div>
      </div>
    </div>
    <!-- Story Modal -->
<div v-if="showStoryModal" class="modal-overlay" @click.self="closeStoryModal">
  <div class="modal-content">
    <button class="modal-close-btn" @click="closeStoryModal">×</button>
    <h2 class="modal-title">{{ categoryStories[activeCategory]?.title }}</h2>

    <img 
      :src="categoryStories[activeCategory]?.image" 
      :alt="categoryStories[activeCategory]?.title" 
      class="modal-image" 
    />
    <div class="modal-dialogue" v-html="categoryStories[activeCategory]?.dialogue"></div>
  </div>
</div>
<!-- Story Modal -->
  </div>
</template>



<script setup>
import { ref, computed, onMounted, h } from 'vue'
import { useRoute } from 'vue-router'
import { DotLottieVue } from '@lottiefiles/dotlottie-vue'


// ------------------slide rish---------------//

// For single-badge carousel
const currentBadgeIndexes = ref({})

onMounted(() => {
  categories.value.forEach(cat => {
    currentBadgeIndexes.value[cat] = 0
  })
})

const currentBadge = (category) => {
  return getBadgesByCategory(category)[currentBadgeIndexes.value[category]]
}

const prevBadge = (category) => {
  if (currentBadgeIndexes.value[category] > 0) {
    currentBadgeIndexes.value[category]--
  }
}
const nextBadge = (category) => {
  if (currentBadgeIndexes.value[category] < getBadgesByCategory(category).length - 1) {
    currentBadgeIndexes.value[category]++
  }
}

// -----------------------------------//

// Icons (you'll need to import these from your icon library)
// For this example, I'm using simple string representations
// Replace with actual icon components from lucide-vue-next or similar
const Trophy = 'trophy'
const Star = 'star'
const Target = 'target'
const Clock = 'clock'
const BookOpen = 'book-open'
const Brain = 'brain'
const Zap = 'zap'
const Award = 'award'
const Medal = 'medal'
const Crown = 'crown'
const Compass = 'compass'
const Palette = 'palette'
const Puzzle = 'puzzle'
const Heart = 'heart'
const Money = 'money'
const Chat = 'chat'

const route = useRoute()
const studentId = route.params.id

const userBadges = ref([])
const loading = ref(true)


// --------modal-------//
const showStoryModal = ref(false)
const activeCategory = ref(null)

// --------------------------//

// All available badges
const allBadges = ref([
  // Academic Excellence Badges
  {
    id: 1,
    name: 'Perfect Scholar',
    description: 'Score 100% on an assignment',
    storyImage: 'https://kumarrishabh-crypto.github.io/cdn-images/Perfect%20Scholar.jpg', // <-- new
    icon: Trophy,
    color: 'yellow',
    category: 'Academic',
    rarity: 'gold',
    points: 100
  },
  {
    id: 2,
    name: 'Academic Star',
    description: 'Score 95%+ on 5 assignments',
    storyImage: 'https://kumarrishabh-crypto.github.io/cdn-images/Academic%20Star.jpg', // <-- new
    icon: Star,
    color: 'blue',
    category: 'Academic',
    rarity: 'gold',
    points: 250
  },
  {
    id: 3,
    name: 'Subject Master',
    description: 'Maintain 90%+ in atleast 20 assignments',
    storyImage: 'https://kumarrishabh-crypto.github.io/cdn-images/Subject%20Master.jpg', // <-- new
    icon: BookOpen,
    color: 'purple',
    category: 'Academic',
    rarity: 'gold',
    points: 300
  },
  
  // Consistency Badges
  {
    id: 4,
    name: 'Streak Master',
    description: 'Active for 5 consecutive days',
    storyImage: 'https://kumarrishabh-crypto.github.io/cdn-images/Streak%20Master.jpg', // <-- new
    icon: Zap,
    color: 'orange',
    category: 'Consistency',
    rarity: 'silver',
    points: 50
  },
  {
    id: 5,
    name: 'Dedication Champion',
    description: 'Active for 10 consecutive days',
    storyImage: 'https://kumarrishabh-crypto.github.io/cdn-images/Dedicated%20Champion.jpg', // <-- new
    icon: Target,
    color: 'red',
    category: 'Consistency',
    rarity: 'gold',
    points: 100
  },
  {
    id: 6,
    name: 'Persistent Learner',
    description: 'Active for 30 consecutive days',
    storyImage: 'https://kumarrishabh-crypto.github.io/cdn-images/Persistent%20Learner.jpg', // <-- new
    icon: Medal,
    color: 'emerald',
    category: 'Consistency',
    rarity: 'diamond',
    points: 200
  },
  
  // Task Management Badges
  {
    id: 7,
    name: 'Task Completionist',
    description: 'Complete 10 tasks',
    storyImage: 'https://kumarrishabh-crypto.github.io/cdn-images/Task%20Completionist.jpg', // <-- new
    icon: Award,
    color: 'teal',
    category: 'Tasks',
    rarity: 'bronze',
    points: 75
  },
  {
    id: 8,
    name: 'Task Master',
    description: 'Complete 50 tasks',
    storyImage: 'https://kumarrishabh-crypto.github.io/cdn-images/Task%20Master.jpg', // <-- new
    icon: Crown,
    color: 'indigo',
    category: 'Tasks',
    rarity: 'gold',
    points: 200
  },
  {
    id: 9,
    name: 'Time Manager',
    description: 'Complete 5 tasks before deadline',
    storyImage: 'https://kumarrishabh-crypto.github.io/cdn-images/Time%20Manager.jpg', // <-- new
    icon: Clock,
    color: 'pink',
    category: 'Tasks',
    rarity: 'silver',
    points: 100
  },
  {
    id: 10,
    name: 'Early Bird',
    description: 'Submit 10 assignments early',
    storyImage: 'https://kumarrishabh-crypto.github.io/cdn-images/Early%20Bird.jpg', // <-- new
    icon: Star,
    color: 'amber',
    category: 'Tasks',
    rarity: 'gold',
    points: 150
  },
  
  // Focus Mode Badges
  {
    id: 11,
    name: 'Focus Novice',
    description: 'Complete 5 focus sessions',
    storyImage: 'https://kumarrishabh-crypto.github.io/cdn-images/Focus%20Novice.jpg', // <-- new
    icon: Brain,
    color: 'cyan',
    category: 'Focus',
    rarity: 'bronze',
    points: 50
  },
  {
    id: 12,
    name: 'Focus Expert',
    description: 'Complete 25 focus sessions',
    storyImage: 'https://kumarrishabh-crypto.github.io/cdn-images/Focus%20Expert.jpg', // <-- new
    icon: Brain,
    color: 'violet',
    category: 'Focus',
    rarity: 'gold',
    points: 150
  },
  {
    id: 13,
    name: 'Concentration Master',
    description: 'Complete 2-hour focus session',
    storyImage: 'https://kumarrishabh-crypto.github.io/cdn-images/Concentration%20Master.jpg', // <-- new
    icon: Target,
    color: 'rose',
    category: 'Focus',
    rarity: 'diamond',
    points: 200
  },
  {
    id: 14,
    name: 'Distraction Fighter',
    description: 'Focus session with <5 tab switches',
    storyImage: 'https://kumarrishabh-crypto.github.io/cdn-images/Distraction%20Fighter.jpg', // <-- new
    icon: Zap,
    color: 'lime',
    category: 'Focus',
    rarity: 'silver',
    points: 100
  },
  {
    id: 15,
    name: 'Explorer',
    description: 'Complete nature/outdoor assignment',
    storyImage: 'https://kumarrishabh-crypto.github.io/cdn-images/Explorer.jpg', // <-- new
    icon: Compass,
    color: 'green',
    category: 'Special',
    rarity: 'gold',
    points: 75
  },
  {
    id: 16,
    name: 'Creative Genius',
    description: 'Score 100% on creative assignment',
    storyImage: 'https://kumarrishabh-crypto.github.io/cdn-images/Creative%20Genius.jpg', // <-- new
    icon: Palette,
    color: 'purple',
    category: 'Special',
    rarity: 'diamond',
    points: 100
  },
  {
    id: 17,
    name: 'Problem Solver',
    description: 'Complete problem-solving assignment',
    storyImage: 'https://kumarrishabh-crypto.github.io/cdn-images/Problem%20Solver.jpg', // <-- new
    icon: Puzzle,
    color: 'blue',
    category: 'Special',
    rarity: 'gold',
    points: 100
  },
  {
    id: 18,
    name: 'Health Champion',
    description: 'Complete health-related assignment',
    storyImage: 'https://kumarrishabh-crypto.github.io/cdn-images/Health%20Champion.jpg', // <-- new
    icon: Heart,
    color: 'red',
    category: 'Special',
    rarity: 'silver',
    points: 75
  },
  {
    id: 19,
    name: 'Financial Wizard',
    description: 'Excel in financial literacy',
    storyImage: 'https://kumarrishabh-crypto.github.io/cdn-images/Financial%20Wizard.jpg', // <-- new
    icon: Money,
    color: 'yellow',
    category: 'Special',
    rarity: 'gold',
    points: 75
  },
  {
    id: 20,
    name: 'Communication Expert',
    description: 'Excel in communication skills',
    storyImage: 'https://kumarrishabh-crypto.github.io/cdn-images/Communication%20Expert.jpg', // <-- new
    icon: Chat,
    color: 'orange',
    category: 'Special',
    rarity: 'diamond',
    points: 75
  },    
  {
    id:21,
    name: 'Improvement Star',
    description: 'Show 20% improvement in scores',
    storyImage: 'https://kumarrishabh-crypto.github.io/cdn-images/Improvement%20Star.jpg', // <-- new
    icon: Star,
    color: 'yellow',
    category: 'Special Recognition',
    rarity: 'gold',
    points: 150
  },
  {
    id: 22,
    name: 'Participation Champion',
    description: '100% assignment submission rate',
    storyImage: 'https://kumarrishabh-crypto.github.io/cdn-images/Participation%20Champion.jpg', // <-- new
    icon: Star,
    color: 'blue',
    category: 'Special Recognition',
    rarity: 'gold',
    points: 200
  },
  {
    id: 23,
    name: 'Excellence Award',
    description: 'Top 10% of class performance',
    storyImage: 'https://kumarrishabh-crypto.github.io/cdn-images/Excellence%20Award.jpg', // <-- new
    icon: Star,
    color: 'purple',
    category: 'Special Recognition',
    rarity: 'diamond',
    points: 400
  },

  // custom badges
  {
    id: 24,
    name: 'First Step',
    description: 'First assignment submitted',
    storyImage: 'https://kumarrishabh-crypto.github.io/cdn-images/First%20Step.jpg', // <-- new
    icon: Star,
    color: 'green',
    category: 'Custom',
    rarity: 'gold',
    points: 100
  },
  {
    id: 25,
    name: 'Laser Focused',
    description: 'Completed 20+ min focus session',
    storyImage: 'https://kumarrishabh-crypto.github.io/cdn-images/Laser%20Focused.jpg', // <-- new
    icon: Star,
    color: 'orange',
    category: 'Custom',
    rarity: 'silver',
    points: 200
  },
  {
    id: 26,
    name: 'Task Ninja',
    description: 'Complete 100 tasks',
    storyImage: 'https://kumarrishabh-crypto.github.io/cdn-images/Task%20Ninja.jpg', // <-- new
    icon: Star,
    color: 'red',
    category: 'Custom',
    rarity: 'diamond',
    points: 400
  },
    {
    id: 27,
    name: 'Bronze Achiever',
    description: 'Earn first 3 badges',
    storyImage: 'https://kumarrishabh-crypto.github.io/cdn-images/Bronze%20Achiever.jpg', // <-- new
    icon: Star,
    color: 'amber',
    category: 'Progression',
    rarity: 'gold',
    points: 150
  },
  {
    id: 28,
    name: 'Silver Achiever',
    description: 'Earn 10 badges',
    storyImage: 'https://kumarrishabh-crypto.github.io/cdn-images/Silver%20Achiever.jpg', // <-- new
    icon: Star,
    color: 'silver',
    category: 'Progression',
    rarity: 'gold',
    points: 300
  },
  {
    id: 29,
    name: 'Gold Achiever',
    description: 'Earn 25 badges',
    storyImage: 'https://kumarrishabh-crypto.github.io/cdn-images/Gold%20Achiever.jpg', // <-- new
    icon: Star,
    color: 'gold',
    category: 'Progression',
    rarity: 'gold',
    points: 500
  },
])

// Real, detailed kahani-style stories for each achievement category
const categoryStories = {
  Academic: {
    title: "The Secret of the Banyan Tree",
    image: "https://kumarrishabh-crypto.github.io/cdn-images/Achievement1.jpg",
    dialogue: `
      Long ago, in a small riverside village, there stood an ancient banyan tree whose
      roots whispered stories to the wind. Every evening, a curious boy named Aarav
      would sit beneath it, listening to the rustling leaves that told tales from
      faraway lands — kings who hid their crowns in clay pots, birds who raced the
      monsoon, and travelers who found magic in the most ordinary places.
      One evening, Aarav placed his palm on the tree's trunk and swore to keep the
      stories alive. The banyan rustled gently, as if to say, "The more you listen,
      the more the world will speak to you."
    `
  },
  Consistency: {
    title: "The Potter's Wheel",
    image: "https://kumarrishabh-crypto.github.io/cdn-images/Achievement2.jpg",
    dialogue: `
      On the outskirts of a bustling town lived Meena, the potter. Every morning,
      before the sun had fully climbed the sky, she would sit by her wheel. Her hands
      were weathered, her motions steady, and each spin brought clay closer to life.
      Neighbors often wondered how her pots never cracked. One day, a young helper
      asked her secret. Meena smiled and replied, "Clay remembers the touch given to
      it each day. Care for it, and it will hold strong even in the fiercest heat."
      The boy never forgot — that steady effort shapes not just clay, but life itself.
    `
  },
  Tasks: {
    title: "The Lantern Collector",
    image: "https://kumarrishabh-crypto.github.io/cdn-images/Achievement3.jpg",
    dialogue: `
      In a quiet coastal village, lived Ravi, who loved lanterns. Each evening he
      would light one, placing it along the winding path near the shore. Soon the
      path glowed with gentle lights guiding fishermen home. Some nights brought
      storms, others brought exhaustion, but Ravi would still light each lantern,
      one after the other. Years later, old and grey, he looked out at the glowing
      path and thought, "Perhaps the greatest journeys are lit by the smallest
      acts we repeat, night after night."
    `
  },
  Focus: {
    title: "The Weaver of Monsoon Silk",
    image: "https://kumarrishabh-crypto.github.io/cdn-images/Achievement4.jpg",
    dialogue: `
      Tara was a weaver who lived where the river curved like a silver snake. During
      monsoon, when winds howled, she sat in her dimly lit hut weaving silk threads
      as fine as rain. Her loom sang a quiet song that drowned the storm’s chaos.
      Days passed, but Tara's gaze never strayed from each pattern taking shape.
      When she finally lifted her eyes, a tapestry shimmered, telling the story of
      clouds and lightning. People asked how she wove such beauty.
      "By listening only to the thread in my hands," she said.
    `
  },
  Special: {
    title: "The Song of the Fireflies",
    image: "https://kumarrishabh-crypto.github.io/cdn-images/Achievement5.jpg",
    dialogue: `
      One summer, the meadow behind Lila's home lit up with thousands of fireflies.
      She spent her nights chasing their golden glow, cupping them gently before
      letting them free. One evening, she noticed they pulsed their lights in a
      gentle rhythm — on, off, on, off. Curious, she began to hum along, creating
      a lullaby that floated into the warm night air. The fireflies seemed to
      dance to her tune, and when the wind carried her song to the forest, even
      the owls hushed to listen.
    `
  },
  "Special Recognition": {
    title: "The Woman Who Painted the Rain",
    image: "https://kumarrishabh-crypto.github.io/cdn-images/Achievement6.jpg",
    dialogue: `
      In a mountain village where the rain stayed for months, life was often grey
      and quiet. Then came an old woman with a cart of colors. She began to paint —
      bright flowers on doors, suns on shutters, and rainbows on cobblestones.
      Children followed her, hands dipped in paint, laughter echoing off the hills.
      One morning, after she had left, the villagers noticed the rain seemed lighter,
      almost playful, as if it too had been touched by her colors. No one ever forgot
      her gift, proving the smallest acts can brighten entire seasons.
    `
  },
  Custom: {
    title: "The Pebble and the River",
    image: "https://kumarrishabh-crypto.github.io/cdn-images/Achievement7.jpg",
    dialogue: `
      A young girl named Noor once found a smooth pebble by the riverbank. She carried
      it everywhere — to the market, to school, even to bed. Her friends teased her,
      but Noor believed the pebble held stories of waters it had traveled. One day,
      she dropped it into the river, watching the ripples spread. "Go," she whispered,
      "and gather more tales." Years later, as a storyteller herself, she often began
      with, "I once knew a pebble who traveled the world…"
    `
  },
  Progression: {
    title: "The Ladder in the Orchard",
    image: "https://kumarrishabh-crypto.github.io/cdn-images/Achievement8.jpg",
    dialogue: `
      In an orchard heavy with fruit, a boy named Kian found an old wooden ladder.
      Each day, he climbed one rung higher, picking ripe fruit for his family. One
      afternoon, he looked down and realized he had reached the highest branch.
      From there he could see the hills, the river, and his tiny house far away.
      He understood then — the ladder hadn’t just lifted him to fruit, but to a view
      he had never imagined. Sometimes, each small step takes you to places your
      eyes have yet to dream.
    `
  }
}



// Computed properties
const categories = computed(() => [...new Set(allBadges.value.map(badge => badge.category))])

const earnedBadges = computed(() => 
  allBadges.value.filter(badge => userBadges.value.includes(badge.name))
)

const totalEarnedPoints = computed(() => 
  earnedBadges.value.reduce((sum, badge) => sum + badge.points, 0)
)

const progressPercentage = computed(() => 
  Math.round((userBadges.value.length / allBadges.value.length) * 100)
)

// Methods
const getCategoryProgress = (category) => {
  const total = allBadges.value.filter(b => b.category === category).length
  const earned = earnedBadges.value.filter(b => b.category === category).length
  return {
    total,
    earned,
    percentage: total === 0 ? 0 : Math.round((earned / total) * 100)
  }
}

const getCategoryLottie = (category) => {
  switch (category) {
    case 'Academic':
      return 'https://lottie.host/5c8cfe63-a2d2-4399-967e-be9d96d1a126/4SlmPOojf9.lottie';
    case 'Consistency':
      return 'https://lottie.host/e891727a-cefb-4dfa-aad2-07ff01ba6717/6iKMZ8Yg0s.lottie';
    case 'Tasks':
      return 'https://lottie.host/5824751d-da9b-473a-9bdf-4f3432579e44/JODPPH4sba.lottie';
    case 'Focus':
      return 'https://lottie.host/focus-character.lottie';

    case 'Special':
      return 'https://lottie.host/c7f77754-0eaa-4f88-a33a-a541c35f0831/vGCUXMotDF.lottie';
    case 'Special Recognition':
      return 'https://lottie.host/9eb84171-70d1-4872-80c0-bf8d52eb40e5/pDwfAdnefb.lottie';
    case 'Custom':
      return 'https://lottie.host/c2293add-ffaf-44ab-82b5-38318bef19d1/MYCNBUuXH0.lottie';
    case 'Progression':
      return 'https://lottie.host/87895a01-25b3-4552-aa14-8f3d2f3d9909/CGLbSKOzln.lottie';
    default:
      return 'https://lottie.host/default-character.lottie';
  }
};


const getCategoryEmoji = (category) => {
  const emojiMap = {
    'Academic': '📚',
    'Consistency': '🔥',
    'Tasks': '✅',
    'Focus': '🧠',
    'Special': '🌟',
    'Special Recognition': '🏆',
    'Custom': '🎨',

  }
  return emojiMap[category] || '🏆'
}

const getBadgesByCategory = (category) => {
  return allBadges.value.filter(badge => badge.category === category)
}

import api from '../api'

const fetchBadges = async () => {
  loading.value = true
  try {
    const response = await api.get(`/student/${studentId}/badges`)
    console.log(response.data)
    userBadges.value = response.data
  } catch (error) {
    console.error('Failed to fetch badges:', error)
    userBadges.value = []
  } finally {
    loading.value = false
  }
}

onMounted(() => {
  fetchBadges()
// --------
  categories.value.forEach(cat => {
    currentBadgeIndexes.value[cat] = 0
  })
// --------
})

// ------------- Story Modal Logic -------------

const onBadgeClick = (badge) => {
  if (userBadges.value.includes(badge.name)) {
    activeCategory.value = badge.category
    showStoryModal.value = true
  }
}

const closeStoryModal = () => {
  showStoryModal.value = false
  activeCategory.value = null
}

</script>

<style scoped>
.badge-system {
  min-height: 100vh;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  padding: 1.5rem;
}

.container {
  max-width: 1200px;
  margin: 0 auto;
}

/* Loading State */
.loading-container {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 5rem 0;
}

.spinner {
  width: 4rem;
  height: 4rem;
  border: 4px solid #e5e7eb;
  border-top: 4px solid #4f46e5;
  border-radius: 50%;
  animation: spin 1s linear infinite;
  margin-bottom: 1rem;
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

.loading-text {
  color: #6b7280;
  font-size: 1.125rem;
}

/* Header Section */
.header-section {
  text-align: center;
  margin-bottom: 2rem;
}

.main-title {
  font-size: 2.5rem;
  font-weight: bold;
  color: whitesmoke;
  margin-bottom: 1rem;
}

.subtitle {
  color: whitesmoke;
  font-size: 1.125rem;
  margin-bottom: 1.5rem;
}

.stats-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 1rem;
  max-width: 600px;
  margin: 0 auto 2rem;
}

.stat-card {
  background: white;
  padding: 1rem;
  border-radius: 0.75rem;
  box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
}

.stat-number {
  font-size: 1.5rem;
  font-weight: bold;
  margin-bottom: 0.25rem;
}

.stat-indigo { color: #4f46e5; }
.stat-green { color: #059669; }
.stat-purple { color: #7c3aed; }

.stat-label {
  font-size: 0.875rem;
  color: #6b7280;
}

/* Sections */
.section {
  margin-bottom: 3rem;
}

.section-title {
  font-size: 1.5rem;
  font-weight: bold;
  color: #1f2937;
  margin-bottom: 1.5rem;
  display: flex;
  align-items: center;
}

.medal-emoji, .category-emoji {
  margin-right: 0.75rem;
}

/* Badge Grid */
.badges-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
  gap: 1rem;
}

.badge-card {
  background: white;
  padding: 1.5rem;
  border-radius: 0.75rem;
  box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
  text-align: center;
  transition: all 0.3s ease;
  border: 4px solid transparent;
}

.badge-card.earned {
  transform: scale(1);
}

.badge-card.earned:hover {
  transform: scale(1.05);
}

.badge-card.locked {
  opacity: 0.75;
}

.badge-card.locked:hover {
  opacity: 1;
  box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1);
}

/* Badge Rarity Rings */
.rarity-bronze.earned {
  border-color: #fbbf24;
  box-shadow: 0 10px 15px -3px rgba(251, 191, 36, 0.2);
}

.rarity-silver.earned {
  border-color: #9ca3af;
  box-shadow: 0 10px 15px -3px rgba(156, 163, 175, 0.2);
}

.rarity-gold.earned {
  border-color: #fde047;
  box-shadow: 0 10px 15px -3px rgba(253, 224, 71, 0.2);
}

.rarity-diamond.earned {
  border-color: #60a5fa;
  box-shadow: 0 10px 15px -3px rgba(96, 165, 250, 0.2);
}

/* Badge Icon */
.badge-icon {
  width: 4rem;
  height: 4rem;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  margin: 0 auto 1rem;
  box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
  transition: all 0.3s ease;
}

.icon {
  width: 2rem;
  height: 2rem;
  color: white;
}

.locked-icon {
  background: #e5e7eb;
}

.locked-icon .icon {
  color: #9ca3af;
}

/* Gradient Colors */
.gradient-yellow { background: linear-gradient(135deg, #fbbf24, #d97706); }
.gradient-blue { background: linear-gradient(135deg, #60a5fa, #3b82f6); }
.gradient-purple { background: linear-gradient(135deg, #a78bfa, #8b5cf6); }
.gradient-orange { background: linear-gradient(135deg, #fb923c, #f97316); }
.gradient-red { background: linear-gradient(135deg, #f87171, #ef4444); }
.gradient-emerald { background: linear-gradient(135deg, #6ee7b7, #10b981); }
.gradient-teal { background: linear-gradient(135deg, #5eead4, #14b8a6); }
.gradient-indigo { background: linear-gradient(135deg, #a5b4fc, #6366f1); }
.gradient-pink { background: linear-gradient(135deg, #f9a8d4, #ec4899); }
.gradient-amber { background: linear-gradient(135deg, #fcd34d, #f59e0b); }
.gradient-cyan { background: linear-gradient(135deg, #67e8f9, #06b6d4); }
.gradient-violet { background: linear-gradient(135deg, #c4b5fd, #8b5cf6); }
.gradient-rose { background: linear-gradient(135deg, #fda4af, #f43f5e); }
.gradient-lime { background: linear-gradient(135deg, #bef264, #84cc16); }

/* Badge Text */
.badge-name {
  font-weight: bold;
  color: #1f2937;
  margin-bottom: 0.5rem;
  font-size: 1rem;
}

.badge-description {
  font-size: 0.875rem;
  color: #6b7280;
  margin-bottom: 0.75rem;
  line-height: 1.4;
}

.locked-text {
  color: #9ca3af;
}

/* Badge Points */
.badge-points {
  display: inline-block;
  padding: 0.25rem 0.75rem;
  border-radius: 9999px;
  font-size: 0.75rem;
  font-weight: 600;
  margin-bottom: 0.5rem;
}

.earned-points {
  background: #dcfce7;
  color: #166534;
}

.locked-points {
  background: #f3f4f6;
  color: #6b7280;
}

/* Badge Rarity */
.badge-rarity {
  display: inline-block;
  padding: 0.25rem 0.5rem;
  border-radius: 0.25rem;
  font-size: 0.75rem;
  font-weight: 500;
  background: #f3f4f6;
  color: #6b7280;
}

/* No Badges State */
.no-badges {
  text-align: center;
  padding: 3rem;
  background: white;
  border-radius: 0.75rem;
  box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
}

.trophy-icon {
  font-size: 4rem;
  margin-bottom: 1rem;
}

.no-badges-title {
  color: #6b7280;
  font-size: 1.125rem;
  margin-bottom: 0.5rem;
}

.no-badges-subtitle {
  color: #9ca3af;
}

/* Progress Section */
.progress-section {
  background: white;
  padding: 1.5rem;
  border-radius: 0.75rem;
  box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
  margin-top: 3rem;
}

.progress-title {
  font-size: 1.125rem;
  font-weight: bold;
  color: #1f2937;
  margin-bottom: 1rem;
}

.progress-bar-container {
  width: 100%;
  height: 1rem;
  background: #e5e7eb;
  border-radius: 9999px;
  margin-bottom: 1rem;
  overflow: hidden;
}

.progress-bar {
  height: 100%;
  background: linear-gradient(135deg, #6366f1, #8b5cf6);
  border-radius: 9999px;
  transition: width 1s ease-out;
}

.progress-text {
  text-align: center;
  color: #6b7280;
  font-size: 0.875rem;
}

/* Responsive Design */
@media (max-width: 768px) {
  .badge-system {
    padding: 1rem;
  }
  
  .main-title {
    font-size: 2rem;
  }
  
  .badges-grid {
    grid-template-columns: 1fr;
  }
  
  .stats-grid {
    grid-template-columns: 1fr;
  }
}

.category-progress-bar-container {
  position: relative;
  width: 100%;
  height: 80px; /* Taller container to allow character to float above */
  margin-bottom: -40px;
  /* margin-top: 20px; */
}

/* This is the cute animated Lottie character */
.category-lottie {
  position: absolute;
  bottom: 20px; /* Raise it above the bar */
  transform: translateX(-50%);
  width: 100px; /* Adjust size as needed */
  height: 100px;
  z-index: 2;
  pointer-events: none;
}

/* The outer track (gray bar) */
.category-progress-bar-background {
  width: 100%;
  height: 20px;
  background-color: #e0e0e0;
  border-radius: 10px;
  position: relative;
  overflow: hidden;
  z-index: 0;
}

/* The black filled part */
.category-progress-bar-fill {
  height: 20vh !important;
  background-color: #000;
  border-radius: 10px;
  position: absolute;
  left: 0;
  top: 0;
  z-index: 1;
}
.header-section {
  padding: 40px 20px;
  background: transparent;
}

/* Use Flexbox to align the dog and text */
.header-content {
  display: flex;
  align-items: center;
  justify-content: left;
  flex-wrap: wrap; /* Wraps on smaller screens */
  gap: 40px;
}

/* Style the Lottie */
.header-lottie-animation {
  width: 300px;
  height: 200px;
  flex-shrink: 0;
}

/* Content */
.header-text {
  text-align: center;
}

/* Titles */
.main-title {
  font-size: 32px;
  font-weight: bold;
  color: white;
  margin: 0;
}

.subtitle {
  font-size: 16px;
  color: #e5e5e5;
  margin-bottom: 24px;
}

/* Stats Grid */
.stats-grid {
  display: flex;
  flex-wrap: wrap;
  gap: 20px;
  justify-content: center;
}

.stat-card {
  background-color: white;
  border-radius: 12px;
  padding: 16px 24px;
  box-shadow: 0 4px 8px rgba(0,0,0,0.05);
  min-width: 120px;
  text-align: center;
}

.stat-number {
  font-size: 24px;
  font-weight: bold;
}

.stat-label {
  font-size: 14px;
  color: #555;
}

/* ---------- */

/* New sideshow horizontal container */
.carousel-wrapper {
  display: flex;
  align-items: center;
  gap: 0.5rem;
}

.arrow-btn {
  background: rgba(0,0,0,0.5);
  color: white;
  border: none;
  font-size: 1.5rem;
  cursor: pointer;
  padding: 0.5rem 0.75rem;
  border-radius: 50%;
  transition: background 0.3s;
  z-index: 1;
}
.arrow-btn:hover {
  background: rgba(0,0,0,0.8);
}

.badges-carousel {
  display: flex;
  overflow-x: hidden;
  scroll-behavior: smooth;
  gap: 1rem;
  flex: 1 1 0;
}

.badge-card-carousel {
  min-width: 220px;
  background: white;
  padding: 1rem;
  border-radius: 0.75rem;
  text-align: center;
  position: relative;
  transition: transform 0.3s ease;
}
.badge-card-carousel.earned:hover {
  transform: scale(1.05);
}
.badge-card-carousel.locked {
  opacity: 0.7;
  filter: blur(1px);
}

.lock-overlay {
  position: absolute;
  top: 8px;
  right: 8px;
  font-size: 1.5rem;
  color: #374151;
}

.lock-overlay {
  position: absolute;
  top: 8px;
  right: 8px;
  font-size: 1.5rem;
  color: #374151;
  z-index: 3;
}

/* Keep your old .gradient-* and .badge-icon styles */
.carousel-single-box {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 1rem;
}

.single-badge-card {
  width: 260px;
  background: white;
  padding: 1.5rem;
  border-radius: 0.8rem;
  box-shadow: 0 8px 16px rgba(0,0,0,0.06);
  position: relative;
  text-align: center;
}
.single-badge-card.locked {
  opacity: 0.7;
  filter: blur(2px);
}

.arrow-btn {
  background: #6366f1;
  color: white;
  border: none;
  font-size: 1.5rem;
  border-radius: 50%;
  padding: 0.7rem;
  cursor: pointer;
}
.arrow-btn:disabled {
  opacity: 0.5;
  cursor: default;
}

.lock-overlay {
  position: absolute;
  top: 8px;
  right: 8px;
  font-size: 1.5rem;
  color: #374151;
}

.carousel-index-indicator {
  text-align: center;
  color: white;
  margin-top: 0.5rem;
  font-size: 0.95rem;
  opacity: 0.7;
}

.single-story-card {
  width: 320px;
  background: white;
  padding: 1.5rem;
  border-radius: 0.8rem;
  box-shadow: 0 8px 16px rgba(0,0,0,0.06);
  text-align: center;
  position: relative;
}
.single-story-card.locked {
  opacity: 0.7;
  filter: blur(1px);
}

.story-image-container {
  position: relative;
  margin-bottom: 1rem;
}
.story-image {
  width: 100%;
  height: 180px;
  object-fit: cover;
  border-radius: 0.5rem;
}
.lock-overlay {
  position: absolute;
  top: 8px;
  right: 8px;
  font-size: 1.8rem;
  color: #374151;
}

.story-title {
  font-size: 1.25rem;
  font-weight: bold;
  margin-bottom: 0.75rem;
}
.story-description {
  font-size: 0.95rem;
  line-height: 1.4;
  color: #4b5563;
  margin-bottom: 1rem;
}
.story-status.unlocked-text {
  color: #10b981;
  font-weight: 600;
}
.story-status.locked-text {
  color: #9ca3af;
  font-weight: 600;
}

.modal-overlay {
  position: fixed;
  inset: 0;
  background: rgba(0,0,0,0.65);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 1100;
}

.modal-content {
  background: #fffdf5;
  border-radius: 20px;
  width: 95%;
  max-width: 560px;
  padding: 2rem 1.4rem 2.3rem 1.4rem;
  position: relative;
  max-height: 85vh;
  overflow-y: auto;
  box-shadow: 0 8px 44px rgba(0,0,0,0.25);
  animation: popIn 0.3s;
  border: 3.5px solid #ffe066; /* fun yellow border */
}

@keyframes popIn {
  0% { transform: scale(0.92); opacity:0;}
  100% {transform: scale(1); opacity:1;}
}


.modal-close-btn {
  position: absolute;
  top: 0.6rem;
  right: 1rem;
  font-size: 2.1rem;
  background: transparent;
  border: none;
  cursor: pointer;
  color: #ff6f00;
  transition: color 0.2s;
}

.modal-close-btn:hover {
  color: #d84315;
}

.modal-title {
  font-family: 'Fredoka', 'Comic Sans MS', cursive, sans-serif;
  font-size: 2rem;
  letter-spacing: 0.5px;
  color: #f57c00;
  margin-bottom: 1.1rem;
  text-align: center;
  text-shadow: 1px 3px 8px #fff5e1;
}

.modal-image {
  width: 90%;
  max-width: 400px;
  height: 180px;
  object-fit: cover;
  border-radius: 18px;
  display: block;
  margin: 0 auto 1.2rem auto;
  box-shadow: 0 4px 16px #ffe06688;
}

.modal-dialogue {
  font-family: 'Fredoka', 'Comic Sans MS', cursive, sans-serif;
  font-size: 1.1rem;
  line-height: 1.8;
  color: #333;
  background: #fffbe8;
  padding: 1.15rem 1rem;
  border-radius: 14px;
  margin-top: 0.7rem;
  box-shadow: 0 2px 8px #ffe06633;
  text-align: left;
  letter-spacing: 0.06em;
  border: 2px dashed #ffd600;
}

.modal-dialogue strong {
  color: #3ca0e7;
  font-weight: 700;
  font-size: 1.13em;
}

.modal-dialogue em {
  color: #fd5732;
  font-style: italic;
  background: #fff7d1;
  border-radius: 4px;
  padding: 0 4px;
  font-size: 1.02em;
}

</style>