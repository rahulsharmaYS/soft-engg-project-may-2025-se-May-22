<template>
  <div class="messages-page">
    <!-- <Header title="Messages & Reports" subtitle="Stay updated on your child's academic journey" /> -->
    <header style="color: whitesmoke;">
      <h1>Messages & Reports</h1>
      <p>Stay updated on your child's academic journey</p>
    </header>
    <div class="main-content-wrapper">
      <div class="message-filters">
        <button :class="{ active: selectedTab === 'all' }" @click="selectedTab = 'all'">
          All
          <span class="badge">{{ messages.length + announcements.length }}</span>
        </button>
        <button :class="{ active: selectedTab === 'pending_tasks_assignments' }"
          @click="selectedTab = 'pending_tasks_assignments'">Pending Tasks</button>
        <button :class="{ active: selectedTab === 'score_update' }" @click="selectedTab = 'score_update'">Score
          Updates</button>
        <button :class="{ active: selectedTab === 'report' }" @click="selectedTab = 'report'">Reports</button>
        <button :class="{ active: selectedTab === 'announcements' }"
          @click="selectedTab = 'announcements'">Announcements</button>
      </div>

      <div class="messages-list">
        <div v-for="message in filteredMessages" :key="message.id" class="message-card" :class="message.message_type">
          <div class="message-content">
            <div class="message-icon">
              <span v-if="message.message_type === 'report'">📄</span>
              <span v-else-if="message.message_type === 'notification' && message.title?.includes('Meeting')">📅</span>
              <span v-else-if="message.message_type === 'pending_tasks_assignments'">📝</span>
              <span v-else-if="message.message_type === 'score_update'">🏆</span>
              <span v-else-if="message.message_type === 'announcements'">📢</span>
            </div>
            <div class="message-details">
              <div class="message-header">
                <h4>{{ message.message }}</h4>
                <!-- <span v-if="message.isNew" class="new-badge">New</span> -->
              </div>
              <small>{{ formatDate(message.timestamp) }}</small>
            </div>
            <div class="message-actions">
              <button v-if="message.message_type === 'report'" class="action-btn download-btn"
                @click="downloadReport(message.report_filename)">
                <span class="btn-icon">⬇️</span>
                Download
              </button>
              <button v-else-if="message.message.includes('Meeting')" class="action-btn calendar-btn">
                <span class="btn-icon">📅</span>
                Add to Calendar
              </button>
            </div>
          </div>
        </div>

        <div class="load-more-container">
          <button class="load-more-btn">Load More Messages</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import Header from '../components/Header.vue'
import { ref, computed, onMounted, watch } from 'vue'
import api from '../api'
import { useRoute } from 'vue-router'

const route = useRoute()
const selectedTab = ref('all')
const messages = ref([])               // All other notifications
const announcements = ref([])          // Separate store for announcements

// Filtered messages based on selected tab
const filteredMessages = computed(() => {
  if (selectedTab.value === 'all') {
    // Merge messages and announcements
    return [...messages.value, ...announcements.value]
  }
  if (selectedTab.value === 'announcements') return announcements.value || []
  return (messages.value || []).filter(msg => msg.message_type === selectedTab.value)
})


function formatDate(dateStr) {
  const options = { day: 'numeric', month: 'short', year: 'numeric' }
  return new Date(dateStr).toLocaleDateString('en-GB', options)
}

async function fetchParentNotifications() {
  try {
    const parentId = route.params.parentId
    const res = await api.get(`parent/notifications/${parentId}`)
    messages.value = res.data
    console.log("Fetched all notifications:", messages.value)
  } catch (e) {
    console.error("Error fetching notifications:", e)
  }
}

// Separate fetch for announcements
async function fetchAnnouncements() {
  try {
    const parentId = route.params.parentId
    const res = await api.get(`parent/announcements/${parentId}`)

    // Convert API shape into common notification structure
    announcements.value = res.data.map(a => ({
      id: a.id,
      message_type: 'announcements',      // fixed type for tab filtering & styling
      title: a.subject || '',              // map subject
      message: a.body || '',               // map body
      timestamp: a.created_at,             // map created_at
      report_filename: a.file_url          // in case there's a file
    }))
    console.log("Fetched announcements:", announcements.value)
  } catch (e) {
    console.error("Error fetching announcements:", e)
  }
}


// File download
const downloadReport = async (filename) => {
  try {
    const res = await api.get(`parent/reports/download/${filename}`, { responseType: 'blob' })
    const blob = new Blob([res.data], { type: 'application/pdf' })
    const url = window.URL.createObjectURL(blob)
    const link = document.createElement('a')
    link.href = url
    link.download = filename
    link.click()
    window.URL.revokeObjectURL(url)
  } catch (err) {
    console.error("Download failed:", err)
  }
}

onMounted(async () => {
  await fetchParentNotifications()
  await fetchAnnouncements()  // Fetch everything except announcements
})
</script>


<style scoped>
.messages-page {
  min-height: 100vh;
  /* background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); */
    background: linear-gradient(135deg, #B12BE2, #1F6CF3);
  padding: 2rem;
  font-family: 'Inter', sans-serif;
}

/* A wrapper is added for consistent spacing */
.main-content-wrapper {
  margin-top: 2rem;
  display: flex;
  flex-direction: column;
  gap: 2rem;
  max-width: 1200px;
  margin-left: auto;
  margin-right: auto;
  padding: 0 1rem;
}

.message-filters {
  display: flex;
  gap: 0;
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(10px);
  border-radius: 12px;
  padding: 8px;
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.2);
  width: fit-content;
}

.message-filters button {
  padding: 12px 24px;
  background: transparent;
  border: none;
  color: #64748b;
  border-radius: 8px;
  cursor: pointer;
  font-weight: 600;
  font-size: 14px;
  transition: all 0.3s ease;
  position: relative;
  display: flex;
  align-items: center;
  gap: 8px;
}

.message-filters button.active {
  background: rgba(102, 126, 234, 0.1);
  color: #667eea;
}

.badge {
  background: #667eea;
  color: white;
  border-radius: 12px;
  padding: 2px 8px;
  font-size: 12px;
  font-weight: 700;
  min-width: 20px;
  text-align: center;
}

.messages-list {
  display: flex;
  flex-direction: column;
  gap: 1.25rem;
}

.message-card {
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(10px);
  border-radius: 16px;
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.2);
  overflow: hidden;
  transition: all 0.3s ease;
  border-left: 4px solid transparent;
}

.message-card:hover {
  transform: translateY(-2px);
  box-shadow: 0 12px 40px rgba(0, 0, 0, 0.15);
}

.message-card.notification {
  border-left-color: #667eea;
}

.message-card.report {
  border-left-color: #10b981;
}

.message-content {
  padding: 20px;
  display: flex;
  align-items: flex-start;
  gap: 16px;
}

.message-icon {
  width: 48px;
  height: 48px;
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 20px;
  flex-shrink: 0;
}

.message-card.report .message-icon {
  background: rgba(16, 185, 129, 0.1);
}

.message-card.notification .message-icon {
  background: rgba(102, 126, 234, 0.1);
}

.message-details {
  flex: 1;
}

.message-header {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 8px;
}

.message-card h4 {
  margin: 0;
  font-size: 16px;
  font-weight: 600;
  color: #1e293b;
}

.new-badge {
  background: #ef4444;
  color: white;
  padding: 2px 8px;
  border-radius: 12px;
  font-size: 11px;
  font-weight: 700;
  text-transform: uppercase;
}

.message-card p {
  margin: 0 0 8px 0;
  color: #64748b;
  font-size: 14px;
  line-height: 1.5;
}

.message-card small {
  color: #94a3b8;
  font-size: 12px;
  font-weight: 500;
}

.message-actions {
  display: flex;
  align-items: center;
}

.action-btn {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 8px 16px;
  border: 1px solid #e2e8f0;
  background: white;
  color: #64748b;
  border-radius: 8px;
  cursor: pointer;
  font-size: 13px;
  font-weight: 600;
  transition: all 0.3s ease;
}

.action-btn:hover {
  background: #f8fafc;
  border-color: #cbd5e0;
  transform: translateY(-1px);
}

.download-btn:hover {
  color: #10b981;
  border-color: #10b981;
}

.calendar-btn:hover {
  color: #667eea;
  border-color: #667eea;
}

.btn-icon {
  font-size: 14px;
}

.load-more-container {
  display: flex;
  justify-content: center;
  margin-top: 2rem;
}

.load-more-btn {
  padding: 12px 32px;
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(10px);
  border: 1px solid rgba(255, 255, 255, 0.2);
  color: #64748b;
  border-radius: 12px;
  cursor: pointer;
  font-weight: 600;
  font-size: 14px;
  transition: all 0.3s ease;
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.1);
}

.load-more-btn:hover {
  background: white;
  color: #667eea;
  transform: translateY(-2px);
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.15);
}

/* Responsive Design */
@media (max-width: 768px) {
  .main-content-wrapper {
    padding: 0 0.5rem;
  }

  .message-filters {
    width: 100%;
    justify-content: center;
  }

  .message-filters button {
    padding: 10px 16px;
    font-size: 13px;
  }

  .message-content {
    padding: 16px;
    gap: 12px;
  }

  .message-icon {
    width: 40px;
    height: 40px;
    font-size: 18px;
  }

  .message-card h4 {
    font-size: 15px;
  }

  .message-card p {
    font-size: 13px;
  }

  .action-btn {
    padding: 6px 12px;
    font-size: 12px;
  }
}

@media (max-width: 480px) {
  .message-content {
    flex-direction: column;
    align-items: flex-start;
  }

  .message-actions {
    width: 100%;
    justify-content: flex-end;
  }

  .message-filters {
    flex-direction: column;
    align-items: stretch;
  }

  .message-filters button {
    width: 100%;
    justify-content: center;
  }
}
</style>