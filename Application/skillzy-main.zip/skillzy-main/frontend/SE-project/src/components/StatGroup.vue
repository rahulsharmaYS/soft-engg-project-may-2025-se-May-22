<template>
  <div class="stats">
    <div v-for="c in classes" :key="c.name" class="stat-card">
      <p class="label">{{ c.name }}</p>
      <div class="progress">
        <div class="bar" :style="{ width: c.progress + '%' }"></div>
      </div>
      <small>{{ c.progress }}% Progress</small>
    </div>
  </div>
</template>

<script setup>
const classes = [
  { name: 'Time Management', progress: 43 },
  { name: 'Communication', progress: 67 },
  { name: 'Health & Wellness', progress: 56 },
  { name: 'Decision Making', progress: 32 }
]
</script>

<style scoped>
.stats {
  display: flex;
  flex-wrap: wrap;
  gap: 1rem;
}
.stat-card {
  background: var(--card);
  color: var(--text);
  box-shadow: var(--shadow);
  border-radius: var(--card-radius);
  padding: 1rem;
}

.label {
  font-weight: bold;
}
.progress {
  background: #e5e7eb;
  height: 10px;
  border-radius: 5px;
  margin: 8px 0;
}
.bar {
  background: #3b82f6;
  height: 100%;
  border-radius: 5px;
}
</style>
