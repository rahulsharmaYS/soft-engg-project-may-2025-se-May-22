from fastapi import APIRouter, UploadFile, File, Form, Depends, HTTPException
from sqlalchemy.orm import Session
from openai import OpenAI
import os
from datetime import datetime
from typing import Dict, List, Optional
from extensions import get_db
import tempfile
from dotenv import load_dotenv
from langchain.memory import ConversationBufferWindowMemory
from langchain.schema import BaseMessage, HumanMessage, AIMessage

# Load environment variables
load_dotenv()

# Create the router instance
chatbot_router = APIRouter(prefix="/api/v1/chatbot", tags=["Chatbot"])

# Initialize OpenAI client with API key
api_key = os.getenv("OPENAI_API_KEY")
if not api_key:
    raise ValueError("OPENAI_API_KEY environment variable is not set")

client = OpenAI(api_key=api_key)

AUDIO_DIR = "chatbot_audio"
os.makedirs(AUDIO_DIR, exist_ok=True)

# Global memory storage for different sessions
conversation_memories: Dict[str, ConversationBufferWindowMemory] = {}

def get_or_create_memory(session_id: str) -> ConversationBufferWindowMemory:
    """Get or create conversation memory for a session using langchain"""
    if session_id not in conversation_memories:
        conversation_memories[session_id] = ConversationBufferWindowMemory(
            k=3,  # Keep last 3 exchanges
            return_messages=True,
            memory_key="history"
        )
    return conversation_memories[session_id]

@chatbot_router.post("/reply")
async def chatbot_reply(
    text: str = Form(...),
    session_id: str = Form(default="default_session"),
    db: Session = Depends(get_db)
):
    try:
        # Get conversation memory for this session
        memory = get_or_create_memory(session_id)
        
        # Add user message to memory
        memory.chat_memory.add_user_message(text)
        
        # Get messages from memory
        messages = memory.chat_memory.messages
        
        # Role mapping for OpenAI format
        role_map = {"human": "user", "ai": "assistant", "system": "system"}
        
        # System prompt
        system_prompt = {
            "role": "system",
            "content": (
                "You are a communication teacher. "
                "Your goal is to help students improve their speaking skills, "
                "especially if they are introverted or shy. "
                "Give guidance on public speaking, effective expression, conversation skills, and confidence building."
            )
        }
        
        # Build chat messages for OpenAI API
        chat_messages = [system_prompt] + [
            {"role": role_map.get(m.type, "user"), "content": m.content} 
            for m in messages
        ]
        
        # Call GPT
        response = client.chat.completions.create(
            model="gpt-4o",
            messages=chat_messages
        )
        reply_text = response.choices[0].message.content
        
        # Add AI response to memory
        memory.chat_memory.add_ai_message(reply_text)
        
        # Generate speech
        speech = client.audio.speech.create(
            model="tts-1",
            voice="alloy",
            input=reply_text
        )
        
        # Save audio file
        filename = f"reply_{session_id}_{datetime.utcnow().timestamp()}.mp3"
        filepath = os.path.join(AUDIO_DIR, filename)
        with open(filepath, "wb") as f:
            f.write(speech.content)
        
        return {
            "text": reply_text,
            "audio_url": f"/{AUDIO_DIR}/{filename}",
            "session_id": session_id
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error processing request: {str(e)}")

@chatbot_router.post("/voice-reply")
async def voice_chatbot_reply(
    audio: UploadFile = File(...),
    session_id: str = Form(default="default_session"),
    db: Session = Depends(get_db)
):
    """Handle voice input from user"""
    try:
        # Save uploaded audio to temporary file
        with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as tmpfile:
            content = await audio.read()
            tmpfile.write(content)
            temp_audio_path = tmpfile.name
        
        # Transcribe audio using Whisper
        with open(temp_audio_path, "rb") as f:
            transcript = client.audio.transcriptions.create(
                model="whisper-1",
                file=f
            ).text
        
        # Clean up temporary file
        os.unlink(temp_audio_path)
        
        # Get conversation memory
        memory = get_or_create_memory(session_id)
        
        # Add user message to memory
        memory.chat_memory.add_user_message(transcript)
        
        # Get messages from memory
        messages = memory.chat_memory.messages
        
        # Role mapping for OpenAI format
        role_map = {"human": "user", "ai": "assistant", "system": "system"}
        
        # System prompt
        system_prompt = {
            "role": "system",
            "content": (
                "You are a communication teacher. "
                "Your goal is to help students improve their speaking skills, "
                "especially if they are introverted or shy. "
                "Give guidance on public speaking, effective expression, conversation skills, and confidence building."
            )
        }
        
        # Build chat messages for OpenAI API
        chat_messages = [system_prompt] + [
            {"role": role_map.get(m.type, "user"), "content": m.content} 
            for m in messages
        ]
        
        # Call GPT
        response = client.chat.completions.create(
            model="gpt-4o",
            messages=chat_messages
        )
        reply_text = response.choices[0].message.content
        
        # Add AI response to memory
        memory.chat_memory.add_ai_message(reply_text)
        
        # Generate speech response
        speech = client.audio.speech.create(
            model="tts-1",
            voice="alloy",
            input=reply_text
        )
        
        # Save audio file
        filename = f"reply_{session_id}_{datetime.utcnow().timestamp()}.mp3"
        filepath = os.path.join(AUDIO_DIR, filename)
        with open(filepath, "wb") as f:
            f.write(speech.content)
        
        return {
            "transcript": transcript,
            "text": reply_text,
            "audio_url": f"/{AUDIO_DIR}/{filename}",
            "session_id": session_id
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error processing voice request: {str(e)}")

@chatbot_router.get("/conversation/{session_id}")
async def get_conversation_history(session_id: str):
    """Get conversation history for a session"""
    try:
        if session_id not in conversation_memories:
            return {
                "session_id": session_id,
                "messages": [],
                "conversation_length": 0
            }
            
        memory = conversation_memories[session_id]
        messages = memory.chat_memory.messages
        
        # Convert to readable format
        formatted_messages = []
        for msg in messages:
            formatted_messages.append({
                "role": "user" if msg.type == "human" else "assistant",
                "content": msg.content
            })
        
        return {
            "session_id": session_id,
            "messages": formatted_messages,
            "conversation_length": len(messages)
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error retrieving conversation: {str(e)}")

@chatbot_router.delete("/conversation/{session_id}")
async def clear_conversation(session_id: str):
    """Clear conversation history for a session"""
    try:
        if session_id in conversation_memories:
            conversation_memories[session_id].chat_memory.clear()
            
        return {
            "message": f"Conversation history cleared for session: {session_id}",
            "session_id": session_id
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error clearing conversation: {str(e)}")

@chatbot_router.get("/sessions")
async def list_active_sessions():
    """List all active conversation sessions"""
    try:
        active_sessions = list(conversation_memories.keys())
        return {
            "active_sessions": active_sessions,
            "total_sessions": len(active_sessions)
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error listing sessions: {str(e)}")