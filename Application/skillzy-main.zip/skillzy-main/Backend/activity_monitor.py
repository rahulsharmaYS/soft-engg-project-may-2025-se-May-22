import time
import csv
import os
import pyautogui
import pandas as pd
from datetime import datetime
from pynput import mouse, keyboard
import threading
import subprocess

# Setup
BLACKLIST = ['instagram', 'netflix', 'tiktok', 'facebook', 'steam', 'epicgames', 'valorant']
EDU_WHITELIST = ['khanacademy', 'coursera', 'edx', 'youtube.com/watch?v=', 'nptel', 'wikipedia']
EDU_KEYWORDS = ['YouTube', 'Khan Academy', 'Wikipedia', 'Docs', 'GeeksforGeeks']

CSV_LOG = "activity_log.csv"
activity_log = []
last_activity_time = time.time()
stop_monitor = False  # Flag to stop threads
session_start_time = None  # Store the actual session start time
session_end_time = None    # Store the actual session end time

def get_active_window_title():
    try:
        result = subprocess.run(
            ['xdotool', 'getactivewindow', 'getwindowname'],
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            timeout=1
        )
        title = result.stdout.decode().strip()
        if not title:
            return "Unknown"
        return title
    except Exception:
        return "Unknown"

def is_blacklisted(title):
    return any(b in title.lower() for b in BLACKLIST)

def is_educational(title):
    return any(e in title.lower() for e in EDU_WHITELIST)

def alert_user(msg):
    print(f"[⚠️ ALERT] {msg}")
    pyautogui.alert(msg)

def close_tab():
    pyautogui.hotkey('ctrl', 'w')

def log_event(event_type, data):
    timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    activity_log.append([timestamp, event_type, data])
    with open(CSV_LOG, "a", newline='') as f:
        csv.writer(f).writerow([timestamp, event_type, data])

# Listener callbacks
def on_move(x, y):
    global last_activity_time
    last_activity_time = time.time()

def on_click(x, y, b, p):
    global last_activity_time
    last_activity_time = time.time()

def on_scroll(x, y, dx, dy):
    global last_activity_time
    last_activity_time = time.time()

def on_press(key):
    global last_activity_time
    last_activity_time = time.time()
    try:
        log_event("key_press", key.char)
    except:
        log_event("key_press", str(key))

def run_monitor(duration_min):
    global last_activity_time, stop_monitor, session_start_time, session_end_time
    stop_monitor = False
    
    # Capture the actual session start time
    session_start_time = datetime.now()
    end_time = time.time() + duration_min * 60
    last_title = ""

    # Start listeners
    m_listener = mouse.Listener(on_move=on_move, on_click=on_click, on_scroll=on_scroll)
    k_listener = keyboard.Listener(on_press=on_press)
    m_listener.start()
    k_listener.start()

    # Create CSV if not exists
    if not os.path.exists(CSV_LOG):
        with open(CSV_LOG, "w", newline='') as f:
            csv.writer(f).writerow(["Timestamp", "Event Type", "Data"])

    # Log session start
    log_event("session_start", f"Focus session started for {duration_min} minutes")
    print(f"[🎯] Focus session started at {session_start_time.strftime('%Y-%m-%d %H:%M:%S')} for {duration_min} minutes")

    while time.time() < end_time and not stop_monitor:
        current_title = get_active_window_title()

        # Ignore unknown titles to avoid noise
        if current_title != last_title and current_title != "Unknown":
            log_event("window_change", current_title)
            print(f"[🪟] Window: {current_title}")

            if 'youtube' in current_title.lower() and not is_educational(current_title):
                alert_user("You're watching non-educational YouTube!")
                close_tab()

            if is_blacklisted(current_title):
                alert_user(f"Blocked: {current_title}")
                close_tab()

            last_title = current_title

        if time.time() - last_activity_time > 300:
            alert_user("Idle for 5+ min. Resume!")
            last_activity_time = time.time()

        time.sleep(5)

    # Capture the actual session end time
    session_end_time = datetime.now()
    log_event("session_end", "Focus session ended")
    print(f"[✅] Focus session ended at {session_end_time.strftime('%Y-%m-%d %H:%M:%S')}")

    m_listener.stop()
    k_listener.stop()

def generate_summary_to_txt(output_file):
    global session_start_time, session_end_time
    
    try:
        df = pd.read_csv(CSV_LOG)
    except Exception as e:
        print(f"Error reading CSV: {e}")
        return

    df['Timestamp'] = pd.to_datetime(df['Timestamp'])

    win_changes = df[df['Event Type'] == 'window_change'].copy()
    win_changes['Next_Timestamp'] = win_changes['Timestamp'].shift(-1)
    win_changes['Duration'] = (win_changes['Next_Timestamp'] - win_changes['Timestamp']).dt.total_seconds().fillna(0)

    win_keys = {}
    active_window = None
    for _, row in df.iterrows():
        if row['Event Type'] == 'window_change':
            active_window = row['Data']
            if active_window not in win_keys:
                win_keys[active_window] = []
        elif row['Event Type'] == 'key_press' and active_window:
            win_keys[active_window].append(row['Data'])

    os.makedirs("static/focus_logs", exist_ok=True)
    filepath = os.path.join("static/focus_logs", output_file)

    # Use the captured session times instead of CSV data
    actual_start = session_start_time if session_start_time else df['Timestamp'].min()
    actual_end = session_end_time if session_end_time else df['Timestamp'].max()
    total_duration = (actual_end - actual_start).total_seconds() if session_start_time and session_end_time else (df['Timestamp'].max() - df['Timestamp'].min()).total_seconds()

    with open(filepath, "w") as f:
        f.write("==== SESSION SUMMARY ====\n")
        f.write(f"Start: {actual_start.strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write(f"End:   {actual_end.strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write(f"Total Time: {total_duration:.0f} sec \n\n")

        f.write("==== TIME SPENT ON EACH WINDOW ====\n")
        for _, row in win_changes.iterrows():
            f.write(f"- {row['Data']}: {row['Duration']:.2f} sec\n")

        f.write("\n==== KEYS PER WINDOW ====\n")
        for w, keys in win_keys.items():
            if keys:
                safe_keys = [str(k) for k in keys if pd.notna(k)]
                f.write(f"{w} → {''.join(safe_keys)}\n")

        f.write("\n==== BLACKLIST WARNINGS ====\n")
        found = False
        for w in win_keys:
            if any(b in w.lower() for b in BLACKLIST):
                f.write(f"🚫 {w}\n")
                found = True
        if not found:
            f.write("✅ No blacklisted usage detected.\n")

        f.write("\n==== CLASSIFICATION ====\n")
        for w in win_keys:
            tag = "Educational" if any(e.lower() in w.lower() for e in EDU_KEYWORDS) else "Non-Educational"
            f.write(f"{w} → {tag}\n")

        f.write(f"\nTotal Window Switches: {len(win_changes)}\n")
        
        # Add productivity metrics
        edu_time = sum(row['Duration'] for _, row in win_changes.iterrows() 
                      if any(e.lower() in row['Data'].lower() for e in EDU_KEYWORDS))
        total_window_time = sum(row['Duration'] for _, row in win_changes.iterrows())
        
        if total_window_time > 0:
            productivity_rate = (edu_time / total_window_time) * 100
            f.write(f"Educational Content Time: {edu_time:.1f} sec ({productivity_rate:.1f}%)\n")

def start_focus_session(minutes, output_txt_file):
    thread = threading.Thread(target=lambda: [run_monitor(minutes), generate_summary_to_txt(output_txt_file)])
    thread.start()
    return output_txt_file
