import openai
import json
from datetime import datetime, timedelta
from typing import Dict, Any, Optional, List
from sqlalchemy.orm import Session
from models import Task, Student, TaskStatusEnum
import pytz
from pydantic import BaseModel

class TaskAgentResponse(BaseModel):
    success: bool
    message: str
    task_data: Optional[Dict] = None
    tasks: Optional[List[Dict]] = None

class TaskAgent:
    def __init__(self, openai_api_key: str):
        self.client = openai.OpenAI(api_key=openai_api_key)
        self.ist = pytz.timezone("Asia/Kolkata")
        
    def parse_natural_language(self, user_input: str, student_id: int) -> Dict[str, Any]:
        """Parse natural language input and determine the intended action"""
        
        system_prompt = """
        You are a task management assistant. Parse the user's natural language input and determine what CRUD operation they want to perform on their tasks.

        Respond with a JSON object containing:
        - action: "create", "read", "update", or "delete"
        - task_data: relevant task information (title, description, due_date, status)
        - filters: for read operations (status, date_range, etc.)
        - task_identifier: for update/delete operations (task title or partial match)

        Examples:
        - "Create a task to submit math homework by tomorrow" -> {"action": "create", "task_data": {"title": "Submit math homework", "due_date": "tomorrow"}}
        - "Show me all pending tasks" -> {"action": "read", "filters": {"status": "pending"}}
        - "Mark physics assignment as complete" -> {"action": "update", "task_identifier": "physics assignment", "task_data": {"status": "complete"}}
        - "Delete the chemistry project task" -> {"action": "delete", "task_identifier": "chemistry project"}

        Current date context: Use relative dates like "today", "tomorrow", "next week" appropriately.
        Always extract as much relevant information as possible from the user input.
        """

        try:
            response = self.client.chat.completions.create(
                model="gpt-4o-mini",
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_input}
                ],
                temperature=0.1,
                response_format={"type": "json_object"}
            )
            
            return json.loads(response.choices[0].message.content)
        except Exception as e:
            return {"error": f"Failed to parse input: {str(e)}"}

    def process_request(self, user_input: str, student_id: int, db: Session) -> TaskAgentResponse:
        """Main function to process natural language task requests"""
        
        # Parse the natural language input
        parsed_data = self.parse_natural_language(user_input, student_id)
        
        if "error" in parsed_data:
            return TaskAgentResponse(success=False, message=parsed_data["error"])
        
        action = parsed_data.get("action")
        
        try:
            if action == "create":
                return self._create_task(parsed_data.get("task_data", {}), student_id, db)
            elif action == "read":
                return self._read_tasks(parsed_data.get("filters", {}), student_id, db)
            elif action == "update":
                return self._update_task(
                    parsed_data.get("task_identifier", ""),
                    parsed_data.get("task_data", {}),
                    student_id,
                    db
                )
            elif action == "delete":
                return self._delete_task(
                    parsed_data.get("task_identifier", ""),
                    student_id,
                    db
                )
            else:
                return TaskAgentResponse(
                    success=False,
                    message="I couldn't understand what you want to do. Try phrases like 'create task', 'show tasks', 'update task', or 'delete task'."
                )
                
        except Exception as e:
            return TaskAgentResponse(success=False, message=f"Error processing request: {str(e)}")

    def _create_task(self, task_data: Dict, student_id: int, db: Session) -> TaskAgentResponse:
        """Create a new task"""
        try:
            # Get student
            student = db.query(Student).filter(Student.user_id == student_id).first()
            if not student:
                return TaskAgentResponse(success=False, message="Student not found")
            
            # Extract and process task data
            title = task_data.get("title", "New Task")
            description = task_data.get("description", "")
            due_date_str = task_data.get("due_date")
            
            # Process due date
            due_date = self._parse_due_date(due_date_str) if due_date_str else None
            
            # Create task
            task = Task(
                title=title,
                description=description,
                due_date=due_date,
                student_id=student.id,
                status=TaskStatusEnum.pending,
                created_at=datetime.now(self.ist)
            )
            
            db.add(task)
            db.commit()
            db.refresh(task)
            
            return TaskAgentResponse(
                success=True,
                message=f"✅ Task '{title}' created successfully!",
                task_data=task.to_dict()
            )
            
        except Exception as e:
            return TaskAgentResponse(success=False, message=f"Failed to create task: {str(e)}")

    def _read_tasks(self, filters: Dict, student_id: int, db: Session) -> TaskAgentResponse:
        """Read/retrieve tasks based on filters"""
        try:
            # Get student
            student = db.query(Student).filter(Student.user_id == student_id).first()
            if not student:
                return TaskAgentResponse(success=False, message="Student not found")
            
            # Build query
            query = db.query(Task).filter(Task.student_id == student.id)
            
            # Apply filters
            status_filter = filters.get("status")
            if status_filter:
                if status_filter.lower() in ["pending", "complete", "overdue"]:
                    query = query.filter(Task.status == status_filter.lower())
            
            # Date filters
            date_filter = filters.get("date_range")
            if date_filter == "today":
                today = datetime.now(self.ist).date()
                query = query.filter(Task.due_date >= today, Task.due_date < today + timedelta(days=1))
            elif date_filter == "this_week":
                start_week = datetime.now(self.ist).date()
                end_week = start_week + timedelta(days=7)
                query = query.filter(Task.due_date >= start_week, Task.due_date <= end_week)
            
            tasks = query.all()
            
            if not tasks:
                return TaskAgentResponse(
                    success=True,
                    message="No tasks found matching your criteria.",
                    tasks=[]
                )
            
            tasks_data = [task.to_dict() for task in tasks]
            
            # Generate summary message
            status_counts = {}
            for task in tasks:
                status = task.status.value if hasattr(task.status, 'value') else str(task.status)
                status_counts[status] = status_counts.get(status, 0) + 1
            
            summary = f"Found {len(tasks)} tasks: "
            summary += ", ".join([f"{count} {status}" for status, count in status_counts.items()])
            
            return TaskAgentResponse(
                success=True,
                message=summary,
                tasks=tasks_data
            )
            
        except Exception as e:
            return TaskAgentResponse(success=False, message=f"Failed to retrieve tasks: {str(e)}")

    def _update_task(self, task_identifier: str, task_data: Dict, student_id: int, db: Session) -> TaskAgentResponse:
        """Update an existing task"""
        try:
            # Get student
            student = db.query(Student).filter(Student.user_id == student_id).first()
            if not student:
                return TaskAgentResponse(success=False, message="Student not found")
            
            # Find task by identifier (fuzzy matching on title)
            tasks = db.query(Task).filter(Task.student_id == student.id).all()
            
            matching_task = None
            for task in tasks:
                if task_identifier.lower() in task.title.lower():
                    matching_task = task
                    break
            
            if not matching_task:
                return TaskAgentResponse(
                    success=False,
                    message=f"No task found matching '{task_identifier}'"
                )
            
            # Update task fields
            if "title" in task_data:
                matching_task.title = task_data["title"]
            if "description" in task_data:
                matching_task.description = task_data["description"]
            if "status" in task_data:
                status = task_data["status"].lower()
                if status in ["pending", "complete", "overdue"]:
                    matching_task.status = status
            if "due_date" in task_data:
                matching_task.due_date = self._parse_due_date(task_data["due_date"])
            
            db.commit()
            db.refresh(matching_task)
            
            return TaskAgentResponse(
                success=True,
                message=f"✅ Task '{matching_task.title}' updated successfully!",
                task_data=matching_task.to_dict()
            )
            
        except Exception as e:
            return TaskAgentResponse(success=False, message=f"Failed to update task: {str(e)}")

    def _delete_task(self, task_identifier: str, student_id: int, db: Session) -> TaskAgentResponse:
        """Delete a task"""
        try:
            # Get student
            student = db.query(Student).filter(Student.user_id == student_id).first()
            if not student:
                return TaskAgentResponse(success=False, message="Student not found")
            
            # Find task by identifier
            tasks = db.query(Task).filter(Task.student_id == student.id).all()
            
            matching_task = None
            for task in tasks:
                if task_identifier.lower() in task.title.lower():
                    matching_task = task
                    break
            
            if not matching_task:
                return TaskAgentResponse(
                    success=False,
                    message=f"No task found matching '{task_identifier}'"
                )
            
            task_title = matching_task.title
            db.delete(matching_task)
            db.commit()
            
            return TaskAgentResponse(
                success=True,
                message=f"✅ Task '{task_title}' deleted successfully!"
            )
            
        except Exception as e:
            return TaskAgentResponse(success=False, message=f"Failed to delete task: {str(e)}")

    def _parse_due_date(self, due_date_str: str) -> Optional[datetime]:
        """Parse natural language due dates"""
        if not due_date_str:
            return None
            
        due_date_str = due_date_str.lower().strip()
        now = datetime.now(self.ist)
        
        if due_date_str == "today":
            return now.replace(hour=23, minute=59, second=59)
        elif due_date_str == "tomorrow":
            return (now + timedelta(days=1)).replace(hour=23, minute=59, second=59)
        elif due_date_str == "next week":
            return (now + timedelta(days=7)).replace(hour=23, minute=59, second=59)
        elif "days" in due_date_str:
            # Extract number of days
            try:
                days = int(''.join(filter(str.isdigit, due_date_str)))
                return (now + timedelta(days=days)).replace(hour=23, minute=59, second=59)
            except:
                pass
        
        # Try to parse ISO format
        try:
            return datetime.fromisoformat(due_date_str)
        except:
            pass
            
        return None

# Configuration
import os
from functools import lru_cache

@lru_cache()
def get_task_agent():
    openai_api_key = os.getenv("OPENAI_API_KEY")
    if not openai_api_key:
        raise ValueError("OPENAI_API_KEY environment variable not set")
    return TaskAgent(openai_api_key)