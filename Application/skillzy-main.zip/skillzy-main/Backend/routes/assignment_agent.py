import openai
import json
from datetime import datetime, timedelta
from typing import Dict, Any, Optional, List
from sqlalchemy.orm import Session
from models import Assignment, Teacher, AssignmentStatus, Question, Student, Subject
import pytz
from pydantic import BaseModel

class AssignmentAgentResponse(BaseModel):
    success: bool
    message: str
    assignment_data: Optional[Dict] = None
    assignments: Optional[List[Dict]] = None
    questions: Optional[List[Dict]] = None

class AssignmentAgent:
    def __init__(self, openai_api_key: str):
        self.client = openai.OpenAI(api_key=openai_api_key)
        self.ist = pytz.timezone("Asia/Kolkata")
        
    def parse_natural_language(self, user_input: str, teacher_id: int) -> Dict[str, Any]:
        """Parse natural language input and determine the intended action for assignments"""
        
        system_prompt = """
        You are an assignment management assistant for teachers. Parse the teacher's natural language input and determine what CRUD operation they want to perform on assignments and questions.

        Respond with a JSON object containing:
        - action: "create_assignment", "read_assignments", "update_assignment", "delete_assignment", "create_questions", "read_questions", "update_question", "delete_question", "create_assignment_with_questions"
        - assignment_data: relevant assignment information (title, description, assignment_deadline, question_type, feedback, scores)
        - question_data: for question operations (question text, options, correct_answer, descriptive_answer, topic)
        - questions_count: number of questions to generate (extract from phrases like "5 questions", "ten questions")
        - filters: for read operations (question_type, search terms, date_range, etc.)
        - assignment_identifier: for update/delete operations (assignment title or partial match)
        - question_identifier: for question update/delete operations
        - create_if_not_exists: boolean flag to create assignment if it doesn't exist when creating questions

        IMPORTANT: When someone asks to "create questions for [subject/topic] assignment", check if they want to:
        1. Add questions to an existing assignment (if they mention a specific existing one)
        2. Create a new assignment with questions (if the assignment doesn't seem to exist)
        
        For ambiguous cases like "Create 5 multiple choice questions for Time management assignment about time and its importance":
        - Set action to "create_assignment_with_questions" 
        - Extract assignment_data with title "Time management assignment"
        - Extract question_data with topic "time and its importance"
        - Set create_if_not_exists to true

        Examples:
        - "Create a math assignment on algebra due next Friday" -> {"action": "create_assignment", "assignment_data": {"title": "Math Assignment - Algebra", "assignment_deadline": "next Friday", "question_type": "math"}}
        - "Show me all my assignments" -> {"action": "read_assignments", "filters": {}}
        - "Create 5 multiple choice questions for Time management assignment about time and its importance" -> {"action": "create_assignment_with_questions", "assignment_data": {"title": "Time Management Assignment", "question_type": "multiple_choice"}, "question_data": {"topic": "time and its importance", "question_type": "multiple_choice"}, "questions_count": 5, "create_if_not_exists": true}
        - "Add 3 questions to my existing physics assignment" -> {"action": "create_questions", "assignment_identifier": "physics", "questions_count": 3}
        - "Generate 10 questions about photosynthesis" -> {"action": "create_assignment_with_questions", "assignment_data": {"title": "Photosynthesis Assignment"}, "question_data": {"topic": "photosynthesis"}, "questions_count": 10, "create_if_not_exists": true}

        Always extract as much context as possible including subject, topic, difficulty, question count.
        """

        try:
            response = self.client.chat.completions.create(
                model="gpt-4o-mini",
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_input}
                ],
                temperature=0.1,
                response_format={"type": "json_object"}
            )
            
            return json.loads(response.choices[0].message.content)
        except Exception as e:
            return {"error": f"Failed to parse input: {str(e)}"}

    def process_request(self, user_input: str, teacher_id: int, db: Session) -> AssignmentAgentResponse:
        """Main function to process natural language assignment requests"""
        
        # Parse the natural language input
        parsed_data = self.parse_natural_language(user_input, teacher_id)
        
        if "error" in parsed_data:
            return AssignmentAgentResponse(success=False, message=parsed_data["error"])
        
        action = parsed_data.get("action")
        
        try:
            if action == "create_assignment":
                return self._create_assignment(parsed_data.get("assignment_data", {}), teacher_id, db)
            elif action == "create_assignment_with_questions":
                return self._create_assignment_with_questions(
                    parsed_data.get("assignment_data", {}),
                    parsed_data.get("question_data", {}),
                    parsed_data.get("questions_count", 5),
                    teacher_id,
                    db
                )
            elif action == "read_assignments":
                return self._read_assignments(parsed_data.get("filters", {}), teacher_id, db)
            elif action == "update_assignment":
                return self._update_assignment(
                    parsed_data.get("assignment_identifier", ""),
                    parsed_data.get("assignment_data", {}),
                    teacher_id,
                    db
                )
            elif action == "delete_assignment":
                return self._delete_assignment(
                    parsed_data.get("assignment_identifier", ""),
                    teacher_id,
                    db
                )
            elif action == "create_questions":
                return self._create_questions(
                    parsed_data.get("assignment_identifier", ""),
                    parsed_data.get("question_data", {}),
                    parsed_data.get("questions_count", 1),
                    teacher_id,
                    db,
                    create_if_not_exists=parsed_data.get("create_if_not_exists", False)
                )
            elif action == "read_questions":
                return self._read_questions(
                    parsed_data.get("assignment_identifier", ""),
                    teacher_id,
                    db
                )
            elif action == "update_question":
                return self._update_question(
                    parsed_data.get("assignment_identifier", ""),
                    parsed_data.get("question_identifier", ""),
                    parsed_data.get("question_data", {}),
                    teacher_id,
                    db
                )
            elif action == "delete_question":
                return self._delete_question(
                    parsed_data.get("assignment_identifier", ""),
                    parsed_data.get("question_identifier", ""),
                    teacher_id,
                    db
                )
            else:
                return AssignmentAgentResponse(
                    success=False,
                    message="I couldn't understand what you want to do. Try phrases like 'create assignment', 'show assignments', 'create questions', etc."
                )
                
        except Exception as e:
            return AssignmentAgentResponse(success=False, message=f"Error processing request: {str(e)}")

    def _create_assignment_with_questions(self, assignment_data: Dict, question_data: Dict, questions_count: int, teacher_id: int, db: Session) -> AssignmentAgentResponse:
        """Create a new assignment and immediately add questions to it"""
        try:
            # First create the assignment
            assignment_response = self._create_assignment(assignment_data, teacher_id, db)
            
            if not assignment_response.success:
                return assignment_response
            
            # Get the created assignment
            teacher = db.query(Teacher).filter(Teacher.user_id == teacher_id).first()
            if not teacher:
                return AssignmentAgentResponse(success=False, message="Teacher not found")
            
            # Find the most recently created assignment with the title
            assignment_title = assignment_data.get("title", "New Assignment")
            assignment = db.query(Assignment).filter(
                Assignment.teacher_id == teacher_id,
                Assignment.title.ilike(f"%{assignment_title}%")
            ).order_by(Assignment.assignment_created.desc()).first()
            
            if not assignment:
                return AssignmentAgentResponse(success=False, message="Failed to find created assignment")
            
            # Now create questions for this assignment
            generated_questions = self._generate_questions_with_ai(
                assignment.title,
                question_data.get("topic", assignment_title),
                questions_count,
                question_data.get("question_type", "multiple_choice")
            )

            created_questions = []
            for q_data in generated_questions:
                question = Question(
                    assignment_id=assignment.id,
                    question=q_data.get("question", ""),
                    option_1=q_data.get("option_1", ""),
                    option_2=q_data.get("option_2", ""),
                    option_3=q_data.get("option_3", ""),
                    option_4=q_data.get("option_4", ""),
                    correct_answer=q_data.get("correct_answer", ""),
                    descriptive_answer=q_data.get("descriptive_answer", "")
                )
                db.add(question)
                created_questions.append(question)

            db.commit()

            questions_data = [q.to_dict() for q in created_questions]
            
            # Get student count for the message
            student_count = db.query(Assignment).filter(
                Assignment.teacher_id == teacher_id,
                Assignment.title == assignment.title
            ).count()
            
            return AssignmentAgentResponse(
                success=True,
                message=f"✅ Created assignment '{assignment.title}' for {student_count} students with {len(created_questions)} questions about '{question_data.get('topic', 'the topic')}'!",
                assignment_data=assignment.to_dict(),
                questions=questions_data
            )
            
        except Exception as e:
            db.rollback()
            return AssignmentAgentResponse(success=False, message=f"Failed to create assignment with questions: {str(e)}")

    def _create_assignment(self, assignment_data: Dict, teacher_id: int, db: Session) -> AssignmentAgentResponse:
        """Create a new assignment"""
        try:
            teacher = db.query(Teacher).filter(Teacher.user_id == teacher_id).first()
            if not teacher:
                return AssignmentAgentResponse(success=False, message="Teacher not found")
                
            if not teacher.class_id or not teacher.subject_id:
                return AssignmentAgentResponse(success=False, message="Teacher must be assigned to both class and subject")

            # Extract assignment data
            title = assignment_data.get("title", "New Assignment")
            assignment_deadline = self._parse_due_date(assignment_data.get("assignment_deadline"))
            question_type = self._map_question_type(assignment_data.get("question_type", "general"))
            
            # Get matching students
            matching_students = db.query(Student).filter(
                Student.class_id == teacher.class_id
            ).join(Student.subjects).filter(
                Subject.id == teacher.subject_id
            ).all()

            if not matching_students:
                return AssignmentAgentResponse(success=False, message="No matching students found")

            # Create assignments for each student
            created_assignments = []
            for student in matching_students:
                assignment = Assignment(
                    title=title,
                    teacher_id=teacher.user_id,
                    class_id=teacher.class_id,
                    subject_id=teacher.subject_id,
                    student_id=student.id,
                    assignment_created=datetime.utcnow(),
                    assignment_deadline=assignment_deadline,
                    question_type=question_type,
                    status=AssignmentStatus.assigned
                )
                db.add(assignment)
                created_assignments.append(assignment)

            db.commit()
            
            return AssignmentAgentResponse(
                success=True,
                message=f"✅ Assignment '{title}' created for {len(created_assignments)} students!",
                assignment_data=created_assignments[0].to_dict() if created_assignments else None
            )
            
        except Exception as e:
            db.rollback()
            return AssignmentAgentResponse(success=False, message=f"Failed to create assignment: {str(e)}")

    def _create_questions(self, assignment_identifier: str, question_data: Dict, questions_count: int, teacher_id: int, db: Session, create_if_not_exists: bool = False) -> AssignmentAgentResponse:
        """Create multiple questions for an assignment using AI"""
        try:
            # Find assignment
            assignment = None
            if assignment_identifier:
                assignments = db.query(Assignment).filter(Assignment.teacher_id == teacher_id).all()
                for a in assignments:
                    if assignment_identifier.lower() in a.title.lower():
                        assignment = a
                        break
            
            if not assignment and create_if_not_exists and assignment_identifier:
                # Create assignment first
                assignment_data = {
                    "title": assignment_identifier,
                    "question_type": question_data.get("question_type", "multiple_choice")
                }
                create_response = self._create_assignment(assignment_data, teacher_id, db)
                if not create_response.success:
                    return create_response
                
                # Find the created assignment
                assignments = db.query(Assignment).filter(
                    Assignment.teacher_id == teacher_id,
                    Assignment.title.ilike(f"%{assignment_identifier}%")
                ).order_by(Assignment.assignment_created.desc()).all()
                if assignments:
                    assignment = assignments[0]
            
            if not assignment:
                return AssignmentAgentResponse(
                    success=False,
                    message=f"No assignment found matching '{assignment_identifier}'. Try creating the assignment first or be more specific with the assignment name."
                )

            # Generate questions using AI
            generated_questions = self._generate_questions_with_ai(
                assignment.title,
                question_data.get("topic", assignment.title),
                questions_count,
                question_data.get("question_type", "multiple_choice")
            )

            created_questions = []
            for q_data in generated_questions:
                question = Question(
                    assignment_id=assignment.id,
                    question=q_data.get("question", ""),
                    option_1=q_data.get("option_1", ""),
                    option_2=q_data.get("option_2", ""),
                    option_3=q_data.get("option_3", ""),
                    option_4=q_data.get("option_4", ""),
                    correct_answer=q_data.get("correct_answer", ""),
                    descriptive_answer=q_data.get("descriptive_answer", "")
                )
                db.add(question)
                created_questions.append(question)

            db.commit()

            questions_data = [q.to_dict() for q in created_questions]
            
            return AssignmentAgentResponse(
                success=True,
                message=f"✅ Created {len(created_questions)} questions for assignment '{assignment.title}'!",
                questions=questions_data
            )
            
        except Exception as e:
            db.rollback()
            return AssignmentAgentResponse(success=False, message=f"Failed to create questions: {str(e)}")

    def _generate_questions_with_ai(self, assignment_title: str, topic: str, count: int, question_type: str) -> List[Dict]:
        """Generate questions using AI"""
        try:
            question_type_readable = self._get_readable_question_type(question_type)
            
            prompt = f"""
            Generate {count} {question_type_readable} questions about "{topic}" for the assignment "{assignment_title}".
            
            For each question, provide a JSON object with:
            - question: the question text (clear, educational, and relevant to the topic)
            - option_1, option_2, option_3, option_4: four realistic options (for multiple choice questions)
            - correct_answer: the correct option number (1, 2, 3, or 4) for multiple choice, or descriptive answer for text questions
            - descriptive_answer: detailed explanation of why the answer is correct
            
            Make questions:
            - Educational and thought-provoking
            - Varied in difficulty (mix of easy, medium, hard)
            - Directly relevant to "{topic}"
            - Appropriate for the context of "{assignment_title}"
            
            For time management topics, focus on practical concepts like:
            - Planning and prioritization techniques
            - Time allocation strategies  
            - Productivity methods
            - Work-life balance
            - Goal setting and deadlines
            - Common time management challenges
            
            Return as a JSON object with "questions" array containing the question objects.
            """

            response = self.client.chat.completions.create(
                model="gpt-4o-mini",
                messages=[
                    {"role": "system", "content": "You are an expert educator creating high-quality, engaging questions that help students learn effectively."},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.7,
                response_format={"type": "json_object"}
            )
            
            result = json.loads(response.choices[0].message.content)
            return result.get("questions", [])
            
        except Exception as e:
            print(f"AI question generation failed: {str(e)}")
            # Fallback to basic question generation
            return self._create_fallback_questions(topic, count, question_type)

    def _create_fallback_questions(self, topic: str, count: int, question_type: str) -> List[Dict]:
        """Create fallback questions when AI generation fails"""
        fallback_questions = []
        
        # Time management specific questions
        if "time" in topic.lower() or "management" in topic.lower():
            time_questions = [
                {
                    "question": "What is the most important principle of effective time management?",
                    "option_1": "Working longer hours",
                    "option_2": "Prioritizing tasks based on importance and urgency",
                    "option_3": "Multitasking as much as possible",
                    "option_4": "Avoiding all breaks and rest periods",
                    "correct_answer": "2",
                    "descriptive_answer": "Prioritizing tasks based on importance and urgency is fundamental to effective time management. This helps focus effort on what matters most."
                },
                {
                    "question": "Which technique is commonly used for task prioritization?",
                    "option_1": "Eisenhower Matrix",
                    "option_2": "Random selection",
                    "option_3": "Alphabetical ordering",
                    "option_4": "Doing easiest tasks first",
                    "correct_answer": "1",
                    "descriptive_answer": "The Eisenhower Matrix helps categorize tasks by importance and urgency, making prioritization more systematic and effective."
                },
                {
                    "question": "What is a key benefit of proper time management?",
                    "option_1": "Increased stress levels",
                    "option_2": "Reduced productivity",
                    "option_3": "Better work-life balance",
                    "option_4": "More overtime work",
                    "correct_answer": "3",
                    "descriptive_answer": "Proper time management leads to better work-life balance by helping people accomplish tasks efficiently and making time for personal activities."
                }
            ]
            fallback_questions.extend(time_questions[:count])
        
        # Generic fallback questions
        while len(fallback_questions) < count:
            fallback_questions.append({
                "question": f"Question {len(fallback_questions) + 1} about {topic}",
                "option_1": "Option A",
                "option_2": "Option B", 
                "option_3": "Option C",
                "option_4": "Option D",
                "correct_answer": "1",
                "descriptive_answer": f"This is a sample question about {topic}. The correct answer demonstrates key concepts related to the topic."
            })
        
        return fallback_questions[:count]
    
    def _get_readable_question_type(self, question_type: str) -> str:
        """Convert database question type to readable format for AI prompt"""
        mapping = {
            "multiple_choice": "multiple choice",
            "text": "descriptive/text-based"
        }
        return mapping.get(question_type, "multiple choice")

    def _read_assignments(self, filters: Dict, teacher_id: int, db: Session) -> AssignmentAgentResponse:
        """Read/retrieve assignments based on filters"""
        try:
            query = db.query(Assignment).filter(Assignment.teacher_id == teacher_id)

            # Apply filters
            question_type = filters.get("question_type")
            if question_type:
                query = query.filter(Assignment.question_type == question_type)

            search = filters.get("search")
            if search:
                query = query.filter(Assignment.title.ilike(f"%{search}%"))

            assignments = query.order_by(Assignment.assignment_created.desc()).all()

            if not assignments:
                return AssignmentAgentResponse(
                    success=True,
                    message="No assignments found.",
                    assignments=[]
                )

            # Simple deduplication by title
            unique = {}
            for a in assignments:
                if a.title not in unique:
                    unique[a.title] = a

            assignments_data = [a.to_dict() for a in unique.values()]
            
            return AssignmentAgentResponse(
                success=True,
                message=f"Found {len(assignments_data)} unique assignments.",
                assignments=assignments_data
            )
            
        except Exception as e:
            return AssignmentAgentResponse(success=False, message=f"Failed to retrieve assignments: {str(e)}")

    def _read_questions(self, assignment_identifier: str, teacher_id: int, db: Session) -> AssignmentAgentResponse:
        """Read questions for an assignment"""
        try:
            # Find assignment
            assignments = db.query(Assignment).filter(Assignment.teacher_id == teacher_id).all()
            
            matching_assignment = None
            for assignment in assignments:
                if assignment_identifier.lower() in assignment.title.lower():
                    matching_assignment = assignment
                    break
            
            if not matching_assignment:
                return AssignmentAgentResponse(
                    success=False,
                    message=f"No assignment found matching '{assignment_identifier}'"
                )

            questions = db.query(Question).filter(Question.assignment_id == matching_assignment.id).all()
            
            if not questions:
                return AssignmentAgentResponse(
                    success=True,
                    message=f"No questions found for assignment '{matching_assignment.title}'.",
                    questions=[]
                )

            questions_data = [q.to_dict() for q in questions]
            
            return AssignmentAgentResponse(
                success=True,
                message=f"Found {len(questions)} questions for assignment '{matching_assignment.title}'.",
                questions=questions_data
            )
            
        except Exception as e:
            return AssignmentAgentResponse(success=False, message=f"Failed to retrieve questions: {str(e)}")

    def _update_assignment(self, assignment_identifier: str, assignment_data: Dict, teacher_id: int, db: Session) -> AssignmentAgentResponse:
        """Update an existing assignment"""
        try:
            # Find assignment by identifier
            assignments = db.query(Assignment).filter(Assignment.teacher_id == teacher_id).all()
            
            matching_assignment = None
            for assignment in assignments:
                if assignment_identifier.lower() in assignment.title.lower():
                    matching_assignment = assignment
                    break
            
            if not matching_assignment:
                return AssignmentAgentResponse(
                    success=False,
                    message=f"No assignment found matching '{assignment_identifier}'"
                )
            
            # Update assignment fields
            if "title" in assignment_data:
                matching_assignment.title = assignment_data["title"]
            if "feedback" in assignment_data:
                matching_assignment.feedback = assignment_data["feedback"]
            if "assignment_deadline" in assignment_data:
                matching_assignment.assignment_deadline = self._parse_due_date(assignment_data["assignment_deadline"])
            if "scores" in assignment_data:
                matching_assignment.scores = assignment_data["scores"]
            if "question_type" in assignment_data:
                matching_assignment.question_type = self._map_question_type(assignment_data["question_type"])
            
            db.commit()
            db.refresh(matching_assignment)
            
            return AssignmentAgentResponse(
                success=True,
                message=f"✅ Assignment '{matching_assignment.title}' updated successfully!",
                assignment_data=matching_assignment.to_dict()
            )
            
        except Exception as e:
            db.rollback()
            return AssignmentAgentResponse(success=False, message=f"Failed to update assignment: {str(e)}")

    def _delete_assignment(self, assignment_identifier: str, teacher_id: int, db: Session) -> AssignmentAgentResponse:
        """Delete an assignment"""
        try:
            # Find assignment by identifier
            assignments = db.query(Assignment).filter(Assignment.teacher_id == teacher_id).all()
            
            matching_assignments = []
            for assignment in assignments:
                if assignment_identifier.lower() in assignment.title.lower():
                    matching_assignments.append(assignment)
            
            if not matching_assignments:
                return AssignmentAgentResponse(
                    success=False,
                    message=f"No assignment found matching '{assignment_identifier}'"
                )
            
            assignment_title = matching_assignments[0].title
            
            # Delete all matching assignments (for all students)
            for assignment in matching_assignments:
                db.delete(assignment)
            
            db.commit()
            
            return AssignmentAgentResponse(
                success=True,
                message=f"✅ Assignment '{assignment_title}' deleted successfully for {len(matching_assignments)} students!"
            )
            
        except Exception as e:
            db.rollback()
            return AssignmentAgentResponse(success=False, message=f"Failed to delete assignment: {str(e)}")

    def _update_question(self, assignment_identifier: str, question_identifier: str, question_data: Dict, teacher_id: int, db: Session) -> AssignmentAgentResponse:
        """Update a specific question"""
        try:
            # Find assignment first
            assignments = db.query(Assignment).filter(Assignment.teacher_id == teacher_id).all()
            
            matching_assignment = None
            for assignment in assignments:
                if assignment_identifier.lower() in assignment.title.lower():
                    matching_assignment = assignment
                    break
            
            if not matching_assignment:
                return AssignmentAgentResponse(
                    success=False,
                    message=f"No assignment found matching '{assignment_identifier}'"
                )

            # Find question
            questions = db.query(Question).filter(Question.assignment_id == matching_assignment.id).all()
            
            matching_question = None
            if question_identifier.isdigit():
                # Question number
                q_num = int(question_identifier) - 1
                if 0 <= q_num < len(questions):
                    matching_question = questions[q_num]
            else:
                # Question text match
                for question in questions:
                    if question_identifier.lower() in question.question.lower():
                        matching_question = question
                        break
            
            if not matching_question:
                return AssignmentAgentResponse(
                    success=False,
                    message=f"No question found matching '{question_identifier}'"
                )

            # Update question fields
            if "question" in question_data:
                matching_question.question = question_data["question"]
            if "option_1" in question_data:
                matching_question.option_1 = question_data["option_1"]
            if "option_2" in question_data:
                matching_question.option_2 = question_data["option_2"]
            if "option_3" in question_data:
                matching_question.option_3 = question_data["option_3"]
            if "option_4" in question_data:
                matching_question.option_4 = question_data["option_4"]
            if "correct_answer" in question_data:
                matching_question.correct_answer = question_data["correct_answer"]
            if "descriptive_answer" in question_data:
                matching_question.descriptive_answer = question_data["descriptive_answer"]

            db.commit()
            db.refresh(matching_question)
            
            return AssignmentAgentResponse(
                success=True,
                message=f"✅ Question updated successfully!",
                questions=[matching_question.to_dict()]
            )
            
        except Exception as e:
            db.rollback()
            return AssignmentAgentResponse(success=False, message=f"Failed to update question: {str(e)}")

    def _delete_question(self, assignment_identifier: str, question_identifier: str, teacher_id: int, db: Session) -> AssignmentAgentResponse:
        """Delete a specific question"""
        try:
            # Find assignment first
            assignments = db.query(Assignment).filter(Assignment.teacher_id == teacher_id).all()
            
            matching_assignment = None
            for assignment in assignments:
                if assignment_identifier.lower() in assignment.title.lower():
                    matching_assignment = assignment
                    break
            
            if not matching_assignment:
                return AssignmentAgentResponse(
                    success=False,
                    message=f"No assignment found matching '{assignment_identifier}'"
                )

            # Find question
            questions = db.query(Question).filter(Question.assignment_id == matching_assignment.id).all()
            
            matching_question = None
            if question_identifier.isdigit():
                # Question number
                q_num = int(question_identifier) - 1
                if 0 <= q_num < len(questions):
                    matching_question = questions[q_num]
            else:
                # Question text match
                for question in questions:
                    if question_identifier.lower() in question.question.lower():
                        matching_question = question
                        break
            
            if not matching_question:
                return AssignmentAgentResponse(
                    success=False,
                    message=f"No question found matching '{question_identifier}'"
                )

            db.delete(matching_question)
            db.commit()
            
            return AssignmentAgentResponse(
                success=True,
                message=f"✅ Question deleted successfully!"
            )
            
        except Exception as e:
            db.rollback()
            return AssignmentAgentResponse(success=False, message=f"Failed to delete question: {str(e)}")

    def _parse_due_date(self, due_date_str: str) -> Optional[datetime]:
        """Parse natural language due dates"""
        if not due_date_str:
            return None
            
        due_date_str = due_date_str.lower().strip()
        now = datetime.now(self.ist)
        
        if due_date_str == "today":
            return now.replace(hour=23, minute=59, second=59)
        elif due_date_str == "tomorrow":
            return (now + timedelta(days=1)).replace(hour=23, minute=59, second=59)
        elif "next week" in due_date_str:
            return (now + timedelta(days=7)).replace(hour=23, minute=59, second=59)
        elif "next friday" in due_date_str:
            days_ahead = 4 - now.weekday()  # Friday is 4
            if days_ahead <= 0:
                days_ahead += 7
            return (now + timedelta(days=days_ahead)).replace(hour=23, minute=59, second=59)
        elif "days" in due_date_str:
            # Extract number of days
            try:
                days = int(''.join(filter(str.isdigit, due_date_str)))
                return (now + timedelta(days=days)).replace(hour=23, minute=59, second=59)
            except:
                pass
        
        # Try to parse ISO format
        try:
            return datetime.fromisoformat(due_date_str)
        except:
            pass
            
        return None

    def _map_question_type(self, question_type_input: str) -> str:
        """Map natural language question types to database enum values"""
        mapping = {
            "mcq": "multiple_choice",
            "multiple_choice": "multiple_choice", 
            "multiple choice": "multiple_choice",
            "mc": "multiple_choice",
            "descriptive": "text",
            "text": "text",
            "essay": "text",
            "written": "text",
            "short_answer": "text",
            "general": "multiple_choice"  # default
        }
        
        return mapping.get(question_type_input.lower(), "multiple_choice")

# Configuration
import os
from functools import lru_cache

@lru_cache()
def get_assignment_agent():
    openai_api_key = os.getenv("OPENAI_API_KEY")
    if not openai_api_key:
        raise ValueError("OPENAI_API_KEY environment variable not set")
    return AssignmentAgent(openai_api_key)
