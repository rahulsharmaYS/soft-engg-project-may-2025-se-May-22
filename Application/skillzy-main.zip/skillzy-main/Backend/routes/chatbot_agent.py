# routes/chatbot_agent.py
import openai
import json
import os
import tempfile
from datetime import datetime
from typing import Dict, Any, Optional, List
from pydantic import BaseModel
from functools import lru_cache
import pytz
import base64

class ChatMessage(BaseModel):
    role: str  # 'user' or 'assistant'
    content: str
    timestamp: datetime
    audio_path: Optional[str] = None

class ChatSession(BaseModel):
    session_id: str
    user_id: int
    messages: List[ChatMessage] = []
    created_at: datetime
    updated_at: datetime

class ChatbotResponse(BaseModel):
    success: bool
    message: str
    response_text: str
    audio_url: Optional[str] = None
    session_id: str
    suggested_actions: Optional[List[str]] = None

class AudioTranscriptionRequest(BaseModel):
    audio_data: str  # base64 encoded audio
    session_id: Optional[str] = None

class CommunicationChatbot:
    def __init__(self, openai_api_key: str):
        self.client = openai.OpenAI(api_key=openai_api_key)
        self.ist = pytz.timezone("Asia/Kolkata")
        self.sessions: Dict[str, ChatSession] = {}  # In production, use Redis or database
        
    def get_or_create_session(self, user_id: int, session_id: Optional[str] = None) -> ChatSession:
        """Get existing session or create new one"""
        if session_id and session_id in self.sessions:
            session = self.sessions[session_id]
            session.updated_at = datetime.now(self.ist)
            return session
        
        # Create new session
        new_session_id = f"chat_{user_id}_{datetime.now().timestamp()}"
        session = ChatSession(
            session_id=new_session_id,
            user_id=user_id,
            created_at=datetime.now(self.ist),
            updated_at=datetime.now(self.ist)
        )
        self.sessions[new_session_id] = session
        return session
    
    def generate_response(self, user_input: str, session: ChatSession) -> str:
        """Generate conversational response"""
        
        system_prompt = """
        You are a helpful AI assistant and communication teacher. Your role is to:
        1. Help students with general questions and conversation
        2. Provide guidance on communication skills, public speaking, and confidence building
        3. Be supportive and encouraging, especially for introverted or shy students
        4. Maintain a friendly, educational, and conversational tone
        5. Keep responses concise but helpful (under 200 words unless asked for detailed explanation)
        
        IMPORTANT: You are NOT a task manager. If users ask about creating, managing, or organizing tasks, 
        politely redirect them to use the dedicated task management features available in the app.
        
        Focus on:
        - Communication skills and techniques
        - Building confidence in speaking
        - General conversation and support
        - Educational guidance
        - Motivation and encouragement
        
        Example redirections for task-related queries:
        - "I can help you with communication skills! For task management, please use the task management feature in your app."
        - "That sounds like something for your task organizer! I'm here to help with communication and conversation skills."
        """
        
        # Build conversation history
        messages = [{"role": "system", "content": system_prompt}]
        
        # Add recent conversation history (last 10 messages to maintain context)
        recent_messages = session.messages[-10:] if len(session.messages) > 10 else session.messages
        for msg in recent_messages:
            messages.append({"role": msg.role, "content": msg.content})
        
        # Add current user input
        messages.append({"role": "user", "content": user_input})
        
        try:
            response = self.client.chat.completions.create(
                model="gpt-4o-mini",
                messages=messages,
                temperature=0.7,
                max_tokens=300
            )
            return response.choices[0].message.content
        except Exception as e:
            return "I'm having trouble processing your request right now. Please try again in a moment."
    
    def generate_audio(self, text: str, session_id: str) -> Optional[str]:
        """Generate audio from text using OpenAI TTS"""
        try:
            speech = self.client.audio.speech.create(
                model="tts-1",
                voice="alloy",
                input=text
            )
            
            # Create audio directory if it doesn't exist
            os.makedirs("audio_cache", exist_ok=True)
            
            # Generate unique filename
            audio_filename = f"chat_{session_id}_{datetime.now().timestamp()}.mp3"
            audio_path = os.path.join("audio_cache", audio_filename)
            
            with open(audio_path, "wb") as f:
                f.write(speech.content)
                
            return audio_filename  # Return just filename for URL construction
            
        except Exception as e:
            print(f"Error generating audio: {str(e)}")
            return None
    
    def transcribe_audio(self, audio_data: str) -> Optional[str]:
        """Transcribe audio from base64 data"""
        try:
            # Decode base64 audio data
            audio_bytes = base64.b64decode(audio_data)
            
            # Create temporary file
            with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as tmp_file:
                tmp_file.write(audio_bytes)
                tmp_file_path = tmp_file.name
            
            # Transcribe using Whisper
            with open(tmp_file_path, "rb") as audio_file:
                transcript = self.client.audio.transcriptions.create(
                    model="whisper-1",
                    file=audio_file
                )
            
            # Clean up temporary file
            os.unlink(tmp_file_path)
            
            return transcript.text
            
        except Exception as e:
            print(f"Error transcribing audio: {str(e)}")
            return None
    
    def process_text_message(self, 
                           user_input: str, 
                           user_id: int, 
                           session_id: Optional[str] = None,
                           generate_audio: bool = True) -> ChatbotResponse:
        """Process text message from user"""
        
        try:
            # Get or create session
            session = self.get_or_create_session(user_id, session_id)
            
            # Add user message to session
            user_message = ChatMessage(
                role="user",
                content=user_input,
                timestamp=datetime.now(self.ist)
            )
            session.messages.append(user_message)
            
            # Generate response
            response_text = self.generate_response(user_input, session)
            
            # Generate audio if requested
            audio_filename = None
            audio_url = None
            if generate_audio:
                audio_filename = self.generate_audio(response_text, session.session_id)
                if audio_filename:
                    audio_url = f"/student/{user_id}/chat-audio/{audio_filename}"
            
            # Add assistant message to session
            assistant_message = ChatMessage(
                role="assistant",
                content=response_text,
                timestamp=datetime.now(self.ist),
                audio_path=audio_url
            )
            session.messages.append(assistant_message)
            
            # Generate suggested actions
            suggested_actions = self._generate_suggested_actions(user_input, response_text)
            
            return ChatbotResponse(
                success=True,
                message="Response generated successfully",
                response_text=response_text,
                audio_url=audio_url,
                session_id=session.session_id,
                suggested_actions=suggested_actions
            )
            
        except Exception as e:
            return ChatbotResponse(
                success=False,
                message=f"Error processing message: {str(e)}",
                response_text="I'm sorry, I encountered an error. Please try again.",
                session_id=session_id or "error"
            )
    
    def process_audio_message(self, 
                            audio_data: str, 
                            user_id: int, 
                            session_id: Optional[str] = None) -> ChatbotResponse:
        """Process audio message from user"""
        
        # First transcribe the audio
        transcribed_text = self.transcribe_audio(audio_data)
        
        if not transcribed_text:
            return ChatbotResponse(
                success=False,
                message="Could not transcribe audio",
                response_text="I'm sorry, I couldn't understand your audio. Please try again or type your message.",
                session_id=session_id or "error"
            )
        
        # Process as text message with audio enabled
        return self.process_text_message(transcribed_text, user_id, session_id, generate_audio=True)
    
    def get_conversation_history(self, session_id: str) -> Optional[List[ChatMessage]]:
        """Get conversation history for a session"""
        if session_id in self.sessions:
            return self.sessions[session_id].messages
        return None
    
    def clear_session(self, session_id: str) -> bool:
        """Clear a conversation session"""
        if session_id in self.sessions:
            del self.sessions[session_id]
            return True
        return False
    
    def _generate_suggested_actions(self, user_input: str, response_text: str) -> List[str]:
        """Generate suggested follow-up actions"""
        suggestions = []
        
        # Communication-related suggestions
        if any(word in user_input.lower() for word in ['speak', 'talk', 'presentation', 'public']):
            suggestions.extend([
                "Tell me about overcoming stage fright",
                "How to improve body language", 
                "Tips for confident speaking"
            ])
        elif any(word in user_input.lower() for word in ['shy', 'introvert', 'nervous']):
            suggestions.extend([
                "Help me build confidence",
                "Social interaction tips",
                "How to start conversations"
            ])
        elif any(word in user_input.lower() for word in ['task', 'homework', 'assignment']):
            suggestions.extend([
                "Use task management feature →",
                "Create a new task →", 
                "View my tasks →"
            ])
        else:
            suggestions.extend([
                "Tell me about communication skills",
                "How to be more confident",
                "Help with public speaking"
            ])
        
        return suggestions[:3]  # Return max 3 suggestions

# Configuration
@lru_cache()
def get_chatbot_agent():
    openai_api_key = os.getenv("OPENAI_API_KEY")
    if not openai_api_key:
        raise ValueError("OPENAI_API_KEY environment variable not set")
    return CommunicationChatbot(openai_api_key)