from fastapi import APIRouter, Depends, HTTPException
from extensions import get_db
from sqlalchemy.orm import Session
from auth import get_user, SECRET_KEY, ALGORITHM, JWTError, jwt
from models import Parent, Student, Teacher, ChatMessage, student_teacher_subject
from datetime import datetime
import time
import asyncio

chat_poll_router = APIRouter(prefix="/api/v1/chat")

# ---------------------------
# Helper to authenticate user from token (HTTP version)
# ---------------------------
def get_current_user_http(token: str, db: Session) -> dict:
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        username = payload.get("sub")
        if username is None:
            raise HTTPException(status_code=401, detail="Invalid token")
        user = get_user(username, db)
        if not user:
            raise HTTPException(status_code=401, detail="User not found")
    except JWTError:
        raise HTTPException(status_code=401, detail="Invalid token")

    return {
        "id": user["id"],
        "email": user["email"],
        "full_name": user["full_name"],
        "role_name": user["role_name"],
    }

# ---------------------------
# Conversations list for teacher
# ---------------------------
@chat_poll_router.get("/conversations/{teacher_id}")
def get_teacher_conversations(teacher_id: int, db: Session = Depends(get_db)):
    teacher = db.query(Teacher).filter(Teacher.user_id == teacher_id).first()
    if not teacher:
        raise HTTPException(status_code=404, detail="Teacher not found")

    parents = (
        db.query(Parent)
        .join(Student, Parent.student_id == Student.id)
        .join(student_teacher_subject, Student.id == student_teacher_subject.c.student_id)
        .filter(student_teacher_subject.c.teacher_id == teacher.id)
        .all()
    )

    conversations = []
    for parent in parents:
        user = parent.user
        # In /conversations/{teacher_id}
        conversations.append({
            "id": f"conv_{parent.user.id}",
            "participants": [
                {
                    "id": teacher.user_id,
                    "name": teacher.user.full_name,
                    "role": teacher.user.role_name
                },
                {
                    "id": parent.user.id,
                    "name": parent.user.full_name,
                    "role": parent.user.role_name,
                    "student_name": parent.student.user.full_name
                }
            ]
        })

    return {"conversations": conversations}

# ---------------------------
# Parent's only teacher contact
# ---------------------------
@chat_poll_router.get("/parent/{parent_id}/contact")
def get_parent_contact(parent_id: int, db: Session = Depends(get_db)):
    parent = db.query(Parent).filter(Parent.user_id == parent_id).first()
    if not parent:
        raise HTTPException(status_code=404, detail="Parent not found")

    student = db.query(Student).filter(Student.id == parent.student_id).first()
    if not student:
        raise HTTPException(status_code=404, detail="Student not found")

    teacher = (
        db.query(Teacher)
        .join(student_teacher_subject, Teacher.id == student_teacher_subject.c.teacher_id)
        .filter(student_teacher_subject.c.student_id == student.id)
        .first()
    )
    if not teacher:
        raise HTTPException(status_code=404, detail="No teacher found for this student")

    return {
        "user_id": teacher.user_id,
        "role_name": teacher.user.role_name,
        "full_name": teacher.user.full_name,
        "email": teacher.user.email,
        "student_name": student.user.full_name,
    }

# ---------------------------
# Send message (POST)
# ---------------------------
@chat_poll_router.post("/send_message")
def send_message(token: str, receiver_id: int, content: str, db: Session = Depends(get_db)):
    user = get_current_user_http(token, db)

    if not content.strip():
        raise HTTPException(status_code=400, detail="Empty message")

    message = ChatMessage(
        sender_id=user["id"],
        receiver_id=receiver_id,
        content=content,
        timestamp=datetime.utcnow()
    )
    db.add(message)
    db.commit()
    db.refresh(message)

    return {
        "id": message.id,
        "sender_id": message.sender_id,
        "receiver_id": message.receiver_id,
        "content": message.content,
        "timestamp": message.timestamp.isoformat()
    }

# ---------------------------
# Poll for new messages (Long Polling GET)
# ---------------------------
@chat_poll_router.get("/poll_messages")
async def poll_messages(token: str, receiver_id: int, since: float = 0.0, db: Session = Depends(get_db)):
    user = get_current_user_http(token, db)
    timeout = 25   # seconds
    interval = 0.5 # seconds
    waited = 0

    while waited < timeout:
        msgs = db.query(ChatMessage).filter(
            ((ChatMessage.sender_id == user["id"]) & (ChatMessage.receiver_id == receiver_id)) |
            ((ChatMessage.sender_id == receiver_id) & (ChatMessage.receiver_id == user["id"]))
        ).filter(ChatMessage.timestamp > datetime.fromtimestamp(since)) \
         .order_by(ChatMessage.timestamp.asc()) \
         .all()
        if msgs:
            return {
                "messages": [
                    {
                        "id": m.id,
                        "sender_id": m.sender_id,
                        "receiver_id": m.receiver_id,
                        "content": m.content,
                        "timestamp": m.timestamp.isoformat()
                    }
                    for m in msgs
                ]
            }
        await asyncio.sleep(interval)
        waited += interval
    # Timeout expires: just return empty
    return {"messages": []}
