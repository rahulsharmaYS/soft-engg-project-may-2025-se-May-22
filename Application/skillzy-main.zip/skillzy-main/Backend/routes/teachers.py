from models import *
from fastapi import APIRouter, HTTPException, Depends, Query, Form, UploadFile, File
from sqlalchemy.orm import Session
from extensions import get_db
from fastapi.responses import JSONResponse
from datetime import datetime
from sqlalchemy import distinct
from sqlalchemy import func
from typing import List, Literal
from pydantic import BaseModel, EmailStr, HttpUrl, AnyHttpUrl, Field
from pydantic import ValidationError
from sqlalchemy import or_
from models import Teacher, Student, Assignment, User, UserStatus, Subject, Task, Resource, Question, AssignmentStatus, Submission, Score, Announcement
from passlib.context import CryptContext
from passlib.hash import bcrypt
import pytz
from schema import ChangePasswordRequest, ResourceCreate, AssignmentCreate, QuestionCreate, ResourceOut, ResourceResponse
from pydantic import BaseModel, EmailStr
from typing import Optional
from sqlalchemy.orm import joinedload
import uuid
import os
import shutil
import time
from tasks import send_parent_score_notification

ist = pytz.timezone("Asia/Kolkata")
now = datetime.now(ist)

teacher_router = APIRouter(
    prefix="/api/v1/teacher",
    tags=["Teachers"]
)

@teacher_router.get("/{teacher_id}")
def get_teacher(teacher_id: int, db: Session = Depends(get_db)):
    try:
        if teacher_id is None:
            raise HTTPException(status_code=400, detail="Teacher ID is required")

        teacher = db.query(Teacher).filter(Teacher.id == teacher_id).first()
        if not teacher:
            raise HTTPException(status_code=404, detail="Teacher not found")
        print(f"DEBUG: Retrieved teacher {teacher_id} - {teacher.to_dict(False)}")
        return {"teacher": teacher.to_dict(False)}
    except Exception as e:
        print(f"DEBUG: Error retrieving teacher {teacher_id} - {str(e)}")
        raise HTTPException(status_code=500, detail=f"Internal Server Error: {str(e)}")


@teacher_router.get("/{teacher_id}/dashboard")
def get_teacher_dashboard(teacher_id: int, db: Session = Depends(get_db)):
    try:
        teacher = db.query(Teacher).filter(Teacher.user_id == teacher_id).first()
        if not teacher:
            raise HTTPException(status_code=404, detail="Teacher not found")

        ################# Teacher Cards ############################
        students = db.query(Student).filter(Student.class_id == teacher.class_id).all()
        total_students = len(students)

        active_students = db.query(Student).join(Student.user).filter(
            Student.class_id == teacher.class_id,
            User.user_status == UserStatus.active
        ).count()

        resources_provided = db.query(Resource).filter(
            Resource.instructor_id == teacher_id,
            Resource.category == "student"
        ).count()

        assigned_count = db.query(Assignment).filter(
            Assignment.teacher_id == teacher_id,
            Assignment.student_id != None
        ).count()

        completed_count = db.query(Submission).join(Assignment).filter(
            Assignment.teacher_id == teacher_id,
            Submission.status != "pending"
        ).count()

        ###################### Teacher Charts ########################
        course_completion = (
            round((completed_count / assigned_count) * 100)
            if assigned_count else 0
        )

        assignment_counts = dict(
            db.query(
                Assignment.student_id,
                func.count(Assignment.id)
            )
            .filter(
                Assignment.teacher_id == teacher_id,
                Assignment.student_id != None
            )
            .group_by(Assignment.student_id)
            .all()
        )

        submission_counts = dict(
            db.query(
                Submission.student_id,
                func.count(Submission.id)
            )
            .join(Assignment, Submission.assignment_id == Assignment.id)
            .filter(
                Assignment.teacher_id == teacher_id
            )
            .group_by(Submission.student_id)
            .all()
        )

        completion_percentages = {}
        for student_id, total_assigned in assignment_counts.items():
            total_submitted = submission_counts.get(student_id, 0)
            completion_percentage = (total_submitted / total_assigned) * 100 if total_assigned > 0 else 0
            completion_percentages[student_id] = completion_percentage

        highly_active_students = [
            student_id for student_id, percent in completion_percentages.items()
            if percent > 80
        ]

        highly_active_count = len(highly_active_students)
        moderately_active_count = sum(1 for _, percent in completion_percentages.items() if 60 < percent <= 80)
        low_active_count = sum(1 for _, percent in completion_percentages.items() if 40 < percent <= 60)
        inactive_count = sum(1 for _, percent in completion_percentages.items() if percent <= 40)

        assignments_created = (
            db.query(Assignment.title)
            .filter(Assignment.teacher_id == teacher_id)
            .distinct()
            .count()
        )

        ###################### Teacher Notifications ########################
        notifications = db.query(Announcement).filter(
            or_(
                Announcement.recipient_role.in_(["all", "teacher"]),
                Announcement.specific_user_id == teacher_id
            )
        ).order_by(Announcement.created_at.desc()).all()

        notifications_list = [
            {
                "id": ann.id,
                "title": ann.subject,
                "body": ann.body,
                "date": ann.created_at.isoformat()
            }
            for ann in notifications
        ]

        ###################### Final Response ########################
        return {
            "teacher_name": teacher.user.full_name,
            "summary": {
                "total_students": total_students,
                "active_students": active_students,
                "assignments_created": assignments_created,
                "resources_provided": resources_provided,
                "course_completion_percentage": course_completion
            },
            "engagementCounts": {
                "highlyActive": highly_active_count,
                "moderatelyActive": moderately_active_count,
                "lowActivity": low_active_count,
                "inactive": inactive_count
            },
            "notifications": notifications_list
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Internal Server Error: {str(e)}")

@teacher_router.get("/{teacher_id}/profile")
def get_teacher_profile(teacher_id: int, db: Session = Depends(get_db)):
    try:
        teacher = db.query(Teacher).filter(Teacher.user_id == teacher_id).first()
        if not teacher:
            raise HTTPException(status_code=404, detail="Teacher not found")

        user = teacher.user
        subject = db.query(Subject).filter(Subject.id == teacher.subject_id).first()

        profile_pic_url = None
        if user.profile_picture:
            profile_pic_url = f"/{user.profile_picture.replace(os.sep, '/')}"

        return {
            "name": user.full_name,
            "email": user.email,
            "subjects": [subject.name] if subject else [],
            "role": user.role_name.value,
            "joined": user.created_at,
            "experience": teacher.experience,
            "profile_picture": profile_pic_url,
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Internal Server Error: {str(e)}")



class EditProfileRequest(BaseModel):
    full_name: str
    email: EmailStr


@teacher_router.put("/{teacher_id}/editprofile")
async def edit_teacher_profile(
    teacher_id: int,
    full_name: str = Form(...),
    email: str = Form(...),
    profile_pic: UploadFile = File(None),
    db: Session = Depends(get_db)
):
    try:
        teacher = db.query(Teacher).filter(Teacher.user_id == teacher_id).first()
        if not teacher:
            raise HTTPException(status_code=404, detail="Teacher not found")

        teacher.user.full_name = full_name
        teacher.user.email = email

        if profile_pic:
            dir_path = f"static/profile_pictures/teacher/{teacher_id}"
            os.makedirs(dir_path, exist_ok=True)

            ext = os.path.splitext(profile_pic.filename)[1]
            filename = f"profile_{int(time.time())}{ext}"
            file_path = os.path.join(dir_path, filename)

            contents = await profile_pic.read()
            with open(file_path, "wb") as f:
                f.write(contents)

            teacher.user.profile_picture = file_path

        db.commit()
        return {"message": "Profile updated successfully"}

    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Internal Server Error: {str(e)}")

from fastapi import Request

@teacher_router.post("/{teacher_id}/resources", response_model=ResourceResponse)
async def create_resource_for_teacher(
    teacher_id: int,
    request: Request,
    db: Session = Depends(get_db)
):
    try:
        content_type = request.headers.get("content-type", "")

        title = description = category = url = None
        file = None

        if "multipart/form-data" in content_type:
            # Parse multipart form-data
            form = await request.form()
            title = form.get("title")
            description = form.get("description")
            category = form.get("category")
            url = form.get("url")
            file = form.get("file")  # UploadFile
        else:
            # Parse JSON
            data = await request.json()
            title = data.get("title")
            description = data.get("description")
            category = data.get("category")
            url = data.get("url")

        if not title or not description or not category:
            raise HTTPException(status_code=400, detail="Title, description, and category are required")

        # Validate URL if provided
        if url:
            try:
                validated_url = AnyHttpUrl(url)
                url = str(validated_url)
                print("Validated URL:", url)
            except Exception:
                raise HTTPException(status_code=400, detail="Invalid URL format")

        # Ensure teacher exists
        teacher = db.query(Teacher).filter(Teacher.user_id == teacher_id).first()
        if not teacher:
            raise HTTPException(status_code=404, detail="Teacher not found")

        # Process file or URL
        final_url = None
        if url:
            final_url = url
        elif file:
            role_folder = "teacher" if category.lower() in ["instructor", "teacher"] else "student"
            upload_dir = os.path.join("static", "resources", role_folder, str(teacher_id))
            os.makedirs(upload_dir, exist_ok=True)

            original_filename = os.path.basename(file.filename or "upload")
            upload_path = os.path.join(upload_dir, original_filename)

            file_bytes = await file.read()
            with open(upload_path, "wb") as buffer:
                buffer.write(file_bytes)
            await file.close()

            final_url = upload_path.replace(os.path.sep, "/")
        else:
            raise HTTPException(status_code=400, detail="Either URL or file must be provided")

        # Save resource
        new_resource = Resource(
            title=title,
            description=description,
            url=final_url,
            category=category,
            instructor_id=teacher_id
        )
        db.add(new_resource)
        db.commit()
        db.refresh(new_resource)

        return {
            "message": "Resource created successfully",
            "resource": ResourceOut.model_validate(new_resource, from_attributes=True)
        }

    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))

@teacher_router.get("/{teacher_id}/resources", response_model=List[ResourceOut])
def get_resources_for_teacher(
    teacher_id: int,
    category: Literal["student", "instructor"] = Query(...),
    db: Session = Depends(get_db)
):
    try:
        resources = db.query(Resource).filter(
            Resource.instructor_id == teacher_id,
            Resource.category == category
        ).all()

        # return [res.to_dict() for res in resources]
        return resources
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Internal Server Error: {str(e)}")

@teacher_router.get("/{teacher_id}/profile")
def get_teacher_profile(teacher_id: int, db: Session = Depends(get_db)):
    try:
        teacher = db.query(Teacher).filter(Teacher.user_id == teacher_id).first()
        if not teacher:
            raise HTTPException(status_code=404, detail="Teacher not found")

        user = teacher.user
        subject = db.query(Subject).filter(Subject.id == teacher.subject_id).first()

        profile_pic_url = None
        if user.profile_picture:
            profile_pic_url = f"/{user.profile_picture.replace(os.sep, '/')}"

        return {
            "name": user.full_name,
            "email": user.email,
            "subjects": [subject.name] if subject else [],
            "role": user.role_name.value,
            "joined": user.created_at,
            "experience": teacher.experience,
            "profile_picture": profile_pic_url,
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Internal Server Error: {str(e)}")


@teacher_router.get("/{teacher_id}/students")
def get_students_for_teacher(teacher_id: int, db: Session = Depends(get_db)):
    try:
        teacher = db.query(Teacher).filter(Teacher.user_id == teacher_id).first()
        if not teacher:
            raise HTTPException(status_code=404, detail="Teacher not found")

        students = db.query(Student).filter(Student.class_id == teacher.class_id).all()
        result = []

        for student in students:
            user = student.user
            if not user:
                continue

            assigned_assignments = db.query(Assignment).filter(
                Assignment.teacher_id == teacher_id,
                Assignment.class_id == student.class_id,
                Assignment.student_id == student.id
            ).all()

            completed_assignments = db.query(Assignment).join(Submission).filter(
                Submission.student_id == student.id,
                Submission.assignment_id == Assignment.id,
                Assignment.teacher_id == teacher_id,
            ).distinct().all()

            assigned_list = [{"id": a.id, "title": a.title} for a in assigned_assignments]
            completed_list = [{"id": a.id, "title": a.title} for a in completed_assignments]

            result.append({
                "id": f"#{student.id}",
                "name": user.full_name,
                "status": user.user_status.name.capitalize(),
                "assigned_assignments": assigned_list,
                "completed_assignments": completed_list,
            })

        return result

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Internal Server Error: {str(e)}")



@teacher_router.get("/student/{student_id}")
def get_student_details(student_id: int, db: Session = Depends(get_db)):
    try:
        student = db.query(Student).filter(Student.id == student_id).first()
        if not student:
            raise HTTPException(status_code=404, detail="Student not found")

        user = student.user
        class_info = student.school_class
        class_name = f"{class_info.standard}-{class_info.division}" if class_info else None

        return {
            "id": student.id,
            "name": user.full_name,
            "email": user.email,
            "status": user.user_status.name.capitalize(),
            "class": class_name
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Internal Server Error: {str(e)}")

@teacher_router.post("/{teacher_id}/assignments")
def create_assignment(teacher_id: int, data: AssignmentCreate, db: Session = Depends(get_db)):
    try:
        teacher = db.query(Teacher).filter(Teacher.user_id == teacher_id).first()

        if not teacher:
            raise HTTPException(status_code=404, detail="Teacher not found")

        if not teacher.class_id or not teacher.subject_id:
            raise HTTPException(status_code=400, detail="Teacher must be assigned to both class and subject")

        print(f"Teacher ID: {teacher.id}, Class ID: {teacher.class_id}, Subject ID: {teacher.subject_id}")

        all_students = db.query(Student).filter(Student.class_id == teacher.class_id).all()

        print(f"All Students: {len(all_students)}")

        # Match students by subject
        matching_students = db.query(Student).filter(
    Student.class_id == teacher.class_id
).join(Student.subjects).filter(
    Subject.id == teacher.subject_id
).all()

        if not matching_students:
            raise HTTPException(status_code=404, detail="No matching students found")

        created_assignments = []
        for student in matching_students:
            assignment = Assignment(
                title=data.title,
                teacher_id=teacher.user_id,
                class_id=teacher.class_id,
                subject_id=teacher.subject_id,
                student_id=student.id,
                assignment_created=datetime.utcnow(),
                assignment_deadline=data.assignment_deadline,
                question_type=data.question_type,
                status=AssignmentStatus.assigned
            )
            db.add(assignment)
            created_assignments.append(assignment)

        db.commit()

        return {
            "message": f"{len(created_assignments)} assignments created.",
            "students": [s.user.full_name for s in matching_students],
            "assignment": created_assignments[0].to_dict() 
        }

    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Something went wrong: {str(e)}")


@teacher_router.put("/{teacher_id}/assignments/{assignment_id}")
def update_assignment(teacher_id: int, assignment_id: int, data: AssignmentCreate, db: Session = Depends(get_db)):
    try:
        assignment = db.query(Assignment).filter(
            Assignment.id == assignment_id,
            Assignment.teacher_id == teacher_id
        ).first()

        if not assignment:
            raise HTTPException(status_code=404, detail="Assignment not found")

        assignment.title = data.title
        assignment.feedback = data.description
        assignment.assignment_deadline = data.assignment_deadline
        assignment.scores = data.score
        assignment.question_type = data.question_type

        db.commit()
        db.refresh(assignment)
        return {"message": "Assignment updated", "assignment": assignment.to_dict()}
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))

@teacher_router.get("/{teacher_id}/assignments")
def get_assignments(teacher_id: int, type: str = '', search: str = '', db: Session = Depends(get_db)):
    try:
        query = db.query(Assignment).filter(Assignment.teacher_id == teacher_id)

        if type:
            query = query.filter(Assignment.question_type == type)

        if search:
            query = query.filter(Assignment.title.ilike(f"%{search}%"))

        assignments = query.order_by(Assignment.assignment_created.desc()).all()

        # Simple deduplication by title
        unique = {}
        for a in assignments:
            if a.title not in unique:
                unique[a.title] = a

        return [a.to_dict() for a in unique.values()]

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ------------------ QUESTION MANAGEMENT ------------------

@teacher_router.post("/{teacher_id}/assignments/{assignment_id}/questions")
def add_question(teacher_id: int, assignment_id: int, question_data: QuestionCreate, db: Session = Depends(get_db)):
    try:
        assignment = db.query(Assignment).filter(
            Assignment.id == assignment_id,
            Assignment.teacher_id == teacher_id
        ).first()
        if not assignment:
            raise HTTPException(status_code=404, detail="Assignment not found")

        new_question = Question(
            assignment_id=assignment_id,
            question=question_data.question,
            option_1=question_data.option_1,
            option_2=question_data.option_2,
            option_3=question_data.option_3,
            option_4=question_data.option_4,
            correct_answer=question_data.correct_answer,
            descriptive_answer=question_data.descriptive_answer
        )
        db.add(new_question)
        db.commit()
        db.refresh(new_question)

        return {"message": "Question added", "question": new_question.to_dict()}
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))

@teacher_router.put("/{teacher_id}/assignments/{assignment_id}/questions/{question_id}")
def update_question(teacher_id: int, assignment_id: int, question_id: int, question_data: QuestionCreate, db: Session = Depends(get_db)):
    try:
        question = db.query(Question).join(Assignment).filter(
            Question.id == question_id,
            Question.assignment_id == assignment_id,
            Assignment.teacher_id == teacher_id
        ).first()

        if not question:
            raise HTTPException(status_code=404, detail="Question not found")

        question.question = question_data.question
        question.option_1 = question_data.option_1
        question.option_2 = question_data.option_2
        question.option_3 = question_data.option_3
        question.option_4 = question_data.option_4
        question.correct_answer = question_data.correct_answer
        question.descriptive_answer = question_data.descriptive_answer

        db.commit()
        db.refresh(question)
        return {"message": "Question updated", "question": question.to_dict()}
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))

@teacher_router.delete("/{teacher_id}/assignments/{assignment_id}/questions/{question_id}")
def delete_question(teacher_id: int, assignment_id: int, question_id: int, db: Session = Depends(get_db)):
    try:
        question = db.query(Question).join(Assignment).filter(
            Question.id == question_id,
            Question.assignment_id == assignment_id,
            Assignment.teacher_id == teacher_id
        ).first()

        if not question:
            raise HTTPException(status_code=404, detail="Question not found")

        db.delete(question)
        db.commit()
        return {"message": "Question deleted"}
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))
    

@teacher_router.get("/{teacher_id}/assignments/{assignment_id}/questions")
def get_assignment_questions(teacher_id: int, assignment_id: int, db: Session = Depends(get_db)):
    try:
        assignment = db.query(Assignment).filter(
            Assignment.id == assignment_id,
            Assignment.teacher_id == teacher_id
        ).first()
        if not assignment:
            raise HTTPException(status_code=404, detail="Assignment not found")

        questions = db.query(Question).filter(
            Question.assignment_id == assignment_id
        ).all()

        return [q.to_dict() for q in questions]
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

###############Evaluation Routes#########################

@teacher_router.get("/teacher/{teacher_id}/evaluations")
def get_evaluations(teacher_id: int, status: Optional[str] = None, db: Session = Depends(get_db)):
    assignment_ids = db.query(Assignment.id).filter_by(teacher_id=teacher_id).filter(Assignment.question_type == "text").subquery()

    query = db.query(Submission).filter(Submission.assignment_id.in_(assignment_ids))
    print(f"DEBUG: Fetching evaluations for teacher {teacher_id} with status {status}")
    if status in ["pending", "evaluated"]:
        query = query.filter(Submission.status == status)

    submissions = query.all()

    result = []
    for s in submissions:
        data = s.to_dict(include_relationships=True)
        data["student_name"] = s.student.user.full_name if s.student and s.student.user else "Unknown"
        result.append(data)

    return result


@teacher_router.get("/submission/{submission_id}/details")
def get_submission_details(submission_id: int, db: Session = Depends(get_db)):
    submission = db.query(Submission).filter_by(id=submission_id).first()
    if not submission:
        raise HTTPException(status_code=404, detail="Submission not found")

    assignment = db.query(Assignment).filter_by(id=submission.assignment_id).first()
    questions = db.query(Question).filter_by(assignment_id=assignment.id).all()

    return {
        "submission": submission.to_dict(),
        "questions": [q.to_dict() for q in questions]
    }


@teacher_router.post("/submission/{submission_id}/evaluate")
def evaluate_submission(
    submission_id: int,
    score: int,
    feedback: Optional[str] = None,
    teacher_id: Optional[int] = None,
    db: Session = Depends(get_db)
):
    submission = db.query(Submission).filter_by(id=submission_id).first()
    if not submission:
        raise HTTPException(status_code=404, detail="Submission not found")

    # Update submission
    submission.status = "evaluated"
    submission.updated_at = datetime.utcnow()

    # Save score (if already exists, update it)
    score_record = db.query(Score).filter_by(
        student_id=submission.student_id,
        assignment_id=submission.assignment_id
    ).first()

    if not score_record:
        score_record = Score(
            student_id=submission.student_id,
            assignment_id=submission.assignment_id,
            # created_at=datetime.utcnow()
        )
        db.add(score_record)

    score_record.score = score
    score_record.percentage = score
    score_record.status = "graded"
    score_record.feedback = feedback
    score_record.graded_by = teacher_id
    score_record.graded_at = datetime.utcnow()
    score_record.max_score = 100    

    db.commit()
    # send_parent_score_notification(assignment.id).delay() #type: ignore

    return {"message": "Evaluation saved successfully"}

@teacher_router.get("/submission/{submission_id}/evaluation")
def get_evaluation_details(submission_id: int, db: Session = Depends(get_db)):
    submission = db.query(Submission).filter_by(id=submission_id).first()
    if not submission:
        raise HTTPException(status_code=404, detail="Submission not found")

    assignment = db.query(Assignment).filter_by(id=submission.assignment_id).first()
    questions = db.query(Question).filter_by(assignment_id=assignment.id).all()

    score_record = db.query(Score).filter_by(
        student_id=submission.student_id,
        assignment_id=submission.assignment_id
    ).first()

    return {
        "student_answer": submission.answer if hasattr(submission, "answer") else None,
        "status": submission.status,
        "score": score_record.score if score_record else None,
        "feedback": score_record.feedback if score_record else None,
        "questions": [q.to_dict() for q in questions]
    }

def add_notification(teacher_id: int, message: str, db):
    notification = Notification(
        user_id=teacher_id,
        message=message,
        timestamp=datetime.now()
    )
    db.add(notification)
    db.commit()

from routes.assignment_agent import get_assignment_agent, AssignmentAgentResponse
from fastapi import Body
from auth import get_current_user
import json


@teacher_router.post("/{teacher_id}/ai-assignment")
def ai_assignment_manager(
    teacher_id: int, 
    request_data: dict = Body(...), 
    db: Session = Depends(get_db),
    user=Depends(get_current_user)
):
    """
    AI-powered assignment management endpoint
    Accepts natural language input to perform CRUD operations on assignments and questions
    
    Example requests:
    - "Create a math assignment on algebra due next Friday"
    - "Show me all my assignments"
    - "Create 5 MCQ questions for physics assignment"
    - "Generate 10 questions about photosynthesis"
    - "Update algebra assignment due date to tomorrow"
    - "Delete chemistry project assignment"
    - "Show questions for math assignment"
    """
    try:
        user_input = request_data.get("message", "").strip()
        
        if not user_input:
            return {
                "success": False,
                "message": "Please provide a message describing what you want to do with your assignments."
            }
        
        # Get the AI agent
        agent = get_assignment_agent()
        
        # Process the request
        response = agent.process_request(user_input, teacher_id, db)
        
        # Add notification for successful operations
        if response.success and (response.assignment_data or response.questions):
            add_notification(teacher_id, f"🤖 AI Assignment Assistant: {response.message}", db)
        
        return response.dict()
        
    except Exception as e:
        return {
            "success": False,
            "message": f"AI Assignment Assistant error: {str(e)}"
        }

@teacher_router.get("/{teacher_id}/ai-assignment/help")
def ai_assignment_help(teacher_id: int):
    """Get help information for AI assignment management"""
    return {
        "message": "AI Assignment Assistant Help",
        "assignment_examples": [
            {
                "input": "Create a math assignment on algebra due next Friday",
                "description": "Creates a new assignment with title, subject, and due date"
            },
            {
                "input": "Show me all my assignments",
                "description": "Lists all your assignments"
            },
            {
                "input": "Update physics assignment due date to tomorrow",
                "description": "Updates assignment deadline"
            },
            {
                "input": "Delete the old chemistry project",
                "description": "Removes an assignment"
            },
            {
                "input": "Show assignments with MCQ questions",
                "description": "Filters assignments by question type"
            }
        ],
        "question_examples": [
            {
                "input": "Create 5 MCQ questions for physics assignment",
                "description": "Generates 5 multiple choice questions for an assignment"
            },
            {
                "input": "Generate 10 questions about photosynthesis",
                "description": "Creates questions on a specific topic"
            },
            {
                "input": "Show questions for math assignment",
                "description": "Displays all questions in an assignment"
            },
            {
                "input": "Update question 1 in physics assignment",
                "description": "Modifies a specific question"
            },
            {
                "input": "Delete question about cell division",
                "description": "Removes a specific question"
            },
            {
                "input": "Create 15 chemistry questions about organic compounds",
                "description": "Generates multiple questions on a specific chemistry topic"
            }
        ],
        "supported_operations": [
            "Create assignments with natural language",
            "List and filter assignments",
            "Update assignment details (title, due date, feedback, scores)",
            "Delete assignments",
            "Generate multiple questions automatically using AI",
            "Create, read, update, delete individual questions",
            "Smart date parsing (tomorrow, next week, next Friday, etc.)",
            "Intelligent question generation based on topics",
            "Support for different question types (multiple_choice, text)"
        ],
        "question_generation_features": [
            "Auto-generate questions based on subject/topic",
            "Create multiple questions in one command (5, 10, 20+ questions)",
            "Intelligent multiple choice options generation",
            "Proper answer explanations",
            "Variable difficulty levels",
            "Subject-specific question formats"
        ]
    }

@teacher_router.post("/{teacher_id}/ai-assignment/bulk-questions")
def bulk_generate_questions(
    teacher_id: int,
    request_data: dict = Body(...),
    db: Session = Depends(get_db),
    user=Depends(get_current_user)
):
    """
    Bulk question generation endpoint
    Specifically for generating large numbers of questions
    
    Example:
    {
        "assignment_id": 123,
        "topic": "Cell Biology",
        "question_count": 20,
        "question_type": "multiple_choice",
        "difficulty": "medium"
    }
    """
    try:
        assignment_id = request_data.get("assignment_id")
        topic = request_data.get("topic", "")
        question_count = request_data.get("question_count", 5)
        question_type = request_data.get("question_type", "multiple_choice")
        difficulty = request_data.get("difficulty", "medium")
        
        if not assignment_id:
            return {
                "success": False,
                "message": "Assignment ID is required"
            }
        
        # Verify assignment belongs to teacher
        assignment = db.query(Assignment).filter(
            Assignment.id == assignment_id,
            Assignment.teacher_id == teacher_id
        ).first()
        
        if not assignment:
            return {
                "success": False,
                "message": "Assignment not found or not owned by teacher"
            }
        
        # Get the AI agent
        agent = get_assignment_agent()
        
        # Create question data for bulk generation
        question_data = {
            "topic": topic,
            "question_type": question_type,
            "difficulty": difficulty
        }
        
        # Generate questions using the agent
        generated_questions = agent._generate_questions_with_ai(
            assignment.title,
            topic or assignment.title,
            question_count,
            question_type
        )
        
        created_questions = []
        for q_data in generated_questions:
            question = Question(
                assignment_id=assignment_id,
                question=q_data.get("question", ""),
                option_1=q_data.get("option_1", ""),
                option_2=q_data.get("option_2", ""),
                option_3=q_data.get("option_3", ""),
                option_4=q_data.get("option_4", ""),
                correct_answer=q_data.get("correct_answer", ""),
                descriptive_answer=q_data.get("descriptive_answer", "")
            )
            db.add(question)
            created_questions.append(question)
        
        db.commit()
        
        # Add notification
        add_notification(
            teacher_id, 
            f"🤖 Generated {len(created_questions)} questions for assignment '{assignment.title}'", 
            db
        )
        
        return {
            "success": True,
            "message": f"Successfully generated {len(created_questions)} questions for assignment '{assignment.title}'",
            "questions": [q.to_dict() for q in created_questions],
            "assignment": assignment.to_dict()
        }
        
    except Exception as e:
        db.rollback()
        return {
            "success": False,
            "message": f"Failed to generate questions: {str(e)}"
        }

@teacher_router.post("/{teacher_id}/ai-assignment/smart-create")
def smart_assignment_creation(
    teacher_id: int,
    request_data: dict = Body(...),
    db: Session = Depends(get_db),
    user=Depends(get_current_user)
):
    """
    Smart assignment creation with automatic question generation
    Creates assignment and questions in one go
    
    Example:
    {
        "title": "Photosynthesis Quiz",
        "subject": "Biology",
        "due_date": "next Friday",
        "question_count": 10,
        "question_type": "mcq",
        "topics": ["chlorophyll", "light reactions", "carbon fixation"]
    }
    """
    try:
        title = request_data.get("title", "New Assignment")
        due_date = request_data.get("due_date", "")
        question_count = request_data.get("question_count", 5)
        question_type = request_data.get("question_type", "multiple_choice")
        topics = request_data.get("topics", [])
        
        # Get the AI agent
        agent = get_assignment_agent()
        
        # First create the assignment
        assignment_data = {
            "title": title,
            "assignment_deadline": due_date,
            "question_type": question_type
        }
        
        assignment_response = agent._create_assignment(assignment_data, teacher_id, db)
        
        if not assignment_response.success:
            return assignment_response.dict()
        
        # Get the created assignment
        created_assignment = db.query(Assignment).filter(
            Assignment.teacher_id == teacher_id,
            Assignment.title == title
        ).first()
        
        if not created_assignment:
            return {
                "success": False,
                "message": "Assignment created but could not retrieve for question generation"
            }
        
        # Generate questions for each topic or general questions
        all_questions = []
        if topics:
            questions_per_topic = max(1, question_count // len(topics))
            for topic in topics:
                generated_questions = agent._generate_questions_with_ai(
                    title, topic, questions_per_topic, question_type
                )
                
                for q_data in generated_questions:
                    question = Question(
                        assignment_id=created_assignment.id,
                        question=q_data.get("question", ""),
                        option_1=q_data.get("option_1", ""),
                        option_2=q_data.get("option_2", ""),
                        option_3=q_data.get("option_3", ""),
                        option_4=q_data.get("option_4", ""),
                        correct_answer=q_data.get("correct_answer", ""),
                        descriptive_answer=q_data.get("descriptive_answer", "")
                    )
                    db.add(question)
                    all_questions.append(question)
        else:
            # Generate general questions about the assignment title
            generated_questions = agent._generate_questions_with_ai(
                title, title, question_count, question_type
            )
            
            for q_data in generated_questions:
                question = Question(
                    assignment_id=created_assignment.id,
                    question=q_data.get("question", ""),
                    option_1=q_data.get("option_1", ""),
                    option_2=q_data.get("option_2", ""),
                    option_3=q_data.get("option_3", ""),
                    option_4=q_data.get("option_4", ""),
                    correct_answer=q_data.get("correct_answer", ""),
                    descriptive_answer=q_data.get("descriptive_answer", "")
                )
                db.add(question)
                all_questions.append(question)
        
        db.commit()
        
        # Add notification
        add_notification(
            teacher_id,
            f"🤖 Created assignment '{title}' with {len(all_questions)} questions",
            db
        )
        
        return {
            "success": True,
            "message": f"Successfully created assignment '{title}' with {len(all_questions)} questions",
            "assignment": created_assignment.to_dict(),
            "questions": [q.to_dict() for q in all_questions],
            "students_count": assignment_response.message.split()[3] if assignment_response.message else "unknown"
        }
        
    except Exception as e:
        db.rollback()
        return {
            "success": False,
            "message": f"Failed to create smart assignment: {str(e)}"
        }

@teacher_router.get("/{teacher_id}/ai-assignment/suggestions")
def get_assignment_suggestions(
    teacher_id: int,
    subject: str = "",
    class_level: str = "",
    db: Session = Depends(get_db)
):
    """Get AI-powered assignment suggestions based on subject and class level"""
    try:
        # Get teacher info
        teacher = db.query(Teacher).filter(Teacher.user_id == teacher_id).first()
        if not teacher:
            return {"success": False, "message": "Teacher not found"}
        
        # Get the AI agent
        agent = get_assignment_agent()
        
        # Generate suggestions using AI
        suggestion_prompt = f"""
        Suggest 5 creative assignment ideas for a {subject or 'general'} teacher teaching {class_level or 'students'}.
        
        For each suggestion, provide:
        - title: Creative assignment title
        - description: Brief description of the assignment
        - question_type: Type of questions (mcq, descriptive, mixed)
        - estimated_questions: Suggested number of questions
        - topics: List of 3-5 specific topics to cover
        - difficulty: easy, medium, or hard
        
        Make suggestions engaging, educational, and age-appropriate.
        Return as JSON with 'suggestions' array.
        """
        
        response = agent.client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": "You are an expert educator providing creative assignment suggestions."},
                {"role": "user", "content": suggestion_prompt}
            ],
            temperature=0.8,
            response_format={"type": "json_object"}
        )
        
        suggestions = json.loads(response.choices[0].message.content)
        
        return {
            "success": True,
            "message": "Generated assignment suggestions",
            "suggestions": suggestions.get("suggestions", [])
        }
        
    except Exception as e:
        return {
            "success": False,
            "message": f"Failed to generate suggestions: {str(e)}"
        }