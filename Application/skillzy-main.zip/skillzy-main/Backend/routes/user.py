from fastapi import HTTPException, Request
from models import Student, Teacher, Parent, User, Subject,student_teacher_subject, student_subject, UserStatus
from sqlalchemy.orm import Session
from fastapi import APIRouter, HTTPException, Depends
from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordRequestForm
from auth import *
from extensions import get_db
from sqlalchemy import text
from schema import ChangePasswordRequest


login_router = APIRouter(
    prefix="/api/v1/user",
    tags=["User"]
)


@login_router.post("/login")
def login(form_data: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    try:
        user = authenticate_user(form_data.username, form_data.password, db)
        if not user:
            raise HTTPException(status_code=401, detail="Incorrect username or password")

        # Check if user status is active (comparing enum objects)
        if user.get("user_status") != UserStatus.active:
            raise HTTPException(status_code=403, detail="Account is inactive. Please contact administrator.")

        access_token = create_access_token(data={"sub": user["username"]})

        return {
            "access_token": access_token,
            "token_type": "bearer",
            "user": {
                "id": user["id"],
                "role": user["role_name"],
                "username": user["username"]
            }
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=401, detail=f"Invalid username or password.: {str(e)}")

from models import student_teacher_subject  # make sure it's imported

@login_router.post("/create_user")
async def register_user(request: Request, db: Session = Depends(get_db)):
    try:
        body = await request.json()
        print("DEBUG BODY:", body)
        if not body.get("username") or not body.get("password") or not body.get("role_name"):
            raise HTTPException(status_code=400, detail="Username, password, and role_name are required")

        if body.get("role_name") not in ["student", "teacher", "parent"]:
            raise HTTPException(status_code=400, detail="Invalid role name. Must be 'student', 'teacher', or 'parent'")
        
        # Check if username exists
        existing_user = db.query(User).filter(User.username == body.get("username")).first()
        if existing_user:
            raise HTTPException(status_code=400, detail="Username already exists")

        # Create user
        new_user = User(
            email=body.get("email"),
            full_name=body.get("full_name"),   
            username=body.get("username"),
            password=pwd_context.hash(body.get("password")),
            role_name=body.get("role_name"),
            created_at=datetime.now()
        )
        db.add(new_user)
        db.commit()           
        db.refresh(new_user)  

        # Role-specific logic
        if body.get("role_name") == "student":
            new_student = Student(
                user_id=new_user.id,
                class_id=body.get("class_id"),
                subject_id=None 
            )
            db.add(new_student)
            db.commit()
            db.refresh(new_student)

            selected_skills = body.get("selected_skills", [])
            selected_teachers = body.get("selected_teachers", [])
            
            if not selected_skills:
                raise HTTPException(status_code=400, detail="At least one skill must be selected")
            
            if not selected_teachers:
                raise HTTPException(status_code=400, detail="At least one teacher must be selected")

            # Link student to selected subjects/skills
            for skill_id in selected_skills:
                subject = db.query(Subject).filter(Subject.id == int(skill_id)).first()
                if not subject:
                    raise HTTPException(status_code=400, detail=f"Subject {skill_id} not found")
                
                # Use execute with values() for association table
                db.execute(
                    student_subject.insert().values(
                        student_id=new_student.id,
                        subject_id=int(skill_id)
                    )
                )

            # Link student to selected teachers for specific subjects
            for teacher_id in selected_teachers:
                teacher = db.query(Teacher).filter(Teacher.id == int(teacher_id)).first()
                if not teacher:
                    raise HTTPException(status_code=400, detail=f"Teacher {teacher_id} not found")
                
                teacher_subject_id = teacher.subject_id
                # Only link if the teacher's subject is in the student's selected skills
                if str(teacher_subject_id) in selected_skills:
                    db.execute(
                        student_teacher_subject.insert().values(
                            student_id=new_student.id,
                            subject_id=teacher_subject_id,
                            teacher_id=int(teacher_id)
                        )
                    )
                else:
                    print(f"Warning: Teacher {teacher_id} doesn't teach any of the selected subjects")

        elif body.get("role_name") == "teacher":
            selected_skills = body.get("skills_to_teach", [])
            if not selected_skills:
                raise HTTPException(status_code=400, detail="At least one skill to teach must be selected")
            
            new_teacher = Teacher(
                user_id=new_user.id,
                class_id=body.get("class_id"),
                subject_id=int(selected_skills[0]),  # First selected skill as primary subject
                experience=body.get("experience"),
                number=body.get("phone")
            )
            db.add(new_teacher)

        elif body.get("role_name") == "parent":
            child_user = db.query(User).filter(User.email == body.get("child_email")).first()
            if not child_user:
                raise HTTPException(status_code=404, detail="Child user not found")

            student = db.query(Student).filter(Student.user_id == child_user.id).first()
            if not student:
                raise HTTPException(status_code=404, detail="Student profile not found")

            new_parent = Parent(
                user_id=new_user.id,
                student_id=student.id,
                number=body.get("parentPhone")
            )
            db.add(new_parent)

        db.commit()
        return {"message": "User created successfully", "user": new_user.to_dict()}

    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")




@login_router.get("/teachers/by-subjects")
def get_teachers_by_subjects(subject_ids: str, db: Session = Depends(get_db)):
    """
    Get teachers that teach specific subjects
    subject_ids: comma-separated list of subject IDs
    """
    try:
        subject_id_list = [int(id.strip()) for id in subject_ids.split(',')]
        
        teachers = db.query(Teacher).join(User).join(Subject).filter(
            Teacher.subject_id.in_(subject_id_list)
        ).all()
        
        teachers_data = []
        for teacher in teachers:
            teachers_data.append({
                "id": teacher.id,
                "name": teacher.user.full_name,
                "experience": teacher.experience,
                "class_id": teacher.class_id,
                "subject_id": teacher.subject_id,
                "subject_name": teacher.subject.name,
                "email": teacher.user.email
            })
        
        return {"teachers": teachers_data}
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error fetching teachers: {str(e)}")

@login_router.post("/change-password")
def change_password(
    password_data: ChangePasswordRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    user = db.query(User).filter(User.id == current_user["id"]).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    if not verify_password(password_data.current_password, user.password):
        raise HTTPException(status_code=403, detail="Incorrect current password")

    user.password = pwd_context.hash(password_data.new_password)
    db.commit()

    return {"message": "Password updated successfully"}
