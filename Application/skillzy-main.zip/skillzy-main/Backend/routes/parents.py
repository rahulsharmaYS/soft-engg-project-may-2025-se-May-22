from fastapi.responses import JSONResponse, FileResponse
from models import *
from fastapi import APIRouter, HTTPException, Depends
from sqlalchemy.orm import Session
from datetime import datetime
from sqlalchemy import func
from auth import *
from schema import *
from extensions import get_db
import os, re
from fastapi import Form, File, UploadFile, status
from collections import defaultdict
from typing import Dict, Any, List
from zoneinfo import ZoneInfo

parent_router = APIRouter(
    prefix="/api/v1/parent",
    tags=["Parents"],
    dependencies=[Depends(require_role("parent")), Depends(get_current_user)],
)

# @parent_router.get("/{parent_id}/profile")
# def get_parent_profile(parent_id: int, db: Session = Depends(get_db)):
#     try:
#         if parent_id is None:
#             raise HTTPException(status_code=400, detail="Parent ID is required")

#         parent = db.query(Parent).filter(Parent.user_id == parent_id).first()

#         user = db.query(User).filter(User.id == parent.user_id).first() if parent else None
#         if not parent:
#             raise HTTPException(status_code=404, detail="Parent not found")
#         profile_pic_url = None
#         if user.profile_picture:
#             profile_pic_url = f"/{user.profile_picture.replace(os.sep, '/')}"
#         print("fucking profile pic", profile_pic_url)
#         parent_data = ParentSchema(
#             id=parent.id, # type: ignore
#             user_id=parent.user_id, # type: ignore
#             student_id=parent.student_id, # type: ignore
#             user=UserSchema(
#                 id=parent.user.id,
#                 email=parent.user.email,
#                 full_name=parent.user.full_name,
#                 username=parent.user.username,
#                 role_name=RoleEnum.parent,
#                 profile_picture=profile_pic_url,
#                 created_at=datetime.now(),
#                 user_status=parent.user.user_status
#             )
#         )
        
#         return parent_data
#     except HTTPException:
#         raise
#     except Exception as e:
#         raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")

# @parent_router.put("/{parent_id}/profile")
# def edit_parent_profile(parent_id: int, data: EditProfileRequest ,db: Session = Depends(get_db)):
#     try:
#         if parent_id is None:
#             raise HTTPException(status_code=400, detail="Parent ID is required")

#         parent = db.query(Parent).filter(Parent.user_id == parent_id).first()
#         if not parent:
#             raise HTTPException(status_code=404, detail="Parent not found")
        
#         exists_email = db.query(User).filter(User.email == data.email).first()
        
#         if exists_email and exists_email.id != parent.user_id: # type: ignore
#             raise HTTPException(status_code=400, detail="Email already exists")

#         # check if dir_path exists for parent profiles
#                    # dir_path = f"static/profile_pictures/teacher/{teacher_id}" like this
#         dir_path = f"static/profile_pictures/parent/{parent_id}"
#         if not os.path.exists(dir_path):
#             os.makedirs(dir_path)

        

#         profile_pic_url = None
#         if data.profile_picture:
#             profile_pic_url = f"/{data.profile_picture.replace(os.sep, '/')}"
#         parent.user.full_name = data.full_name
#         parent.user.email = data.email
#         parent.user.profile_picture = profile_pic_url
#         db.commit()
#         db.refresh(parent)
        
#         return JSONResponse(status_code=status.HTTP_202_ACCEPTED, content={"detail": "Profile updated successfully"})
#     except HTTPException:
#         raise
#     except Exception as e:
#         raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")

@parent_router.get("/{parent_id}/profile")
def get_parent_profile(parent_id: int, db: Session = Depends(get_db)):
    try:
        if parent_id is None:
            raise HTTPException(status_code=400, detail="Parent ID is required")

        parent = db.query(Parent).filter(Parent.user_id == parent_id).first()
        if not parent:
            raise HTTPException(status_code=404, detail="Parent not found")

        user = parent.user

        profile_pic_url = None
        if user.profile_picture:
            profile_pic_url = f"/{user.profile_picture.replace(os.sep, '/')}"
        print('parent profile', profile_pic_url)
        parent_data = ParentSchema(
            id=parent.id,
            user_id=parent.user_id,
            student_id=parent.student_id,
            user=UserSchema(
                id=user.id,
                email=user.email,
                full_name=user.full_name,
                username=user.username,
                role_name=RoleEnum.parent,
                profile_picture=profile_pic_url,
                created_at=user.created_at,
                user_status=user.user_status,
            ),
        )

        return parent_data

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")

@parent_router.put("/{parent_id}/profile")
async def edit_parent_profile(
    parent_id: int,
    full_name: str = Form(...),
    email: str = Form(...),
    profile_pic: UploadFile = File(None),
    db: Session = Depends(get_db)
):
    try:
        if parent_id is None:
            raise HTTPException(status_code=400, detail="Parent ID is required")

        parent = db.query(Parent).filter(Parent.user_id == parent_id).first()
        if not parent:
            raise HTTPException(status_code=404, detail="Parent not found")
        
        exists_email = db.query(User).filter(User.email == email).first()
        if exists_email and exists_email.id != parent.user_id:
            raise HTTPException(status_code=400, detail="Email already exists")

        parent.user.full_name = full_name
        parent.user.email = email

        if profile_pic:
            dir_path = f"static/profile_pictures/parent/{parent_id}"
            os.makedirs(dir_path, exist_ok=True)

            ext = os.path.splitext(profile_pic.filename)[1]
            filename = f"profile{ext}"
            file_path = os.path.join(dir_path, filename)

            contents = await profile_pic.read()
            with open(file_path, "wb") as f:
                f.write(contents)

            # Store relative path
            parent.user.profile_picture = file_path.replace("\\", "/")  # For Windows compatibility

        db.commit()
        db.refresh(parent)

        return JSONResponse(status_code=status.HTTP_202_ACCEPTED, content={"detail": "Profile updated successfully"})

    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")

@parent_router.get("/child_stats/{parent_id}")
def get_child_stats(parent_id: int, db: Session = Depends(get_db)):
    try:
        if parent_id is None:
            raise HTTPException(status_code=400, detail="Parent ID and Student ID are required")

        parent = db.query(Parent).filter(Parent.user_id == parent_id).first()
        if not parent:
            raise HTTPException(status_code=404, detail="Parent not found")

        upcoming_assignment_count = db.query(Assignment).filter(Assignment.student_id == parent.student.id, Assignment.assignment_deadline > datetime.now()).count()
        # CHANGED WHAT ARYA GAVE
        today_tasks_count = db.query(Task).filter(func.date(Task.due_date) == datetime.now().date()).count()
        completed_assignment_count = db.query(Submission).filter(parent.student.id == Submission.student_id).count() # type: ignore
        
        student = db.query(Student).filter(Student.id == parent.student_id).first()
        if not student:
            raise HTTPException(status_code=404, detail="Student not found")
    
        # Direct assignments (assigned to specific student)
        direct_assignments = db.query(Assignment).filter(
            Assignment.student_id == student.id
        ).all()
        
        # Many-to-many assignments (if you have this relationship)
        many_to_many_assignments = student.assignments if hasattr(student, "assignments") else []
        
        # Class-wide assignments for student's subjects
        class_subject_assignments = []
        subject_ids = [s.id for s in student.subjects] 
        if student.class_id and subject_ids:
            class_subject_assignments = db.query(Assignment).filter(
                Assignment.class_id == student.class_id,
                Assignment.subject_id.in_(subject_ids),
                Assignment.student_id == None  # Class-wide, not individual
            ).all()
        
        # Combine all assignments
        all_assignments = {
            a.id: a for a in (
                direct_assignments + many_to_many_assignments + class_subject_assignments
            )
        }.values()
        
        # Enrich assignments with score data
        assignments_with_scores = []
        for assignment in all_assignments:
            assignment_dict = assignment.to_dict()
            
            # Get student's score for this assignment
            score = db.query(Score).filter(
                Score.student_id == student.id,
                Score.assignment_id == assignment.id
            ).first()
            
            # Add score information
            if score:
                assignment_dict['score_info'] = {
                    'score': score.score,
                    'max_score': score.max_score,
                    'percentage': score.percentage,
                    'status': score.status.value,
                    'attempt_number': score.attempt_number,
                    'submitted_at': score.submitted_at.isoformat() if score.submitted_at else None,
                    'graded_at': score.graded_at.isoformat() if score.graded_at else None,
                    'feedback': score.feedback
                }
                assignment_dict['is_completed'] = score.status != ScoreStatus.pending
            else:
                assignment_dict['score_info'] = None
                # For text/subjective assignments, completion means all questions answered
                # For objective assignments, completion means scored/graded
                if assignment.question_type and assignment.question_type.value == "text":
                    total_questions = db.query(Question).filter(Question.assignment_id == assignment.id).count()
                    answered_questions = db.query(Submission).filter(
                        Submission.student_id == student.id,
                        Submission.assignment_id == assignment.id
                    ).count()
                    assignment_dict['is_completed'] = answered_questions >= total_questions
                else:
                    assignment_dict['is_completed'] = False
            
            # Add submission progress
            total_questions = db.query(Question).filter(Question.assignment_id == assignment.id).count()
            answered_questions = db.query(Submission).filter(
                Submission.student_id == student.id,
                Submission.assignment_id == assignment.id
            ).count()
            
            assignment_dict['progress'] = {
                'total_questions': total_questions,
                'answered_questions': answered_questions,
                'completion_percentage': (answered_questions / total_questions * 100) if total_questions > 0 else 0
            }
            
            assignments_with_scores.append(assignment_dict)

        stats = {
            "upcoming_assignment_count": upcoming_assignment_count,
            "today_tasks_count": today_tasks_count,
            "completed_assignment_count": completed_assignment_count,
            "assignments": assignments_with_scores
        }
        return stats
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")

@parent_router.get("/{parent_id}/child/profile", response_model=StudentSchema)
def get_parent_children(parent_id: int, db: Session = Depends(get_db)):
    try:
        parent = db.query(Parent).filter(Parent.user_id == parent_id).first()
        if not parent:
            raise HTTPException(status_code=404, detail="Parent not found")
        parent_children = db.query(Student).filter(Student.id == parent.student_id).first()
        if not parent_children:
            raise HTTPException(status_code=404, detail="No children found for the given parent ID")
        
        student_data = StudentSchema(
            id=parent_children.id, # type: ignore
            user_id=parent_children.user_id, # type: ignore
            user=UserSchema(
                id=parent_children.user_id, # type: ignore
                email=parent_children.user.email,
                full_name=parent_children.user.full_name,
                username=parent_children.user.username,
                role_name=RoleEnum.student,
                profile_picture=parent_children.user.profile_picture,
                created_at=datetime.now(),
                user_status=parent_children.user.user_status
            )
        )

        return student_data
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")

@parent_router.get("/tasks/{parent_id}")
async def get_tasks_for_student(parent_id: int, db: Session = Depends(get_db)):
    try:
        parent = db.query(Parent).filter(Parent.user_id == parent_id).first()
        if not parent:
            raise HTTPException(status_code=404, detail="Parent not found")
        tasks = db.query(Task).filter(Task.student_id == parent.student_id).all()
        if not tasks:
            raise HTTPException(status_code=404, detail="No tasks found for the given student")
        tasks_response = [task.to_dict(False) for task in tasks]
        return tasks_response
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")

@parent_router.get("/assignments/{parent_id}")
async def get_assignments_for_student(parent_id: int, db: Session = Depends(get_db)):
    try:
        parent = db.query(Parent).filter(Parent.user_id == parent_id).first()
        if not parent:
            raise HTTPException(status_code=404, detail="Parent not found")
        
        student = db.query(Student).filter(Student.id == parent.student_id).first()
        if not student:
            raise HTTPException(status_code=404, detail="No children found for the given parent ID")
        
        student_class_id = student.class_id

        if not student_class_id:
            raise HTTPException(status_code=400, detail="Student is not assigned to a class")

        # Step 2: JOIN Assignment -> Teacher -> Class (using explicit JOINs)
        assignments = (
            db.query(Assignment)
            .join(Teacher, Assignment.teacher_id == Teacher.id)
            .join(Class, Teacher.class_id == Class.id)
            .filter(Class.id == student_class_id)
            .all()
        )

        if not assignments:
            raise HTTPException(status_code=404, detail="No assignments found for the given student")
        assignments_response = [assignment.to_dict(False) for assignment in assignments]
        return assignments_response
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")

@parent_router.get("/achievements/{parent_id}")
async def get_achievements_for_student(parent_id: int, db: Session = Depends(get_db)):
    try:
        parent = db.query(Parent).filter(Parent.user_id == parent_id).first()
        if not parent:
            raise HTTPException(status_code=404, detail="Parent not found")
        
        badges = (db.query(Badge).join(Reward, Badge.id == Reward.badge_id)
            .filter(Reward.student_id == parent.student_id)
            .all())
        if not badges:
            raise HTTPException(status_code=404, detail="No achievements found for the given student")
        
        badges_response = [badge.to_dict(False) for badge in badges]
        return badges_response
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")

@parent_router.get("/notifications/{parent_id}")
async def get_notifications_for_parent(parent_id: int, db: Session = Depends(get_db)):
    try:
        parent = db.query(Parent).filter(Parent.user_id == parent_id).first()
        if not parent:
            raise HTTPException(status_code=404, detail="Parent not found")
        
        notifications = db.query(Notification).filter(Notification.user_id == parent.user_id).all()
        if not notifications:
            raise HTTPException(status_code=404, detail="No notifications found for the given user")
        
        notifications_response = [notification.to_dict() for notification in notifications]
        return notifications_response
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")
    
@parent_router.get("/announcements/{parent_id}")
async def get_announcements_for_parent(parent_id: int, db: Session = Depends(get_db)):
    try:
        parent = db.query(Parent).filter(Parent.user_id == parent_id).first()
        if not parent:
            raise HTTPException(status_code=404, detail="Parent not found")

        announcements = db.query(Announcement).all()
        if not announcements:
            raise HTTPException(status_code=404, detail="No announcements found for the given user")

        announcements_response = [announcement.to_dict() for announcement in announcements]
        return announcements_response
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")
    
@parent_router.get("/reports/download/{filename}")
def download_report(filename: str):
    path = f"static/reports/{filename}"
    if not os.path.exists(path):
        raise HTTPException(status_code=404, detail="Report not found")
    return FileResponse(
        path,
        media_type="application/pdf",
        filename=filename
    )

class ReportCreate(BaseModel):
    title: str
    content: str
    screenshot: Optional[str] = None

@parent_router.post("/{parent_id}/reports")
def create_report(parent_id: int, report_data: ReportCreate, db: Session = Depends(get_db)):
    parent = db.query(Parent).filter(Parent.user_id == parent_id).first()
    if not parent:
        raise HTTPException(status_code=404, detail="Parent not found")

    new_report = Report(
        title=report_data.title,
        content=report_data.content,
        screenshot=report_data.screenshot,
        created_at=datetime.utcnow(),
        user_id=parent_id
    )

    db.add(new_report)
    db.commit()
    db.refresh(new_report)

    return {
        "message": "Report issued successfully",
        "report": {
            "id": new_report.id,
            "title": new_report.title,
            "content": new_report.content,
            "screenshot": new_report.screenshot,
            "created_at": new_report.created_at
        }
    }

# Reuse the parser that extracts both window and time spent
def parse_focus_summary_txt(file_path: str):
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()

        def extract(pattern, cast: type = str, default=None):
            match = re.search(pattern, content)
            if not match:
                return default
            try:
                return cast(match.group(1).strip())
            except:
                return default

        # Core timings
        start_time_str = extract(r"Start:\s*(.+)", str, None)
        end_time_str = extract(r"End:\s*(.+)", str, None)
        total_duration_sec = extract(r"Total Time:\s*([\d.]+)\s*sec", float, 0.0)

        start_time = datetime.strptime(start_time_str, "%Y-%m-%d %H:%M:%S") if start_time_str else None
        end_time = datetime.strptime(end_time_str, "%Y-%m-%d %H:%M:%S") if end_time_str else None
        duration = round(total_duration_sec / 60, 2)

        # Windows visited with durations
        window_section = re.search(r"==== TIME SPENT ON EACH WINDOW ====\n(.*?)(\n\n|$)", content, re.DOTALL)
        window_lines = window_section.group(1).strip().splitlines() if window_section else []

        windows_list = []
        for line in window_lines:
            match = re.match(r"- (.+?):\s*([\d.]+)\s*sec", line)
            if match:
                window_name = match.group(1).strip()
                time_spent_sec = float(match.group(2))
                windows_list.append({"window": window_name, "time_sec": time_spent_sec})

        return {
            "start_time": start_time,
            "end_time": end_time,
            "duration": duration,
            "windows_data": windows_list if windows_list else []
        }

    except Exception as e:
        print(f"[ERROR] Failed to parse {file_path}: {str(e)}")
        return None


@parent_router.get("/{parent_id}/websites-usage")
def get_website_usage_for_all_students(parent_id: int, db: Session = Depends(get_db)):
    """
    Returns weekly (last 7 days) aggregated website/app usage for each parent's student.
    Aggregates time per unique window name across multiple focus log files.
    """
    parent = db.query(Parent).filter(Parent.user_id == parent_id).first()
    if not parent:
        raise HTTPException(status_code=404, detail="No parents found")

    asia_kolkata = ZoneInfo("Asia/Kolkata")
    folder_path = "static/focus_logs"
    os.makedirs(folder_path, exist_ok=True)

    results = []  # one entry per student

    
    student = db.query(Student).filter(Student.id == parent.student_id).first()
    if not student:
        raise HTTPException(status_code=404, detail="No student found")

    student_id = student.user_id
    aggregated_time: Dict[str, float] = defaultdict(float)

    # Loop through files for this student
    for filename in os.listdir(folder_path):
        if not filename.startswith(f"focus_session_{student_id}_") or not filename.endswith(".txt"):
            continue

        # Extract session timestamp from filename
        match = re.match(rf"focus_session_{student_id}_(\d+)\.txt", filename)
        if not match:
            continue

        session_time_str = match.group(1)
        session_time = datetime.strptime(session_time_str, "%Y%m%d%H%M%S").replace(tzinfo=asia_kolkata)

        # Skip files older than 7 days
        if datetime.now(asia_kolkata) - session_time > timedelta(days=7):
            continue

        file_path = os.path.join(folder_path, filename)
        session = parse_focus_summary_txt(file_path)
        if not session or not session.get("windows_data"):
            continue

        # Aggregate durations across files
        for w in session["windows_data"]:
            aggregated_time[w["window"]] += w["time_sec"]

        # Prepare sorted list for output
        sorted_usage = [
            {"name": window, "total_time_sec": round(total_sec, 2)}
            for window, total_sec in sorted(aggregated_time.items(), key=lambda x: x[1], reverse=True)
        ]

        results.append({
            "parent_id": parent.id,
            "student_id": student_id,
            "student_name": getattr(student, "name", None),
            "weekly_usage": sorted_usage
        })

    return {"data": results}

@parent_router.get("/{parent_id}/screen-time")
def get_weekly_screen_time(parent_id: int, db: Session = Depends(get_db)):
    """Return last 7 days total screen time per day for the parent's student."""
    parent = db.query(Parent).filter(Parent.user_id == parent_id).first()
    if not parent:
        raise HTTPException(status_code=404, detail="Parent not found")

    student = db.query(Student).filter(Student.id == parent.student_id).first()
    if not student:
        raise HTTPException(status_code=404, detail="Student not found")

    student_id = student.user_id
    folder_path = "static/focus_logs"
    asia_kolkata = ZoneInfo("Asia/Kolkata")

    # daily aggregation in seconds
    daily_usage = defaultdict(float)

    for filename in os.listdir(folder_path):
        if not filename.startswith(f"focus_session_{student_id}_") or not filename.endswith(".txt"):
            continue

        # Extract timestamp from filename
        match = re.match(rf"focus_session_{student_id}_(\d+)\.txt", filename)
        if not match:
            continue

        session_time_str = match.group(1)
        session_time = datetime.strptime(session_time_str, "%Y%m%d%H%M%S").replace(tzinfo=asia_kolkata)

        # Only include last 7 days
        if datetime.now(asia_kolkata) - session_time > timedelta(days=7):
            continue

        file_path = os.path.join(folder_path, filename)
        session_data = parse_focus_summary_txt(file_path)
        if not session_data:
            continue

        # Sum total seconds for this session
        total_sec = sum(w["time_sec"] for w in session_data["windows_data"])
        day_str = session_time.strftime("%A")   # Monday, Tuesday, etc.
        date_str = session_time.strftime("%Y-%m-%d")

        # Use date as key for safety
        daily_usage[date_str] += total_sec

    # Recommended: 2h/day (in seconds)
    recommended_sec = 2 * 3600

    # Sort by date
    weekly_data = [
        {
            "day": datetime.strptime(date, "%Y-%m-%d").strftime("%A"),
            "date": date,
            "actual_sec": round(sec, 2),
            "recommended_sec": recommended_sec
        }
        for date, sec in sorted(daily_usage.items(), key=lambda x: x[0])
    ]

    return {"data": [{
        "parent_id": parent.id,
        "student_id": student.id,
        "student_name": getattr(student, "name", None),
        "weekly_screen_time": weekly_data
    }]}