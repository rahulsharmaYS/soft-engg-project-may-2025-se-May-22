from fastapi import APIRouter, Depends, HTTPException, Body,Request
from fastapi.responses import JSONResponse,FileResponse
from sqlalchemy.orm import Session
from typing import List,Optional
from datetime import datetime,date, timedelta
# from Backend import tasks
from models import User,Student,Teacher,Parent,Resource, Task, Assignment, Reward, Subject, Question,TaskStatusEnum, Notification,Submission,Score,ScoreStatus,calculate_score, Reward, Badge, AssignmentStatus,Report,student_subject, Announcement
from extensions import get_db
from auth import get_current_user, require_role
from pydantic import BaseModel, EmailStr
import pytz
from activity_monitor import start_focus_session
from zoneinfo import ZoneInfo
from sqlalchemy import or_, and_
from tasks import send_parent_score_notification

ist = pytz.timezone("Asia/Kolkata")
now = datetime.now(ist)

student_router = APIRouter(
    prefix="/api/v1/student",
    tags=["Student"]
)

@student_router.get("/{user_id}/dashboard")
def student_dashboard(user_id: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    student = db.query(Student).filter(Student.user_id == user_id).first()
    
    if not student:
        raise HTTPException(status_code=404, detail="Student not found")
    
    today = date.today()
    direct_assignments = student.direct_assignments or []
    class_assignments = []
    if student.classroom:
        class_assignments = student.classroom.assignments or []

    assignments = direct_assignments + class_assignments
    tasks = student.tasks or []
    submitted_assignment_ids = {
        sub.assignment_id for sub in db.query(Submission)
        .filter(Submission.student_id == student.id)
        .filter(Submission.submitted_at != None)
        .distinct(Submission.assignment_id)
        .all()
    }
    completed_assignments = [a for a in assignments if a.id in submitted_assignment_ids]
    upcoming_assignments = [
        a for a in assignments 
        if a.assignment_deadline and a.assignment_deadline.date() > today and a.id not in submitted_assignment_ids
    ]
    total_tasks = len(tasks)
    return {
        "full_name": student.user.full_name,
        "assignments": [a.title for a in assignments],
        "tasks": [t.title for t in tasks],
        "badges": [r.badge.badge_type for r in student.rewards],
        "subjects": [s.name for s in student.subjects],
        "stats": {
            "totalTasks": total_tasks,  # Changed from todaysTasksAndAssignments
            "upcomingAssignments": len(upcoming_assignments),
            "completedAssignments": len(completed_assignments),
        }
    }

@student_router.get("/{user_id}/calendar")
def get_calendar_tasks(user_id: int, db: Session = Depends(get_db)):
    student = db.query(Student).filter(Student.user_id == user_id).first()
    if not student:
        raise HTTPException(status_code=404, detail="Student not found")

    ist = pytz.timezone("Asia/Kolkata")
    now = datetime.now(ist)
    tasks = db.query(Task).filter(Task.student_id == student.id).all()

    updated = False
    for task in tasks:
        if (
            task.status == TaskStatusEnum.pending
            and task.due_date is not None
            and task.due_date.astimezone(ist) < now
        ):
            task.status = TaskStatusEnum.overdue
            updated = True
            add_notification(student.user.id, f"⚠️ Task '{task.title}' is overdue!", db)

    if updated:
        db.commit()

    task_list = []
    for task in tasks:
        data = task.to_dict()
        data["status"] = task.status.value
        task_list.append(data)
    return task_list


def add_notification(user_id: int, message: str, db):
    notification = Notification(
        user_id=user_id,
        message=message,
        timestamp=datetime.now()
    )
    db.add(notification)
    db.commit()

@student_router.post("/{user_id}/calendar")
def create_calendar_task(user_id: int, task_data: dict = Body(...), db: Session = Depends(get_db)):
    student = db.query(Student).filter(Student.user_id == user_id).first()
    if not student:
        raise HTTPException(status_code=404, detail="Student not found")

    due_date_str = task_data.get("due_date")
    due_date = datetime.fromisoformat(due_date_str) if due_date_str else None

    ist = pytz.timezone("Asia/Kolkata")
    due_date = ist.localize(datetime.fromisoformat(due_date_str)) if due_date_str else None

    task = Task(
        title=task_data["title"],
        description=task_data.get("description", ""),
        due_date=due_date,
        student_id=student.id,
        status=task_data.get("status", "pending"),
        created_at=datetime.now()
    )
    db.add(task)
    db.commit()
    add_notification(student.user_id, f"📝 New Task '{task.title}' assigned", db)

    db.refresh(task)
    return task.to_dict()


@student_router.put("/{user_id}/calendar/{task_id}")
def update_calendar_task(user_id: int, task_id: int, data: dict, db: Session = Depends(get_db)):
    student = db.query(Student).filter(Student.user_id == user_id).first()
    if not student:
        raise HTTPException(status_code=404, detail="Student not found")

    task = db.query(Task).filter(Task.id == task_id, Task.student_id == student.id).first()
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")

    task.title = data.get("title", task.title)
    task.description = data.get("description", task.description)
    task.status = data.get("status", task.status)
    if "due_date" in data and data["due_date"]:
        task.due_date = datetime.fromisoformat(data["due_date"])
    db.commit()
    return task


@student_router.delete("/{user_id}/calendar/{task_id}")
def delete_calendar_task(user_id: int, task_id: int, db: Session = Depends(get_db)):
    student = db.query(Student).filter(Student.user_id == user_id).first()
    if not student:
        raise HTTPException(status_code=404, detail="Student not found")

    task = db.query(Task).filter(Task.id == task_id, Task.student_id == student.id).first()
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")

    db.delete(task)
    db.commit()
    return {"message": "Task deleted"}


@student_router.put("/{user_id}/calendar/{task_id}/complete")
def mark_calendar_task_complete(user_id: int, task_id: int, db: Session = Depends(get_db)):
    student = db.query(Student).filter(Student.user_id == user_id).first()
    if not student:
        raise HTTPException(status_code=404, detail="Student not found")

    task = db.query(Task).filter(Task.id == task_id, Task.student_id == student.id).first()
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")

    task.status = "complete"
    db.commit()
    return task


@student_router.get("/{user_id}/assignments")
def get_assignments(user_id: int, db: Session = Depends(get_db)):
    student = db.query(Student).filter(Student.user_id == user_id).first()
    if not student:
        raise HTTPException(status_code=404, detail="Student not found")
    
    # Direct assignments (assigned to specific student)
    direct_assignments = db.query(Assignment).filter(
        Assignment.student_id == student.id
    ).all()
    
    # Many-to-many assignments (if you have this relationship)
    many_to_many_assignments = student.assignments if hasattr(student, "assignments") else []
    
    # Class-wide assignments for student's subjects
    class_subject_assignments = []
    subject_ids = [s.id for s in student.subjects] 
    if student.class_id and subject_ids:
        class_subject_assignments = db.query(Assignment).filter(
            Assignment.class_id == student.class_id,
            Assignment.subject_id.in_(subject_ids),
            Assignment.student_id == None  # Class-wide, not individual
        ).all()
    
    # Combine all assignments
    all_assignments = {
        a.id: a for a in (
            direct_assignments + many_to_many_assignments + class_subject_assignments
        )
    }.values()
    
    # Enrich assignments with score data
    assignments_with_scores = []
    for assignment in all_assignments:
        assignment_dict = assignment.to_dict()
        
        # Get student's score for this assignment
        score = db.query(Score).filter(
            Score.student_id == student.id,
            Score.assignment_id == assignment.id
        ).first()
        
        # Add score information
        if score:
            assignment_dict['score_info'] = {
                'score': score.score,
                'max_score': score.max_score,
                'percentage': score.percentage,
                'status': score.status.value,
                'attempt_number': score.attempt_number,
                'submitted_at': score.submitted_at.isoformat() if score.submitted_at else None,
                'graded_at': score.graded_at.isoformat() if score.graded_at else None,
                'feedback': score.feedback
            }
            assignment_dict['is_completed'] = score.status != ScoreStatus.pending
        else:
            assignment_dict['score_info'] = None
            # For text/subjective assignments, completion means all questions answered
            # For objective assignments, completion means scored/graded
            if assignment.question_type and assignment.question_type.value == "text":
                total_questions = db.query(Question).filter(Question.assignment_id == assignment.id).count()
                answered_questions = db.query(Submission).filter(
                    Submission.student_id == student.id,
                    Submission.assignment_id == assignment.id
                ).count()
                assignment_dict['is_completed'] = answered_questions >= total_questions
            else:
                assignment_dict['is_completed'] = False
        
        # Add submission progress
        total_questions = db.query(Question).filter(Question.assignment_id == assignment.id).count()
        answered_questions = db.query(Submission).filter(
            Submission.student_id == student.id,
            Submission.assignment_id == assignment.id
        ).count()
        
        assignment_dict['progress'] = {
            'total_questions': total_questions,
            'answered_questions': answered_questions,
            'completion_percentage': (answered_questions / total_questions * 100) if total_questions > 0 else 0
        }
        
        assignments_with_scores.append(assignment_dict)

    print(f"📍 Student ID: {student.id}, Class ID: {student.class_id}")
    print(f"📍 Student Subject IDs: {[s.id for s in student.subjects]}")
    print(f"📍 Direct Assignments: {len(direct_assignments)}")
    print(f"📍 Many-to-Many Assignments: {len(many_to_many_assignments)}")
    print(f"📍 Class+Subject Assignments: {len(class_subject_assignments)}")

    add_notification(student.user_id, f"📤 {len(all_assignments)} assignments assigned", db)

    return assignments_with_scores

@student_router.post("/{user_id}/assignments/{assignment_id}/submit")
def submit_assignment(user_id: int, assignment_id: int, answers: List[dict], db: Session = Depends(get_db)):
    print(f"[DEBUG] Received submit_assignment request - user_id: {user_id}, assignment_id: {assignment_id}")
    print(f"[DEBUG] Answers payload: {answers}")

    student = db.query(Student).filter(Student.user_id == user_id).first()
    print(f"[DEBUG] Student fetched: {student}")
    if not student:
        print("[ERROR] Student not found")
        raise HTTPException(status_code=404, detail="Student not found")

    assignment = db.query(Assignment).filter(Assignment.id == assignment_id).first()
    print(f"[DEBUG] Assignment fetched: {assignment}")
    if not assignment:
        print("[ERROR] Assignment not found")
        raise HTTPException(status_code=404, detail="Assignment not found")

    # Verify student has access to this assignment
    is_direct = assignment.student_id == student.id
    subject_ids = [s.id for s in student.subjects]
    is_class_subject = (
        assignment.class_id == student.class_id and
        assignment.subject_id in subject_ids and
        assignment.student_id is None
    )
    print(f"[DEBUG] Access check - is_direct: {is_direct}, is_class_subject: {is_class_subject}")

    if not (is_direct or is_class_subject):
        print("[ERROR] Student does not have access to this assignment")
        raise HTTPException(status_code=403, detail="You are not assigned this assignment")

    # Process all answers
    for idx, answer_data in enumerate(answers):
        question_id = answer_data.get("question_id")
        answer = answer_data.get("answer", "")
        print(f"[DEBUG] Processing answer {idx}: question_id={question_id}, answer={answer}")

        if not question_id:
            print(f"[WARN] Skipping answer {idx} - question_id missing")
            continue

        question = db.query(Question).filter(Question.id == question_id).first()
        if not question or question.assignment_id != assignment_id:
            print(f"[WARN] Skipping answer {idx} - question not found or assignment mismatch")
            continue

        existing_submission = db.query(Submission).filter(
            Submission.student_id == student.id,
            Submission.assignment_id == assignment_id,
            Submission.question_id == question_id
        ).first()
        print(f"[DEBUG] Existing submission: {existing_submission}")

        is_correct = None
        if assignment.question_type and assignment.question_type.value != "text":
            is_correct = (answer == question.correct_answer) if question.correct_answer else None
            print(f"[DEBUG] Auto-evaluation - is_correct: {is_correct}")

        if existing_submission:
            existing_submission.answer = answer
            existing_submission.submitted_at = datetime.utcnow()
            existing_submission.is_correct = is_correct
            existing_submission.status = "evaluated" if is_correct is not None else "pending"
            print(f"[DEBUG] Updated existing submission {existing_submission.id}")
        else:
            submission = Submission(
                student_id=student.id,
                assignment_id=assignment_id,
                question_id=question_id,
                answer=answer,
                is_correct=is_correct,
                submitted_at=datetime.utcnow(),
                status="evaluated" if is_correct is not None else "pending"
            )
            db.add(submission)
            print("[DEBUG] Added new submission")

    try:
        db.commit()
        print("[DEBUG] Database commit successful")
    except Exception as e:
        print(f"[ERROR] Database commit failed: {e}")
        raise HTTPException(status_code=500, detail="Database commit failed")

    final_score = None
    score_info = None

    if assignment.question_type and assignment.question_type.value != "text":
        final_score = calculate_score(db, student.id, assignment_id)
        print(f"[DEBUG] Final score calculated: {final_score}")

        if final_score:
            score_info = {
                'score': final_score.score,
                'max_score': final_score.max_score,
                'percentage': final_score.percentage,
                'status': final_score.status.value
            }

    if assignment.question_type and assignment.question_type.value == "text":
        add_notification(
            student.user_id, 
            f"📤 Assignment '{assignment.title}' submitted successfully! Awaiting teacher evaluation.", 
            db
        )
        message = "Assignment submitted successfully and awaiting teacher evaluation"
    else:
        score_msg = f" Score: {final_score.percentage:.1f}%" if final_score else ""
        add_notification(
            student.user_id, 
            f"📤 Assignment '{assignment.title}' submitted successfully!{score_msg}", 
            db
        )
        message = "Assignment submitted successfully"
        send_parent_score_notification.delay(assignment.id)
        print("[DEBUG] Parent score notification task sent")

    return {
        "message": message,
        "score_info": score_info,
        "submitted_answers": len(answers),
        "requires_manual_grading": assignment.question_type and assignment.question_type.value == "text"
    }




@student_router.post("/{user_id}/assignments/{assignment_id}/questions/{question_id}/answer")
def submit_single_answer(
    user_id: int, 
    assignment_id: int, 
    question_id: int, 
    answer_data: dict, 
    db: Session = Depends(get_db)
):
    """Submit answer for a single question"""
    student = db.query(Student).filter(Student.user_id == user_id).first()
    if not student:
        raise HTTPException(status_code=404, detail="Student not found")

    assignment = db.query(Assignment).filter(Assignment.id == assignment_id).first()
    if not assignment:
        raise HTTPException(status_code=404, detail="Assignment not found")

    # Verify access
    is_direct = assignment.student_id == student.id
    subject_ids = [s.id for s in student.subjects]
    is_class_subject = (
        assignment.class_id == student.class_id and
        assignment.subject_id in subject_ids and
        assignment.student_id is None
    )

    if not (is_direct or is_class_subject):
        raise HTTPException(status_code=403, detail="You are not assigned this assignment")

    question = db.query(Question).filter(
        Question.id == question_id,
        Question.assignment_id == assignment_id
    ).first()
    
    if not question:
        raise HTTPException(status_code=404, detail="Question not found")

    answer = answer_data.get("answer", "")
    
    # Only auto-evaluate for objective questions
    is_correct = None
    if assignment.question_type and assignment.question_type.value != "text":
        is_correct = (answer == question.correct_answer) if question.correct_answer else None
    
    # Check if submission already exists
    existing_submission = db.query(Submission).filter(
        Submission.student_id == student.id,
        Submission.assignment_id == assignment_id,
        Submission.question_id == question_id
    ).first()
    
    if existing_submission:
        existing_submission.answer = answer
        existing_submission.submitted_at = datetime.utcnow()
        existing_submission.is_correct = is_correct
        db.commit()
        submission = existing_submission
    else:
        submission = Submission(
            student_id=student.id,
            assignment_id=assignment_id,
            question_id=question_id,
            answer=answer,
            is_correct=is_correct,
            submitted_at=datetime.utcnow()
        )
        db.add(submission)
        db.commit()
    
    # Check if all questions are answered
    total_questions = db.query(Question).filter(Question.assignment_id == assignment_id).count()
    answered_questions = db.query(Submission).filter(
        Submission.student_id == student.id,
        Submission.assignment_id == assignment_id
    ).count()
    
    score_info = None
    assignment_completed = answered_questions >= total_questions
    
    # Only calculate score for objective assignments when all questions are answered
    if assignment_completed and assignment.question_type and assignment.question_type.value != "text":
        final_score = calculate_score(db, student.id, assignment_id)
        if final_score:
            score_info = {
                'score': final_score.score,
                'max_score': final_score.max_score,
                'percentage': final_score.percentage,
                'status': final_score.status.value,
                'assignment_completed': True
            }
    
    print(f"📍 Student {user_id} answered question {question_id}: {answer}")
    
    return {
        "message": "Answer submitted successfully",
        "submission_id": submission.id,
        "question_id": question_id,
        "answer": answer,
        "is_correct": submission.is_correct,
        "timestamp": submission.submitted_at.isoformat(),
        "progress": f"{answered_questions}/{total_questions}",
        "assignment_completed": assignment_completed,
        "requires_manual_grading": assignment.question_type and assignment.question_type.value == "text",
        "score_info": score_info
    }

@student_router.get("/{user_id}/assignments/{assignment_id}/progress")
def get_assignment_progress(user_id: int, assignment_id: int, db: Session = Depends(get_db)):
    """Get student's progress on an assignment with score info"""
    student = db.query(Student).filter(Student.user_id == user_id).first()
    if not student:
        raise HTTPException(status_code=404, detail="Student not found")

    assignment = db.query(Assignment).filter(Assignment.id == assignment_id).first()
    if not assignment:
        raise HTTPException(status_code=404, detail="Assignment not found")

    # Get all questions for this assignment
    questions = db.query(Question).filter(Question.assignment_id == assignment_id).all()
    total_questions = len(questions)

    # Get student's submissions for this assignment
    submissions = db.query(Submission).filter(
        Submission.student_id == student.id,
        Submission.assignment_id == assignment_id
    ).all()

    answered_questions = len(submissions)
    
    # Only count correct answers for objective assignments
    correct_answers = 0
    if assignment.question_type and assignment.question_type.value != "text":
        correct_answers = len([s for s in submissions if s.is_correct is True])

    # Get score info
    score = db.query(Score).filter(
        Score.student_id == student.id,
        Score.assignment_id == assignment_id
    ).first()

    # Create a map of question_id to submission
    submission_map = {s.question_id: s for s in submissions}

    questions_with_answers = []
    for i, q in enumerate(questions):
        submission = submission_map.get(q.id)
        question_data = {
            "question_number": i + 1,
            "question_id": q.id,
            "question": q.question,
            "points": q.points if hasattr(q, 'points') else 1,
            "answered": submission is not None,
            "answer": submission.answer if submission else None,
            "submitted_at": submission.submitted_at.isoformat() if submission and submission.submitted_at else None
        }
        
        # Only include correctness info for objective assignments
        if assignment.question_type and assignment.question_type.value != "text":
            question_data["is_correct"] = submission.is_correct if submission else None
        else:
            question_data["requires_manual_grading"] = True
            
        questions_with_answers.append(question_data)

    result = {
        "assignment_id": assignment_id,
        "assignment_title": assignment.title,
        "assignment_type": assignment.question_type.value if assignment.question_type else "multiple_choice",
        "assignment_max_score": assignment.max_score if hasattr(assignment, 'max_score') else 100,
        "total_questions": total_questions,
        "answered_questions": answered_questions,
        "completion_percentage": (answered_questions / total_questions * 100) if total_questions > 0 else 0,
        "questions": questions_with_answers,
        "requires_manual_grading": assignment.question_type and assignment.question_type.value == "text"
    }
    
    # Only include correct answers count for objective assignments
    if assignment.question_type and assignment.question_type.value != "text":
        result["correct_answers"] = correct_answers

    # Add score information if available
    if score:
        result["score_info"] = {
            "score": score.score,
            "max_score": score.max_score,
            "percentage": score.percentage,
            "status": score.status.value,
            "attempt_number": score.attempt_number,
            "submitted_at": score.submitted_at.isoformat() if score.submitted_at else None,
            "graded_at": score.graded_at.isoformat() if score.graded_at else None,
            "feedback": score.feedback,
            "grader_id": score.graded_by
        }
        result["is_completed"] = True
        result["final_score_percentage"] = score.percentage
    else:
        result["score_info"] = None
        # For text assignments, completion means all questions answered
        # For objective assignments, completion means scored
        if assignment.question_type and assignment.question_type.value == "text":
            result["is_completed"] = answered_questions >= total_questions
            result["final_score_percentage"] = None  # No auto-scoring for text
        else:
            result["is_completed"] = False
            result["final_score_percentage"] = (correct_answers / total_questions * 100) if total_questions > 0 else 0

    return result

@student_router.get("/{user_id}/scores")
def get_student_scores(user_id: int, db: Session = Depends(get_db)):
    """Get all scores for a student"""
    student = db.query(Student).filter(Student.user_id == user_id).first()
    if not student:
        raise HTTPException(status_code=404, detail="Student not found")
    
    # Get all scores for this student with assignment details
    scores = db.query(Score, Assignment).join(
        Assignment, Score.assignment_id == Assignment.id
    ).filter(Score.student_id == student.id).all()
    
    scores_data = []
    for score, assignment in scores:
        score_dict = {
            "score_id": score.id,
            "assignment_id": assignment.id,
            "assignment_title": assignment.title,
            "assignment_type": assignment.question_type.value if assignment.question_type else "multiple_choice",
            "subject_id": assignment.subject_id,
            "score": score.score,
            "max_score": score.max_score,
            "percentage": score.percentage,
            "status": score.status.value,
            "attempt_number": score.attempt_number,
            "submitted_at": score.submitted_at.isoformat() if score.submitted_at else None,
            "graded_at": score.graded_at.isoformat() if score.graded_at else None,
            "feedback": score.feedback,
            "assignment_deadline": assignment.assignment_deadline.isoformat() if assignment.assignment_deadline else None,
            "requires_manual_grading": assignment.question_type and assignment.question_type.value == "text"
        }
        scores_data.append(score_dict)
    
    # Calculate overall statistics
    if scores_data:
        total_scores = len(scores_data)
        average_percentage = sum(s["percentage"] or 0 for s in scores_data) / total_scores
        graded_scores = [s for s in scores_data if s["status"] == "graded"]
        pending_scores = [s for s in scores_data if s["status"] == "pending"]
        awaiting_grading = [s for s in scores_data if s["requires_manual_grading"] and s["status"] == "pending"]
    else:
        total_scores = 0
        average_percentage = 0
        graded_scores = []
        pending_scores = []
        awaiting_grading = []
    
    return {
        "student_id": student.id,
        "user_id": user_id,
        "scores": scores_data,
        "statistics": {
            "total_assignments": total_scores,
            "graded_assignments": len(graded_scores),
            "pending_assignments": len(pending_scores),
            "awaiting_teacher_grading": len(awaiting_grading),
            "average_percentage": round(average_percentage, 2) if average_percentage else 0,
            "highest_score": max((s["percentage"] or 0 for s in scores_data), default=0),
            "lowest_score": min((s["percentage"] or 0 for s in scores_data if s["percentage"] is not None), default=0)
        }
    }

@student_router.get("/{user_id}/assignments/{assignment_id}/attempt")
def start_assignment_attempt(user_id: int, assignment_id: int, db: Session = Depends(get_db)):
    """Start an assignment attempt - gets assignment info and first question"""
    student = db.query(Student).filter(Student.user_id == user_id).first()
    if not student:
        raise HTTPException(status_code=404, detail="Student not found")

    assignment = db.query(Assignment).filter(Assignment.id == assignment_id).first()
    if not assignment:
        raise HTTPException(status_code=404, detail="Assignment not found")

    # Verify access
    is_direct = assignment.student_id == student.id
    subject_ids = [s.id for s in student.subjects]
    is_class_subject = (
        assignment.class_id == student.class_id and
        assignment.subject_id in subject_ids and
        assignment.student_id is None
    )

    if not (is_direct or is_class_subject):
        raise HTTPException(status_code=403, detail="You are not assigned this assignment")

    # Get all questions for this assignment
    questions = db.query(Question).filter(Question.assignment_id == assignment_id).all()
    print(f"📍 Starting attempt for Assignment ID: {assignment_id}, Student ID: {student.id}, Questions: {len(questions)}")
    print('here')
    print (questions)

    if not questions:
        raise HTTPException(status_code=404, detail="No questions found for this assignment")

    # Prepare questions data (without correct answers for objective, all data for subjective)
    questions_data = []
    question_type = assignment.question_type.value if assignment.question_type else "multiple_choice"
    print('number of questions:', len(questions))
    for i, q in enumerate(questions):
        question_dict = {
            "id": q.id,
            "question_number": i + 1,
            "question": q.question,
            "question_type": question_type
        }
        
        # Add options for multiple choice questions
        if question_type != "text":
            question_dict.update({
                "option_1": q.option_1,
                "option_2": q.option_2,
                "option_3": q.option_3,
                "option_4": q.option_4,
            })
        else:
            # For text questions, include descriptive answer as a hint/guide if available
            question_dict["descriptive_answer"] = q.descriptive_answer
            
        questions_data.append(question_dict)

    add_notification(student.user_id, f"📝 Started attempt for '{assignment.title}'", db)

    return {
        "assignment": {
            "id": assignment.id,
            "title": assignment.title,
            "feedback": assignment.feedback,
            "deadline": assignment.assignment_deadline.isoformat() if assignment.assignment_deadline else None,
            "question_type": question_type,
            "total_questions": len(questions_data),
            "requires_manual_grading": question_type == "text"
        },
        "questions": questions_data,
        "attempt_started_at": datetime.now().isoformat()
    }

    # student = db.query(Student).filter(Student.user_id == user_id).first()
    # if not student:
    #     raise HTTPException(status_code=404, detail="Student not found")

    # student_scores = db.query(Score).filter(Score.student_id == student.id).all() if student else []
    # if not student:
    #     raise HTTPException(status_code=404, detail="Student not found for given user")
    # print('scores:', student_scores)
    # return [
    #     {
    #         "name": "score.badge.badge_type",
    #         "description": score.status,
    #         "points": score.percentage
    #     }
    #     for score in student_scores
    # ]


@student_router.get("/{user_id}/resources")
def get_knowledge_base(user_id: int, db: Session = Depends(get_db)):
    student = db.query(Student).filter(Student.user_id == user_id).first()
    if not student:
        raise HTTPException(status_code=404, detail="Student not found")
    if not student.class_id:
        return []

    subject_ids = (
        db.query(student_subject.c.subject_id)
        .filter(student_subject.c.student_id == student.id)
        .all()
    )
    subject_ids = [sid[0] for sid in subject_ids]
    if not subject_ids:
        return []

    matching_instructors = (
        db.query(Teacher)
        .filter(
            Teacher.class_id == student.class_id,
            Teacher.subject_id.in_(subject_ids)
        )
        .all()
    )
    if not matching_instructors:
        return []

    instructor_ids = [inst.user_id for inst in matching_instructors]

    resources = (
        db.query(Resource)
        .filter(Resource.instructor_id.in_(instructor_ids))
        .all()
    )

    return [
        {
            "id": res.id,
            "title": res.title,
            "description": res.description,
            "url": res.url,
            "category": res.category,
        }
        for res in resources
    ]






@student_router.get("/{user_id}/messages")
def get_student_messages(user_id: int, db: Session = Depends(get_db)):
    student = db.query(Student).filter(Student.user_id == user_id).first()
    if not student:
        raise HTTPException(status_code=404, detail="Student not found")

    # Static messages; you can customize based on student later
    return [
        {"from": "Teacher John", "message": "Submit your assignment by tomorrow", "timestamp": datetime.utcnow()},
        {"from": "Admin", "message": "Holiday tomorrow!", "timestamp": datetime.utcnow()}
    ]


@student_router.get("/{user_id}/profile")
def get_student_profile(user_id: int, db: Session = Depends(get_db)):
    student = db.query(Student).filter(Student.user_id == user_id).first()
    if not student:
        raise HTTPException(status_code=404, detail="Student not found")

    user = student.user
    class_info = student.class_id

    return {
        "full_name": user.full_name,
        "email": user.email,
        "username": user.username,
        "class": class_info if class_info else None,
        "created_at": user.created_at.isoformat() if user.created_at else None
    }

@student_router.get("/{user_id}/calendar")
def get_student_calendar(user_id: int, db: Session = Depends(get_db)):
    student = db.query(Student).filter(Student.user_id == user_id).first()
    if not student:
        raise HTTPException(status_code=404, detail="Student not found")

    assignments = db.query(Assignment).filter(Assignment.student_id == student.id).all()
    
    return [
        {
            "title": a.title,
            "due": a.assignment_deadline.isoformat() if a.assignment_deadline else None,
            "status": a.status.name
        }
        for a in assignments
    ]


def add_notification(user_id: int, message: str, db):
    notification = Notification(
        user_id=user_id,
        message=message,
        timestamp=datetime.now()
    )
    db.add(notification)
    db.commit()

@student_router.get("/{user_id}/notifications")
def get_notifications(user_id: int, db: Session = Depends(get_db)):
    student = db.query(Student).filter(Student.user_id == user_id).first()
    if not student:
        raise HTTPException(status_code=404, detail="Student not found")
    
    announcements = db.query(Announcement).filter(
        or_(
            Announcement.recipient_role == "all",
            Announcement.recipient_role == "student",
            Announcement.specific_user_id == user_id
        )
    ).all()
    
    all_notifications = list(student.user.notifications) + announcements
    
    return [
        {
            "message": getattr(n, 'message', None) or getattr(n, 'body', None),
            "timestamp": (getattr(n, 'timestamp', None) or getattr(n, 'created_at', None)).isoformat()
        }
        for n in all_notifications
    ]


class ProfileUpdateRequest(BaseModel):
    full_name: str
    email: EmailStr
    avatar: str | None = None

@student_router.put("/{user_id}/profile")
def update_student_profile(user_id: int, profile_data: ProfileUpdateRequest, db: Session = Depends(get_db)):
    student = db.query(Student).filter(Student.user_id == user_id).first()
    if not student:
        raise HTTPException(status_code=404, detail="Student not found")

    user = student.user
    user.full_name = profile_data.full_name
    user.email = profile_data.email

    # If avatar is a field in User model, update it
    if hasattr(user, "avatar") and profile_data.avatar:
        user.avatar = profile_data.avatar

    db.commit()
    db.refresh(user)

    return {
        "message": "Profile updated successfully",
        "full_name": user.full_name,
        "email": user.email,
        "avatar": getattr(user, "avatar", None)
    }

import uuid
import threading
@student_router.post("/{user_id}/focus_mode")
async def start_focus_mode(user_id: int, request: Request, db: Session = Depends(get_db)):
    body = await request.json()
    minutes = int(body.get("minutes", 25))  # default 25 minutes

    session_id = str(uuid.uuid4())
    output_file = f"focus_session_{user_id}_{datetime.now(ZoneInfo('Asia/Kolkata')).strftime('%Y%m%d%H%M%S')}.txt"

    # 🔁 Start in background thread so it doesn't block FastAPI
    thread = threading.Thread(target=start_focus_session, args=(minutes, output_file))
    thread.start()

    # 📢 Optional: Log to DB
    add_notification(user_id, f"🎯 Focus mode started for {minutes} minutes", db)

    return JSONResponse({
        "message": f"✅ Focus session started for {minutes} minutes.",
        "output_file": output_file
    })


class ReportCreate(BaseModel):
    title: str
    content: str
    screenshot: Optional[str] = None


@student_router.post("/{user_id}/reports")
def create_report(
    user_id: int,
    report_data: ReportCreate,
    db: Session = Depends(get_db)
):
    student = db.query(Student).filter(Student.user_id == user_id).first()
    if not student:
        raise HTTPException(status_code=404, detail="Student not found")

    new_report = Report(
        title=report_data.title,
        content=report_data.content,
        screenshot=report_data.screenshot,
        # ist timing fixed and working im not changing other utc timing set.....you can change this if you want.....
        created_at=datetime.now(),
        
        user_id=user_id
    )
    db.add(new_report)
    db.commit()
    db.refresh(new_report)

    return {
        "message": "Report issued successfully",
        "report": {
            "id": new_report.id,
            "title": new_report.title,
            "content": new_report.content,
            "screenshot": new_report.screenshot,
            "created_at": new_report.created_at
        }
    }








# badges shit
from extensions import *
from badge_system import setup_automatic_badge_system
# session = SessionLocal()
init_badge_system = setup_automatic_badge_system(SessionLocal)


@student_router.get("/{user_id}/badges")
def get_badges(user_id: int, db: Session = Depends(get_db)):
    student = db.query(Student).join(Student.user).filter(Student.user_id == user_id).first()
    print("rewards", student.rewards)
    if not student:
        raise HTTPException(status_code=404, detail="Student not found for given user")

    update_badges_for_student(student.id, db)
    return [r.badge.badge_type for r in student.rewards]



# ------------------------------------
# 🏅 LIVE BADGE CHECKING FUNCTIONS
# ------------------------------------

def update_badges_for_student(student_id: int, db: Session):
    check_perfect_scholar(student_id, db) 
    check_academic_star(student_id, db)
    check_subject_master(student_id, db)

    # attendance thing not understandable in the backend so i aint making this one :|
    # check_streak_master(student_id, db)
    # check_dedication_champion(student_id, db)
    # check_persistent_learner(student_id, db)


    check_task_completionist(student_id, db)
    check_task_master(student_id, db)
    check_time_manager(student_id, db)
    check_early_bird(student_id, db)


    # check_focus_badges(student_id, db)
    # check_task_badges(student_id, db)
    check_achievement_level(student_id, db)
    check_first_step(student_id, db)
    check_task_ninja(student_id, db)

# working!
def check_perfect_scholar(student_id: int, db: Session):
    # 100% in any one subject atleast
    perfect = db.query(Score).filter_by(student_id=student_id).filter(or_(Score.percentage == 100.0, Score.score == 100.0)).count()
    if perfect >= 1:
        give_badge_if_not_exists(db, student_id, "Perfect Scholar", 100)

# working!
def check_academic_star(student_id: int, db: Session):
    # score 95+ in atleast 5 assignments
    high_scores = db.query(Score).filter_by(student_id=student_id).filter(
        or_(Score.percentage >= 95.0, Score.score >= 95.0)
    ).count()
    if high_scores >= 5:
        give_badge_if_not_exists(db, student_id, "Academic Star", 200)

# working!
def check_subject_master(student_id: int, db: Session):
    # 90+ score in 20 assignments across all subjects
    subject_master = db.query(Score).filter_by(student_id=student_id).filter(
        or_(Score.percentage >= 90.0, Score.score >= 90.0)
    ).count()
    if subject_master >= 20:
        give_badge_if_not_exists(db, student_id, "Subject Master", 100)

def check_streak_master(student_id: int, db: Session):
    # Active for 5 consecutive days
    # no attendance db
    pass

# working!
def check_task_completionist(student_id: int, db: Session):
    # Complete 10 tasks
    completed_tasks = db.query(Task).filter_by(student_id=student_id, status=TaskStatusEnum.complete).count()
    if completed_tasks >= 10:
        give_badge_if_not_exists(db, student_id, "Task Completionist", 75)

# working!
def check_task_master(student_id: int, db: Session):
    # Complete 50 tasks
    completed_tasks = db.query(Task).filter_by(student_id=student_id, status=TaskStatusEnum.complete).count()
    if completed_tasks >= 50:
        give_badge_if_not_exists(db, student_id, "Task Master", 150)

# working!
def check_time_manager(student_id: int, db: Session):

    # Complete 5 assignments before due_date filter too
    completed_tasks = db.query(Task).filter(and_(Task.student_id==student_id, Task.status== "complete", Task.created_at < Task.due_date)).count()
    if completed_tasks >= 5:
        give_badge_if_not_exists(db, student_id, "Time Manager", 100)


# working!
def check_early_bird(student_id: int, db: Session):
    # Complete 25 tasks on time before due date
    tasks = db.query(Task).filter(
        Task.student_id == student_id,
        Task.status == "complete"
    ).all()

    on_time_tasks = []
    for t in tasks:
        created = datetime.fromisoformat(str(t.created_at))
        due = datetime.fromisoformat(str(t.due_date))
        # print(f"Task {t.id}: created at {created}, due at {due}")

        if created < due:
            # print("✅ On time")
            on_time_tasks.append(t)
        else:
            # print("❌ Late")
            pass

    if len(on_time_tasks) >= 25:
        # print("🏆 Awarding Early Bird")
        give_badge_if_not_exists(db, student_id, "Early Bird", 100)
    else:
        # print("Not enough on-time tasks for Early Bird")
        pass

# working!
def check_first_step(student_id: int, db: Session):
    submitted = db.query(Score).filter_by(student_id=student_id).count()
    if submitted >= 1:
        give_badge_if_not_exists(db, student_id, "First Step", 100)

# not working!
def check_focus_badges(student_id: int, db: Session):
    sessions = db.query(FocusMode).filter_by(student_id=student_id).all()
    if len(sessions) == 5:
        give_badge_if_not_exists(db, student_id, "Focus Novice", 50)
    if len(sessions) >= 25:
        give_badge_if_not_exists(db, student_id, "Focus Expert", 300)
    if any(s.duration_minutes >= 20 for s in sessions):
        give_badge_if_not_exists(db, student_id, "Laser Focused", 200)
    if any(s.duration_minutes >= 120 for s in sessions):
        give_badge_if_not_exists(db, student_id, "Concentration Master", 200)

# working!
def check_task_ninja(student_id: int, db: Session):
    # Complete 100 tasks
    completed_count = db.query(Task).filter(
        Task.student_id == student_id,
        Task.status == "complete"
    ).count()

    if completed_count >= 100:
        give_badge_if_not_exists(db, student_id, "Task Ninja", 400)

# working!
def check_achievement_level(student_id: int, db: Session):
    total_rewards = db.query(Reward).filter_by(student_id=student_id).count()
    if total_rewards >= 3:
        give_badge_if_not_exists(db, student_id, "Bronze Achiever", 100)
    if total_rewards >= 10:
        give_badge_if_not_exists(db, student_id, "Silver Achiever", 300)
    if total_rewards >= 25:
        give_badge_if_not_exists(db, student_id, "Gold Achiever", 500)

# ------------------------------------
# badge grant helper live updates
# ------------------------------------

def give_badge_if_not_exists(db: Session, student_id: int, badge_type: str, points: int, parent_id: int = None):
    badge = db.query(Badge).filter_by(badge_type=badge_type).first()
    if not badge:
        badge = Badge(badge_type=badge_type, badge_points=points)
        db.add(badge)
        db.commit()

    existing = db.query(Reward).filter_by(student_id=student_id, badge_id=badge.id).first()

    if not existing:
        parent = db.query(Parent).filter_by(student_id=student_id).first()

        reward = Reward(
            student_id=student_id,
            badge_id=badge.id,
            reward_points=points,
            parent_id=parent.id if parent else None,
            # teacher_id=teacher_id if teacher_id else None
        )

        db.add(reward)
        db.commit()

from routes.ai_agent import get_task_agent, TaskAgentResponse

@student_router.post("/{user_id}/ai-task")
def ai_task_manager(
    user_id: int, 
    request_data: dict = Body(...), 
    db: Session = Depends(get_db),
    user=Depends(get_current_user)
):
    """
    AI-powered task management endpoint
    Accepts natural language input to perform CRUD operations on tasks
    
    Example requests:
    - "Create a task to study math for tomorrow"
    - "Show me all pending tasks"
    - "Mark homework as complete" 
    - "Delete the old chemistry project"
    """
    try:
        user_input = request_data.get("message", "").strip()
        
        if not user_input:
            return {
                "success": False,
                "message": "Please provide a message describing what you want to do with your tasks."
            }
        
        # Get the AI agent
        agent = get_task_agent()
        
        # Process the request
        response = agent.process_request(user_input, user_id, db)
        
        # Add notification for successful operations
        if response.success and response.task_data:
            add_notification(user_id, f"🤖 AI Task Assistant: {response.message}", db)
        
        return response.dict()
        
    except Exception as e:
        return {
            "success": False,
            "message": f"AI Task Assistant error: {str(e)}"
        }

@student_router.get("/{user_id}/ai-task/help")
def ai_task_help(user_id: int):
    """Get help information for AI task management"""
    return {
        "message": "AI Task Assistant Help",
        "examples": [
            {
                "input": "Create a task to submit math homework by tomorrow",
                "description": "Creates a new task with title and due date"
            },
            {
                "input": "Show me all my pending tasks",
                "description": "Lists all tasks with pending status"
            },
            {
                "input": "Mark physics assignment as complete",
                "description": "Updates a task status to complete"
            },
            {
                "input": "Delete the old chemistry project",
                "description": "Removes a task from your list"
            },
            {
                "input": "Update homework task description to include page numbers",
                "description": "Modifies task details"
            },
            {
                "input": "Show me tasks due this week",
                "description": "Filters tasks by due date"
            }
        ],
        "supported_operations": [
            "Create tasks with natural language",
            "List and filter tasks",
            "Update task status, title, description, due date",
            "Delete tasks by name/identifier",
            "Smart date parsing (tomorrow, next week, in 3 days, etc.)"
        ]
    }

from routes.chatbot_agent import get_chatbot_agent, ChatbotResponse, AudioTranscriptionRequest

@student_router.post("/{user_id}/chat")
def chat_with_assistant(
    user_id: int,
    request_data: dict = Body(...),
    db: Session = Depends(get_db),
    user=Depends(get_current_user)
):
    """
    Chat with the AI communication assistant
    
    Request body:
    {
        "message": "Your message here",
        "session_id": "optional_session_id", 
        "generate_audio": true/false
    }
    
    Example requests:
    - "How can I improve my public speaking skills?"
    - "I'm nervous about presentations, any tips?"
    - "Help me build confidence in communication"
    """
    try:
        message = request_data.get("message", "").strip()
        session_id = request_data.get("session_id")
        generate_audio = request_data.get("generate_audio", True)
        
        if not message:
            return {
                "success": False,
                "message": "Please provide a message to chat with the assistant."
            }
        
        # Get chatbot agent
        chatbot = get_chatbot_agent()
        
        # Process message
        response = chatbot.process_text_message(
            user_input=message,
            user_id=user_id,
            session_id=session_id,
            generate_audio=generate_audio
        )
        
        # Add notification for chat interactions if desired
        if response.success:
            add_notification(user_id, f"💬 Chat Assistant: New conversation message", db)
        
        return response.dict()
        
    except Exception as e:
        return {
            "success": False,
            "message": f"Chat Assistant error: {str(e)}"
        }

@student_router.post("/{user_id}/voice-chat")
def voice_chat_with_assistant(
    user_id: int,
    request_data: dict = Body(...),
    db: Session = Depends(get_db),
    user=Depends(get_current_user)
):
    """
    Chat with assistant via voice input
    
    Request body:
    {
        "audio_data": "base64_encoded_audio_data",
        "session_id": "optional_session_id"
    }
    """
    try:
        audio_data = request_data.get("audio_data")
        session_id = request_data.get("session_id")
        
        if not audio_data:
            return {
                "success": False,
                "message": "No audio data provided"
            }
        
        # Get chatbot agent
        chatbot = get_chatbot_agent()
        
        # Process audio message  
        response = chatbot.process_audio_message(
            audio_data=audio_data,
            user_id=user_id,
            session_id=session_id
        )
        
        # Add notification for voice interactions
        if response.success:
            add_notification(user_id, f"🎤 Voice Chat: Message processed", db)
        
        return response.dict()
        
    except Exception as e:
        return {
            "success": False,
            "message": f"Voice Chat error: {str(e)}"
        }

@student_router.get("/{user_id}/chat-history/{session_id}")
def get_chat_history(
    user_id: int,
    session_id: str,
    user=Depends(get_current_user)
):
    """Get conversation history for a chat session"""
    try:
        chatbot = get_chatbot_agent()
        history = chatbot.get_conversation_history(session_id)
        
        if history is None:
            return {
                "success": False,
                "message": "Chat session not found",
                "messages": []
            }
        
        return {
            "success": True,
            "session_id": session_id,
            "messages": [msg.dict() for msg in history],
            "message": f"Retrieved {len(history)} messages"
        }
        
    except Exception as e:
        return {
            "success": False,
            "message": f"Error retrieving chat history: {str(e)}"
        }

@student_router.delete("/{user_id}/chat-session/{session_id}")
def clear_chat_session(
    user_id: int,
    session_id: str,
    user=Depends(get_current_user)
):
    """Clear a specific chat session"""
    try:
        chatbot = get_chatbot_agent()
        success = chatbot.clear_session(session_id)
        
        if not success:
            return {
                "success": False,
                "message": "Chat session not found or already cleared"
            }
        
        return {
            "success": True,
            "message": f"Chat session cleared successfully"
        }
        
    except Exception as e:
        return {
            "success": False,
            "message": f"Error clearing chat session: {str(e)}"
        }

@student_router.get("/{user_id}/chat-help")
def chat_assistant_help(user_id: int, user=Depends(get_current_user)):
    """Get help information for the chat assistant"""
    return {
        "message": "AI Chat Assistant Help",
        "description": "Your personal communication teacher and conversation partner!",
        "capabilities": [
            "💬 General conversation and support",
            "🗣️ Communication skills coaching", 
            "🎤 Public speaking tips and techniques",
            "💪 Building confidence and overcoming shyness",
            "🔊 Voice interaction (speak and listen)",
            "🎯 Personalized advice and guidance"
        ],
        "example_conversations": [
            {
                "input": "I'm nervous about giving a presentation next week",
                "response_type": "Tips for presentation confidence and preparation"
            },
            {
                "input": "How can I be more confident in group discussions?",
                "response_type": "Strategies for active participation and self-assurance"
            },
            {
                "input": "I'm too shy to speak up in class",
                "response_type": "Gentle guidance for overcoming shyness"
            },
            {
                "input": "Can you help me practice speaking?",
                "response_type": "Interactive speaking exercises and feedback"
            }
        ],
        "voice_features": [
            "🎙️ Record voice messages to practice speaking",
            "🔊 Listen to AI responses for pronunciation help", 
            "🗣️ Real-time conversation practice",
            "📝 Automatic transcription of your speech"
        ],
        "usage_tips": [
            "Start conversations naturally - just type or speak what's on your mind",
            "Ask specific questions about communication challenges",
            "Use voice messages to practice speaking out loud",
            "Sessions remember our conversation context",
            "For task management, use the dedicated task features instead"
        ],
        "note": "💡 This chat assistant focuses on communication and conversation. For managing tasks, homework, and assignments, please use the AI Task Manager feature."
    }

# Audio file serving route (if you want it in student routes)

import os
@student_router.get("/{user_id}/chat-audio/{filename}")
def get_chat_audio(
    user_id: int,
    filename: str,
):
    """Serve audio files for chat responses"""
    try:
        # Validate filename for security
        if ".." in filename or "/" in filename or not filename.endswith('.mp3'):
            raise HTTPException(status_code=400, detail="Invalid filename")
        if f"chat_{user_id}_" not in filename:
            raise HTTPException(status_code=403, detail="Access denied")
        
        
        audio_path = os.path.join("audio_cache", filename)
        if os.path.exists(audio_path):
            return FileResponse(
                audio_path, 
                media_type="audio/mpeg",
                filename=filename,
                headers={
                    "Cache-Control": "public, max-age=3600",
                    "Access-Control-Allow-Origin": "*",  # Add CORS header
                    "Accept-Ranges": "bytes"
                }
            )
        else:
            raise HTTPException(status_code=404, detail="Audio file not found")
            
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error serving audio: {str(e)}")

@student_router.get("/{user_id}/chat-sessions")
def get_user_chat_sessions(
    user_id: int,
    user=Depends(get_current_user)
):
    """Get all chat sessions for a user"""
    try:
        chatbot = get_chatbot_agent()
        
        # Filter sessions for this user
        user_sessions = []
        for session_id, session in chatbot.sessions.items():
            if session.user_id == user_id:
                user_sessions.append({
                    "session_id": session_id,
                    "created_at": session.created_at.isoformat(),
                    "updated_at": session.updated_at.isoformat(),
                    "message_count": len(session.messages),
                    "last_message": session.messages[-1].content[:50] + "..." if session.messages else "No messages"
                })
        
        return {
            "success": True,
            "sessions": user_sessions,
            "total_sessions": len(user_sessions)
        }
        
    except Exception as e:
        return {
            "success": False,
            "message": f"Error retrieving sessions: {str(e)}"
        }
    