from fastapi import APIRouter, Depends, HTTPException, Body, UploadFile, File, Form
from sqlalchemy.orm import Session
from typing import List
from datetime import datetime
from models import Student, Task, Assignment, Reward, Subject, Question,TaskStatusEnum, Notification,User,Teacher,Parent,Announcement,UserStatus,Report
from typing import Optional, List
from extensions import get_db
from auth import get_current_user, require_role
from pydantic import BaseModel, EmailStr
import pytz
import shutil
import os

ist = pytz.timezone("Asia/Kolkata")
now = datetime.now(ist)

admin_router = APIRouter(
    prefix="/api/v1/admin",
    tags=["Admin"]
)

UPLOAD_DIR = "uploaded_files"  

@admin_router.get("/dashboard")
def get_dashboard_data(db: Session = Depends(get_db)):
    users = db.query(User).filter(User.role_name != 'admin').all()
    students = db.query(Student).all()
    teachers = db.query(Teacher).all()
    parents = db.query(Parent).all()

    return {
        "users": [u.to_dict() for u in users],
        "students": [s.to_dict() for s in students],
        "teachers": [t.to_dict() for t in teachers],
        "parents": [p.to_dict() for p in parents],
    }


@admin_router.get("/user/search")
def search_user(email: Optional[str] = None, user_id: Optional[int] = None, db: Session = Depends(get_db)):
    if email:
        user = db.query(User).filter(User.email == email).first()
    elif user_id:
        user = db.query(User).filter(User.id == user_id).first()
    else:
        raise HTTPException(status_code=400, detail="Provide either email or user_id")

    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    return user.to_dict(include_relationships=True)

@admin_router.post("/announcement")
def create_announcement(
    subject: str = Form(...),
    body: str = Form(...),
    recipient_role: Optional[str] = Form(None),  # "all", "student", "teacher", "parent"
    specific_user_id: Optional[int] = Form(None),
    file: Optional[UploadFile] = File(None),
    db: Session = Depends(get_db)
):
    file_url = None
    if file:
        os.makedirs(UPLOAD_DIR, exist_ok=True)
        file_path = os.path.join(UPLOAD_DIR, file.filename)
        with open(file_path, "wb") as f:
            shutil.copyfileobj(file.file, f)
        file_url = file_path

    announcement = Announcement(
        subject=subject,
        body=body,
        recipient_role=recipient_role,
        specific_user_id=specific_user_id,
        file_url=file_url,
        created_at=datetime.now()
    )

    db.add(announcement)
    db.commit()
    db.refresh(announcement)
    return {"message": "Announcement sent", "announcement": announcement.to_dict()}

@admin_router.get("/announcements")
def get_announcements(
    recipient_role: Optional[str] = None,
    specific_user_id: Optional[int] = None,
    db: Session = Depends(get_db)
):
    query = db.query(Announcement)
    
    if recipient_role:
        query = query.filter(Announcement.recipient_role == recipient_role)
    
    if specific_user_id:
        query = query.filter(Announcement.specific_user_id == specific_user_id)
    
    announcements = query.order_by(Announcement.created_at.desc()).all()
    
    return {
        "announcements": [a.to_dict() for a in announcements]
    }

@admin_router.put("/user/{user_id}/block")
def block_user(user_id: int, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    user.user_status = UserStatus.inactive
    db.commit()
    return {"message": "User blocked successfully"}

@admin_router.put("/user/{user_id}/unblock")
def unblock_user(user_id: int, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    user.user_status = UserStatus.active
    db.commit()
    return {"message": "User unblocked successfully"}

@admin_router.delete("/user/{user_id}")
def delete_user(user_id: int, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    db.delete(user)
    db.commit()
    return {"message": "User deleted successfully"}

@admin_router.get("/reports/dashboard")
def get_reports_dashboard(db: Session = Depends(get_db)):
    """Get comprehensive dashboard statistics for reports"""
    reports = db.query(Report).all()
    
    # Enhanced statistics
    total_reports = len(reports)
    open_reports = len([r for r in reports if not hasattr(r, 'status') or r.status in ['open', 'pending']])
    resolved_reports = len([r for r in reports if hasattr(r, 'status') and r.status == 'resolved'])
    in_progress_reports = len([r for r in reports if hasattr(r, 'status') and r.status == 'in_progress'])
    
    # Today's activity
    today = datetime.now().date()
    resolved_today = len([r for r in reports if hasattr(r, 'resolved_at') and r.resolved_at and r.resolved_at.date() == today])
    new_today = len([r for r in reports if r.created_at.date() == today])
    
    # Priority breakdown
    high_priority = len([r for r in reports if hasattr(r, 'priority') and r.priority == 'high'])
    medium_priority = len([r for r in reports if hasattr(r, 'priority') and r.priority == 'medium'])
    low_priority = len([r for r in reports if hasattr(r, 'priority') and r.priority == 'low'])
    
    # Category breakdown
    categories = {}
    for report in reports:
        cat = getattr(report, 'category', 'general')
        categories[cat] = categories.get(cat, 0) + 1
    
    return {
        "total_reports": total_reports,
        "open_reports": open_reports,
        "resolved_reports": resolved_reports,
        "in_progress_reports": in_progress_reports,
        "resolved_today": resolved_today,
        "new_today": new_today,
        "high_priority": high_priority,
        "medium_priority": medium_priority,
        "low_priority": low_priority,
        "categories": categories,
        "reports": [r.to_dict(include_relationships=True) for r in reports]
    }

@admin_router.get("/reports")
def get_reports(
    page: int = 1,
    limit: int = 10,
    status: Optional[str] = None,
    category: Optional[str] = None,
    priority: Optional[str] = None,
    search: Optional[str] = None,
    sort_by: str = "created_at",
    sort_order: str = "desc",
    db: Session = Depends(get_db)
):
    """Get paginated and filtered reports"""
    query = db.query(Report)
    
    # Apply filters
    if status:
        query = query.filter(Report.status == status)
    if category:
        query = query.filter(Report.category == category)
    if priority:
        query = query.filter(Report.priority == priority)
    if search:
        query = query.filter(
            Report.title.contains(search) | 
            Report.content.contains(search)
        )
    
    # Apply sorting
    if sort_order == "desc":
        query = query.order_by(getattr(Report, sort_by).desc())
    else:
        query = query.order_by(getattr(Report, sort_by))
    
    # Pagination
    total = query.count()
    reports = query.offset((page - 1) * limit).limit(limit).all()
    
    return {
        "reports": [r.to_dict(include_relationships=True) for r in reports],
        "total": total,
        "page": page,
        "limit": limit,
        "total_pages": (total + limit - 1) // limit
    }

@admin_router.put("/report/{report_id}/status")
def update_report_status(
    report_id: int, 
    status: str = Body(..., embed=True),
    notes: Optional[str] = Body(None, embed=True),
    db: Session = Depends(get_db)
):
    """Update report status with admin notes"""
    report = db.query(Report).filter(Report.id == report_id).first()
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")
    
    old_status = getattr(report, 'status', 'open')
    
    # Update status
    if hasattr(report, 'status'):
        report.status = status
    
    # Add admin notes if provided
    if notes and hasattr(report, 'admin_notes'):
        report.admin_notes = notes
    
    # Set resolved timestamp if resolved
    if status == 'resolved' and hasattr(report, 'resolved_at'):
        report.resolved_at = datetime.now()

    db.commit()
    
    # Create notification for user about status change
    if old_status != status:
        notification = Notification(
            user_id=report.user_id,
            message=f"Your report #{report.id} status has been updated to: {status}",
            created_at=datetime.now()
        )
        db.add(notification)
        db.commit()
    
    return {"message": f"Report status updated to {status}"}

@admin_router.put("/report/{report_id}/priority")
def update_report_priority(
    report_id: int, 
    priority: str = Body(..., embed=True),
    db: Session = Depends(get_db)
):
    """Update report priority"""
    report = db.query(Report).filter(Report.id == report_id).first()
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")
    
    if hasattr(report, 'priority'):
        report.priority = priority
        db.commit()
    
    return {"message": f"Report priority updated to {priority}"}

@admin_router.post("/report/{report_id}/reply")
def reply_to_report(
    report_id: int, 
    message: str = Body(..., embed=True),
    send_email: bool = Body(False, embed=True),
    db: Session = Depends(get_db)
):
    """Reply to a report with notification and optional email"""
    report = db.query(Report).filter(Report.id == report_id).first()
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")
    
    # Create notification for the reporter
    notification = Notification(
        user_id=report.user_id,
        message=f"Admin replied to your report #{report_id}: {message}",
        created_at=datetime.now()
    )
    
    db.add(notification)
    
    # Add reply to report history if your model supports it
    if hasattr(report, 'admin_reply'):
        report.admin_reply = message
        report.reply_at = datetime.now()
    
    db.commit()
    
    # TODO: Implement email sending if send_email is True
    # if send_email:
    #     send_email_to_user(report.user_id, f"Reply to Report #{report_id}", message)
    
    return {"message": "Reply sent successfully"}

@admin_router.get("/report/{report_id}")
def get_report_details(report_id: int, db: Session = Depends(get_db)):
    """Get detailed information about a specific report"""
    report = db.query(Report).filter(Report.id == report_id).first()
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")
    
    # Get reporter details
    reporter = db.query(User).filter(User.id == report.user_id).first()
    
    # Get related reports from same user
    related_reports = db.query(Report).filter(
        Report.user_id == report.user_id,
        Report.id != report_id
    ).limit(5).all()
    
    return {
        "report": report.to_dict(),
        "reporter": reporter.to_dict(include_relationships=True) if reporter else None,
        "related_reports": [r.to_dict() for r in related_reports]
    }


@admin_router.get("/reports/analytics")
def get_reports_analytics(
    days: int = 30,
    db: Session = Depends(get_db)
):
    """Get reports analytics for specified period"""
    from_date = datetime.now() - timedelta(days=days)
    
    reports = db.query(Report).filter(Report.created_at >= from_date).all()
    
    # Daily report counts
    daily_counts = {}
    for report in reports:
        date_key = report.created_at.strftime('%Y-%m-%d')
        daily_counts[date_key] = daily_counts.get(date_key, 0) + 1
    
    # Resolution time analysis
    resolved_reports = [r for r in reports if hasattr(r, 'resolved_at') and r.resolved_at]
    avg_resolution_time = 0
    if resolved_reports:
        total_time = sum([
            (r.resolved_at - r.created_at).total_seconds() / 3600  # hours
            for r in resolved_reports
        ])
        avg_resolution_time = total_time / len(resolved_reports)
    
    return {
        "period_days": days,
        "total_reports": len(reports),
        "daily_counts": daily_counts,
        "avg_resolution_time_hours": avg_resolution_time,
        "resolution_rate": len(resolved_reports) / len(reports) * 100 if reports else 0
    }

@admin_router.post("/reports/bulk-action")
def bulk_action_reports(
    report_ids: List[int] = Body(...),
    action: str = Body(...),  # 'resolve', 'delete', 'change_priority', 'change_status'
    value: Optional[str] = Body(None),  # for priority or status changes
    db: Session = Depends(get_db)
):
    """Perform bulk actions on multiple reports"""
    reports = db.query(Report).filter(Report.id.in_(report_ids)).all()
    
    if not reports:
        raise HTTPException(status_code=404, detail="No reports found")
    
    updated_count = 0
    
    for report in reports:
        if action == 'resolve':
            if hasattr(report, 'status'):
                report.status = 'resolved'
            if hasattr(report, 'resolved_at'):
                report.resolved_at = datetime.now()
            updated_count += 1
            
        elif action == 'change_status' and value:
            if hasattr(report, 'status'):
                report.status = value
            updated_count += 1
            
        elif action == 'change_priority' and value:
            if hasattr(report, 'priority'):
                report.priority = value
            updated_count += 1
    
    if action == 'delete':
        db.query(Report).filter(Report.id.in_(report_ids)).delete()
        updated_count = len(report_ids)
    else:
        db.commit()
    
    return {"message": f"Bulk action completed on {updated_count} reports"}

@admin_router.put("/report/{report_id}/resolve")
def resolve_report(report_id: int, db: Session = Depends(get_db)):
    report = db.query(Report).filter(Report.id == report_id).first()
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")
    
    if hasattr(report, 'status'):
        report.status = 'resolved'
    if hasattr(report, 'resolved_at'):
        report.resolved_at = datetime.now()
    
    db.commit()
    return {"message": "Report resolved successfully"}