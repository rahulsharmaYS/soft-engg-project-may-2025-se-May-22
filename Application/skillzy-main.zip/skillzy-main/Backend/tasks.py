# tasks.py
from celery_app import celery_app
from extensions import SessionLocal
from models import *
from datetime import datetime, timedelta
from sqlalchemy import func
import logging
import os
import re
from fpdf import FPDF
from zoneinfo import ZoneInfo

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@celery_app.task(name="send_parent_pending_tasks_notification")
def send_parent_pending_tasks_notification():
    db = SessionLocal()
    try:
        parents = db.query(Parent).all()
        for parent in parents:
            if parent.student_id is not None:
                tasks = db.query(Task).filter_by(student_id=parent.student_id, status='pending').all()
                if tasks:
                    message = f"Your child has pending tasks: {', '.join(task.title for task in tasks)}" # type: ignore
                    save_notification(parent.user_id, message,message_type=NotificationType.pending_tasks_assignments) # type: ignore
                assignments = (
                    db.query(Assignment)
                    .join(Assignment.assigned_student)  # to filter by parent’s student
                    .filter(Assignment.assignment_deadline > datetime.now(),
                            Student.id == parent.student.id,
                            ~Assignment.id.in_(db.query(Submission.assignment_id)
                                                    .filter(Submission.student_id == parent.student.id))).all())
                if assignments:
                    message = f"Your child has pending assignments: {', '.join(assignment.title for assignment in assignments)}" #type: ignore
                    save_notification(parent.user_id, message, message_type=NotificationType.pending_tasks_assignments) # type: ignore

        db.commit()
        logger.info("Notifications sent successfully")
        return f"Notifications sent successfully"
    except Exception as e:
        logger.error(f"Error sending notifications: {str(e)}")
        db.rollback()
        return f"Error sending notifications: {str(e)}"
    finally:
        db.close()

@celery_app.task(name="send_parent_score_notification")
def send_parent_score_notification(assignment_id: int):
    db = SessionLocal()
    print("Score notify")
    try:
        parents = db.query(Parent).all()
        for parent in parents:
            if parent.student_id is not None:
                # Get all scores for this student with assignment details
                score = (db.query(Score).filter(Score.student_id == parent.student_id, Score.assignment_id == assignment_id).first())

                if score:
                    message = f"Your child has scored {score.score} in \"{score.assignment.title}\" assignment."
                    percentage = (score.score / score.max_score) * 100

                    if percentage >= 90:
                        message += " Excellent progress! Keep it up!"
                    elif percentage >= 75:
                        message += " Great effort! They're on the right path."
                    elif percentage >= 50:
                        message += " Doing okay. A bit more focus will help."
                    else:
                        message += " Needs support — growth starts with small steps."
                    save_notification(parent.user_id, message, NotificationType.score_update) # type: ignore

        db.commit()
        logger.info("Notifications sent successfully")
        return f"Notifications sent successfully"
    except Exception as e:
        logger.error(f"Error sending notifications: {str(e)}")
        db.rollback()
        return f"Error sending notifications: {str(e)}"
    finally:
        db.close()

@celery_app.task(name="create_report_focus_mode")
def create_report_focus_mode():
    db = SessionLocal()
    try:
        parents = db.query(Parent).all()
        if not parents:
            raise Exception("No parents found")

        for parent in parents:
            student = db.query(Student).filter(Student.id == parent.student_id).first()
            if not student:
                continue

            student_id = student.user_id
            folder_path = "static/focus_logs"
            os.makedirs(folder_path, exist_ok=True)

            focus_data = []

            for filename in os.listdir(folder_path):
                if not filename.startswith(f"focus_session_{student_id}_") or not filename.endswith(".txt"):
                    continue

                match = re.match(rf"focus_session_{student_id}_(\d+)\.txt", filename)
                print(match)
                if not match:
                    continue

                session_time_str = match.group(1)
                session_time = datetime.strptime(session_time_str, "%Y%m%d%H%M%S").replace(tzinfo=ZoneInfo("Asia/Kolkata"))

                if datetime.now(ZoneInfo("Asia/Kolkata")) - session_time > timedelta(hours=24):
                    continue

                file_path = os.path.join(folder_path, filename)
                session = parse_focus_summary_txt(file_path)
                if session:
                    focus_data.append(session)

            if not focus_data:
                continue  # No sessions to report

            # Generate PDF
            pdf = FPDF()
            pdf.add_page()
            # === Set Page Border ===
            pdf.set_draw_color(100, 100, 255)  # Light blue border
            pdf.rect(5, 5, 200, 287)  # Draw rectangle: (x, y, w, h)
            pdf.set_font("Courier", "B", 16)
            pdf.cell(0, 10, f"Focus Report", ln=True, align='C')
            pdf.ln(5)
            pdf.set_font("Courier", "B", 14)
            pdf.cell(0, 10, f"Hello {parent.user.full_name}, here is the focus report for {student.user.full_name}", ln=True)
            pdf.ln(5)

            col_widths = [40, 40, 35, 45]
            table_width = sum(col_widths)
            start_x = (pdf.w - table_width) / 2

            # Table headers
            pdf.set_font("Courier", "B", 12)
            pdf.set_x(start_x)
            pdf.cell(40, 10, "Start Time", border=1, align='C')
            pdf.cell(40, 10, "End Time", border=1, align='C')
            pdf.cell(30, 10, "Duration", border=1, align='C')
            pdf.cell(40, 10, "Tab Switches", border=1, align='C')
            pdf.ln()

            # Table rows
            pdf.set_font("Courier", "", 11)
            total_duration = 0
            total_switches = 0

            for entry in focus_data:
                start_time = entry["start_time"].strftime('%Y-%m-%d %H:%M')
                end_time = entry["end_time"].strftime('%Y-%m-%d %H:%M')
                duration = entry["duration"]
                tab_switches = entry["switches"]


                total_duration += duration
                total_switches += tab_switches

                pdf.set_x(start_x)
                pdf.cell(40, 10, start_time, border=1, align='C')
                pdf.cell(40, 10, end_time, border=1, align='C')
                pdf.cell(30, 10, f"{duration} min", border=1, align='C')
                pdf.cell(40, 10, str(tab_switches), border=1, align='C')
                pdf.ln()

                # Total row
                pdf.set_font("Courier", "B", 12)
                pdf.set_x(start_x)
                pdf.cell(80, 10, "Total", border=1, align='C')
                pdf.cell(30, 10, f"{total_duration} min", border=1, align='C')
                pdf.cell(40, 10, str(total_switches), border=1, align='C')
                pdf.ln(15)

            for entry in focus_data:
                windows_visited = entry["windows"]
                keys = entry["keys"]
                blacklist_sites = entry["blacklist"]
                classification = entry["classification"]

                pdf.set_font("Courier", "B", 12)
                pdf.cell(0, 10, f"Windows Visited: ", ln=2, align='L')
                if not windows_visited:
                    pdf.set_font("Courier", "", 11)
                    pdf.cell(0, 10, "No windows visited", ln=2, align='L')
                else:
                    for window in windows_visited:
                        pdf.set_font("Courier", "", 11)
                        pdf.cell(0, 10, f"- {window}", ln=2, align='L')
                pdf.ln(5)
                pdf.set_font("Courier", "B", 12)
                pdf.cell(0, 10, f"Keys Used: ", ln=2, align='L')
                if not keys:
                    pdf.set_font("Courier", "", 11)
                    pdf.cell(0, 10, "No keys used", ln=2, align='L')
                else:
                    for window, keys in keys.items():
                        pdf.set_font("Courier", "", 11)
                        pdf.cell(0, 10, f"{window} : {keys}", ln=2, align='L')
                pdf.ln(5)
                pdf.set_font("Courier", "B", 12)
                pdf.cell(0, 10, f"Blacklist Sites: ", ln=2, align='L')
                if not blacklist_sites:
                    pdf.set_font("Courier", "", 11)
                    pdf.cell(0, 10, "No blacklisted sites visited", ln=2, align='L')
                else:
                    for blacklist in blacklist_sites:
                        pdf.set_font("Courier", "", 11)
                        pdf.cell(0, 10, f"- {blacklist}", ln=2, align='L')
                pdf.ln(5)
                pdf.set_font("Courier", "B", 12)
                pdf.cell(0, 10, f"Classification: ", ln=2, align='L')
                if not classification:
                    pdf.set_font("Courier", "", 11)
                    pdf.cell(0, 10, "No classification available", ln=2, align='L')
                else:
                    for window, tag in classification.items():
                        pdf.set_font("Courier", "", 11)
                        pdf.cell(0, 10, f"{window} - {tag}", ln=2, align='L')
                pdf.ln(5)

            # Save to static/reports
            os.makedirs("static/reports", exist_ok=True)
            timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
            filename = f"focus_report_{student_id}_{timestamp}.pdf"
            filepath = os.path.join("static/reports", filename)

            with open(filepath, 'wb'):
                pdf.output(filepath)

            # Save notification for parent
            message = "Your child’s focus report is ready. Click to download."
            save_notification(parent.user_id, message, NotificationType.report, report_filename=filename) # type: ignore
    except Exception as e:
        print(f"[ERROR] Failed to generate report: {str(e)}")
        raise
    finally:
        db.close()

@celery_app.task(name="create_weekly_report")
def create_weekly_report(parent_id: int):
    db = SessionLocal()
    try:
        parents = db.query(Parent).all()
        if not parents:
            raise Exception("No parents found")

        for parent in parents:
            student = db.query(Student).filter(Student.id == parent.student_id).first()
            if not student:
                continue

            student_id = student.user_id
            folder_path = "static/focus_logs"
            os.makedirs(folder_path, exist_ok=True)

            focus_data = []

            for filename in os.listdir(folder_path):
                if not filename.startswith(f"focus_session_{student_id}_") or not filename.endswith(".txt"):
                    continue

                match = re.match(rf"focus_session_{student_id}_(\d+)\.txt", filename)
                print(match)
                if not match:
                    continue

                session_time_str = match.group(1)
                session_time = datetime.strptime(session_time_str, "%Y%m%d%H%M%S").replace(tzinfo=ZoneInfo("Asia/Kolkata"))

                if datetime.now(ZoneInfo("Asia/Kolkata")) - session_time > timedelta(days=7):
                    continue

                file_path = os.path.join(folder_path, filename)
                session = parse_focus_summary_txt(file_path)
                if session:
                    focus_data.append(session)

            if not focus_data:
                continue  # No sessions to report

            # Generate PDF
            pdf = FPDF()
            pdf.add_page()
            # === Set Page Border ===
            pdf.set_draw_color(100, 100, 255)  # Light blue border
            pdf.rect(5, 5, 200, 287)  # Draw rectangle: (x, y, w, h)
            pdf.set_font("Courier", "B", 16)
            pdf.cell(0, 10, f"Focus Report", ln=True, align='C')
            pdf.ln(5)
            pdf.set_font("Courier", "B", 14)
            pdf.cell(0, 10, f"Hello {parent.user.full_name}, here is the weekly report for {student.user.full_name}", ln=True)
            pdf.ln(5)

            col_widths = [40, 40, 35, 45]
            table_width = sum(col_widths)
            start_x = (pdf.w - table_width) / 2

            # Table headers
            pdf.set_font("Courier", "B", 12)
            pdf.set_x(start_x)
            pdf.cell(40, 10, "Start Time", border=1, align='C')
            pdf.cell(40, 10, "End Time", border=1, align='C')
            pdf.cell(30, 10, "Duration", border=1, align='C')
            pdf.cell(40, 10, "Tab Switches", border=1, align='C')
            pdf.ln()

            # Table rows
            pdf.set_font("Courier", "", 11)

            total_duration = 0

            for entry in focus_data:
                duration = entry["duration"]
                total_duration += duration

            pdf.set_x(start_x)
            pdf.cell(0, 10, f"Total time focused this week: {total_duration} min")
            pdf.ln()

            windows_visited = []
            blacklist_sites = []
            classification = {}
            for entry in focus_data:
                windows_visited.extend(entry["windows"])
                blacklist_sites.extend(entry["blacklist"])
                for window, tag in entry["classification"].items():
                    classification[window] = tag

                pdf.set_font("Courier", "B", 12)
                pdf.cell(0, 10, f"Windows Visited: ", ln=2, align='L')
                if not windows_visited:
                    pdf.set_font("Courier", "", 11)
                    pdf.cell(0, 10, "No windows visited", ln=2, align='L')
                else:
                    for window in windows_visited:
                        pdf.set_font("Courier", "", 11)
                        pdf.cell(0, 10, f"- {window}", ln=2, align='L')
                pdf.ln(5)
                pdf.set_font("Courier", "B", 12)
                pdf.cell(0, 10, f"Blacklist Sites: ", ln=2, align='L')
                if not blacklist_sites:
                    pdf.set_font("Courier", "", 11)
                    pdf.cell(0, 10, "No blacklisted sites visited", ln=2, align='L')
                else:
                    for blacklist in blacklist_sites:
                        pdf.set_font("Courier", "", 11)
                        pdf.cell(0, 10, f"- {blacklist}", ln=2, align='L')
                pdf.ln(5)
                pdf.set_font("Courier", "B", 12)
                pdf.cell(0, 10, f"Classification: ", ln=2, align='L')
                if not classification:
                    pdf.set_font("Courier", "", 11)
                    pdf.cell(0, 10, "No classification available", ln=2, align='L')
                else:
                    for window, tag in classification.items():
                        pdf.set_font("Courier", "", 11)
                        pdf.cell(0, 10, f"{window} - {tag}", ln=2, align='L')
                pdf.ln(5)

            assignments_assigned = db.query(Assignment).filter(Assignment.student_id == student.id, 
                                                               Assignment.assignment_date >= datetime.now() - timedelta(days=7),
                                                               Assignment.status == AssignmentStatus.assigned).all()

            assignments_submitted = (
                                    db.query(Assignment)
                                    .join(Submission, Submission.assignment_id == Assignment.id)
                                    .filter(Submission.submitted_at >= datetime.now() - timedelta(days=7),
                                            Submission.student_id == student.id)
                                    .distinct()
                                    .all()
                                )
            tasks_completed = db.query(Task).filter(Task.student_id == student.id,
                                                      Task.status == TaskStatusEnum.complete,
                                                      Task.due_date > datetime.now() - timedelta(days=7)).all()
            
            pdf.set_font("Courier", "", 11)
            pdf.set_x(start_x)
            pdf.cell(0, 10, f"Total assignment assigned this week: {len(assignments_assigned)}")
            pdf.ln()
            pdf.cell(0, 10, f"Total assignment submitted this week: {len(assignments_submitted)}")
            pdf.ln()
            pdf.cell(0, 10, f"Total tasks completed this week: {len(tasks_completed)}")
            pdf.ln()

            # Save to static/reports
            os.makedirs("static/reports", exist_ok=True)
            timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
            filename = f"weekly_report_{student_id}_{timestamp}.pdf"
            filepath = os.path.join("static/reports", filename)

            with open(filepath, 'wb'):
                pdf.output(filepath)

            # Save notification for parent
            message = "Your child’s weekly report is ready. Click to download."
            save_notification(parent.user_id, message, NotificationType.report, report_filename=filename) # type: ignore
    except Exception as e:
        print(f"[ERROR] Failed to generate report: {str(e)}")
        raise
    finally:
        db.close()

def save_notification(user_id: int, message: str, message_type: NotificationType, report_filename: str = ""):
    db = SessionLocal()
    try:
        notif = Notification(user_id=user_id, message=message, timestamp = datetime.now(), message_type=message_type, report_filename=report_filename)
        print(f"Saving notification: {notif}")
        db.add(notif)
        print("notification saved")
        db.commit()
    finally:
        db.close()

def parse_focus_summary_txt(file_path: str):
    try:
        with open(file_path, 'r') as f:
            content = f.read()

        def extract(pattern, cast: type = str, default=None):
            match = re.search(pattern, content)
            if not match:
                return default
            try:
                return cast(match.group(1).strip())
            except:
                return default

        # Core timings
        start_time_str = extract(r"Start:\s*(.+)", str, None)
        end_time_str = extract(r"End:\s*(.+)", str, None)
        total_duration_sec = extract(r"Total Time:\s*([\d.]+)\s*sec", float, 0.0)

        start_time = datetime.strptime(start_time_str, "%Y-%m-%d %H:%M:%S") if start_time_str else None
        end_time = datetime.strptime(end_time_str, "%Y-%m-%d %H:%M:%S") if end_time_str else None
        duration = round(total_duration_sec / 60, 2)

        # Windows visited
        window_section = re.search(r"==== TIME SPENT ON EACH WINDOW ====\n(.*?)(\n\n|$)", content, re.DOTALL)
        window_lines = window_section.group(1).strip().splitlines() if window_section else []
        windows_visited = []
        for line in window_lines:
            match = re.match(r"- (.+?):", line)
            if match:
                windows_visited.append(match.group(1).strip())

        tab_switches = len(windows_visited)

        # Keys per window
        key_section = re.search(r"==== KEYS PER WINDOW ====\n(.*?)(\n====|\Z)", content, re.DOTALL)
        keys_per_window = key_section.group(1).strip().splitlines() if key_section else []
        keys_map = {}
        for line in keys_per_window:
            if "→" in line:
                window, keys = line.split("→", 1)
                keys_map[window.strip()] = keys.strip()

        # Blacklist warnings
        blacklist_section = re.search(r"==== BLACKLIST WARNINGS ====\n(.*?)(\n====|\Z)", content, re.DOTALL)
        blacklist_lines = blacklist_section.group(1).strip().splitlines() if blacklist_section else []
        blacklisted_windows = []
        for line in blacklist_lines:
            if line.startswith("🚫"):
                blacklisted_windows.append(line[2:].strip())

        # Classification
        classification_section = re.search(r"==== CLASSIFICATION ====\n(.*?)(\nTotal Switches|\Z)", content, re.DOTALL)
        classifications = {}
        if classification_section:
            for line in classification_section.group(1).strip().splitlines():
                if "→" in line:
                    window, tag = line.split("→", 1)
                    classifications[window.strip()] = tag.strip()

        return {
            "start_time": start_time,
            "end_time": end_time,
            "duration": duration,
            "switches": tab_switches,
            "windows": windows_visited if windows_visited else None,
            "keys": keys_map if keys_map else None,
            "blacklist": blacklisted_windows if blacklisted_windows else None,
            "classification": classifications if classifications else None,
        }

    except Exception as e:
        print(f"[ERROR] Failed to parse {file_path}: {str(e)}")
        return None
