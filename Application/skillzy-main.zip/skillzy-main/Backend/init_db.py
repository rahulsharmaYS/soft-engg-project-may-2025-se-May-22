from auth import pwd_context
from datetime import datetime, timedelta
import random
from sqlalchemy.orm import Session
from extensions import SessionLocal, engine, SQLBase
from models import *

def generate_dummy_data(session):
    create_default_subjects(session)
    create_admin_user(session)

    # Create Badges
    badge_types = ["gold", "silver", "bronze", "participation", "achievement", "excellence", "creativity"]
    for i, btype in enumerate(badge_types, 1):
        badge = Badge(id=i, badge_type=btype)
        session.add(badge)
    session.commit()
  
    subjects = session.query(Subject).all()
    badges = session.query(Badge).all()

    for s_index in range(1, 4):  # 3 schools
        school = School(name=f"School_{s_index}", address=f"Address_{s_index}")
        session.add(school)
        session.commit()

        for c_index in range(1, 4):  # 3 classes per school
            classroom = Class(school_id=school.id, standard=6 + c_index, division=chr(64 + c_index))  # 6A, 7B, etc.
            session.add(classroom)
            session.commit()

            # Only 1 teacher per class
            t_index = 1
            user = User(
                email=f"teacher{s_index}{c_index}{t_index}@example.com",
                full_name=f"Teacher {s_index}{c_index}{t_index}",
                username=f"teacher{s_index}{c_index}{t_index}",
                password=pwd_context.hash("password"),
                role_name=RoleEnum.teacher,
                created_at=datetime.now(),
                user_status=UserStatus.active
            )
            session.add(user)
            session.commit()

            teacher = Teacher(
                user_id=user.id,
                class_id=classroom.id,
                subject_id=subjects[(t_index - 1) % len(subjects)].id
            )
            session.add(teacher)
            session.commit()

            for r_index in range(2):
                session.add(Resource(
                    title=f"Resource_{teacher.id}_{r_index}",
                    description=f"Resource desc {r_index}",
                    url=f"https://example.com/{teacher.id}/{r_index}",
                    category="General",
                    instructor_id=teacher.id
                ))

            for a_index in range(3):  # 3 assignments
                assignment = Assignment(
                    title=f"Assignment_{teacher.id}_{a_index}",
                    feedback=f"Feedback for {a_index}",
                    class_id=classroom.id,
                    teacher_id=teacher.id,
                    subject_id=teacher.subject_id,
                    assignment_created=datetime.now(),
                    assignment_deadline=datetime.now() + timedelta(days=7),
                    score=85,
                    question_type=QuestionType.multiple_choice,
                    status=AssignmentStatus.assigned
                )
                session.add(assignment)
                session.commit()

                for q_index in range(4):  # 4 questions per assignment
                    session.add(Question(
                        assignment_id=assignment.id,
                        question=f"What is {q_index} + {q_index}?",
                        option_1="A",
                        option_2="B",
                        option_3="C",
                        option_4="D",
                        descriptive_answer="This is a test answer.",
                        correct_answer="A"
                    ))

            for st_index in range(1, 6):  # 5 students
                user = User(
                    email=f"student{s_index}{c_index}{st_index}@example.com",
                    full_name=f"Student {s_index}{c_index}{st_index}",
                    username=f"student{s_index}{c_index}{st_index}",
                    password=pwd_context.hash("password"),
                    role_name=RoleEnum.student,
                    created_at=datetime.now(),
                    user_status=UserStatus.active
                )
                session.add(user)
                session.commit()

                student = Student(
                    user_id=user.id,
                    class_id=classroom.id,
                    subject_id=subjects[st_index % len(subjects)].id
                )
                student.subjects = subjects[:3]
                session.add(student)
                session.commit()

                # Add parent
                parent_user = User(
                    email=f"parent{s_index}{c_index}{st_index}@example.com",
                    full_name=f"Parent {s_index}{c_index}{st_index}",
                    username=f"parent{s_index}{c_index}{st_index}",
                    password=pwd_context.hash("password"),
                    role_name=RoleEnum.parent,
                    created_at=datetime.now(),
                    user_status=UserStatus.active
                )
                session.add(parent_user)
                session.commit()

                parent = Parent(user_id=parent_user.id, student_id=student.id)
                session.add(parent)

                # Add reward
                reward = Reward(
                    student_id=student.id,
                    parent_id=parent.id,
                    teacher_id=teacher.id,  # Link reward to the only teacher in the class
                    reward_points=50,
                    badge_id=badges[st_index % len(badges)].id
                )
                session.add(reward)

                # Add 2 tasks
                for tk in range(2):
                    session.add(Task(
                        title=f"Task_{student.id}_{tk}",
                        description="Do your homework",
                        student_id=student.id,
                        status=TaskStatusEnum.pending,
                        created_at=datetime.now(),
                        due_date=datetime.now() + timedelta(days=3)
                    ))

                # Add focus mode
                session.add(FocusMode(
                    student_id=student.id,
                    start_time=datetime.now(),
                    end_time=datetime.now() + timedelta(hours=1),
                    duration_minutes=60,
                    tab_switch_count=2
                ))

    session.commit()
    print("Dummy data inserted (1 teacher per class, no Faker).")

if __name__ == "__main__":
    SQLBase.metadata.create_all(bind=engine)
    #generate_dummy_data(session=SessionLocal())