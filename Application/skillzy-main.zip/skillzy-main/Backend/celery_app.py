# celery_app.py
from celery import Celery

celery_app = Celery(
    "fastapi_app",
    broker="redis://localhost:6379/0",
    backend="redis://localhost:6379/0"
)

celery_app.conf.update(
    timezone='Asia/Kolkata',
    enable_utc=False,
    task_serializer='json',
    result_serializer='json',
    accept_content=['json'],
    beat_schedule_filename='celerybeat-schedule.db',
    beat_schedule={
        'send_parent_pending_tasks_notification': {
            'task': 'send_parent_pending_tasks_notification',
            'schedule': 30.0, # Every day
        },
        'create_report_focus_mode': {
            'task': 'create_report_focus_mode',
            'schedule': 30.0,  # Every Day
        },
        'create_weekly_report': {
            'task': 'create_weekly_report',
            'schedule': 30.0,  # Every week
        },
    }
)

import tasks