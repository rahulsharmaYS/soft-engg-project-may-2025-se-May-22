"""
Automatic Badge System for Educational Platform
This module handles automatic badge awarding based on student activities and achievements.
"""

from sqlalchemy.orm import Session
from sqlalchemy import func, and_, desc
from datetime import datetime, timedelta
from typing import List, Dict
import logging

# Import your models - adjust the import based on your project structure
from models import (
    Student, Assignment, Task, FocusMode, 
    Badge, Reward, User, AssignmentStatus, TaskStatusEnum,
    BadgeTypeEnum, Subject, Score
)

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class BadgeSystem:
    """Automatic badge awarding system for students based on their activities and achievements"""
    
    def __init__(self, session: Session):
        self.session = session
        self._initialize_badges()
    
    def _initialize_badges(self):
        """Create default badges if they don't exist"""
        default_badges = [
            # Academic Excellence Badges
            {"badge_type": "Perfect Scholar", "description": "Score 100% on an assignment", "badge_points": 100},
            {"badge_type": "Academic Star", "description": "Score 95%+ on 5 assignments", "badge_points": 250},
            {"badge_type": "Subject Master", "description": "Maintain 90%+ in at least 20 assignments", "badge_points": 300},

            # Consistency Badges
            {"badge_type": "Streak Master", "description": "Active for 5 consecutive days" , "badge_points": 50},
            {"badge_type": "Dedication Champion", "description": "Active for 10 consecutive days", "badge_points": 100},
            {"badge_type": "Persistent Learner", "description": "Active for 30 consecutive days", "badge_points": 200},

            # Task Management Badges
            {"badge_type": "Task Completionist", "description": "Complete 10 tasks", "badge_points": 75},
            {"badge_type": "Task Master", "description": "Complete 50 tasks", "badge_points": 200},
            {"badge_type": "Time Manager", "description": "Complete 5 tasks before deadline", "badge_points": 100},
            {"badge_type": "Early Bird", "description": "Submit 10 assignments early", "badge_points": 150},
            
            # Focus Mode Badges
            {"badge_type": "Focus Novice", "description": "Complete 5 focus sessions", "badge_points": 50},
            {"badge_type": "Focus Expert", "description": "Complete 25 focus sessions", "badge_points": 150},
            {"badge_type": "Concentration Master", "description": "Complete 2-hour focus session", "badge_points": 200},
            {"badge_type": "Distraction Fighter", "description": "Focus session with <5 tab switches", "badge_points": 100},

            # Special Achievement Badges
            {"badge_type": "Explorer", "description": "Complete nature/outdoor assignment", "badge_points": 75},
            {"badge_type": "Creative Genius", "description": "Score 100% on creative assignment", "badge_points": 100},
            {"badge_type": "Problem Solver", "description": "Complete problem-solving assignment", "badge_points": 100},
            {"badge_type": "Health Champion", "description": "Complete health-related assignment", "badge_points": 75},
            {"badge_type": "Financial Wizard", "description": "Excel in financial literacy", "badge_points": 75},
            {"badge_type": "Communication Expert", "description": "Excel in communication skills", "badge_points": 75},

            # Progressive Badges (Gold, Silver, Bronze)
            {"badge_type": "Bronze Achiever", "description": "Earn first 3 badges", "badge_points": 100},
            {"badge_type": "Silver Achiever", "description": "Earn 10 badges", "badge_points": 300},
            {"badge_type": "Gold Achiever", "description": "Earn 25 badges", "badge_points": 500},

            # Special Recognition
            {"badge_type": "Improvement Star", "description": "Show 20% improvement in scores", "badge_points": 150},
            {"badge_type": "Participation Champion", "description": "100% assignment submission rate", "badge_points": 200},
            {"badge_type": "Excellence Award", "description": "Top 10% of class performance", "badge_points": 400},

            # Custom Badges
            {"badge_type": "First Step", "description": "First assignment submitted", "badge_points": 100},
            {"badge_type": "Laser Focused", "description": "Completed 20+ min focus session", "badge_points": 200},
            {"badge_type": "Task Ninja", "description": "Complete 100 tasks", "badge_points": 400},
        ]
        
        for badge_info in default_badges:
            existing_badge = self.session.query(Badge).filter_by(
                badge_type=badge_info["badge_type"],
                # description=badge_info["description"],
                badge_points=badge_info["badge_points"]
            ).first()
            
            if not existing_badge:
                badge = Badge(badge_type=badge_info["badge_type"], badge_points=badge_info["badge_points"])
                self.session.add(badge)
        
        try:
            self.session.commit()
            logger.info("Badge system initialized with default badges")
        except Exception as e:
            logger.error(f"Error initializing badges: {e}")
            self.session.rollback()
    
    def award_badge(self, student_id: int, badge_type: str, awarded_by: str = "system") -> bool:
        """Award a badge to a student if they don't already have it"""
        try:
            # Check if student already has this badge
            existing_reward = self.session.query(Reward).join(Badge).filter(
                and_(
                    Reward.student_id == student_id,
                    Badge.badge_type == badge_type
                )
            ).first()
            
            if existing_reward:
                logger.info(f"Student {student_id} already has badge: {badge_type}")
                return False
            
            # Get the badge
            badge = self.session.query(Badge).filter_by(badge_type=badge_type).first()
            if not badge:
                logger.error(f"Badge not found: {badge_type}")
                return False
            
            # Create reward entry
            reward = Reward(
                student_id=student_id,
                badge_id=badge.id,
                reward_points=self._get_badge_points(badge_type)
            )
            
            self.session.add(reward)
            self.session.commit()
            
            logger.info(f"Awarded '{badge_type}' badge to student {student_id}")
            return True
            
        except Exception as e:
            logger.error(f"Error awarding badge {badge_type} to student {student_id}: {e}")
            self.session.rollback()
            return False
    
    def _get_badge_points(self, badge_type: str) -> int:
        """Get points for different badge types"""
        points_map = {
            # Academic badges
            "Perfect Scholar": 100,
            "Academic Star": 250,
            "Subject Master": 300,
            
            # Consistency badges
            "Streak Master": 50,
            "Dedication Champion": 100,
            "Persistent Learner": 200,
            
            # Task badges
            "Task Completionist": 75,
            "Task Master": 200,
            "Time Manager": 100,
            "Early Bird": 150,
            
            # Focus badges
            "Focus Novice": 50,
            "Focus Expert": 150,
            "Concentration Master": 200,
            "Distraction Fighter": 100,
            
            # Special badges
            "Explorer": 75,
            "Creative Genius": 100,
            "Problem Solver": 100,
            "Health Champion": 75,
            "Financial Wizard": 75,
            "Communication Expert": 75,
            
            # Achievement levels
            "Bronze Achiever": 100,
            "Silver Achiever": 300,
            "Gold Achiever": 500,
            
            # Recognition
            "Improvement Star": 150,
            "Participation Champion": 200,
            "Excellence Award": 400,

            # custom badges 
            "First Step": 100,
            "Laser Focused": 200,
            "Task Ninja": 400
        }
        return points_map.get(badge_type, 0)
    
    def check_assignment_badges(self, student_id: int):
        """Check and award assignment-related badges"""
        try:
            student_assignments = self.session.query(Score).filter_by(
                student_id=student_id
            ).all()
            if not student_assignments:
                return
            print("yes sir!")
            # Perfect Scholar - 100% on any assignment
            perfect_scores = [sa for sa in student_assignments if sa.percentage == 100]
            print("heeeree")
            if perfect_scores:
                self.award_badge(student_id, "Perfect Scholar")
            
            # Academic Star - 95%+ on 5 assignments
            high_scores = [sa for sa in student_assignments if sa.percentage and sa.percentage >= 95]
            if len(high_scores) >= 5:
                self.award_badge(student_id, "Academic Star")
            
            # Early Bird - Submit 10 assignments early
            early_submissions = []
            for sa in student_assignments:
                if sa.submission_date and sa.assignment.assignment_deadline:
                    if sa.submission_date < sa.assignment.assignment_deadline:
                        early_submissions.append(sa)
            
            if len(early_submissions) >= 10:
                self.award_badge(student_id, "Early Bird")
            
            # Subject-specific badges
            self._check_subject_badges(student_id, student_assignments)
            
            # Participation Champion - Check submission rate
            self._check_participation_badge(student_id)
            
        except Exception as e:
            logger.error(f"Error checking assignment badges for student {student_id}: {e}")
    
    def _check_participation_badge(self, student_id: int):
        """Check participation champion badge"""
        try:
            # Get total assignments available to student
            total_assignments = self.session.query(Assignment).join(
                Assignment.students
            ).filter(Student.id == student_id).count()
            
            # Get student's submissions
            submitted_assignments = self.session.query(Assignment).filter_by(
                student_id=student_id
            ).count()
            
            if total_assignments > 0:
                submission_rate = submitted_assignments / total_assignments
                if submission_rate >= 1.0:  # 100% submission rate
                    self.award_badge(student_id, "Participation Champion")
                    
        except Exception as e:
            logger.error(f"Error checking participation badge for student {student_id}: {e}")
    
    def _check_subject_badges(self, student_id: int, student_assignments: List[Assignment]):
        """Check for subject-specific badges"""
        try:
            subject_scores = {}
            
            for sa in student_assignments:
                if sa.score and sa.assignment.subject_id:
                    subject_id = sa.assignment.subject_id
                    if subject_id not in subject_scores:
                        subject_scores[subject_id] = []
                    subject_scores[subject_id].append(sa.score)
            
            # Check for subject mastery (90%+ average)
            for subject_id, scores in subject_scores.items():
                if len(scores) >= 3:  # At least 3 assignments
                    avg_score = sum(scores) / len(scores)
                    if avg_score >= 90:
                        self.award_badge(student_id, "Subject Master")
            
            # Special subject badges based on assignment titles
            for sa in student_assignments:
                if sa.score == 100 and sa.assignment.title:
                    title_lower = sa.assignment.title.lower()
                    
                    if any(word in title_lower for word in ["nature", "outdoor", "trek", "explore", "hiking", "camping"]):
                        self.award_badge(student_id, "Explorer")
                    elif any(word in title_lower for word in ["creative", "art", "design", "imagination"]):
                        self.award_badge(student_id, "Creative Genius")
                    elif "problem" in title_lower and "solving" in title_lower:
                        self.award_badge(student_id, "Problem Solver")
                    elif "health" in title_lower:
                        self.award_badge(student_id, "Health Champion")
                    elif "financial" in title_lower:
                        self.award_badge(student_id, "Financial Wizard")
                    elif "communication" in title_lower:
                        self.award_badge(student_id, "Communication Expert")
                        
        except Exception as e:
            logger.error(f"Error checking subject badges for student {student_id}: {e}")
    
    def check_activity_badges(self, student_id: int):
        """Check and award activity-based badges"""
        try:
            # Get recent assignment submissions as activity indicator
            recent_submissions = self.session.query(Assignment).filter(
                and_(
                    Assignment.student_id == student_id,
                    Assignment.submission_date >= datetime.now() - timedelta(days=30)
                )
            ).count()
            
            if recent_submissions >= 5:
                self.award_badge(student_id, "Streak Master")
            if recent_submissions >= 10:
                self.award_badge(student_id, "Dedication Champion")
            if recent_submissions >= 30:
                self.award_badge(student_id, "Persistent Learner")
                
        except Exception as e:
            logger.error(f"Error checking activity badges for student {student_id}: {e}")
    
    def check_task_badges(self, student_id: int):
        """Check and award task-related badges"""
        try:
            completed_tasks = self.session.query(Task).filter(
                and_(
                    Task.student_id == student_id,
                    Task.status == TaskStatusEnum.complete
                )
            ).all()
             
            # Task completion badges
            if len(completed_tasks) >= 10:
                self.award_badge(student_id, "Task Completionist")
            if len(completed_tasks) >= 50:
                self.award_badge(student_id, "Task Master")
            
            # Time management badge - tasks completed before deadline
            early_tasks = [
                task for task in completed_tasks
                if task.created_at and task.due_date and task.created_at < task.due_date
            ]
            
            if len(early_tasks) >= 5:
                self.award_badge(student_id, "Time Manager")
                
        except Exception as e:
            logger.error(f"Error checking task badges for student {student_id}: {e}")
    
    def check_focus_mode_badges(self, student_id: int):
        """Check and award focus mode badges"""
        try:
            focus_sessions = self.session.query(FocusMode).filter_by(student_id=student_id).all()
            
            # Focus session count badges
            if len(focus_sessions) >= 5:
                self.award_badge(student_id, "Focus Novice")
            if len(focus_sessions) >= 25:
                self.award_badge(student_id, "Focus Expert")
            
            # Long focus session badge
            for session in focus_sessions:
                if session.duration_minutes >= 120:  # 2 hours
                    self.award_badge(student_id, "Concentration Master")
                    break
            
            # Low distraction badge
            for session in focus_sessions:
                if session.tab_switch_count <= 5:
                    self.award_badge(student_id, "Distraction Fighter")
                    break
                    
        except Exception as e:
            logger.error(f"Error checking focus mode badges for student {student_id}: {e}")
    
    def check_achievement_level_badges(self, student_id: int):
        """Check and award progressive achievement badges"""
        try:
            total_badges = self.session.query(Reward).filter_by(student_id=student_id).count()
            
            if total_badges >= 3:
                self.award_badge(student_id, "Bronze Achiever")
            if total_badges >= 10:
                self.award_badge(student_id, "Silver Achiever")
            if total_badges >= 25:
                self.award_badge(student_id, "Gold Achiever")
                
        except Exception as e:
            logger.error(f"Error checking achievement level badges for student {student_id}: {e}")
    
    def check_improvement_badges(self, student_id: int):
        """Check for improvement-based badges"""
        try:
            # Get student's assignment scores over time
            assignments = self.session.query(Assignment).filter_by(
                student_id=student_id
            ).order_by(Assignment.submission_date).all()
            
            if len(assignments) >= 5:
                # Compare first 3 and last 3 assignments
                early_scores = [a.score for a in assignments[:3] if a.score]
                recent_scores = [a.score for a in assignments[-3:] if a.score]
                
                if early_scores and recent_scores:
                    early_avg = sum(early_scores) / len(early_scores)
                    recent_avg = sum(recent_scores) / len(recent_scores)
                    
                    if recent_avg > early_avg * 1.2:  # 20% improvement
                        self.award_badge(student_id, "Improvement Star")
                        
        except Exception as e:
            logger.error(f"Error checking improvement badges for student {student_id}: {e}")
    
    def run_badge_check_for_student(self, student_id: int):
        """Run all badge checks for a specific student"""
        logger.info(f"Running badge checks for student {student_id}")
        
        try:
            self.check_assignment_badges(student_id)
            self.check_activity_badges(student_id)
            self.check_task_badges(student_id)
            self.check_focus_mode_badges(student_id)
            self.check_improvement_badges(student_id)
            self.check_achievement_level_badges(student_id)
            
            logger.info(f"Badge check completed for student {student_id}")
        except Exception as e:
            logger.error(f"Error during badge check for student {student_id}: {e}")
    
    # def run_badge_check_for_all_students(self):
    #     """Run badge checks for all active students"""
    #     try:
    #         students = self.session.query(Student).join(User).filter(
    #             User.user_status == "active"
    #         ).all()
            
    #         logger.info(f"Running badge checks for {len(students)} students")
            
    #         for student in students:
    #             self.run_badge_check_for_student(student.id)
            
    #         logger.info("Badge check completed for all students")
    #     except Exception as e:
    #         logger.error(f"Error running badge checks for all students: {e}")
    def run_badge_check_for_student(self, student_id: int):
        logger.info(f"Running badge checks for student {student_id}")
        try:
            self.check_assignment_badges(student_id)
            self.check_activity_badges(student_id)
            self.check_task_badges(student_id)
            self.check_focus_mode_badges(student_id)
            self.check_improvement_badges(student_id)
            self.check_achievement_level_badges(student_id)
            self.award_custom_badges(student_id)  # ← custom logic
            logger.info(f"Badge check completed for student {student_id}")
        except Exception as e:
            logger.error(f"Error during badge check for student {student_id}: {e}")

    
    # custom badge shit
    def award_custom_badges(self, student_id: int):
        """Award additional custom badges (like First Step, Laser Focused)"""
        try:
            # First Step
            submitted_assignments = self.session.query(Score).filter_by(student_id=student_id).count()
            if submitted_assignments >= 1:
                self.award_badge(student_id, "First Step")

            # Laser Focused
            long_focus_sessions = self.session.query(FocusMode).filter(
                FocusMode.student_id == student_id,
                FocusMode.duration_minutes >= 20
            ).count()
            if long_focus_sessions >= 1:
                self.award_badge(student_id, "Laser Focused")

            # Task Ninja
            completed_tasks = self.session.query(Task).filter_by(student_id=student_id, status="completed").count()
            if completed_tasks >= 100:
                self.award_badge(student_id, "Task Ninja")

        except Exception as e:
            logger.error(f"Error awarding custom badges to student {student_id}: {e}")


    
    def get_student_badges(self, student_id: int) -> List[Dict]:
        """Get all badges earned by a student"""
        try:
            badges = self.session.query(Badge, Reward).join(Reward).filter(
                Reward.student_id == student_id
            ).all()
            
            result = []
            for badge, reward in badges:
                result.append({
                    "badge_type": badge.badge_type,
                    "points": reward.reward_points,
                    "badge_id": badge.id
                })
            
            return result
        except Exception as e:
            logger.error(f"Error getting badges for student {student_id}: {e}")
            return []
    
    def get_student_total_points(self, student_id: int) -> int:
        """Get total badge points for a student"""
        try:
            total = self.session.query(func.sum(Reward.reward_points)).filter_by(
                student_id=student_id
            ).scalar()
            
            return total or 0
        except Exception as e:
            logger.error(f"Error getting total points for student {student_id}: {e}")
            return 0


# Event handler functions - Call these from your main application
def on_assignment_submission(student_id: int, session: Session):
    """Call this when a student submits an assignment"""
    try:
        badge_system = BadgeSystem(session)
        badge_system.check_assignment_badges(student_id)
        badge_system.check_achievement_level_badges(student_id)
        badge_system.check_improvement_badges(student_id)
        logger.info(f"Assignment submission badge check completed for student {student_id}")
    except Exception as e:
        logger.error(f"Error in assignment submission handler: {e}")

def on_task_completion(student_id: int, session: Session):
    """Call this when a student completes a task"""
    try:
        badge_system = BadgeSystem(session)
        badge_system.check_task_badges(student_id)
        badge_system.check_achievement_level_badges(student_id)
        logger.info(f"Task completion badge check completed for student {student_id}")
    except Exception as e:
        logger.error(f"Error in task completion handler: {e}")

def on_focus_session_end(student_id: int, session: Session):
    """Call this when a focus session ends"""
    try:
        badge_system = BadgeSystem(session)
        badge_system.check_focus_mode_badges(student_id)
        badge_system.check_achievement_level_badges(student_id)
        logger.info(f"Focus session badge check completed for student {student_id}")
    except Exception as e:
        logger.error(f"Error in focus session handler: {e}")

def on_daily_activity(student_id: int, session: Session):
    """Call this daily for active students"""
    try:
        badge_system = BadgeSystem(session)
        badge_system.check_activity_badges(student_id)
        logger.info(f"Daily activity badge check completed for student {student_id}")
    except Exception as e:
        logger.error(f"Error in daily activity handler: {e}")

def get_student_badge_summary(student_id: int, session: Session) -> Dict:
    """Get complete badge summary for a student"""
    try:
        badge_system = BadgeSystem(session)
        badges = badge_system.get_student_badges(student_id)
        total_points = badge_system.get_student_total_points(student_id)
        
        return {
            "student_id": student_id,
            "total_badges": len(badges),
            "total_points": total_points,
            "badges": badges
        }
    except Exception as e:
        logger.error(f"Error getting badge summary for student {student_id}: {e}")
        return {"student_id": student_id, "total_badges": 0, "total_points": 0, "badges": []}

# Setup and utility functions
def setup_automatic_badge_system(session: Session):
    """Setup the automatic badge system"""
    try:
        badge_system = BadgeSystem(session)
        logger.info("Automatic badge system is ready!")
        return badge_system
    except Exception as e:
        logger.error(f"Error setting up badge system: {e}")
        return None

def daily_badge_check(session: Session):
    """Daily badge check - run this as a scheduled task"""
    try:
        badge_system = BadgeSystem(session)
        badge_system.run_badge_check_for_all_students()
        logger.info("Daily badge check completed successfully")
    except Exception as e:
        logger.error(f"Error in daily badge check: {e}")

# Awarding Badges and giving em
def award_badge_if_eligible(session, student_id):
    student = session.query(Student).get(student_id)

    # Example 1: First Assignment Submitted
    submitted_assignments = session.query(Score).filter_by(student_id=student_id).count()
    if submitted_assignments >= 1:
        give_badge(session, student_id, "First Step", points=50)

    # Example 2: Focus sessions longer than 20 mins
    long_focus = session.query(FocusMode).filter(
        FocusMode.student_id==student_id,
        FocusMode.duration_minutes >= 20
    ).count()
    if long_focus >= 1:
        give_badge(session, student_id, "Laser Focused", points=30)

def give_badge(session, student_id, badge_name, points):
    badge = session.query(Badge).filter_by(badge_type=badge_name).first()
    if not badge:
        badge = Badge(badge_type=badge_name)
        session.add(badge)
        session.commit()
    
    already_rewarded = session.query(Reward).filter_by(
        student_id=student_id, badge_id=badge.id
    ).first()
    
    if not already_rewarded:
        reward = Reward(
            student_id=student_id,
            teacher_id=None,  # optional
            parent_id=None,   # optional
            reward_points=points,
            badge_id=badge.id
        )
        session.add(reward)
        session.commit()

# Initialize badge system when module is imported
def init_badge_system(session: Session):
    """Initialize badge system - call this once during application startup"""
    return setup_automatic_badge_system(session)