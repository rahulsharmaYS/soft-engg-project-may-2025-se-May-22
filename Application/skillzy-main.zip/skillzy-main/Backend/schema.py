from pydantic import BaseModel, EmailStr, HttpUrl, AnyHttpUrl, Field
from typing import Literal, Optional
from datetime import datetime
from fastapi import APIRouter, HTTPException, Depends, Query, Form, UploadFile, File
from models import RoleEnum, UserStatus, QuestionType, TaskStatusEnum

class ORMBase(BaseModel):
    model_config = {
        "from_attributes": True  # Pydantic v2 replaces orm_mode
    }
    __allow_unmapped__ = True

class EditProfileRequest(ORMBase):
    full_name: str
    email: EmailStr
    profile_picture: str

class ResourceCreate(ORMBase):
    title: str
    description: str
    url: Optional[AnyHttpUrl] = None
    file: Optional[UploadFile] = File(None)
    category: Literal["student", "instructor"]

class ResourceOut(ORMBase):
    id: int
    title: str
    description: str
    url: Optional[str]
    file: Optional[UploadFile] = File(None)
    file_path: Optional[str] = None
    category: str
    instructor_id: int

    class Config:
        from_attributes = True

class ResourceResponse(ORMBase):
    message: str
    resource: ResourceOut

class AssignmentCreate(ORMBase):
    title: str
    description: Optional[str] = None
    assignment_deadline: datetime
    score: Optional[int] = 0
    question_type: QuestionType

class QuestionCreate(ORMBase):
    question: str
    option_1: Optional[str] = None
    option_2: Optional[str] = None
    option_3: Optional[str] = None
    option_4: Optional[str] = None
    correct_answer: Optional[str] = None
    descriptive_answer: Optional[str] = None

class ClassSchema(ORMBase):
    id: int
    standard: int
    division: str

class UserSchema(ORMBase):
    id: int
    email: str
    full_name: str
    username: str
    role_name: RoleEnum
    profile_picture: Optional[str]
    created_at: datetime
    user_status: UserStatus

class ParentSchema(ORMBase):
    id: int
    user_id: int
    student_id: int
    user: UserSchema

class StudentSchema(ORMBase):
    id: int
    user_id: int
    user: UserSchema

class TaskSchema(ORMBase):
    id: int
    title: str
    description: str
    student_id: int
    status: TaskStatusEnum
    created_at: datetime
    due_date: datetime

class AssignmentSchema(ORMBase):
    id: int
    title: str
    teacher_id: int
    assignment_created: datetime
    assignment_deadline: datetime
    question_type: QuestionType

class ChangePasswordRequest(BaseModel):
    current_password: str
    new_password: str
