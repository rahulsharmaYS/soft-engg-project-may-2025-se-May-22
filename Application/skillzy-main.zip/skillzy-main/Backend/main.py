from fastapi import FastAPI
from routes.parents import parent_router
from routes.user import login_router
from routes.students import student_router
from routes.teachers import teacher_router
from routes.admin import admin_router
from routes.chat_message import chat_poll_router
from extensions import *
from models import create_admin_user, create_default_subjects, SQLBase
from badge_system import init_badge_system
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
import os
from sqlalchemy import inspect
from chat_bot import chatbot_router

origins = [
    "http://localhost:5173",
    "http://127.0.0.1:5173",
    "http://localhost:5174",
    "http://127.0.0.1:5174"
]

app = FastAPI()
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

def initialize_database():
    try:
        inspector = inspect(engine)
        existing_tables = inspector.get_table_names()
        
        if not existing_tables:
            SQLBase.metadata.create_all(bind=engine)
            create_admin_user(session=SessionLocal())
            create_default_subjects(session=SessionLocal())
        else:
            print(f"Database already exists with {len(existing_tables)} tables")
            
    except Exception as e:
        print(f"Database initialization failed: {e}")
        raise

initialize_database()


# added that just to check the initialization of badges (remove if something is extra)
session = SessionLocal()
try:
    init_badge_system(session)
    print("Badge system initialized successfully.")
finally:
    session.close()
    print("Session closed.")

app.include_router(parent_router)
app.include_router(student_router)
app.include_router(teacher_router)
app.include_router(login_router)
app.include_router(admin_router)
app.include_router(chatbot_router)

# Mount static files for resource downloads
app.mount("/static", StaticFiles(directory="static"), name="static")

app.include_router(chat_poll_router)

import tasks