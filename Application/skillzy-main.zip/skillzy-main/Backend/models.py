from sqlalchemy import Column, Integer, String, Text, ForeignKey, DateTime, Enum, Table,Boolean,Float
from sqlalchemy.orm import relationship
from datetime import date, datetime
import enum
from extensions import SQLBase 

class SQLBaseModel(SQLBase):
    __abstract__ = True  # Prevents table creation for this class

    def to_dict(self, include_relationships=False):
        """Convert model instance to dictionary, handling date serialization."""
        if not hasattr(self, '__table__') or not hasattr(self, '__mapper__'):
            raise TypeError("BaseModel should not be used directly. Inherit and define a concrete model.")

        result = {}

        for column in self.__table__.columns:  # type: ignore
            value = getattr(self, column.name)

            # Convert `date` and `datetime` objects to string
            if isinstance(value, (date, datetime)):
                result[column.name] = value.isoformat()  # Converts to "YYYY-MM-DD" or "YYYY-MM-DDTHH:MM:SS"
            else:
                result[column.name] = value

        if include_relationships:
            for relationship in self.__mapper__.relationships:  # type: ignore
                related_obj = getattr(self, relationship.key)
                if related_obj is None:
                    result[relationship.key] = None
                elif isinstance(related_obj, list):
                    result[relationship.key] = [obj.to_dict() for obj in related_obj]
                else:
                    result[relationship.key] = related_obj.to_dict()
        return result

student_teacher_subject = Table(
    'student_teacher_subject',
    SQLBaseModel.metadata,
    Column('student_id', Integer, ForeignKey('students.id'), primary_key=True),
    Column('subject_id', Integer, ForeignKey('subjects.id'), primary_key=True),
    Column('teacher_id', Integer, ForeignKey('teachers.id'), primary_key=True)
)


student_subject = Table(
    'student_subject',
    SQLBaseModel.metadata,
    Column('student_id', Integer, ForeignKey('students.id')),
    Column('subject_id', Integer, ForeignKey('subjects.id')),
)

class RoleEnum(enum.Enum):
    student = "student"
    teacher = "teacher"
    parent = "parent"
    admin = "admin"

class TaskStatusEnum(enum.Enum):
    pending = "pending"
    complete = "complete"
    overdue = "overdue"

class DivisonEnum(enum.Enum):
    A = "A"
    B = "B"
    C = "C"
    D = "D"
    E = "E"
    F = "F"

class BadgeTypeEnum(enum.Enum):
    gold = "gold"
    silver = "silver"
    bronze = "bronze"
    participation = "participation"
    achievement = "achievement"
    excellence = "excellence"
    creativity = "creativity"

class UserStatus(enum.Enum):
    active = "active"
    inactive = "inactive"
    suspended = "suspended"

class QuestionType(enum.Enum):
    multiple_choice = "multiple_choice"
    text = "text"

class AssignmentStatus(enum.Enum):
    assigned = "assigned"
    pending = "pending"
    submitted = "submitted"
    graded = "graded"

class ScoreStatus(enum.Enum):
    pending = "pending"
    graded = "graded"
    reviewed = "reviewed"

class NotificationType(enum.Enum):
    pending_tasks_assignments = "pending_tasks_assignments"
    score_update = "score_update"
    report = "report"

class User(SQLBaseModel):
    __tablename__ = 'users'
    id = Column(Integer, primary_key=True)
    email = Column(String, unique=True, nullable=False)
    full_name = Column(String, nullable=False)
    username = Column(String, unique=True, nullable=False)
    password = Column(String, nullable=False)
    role_name = Column(Enum(RoleEnum), nullable=False)
    profile_picture = Column(String)
    created_at = Column(DateTime)
    user_status = Column(Enum(UserStatus), default=UserStatus.active)
    profile_picture = Column(String, nullable=True)

    student_profile = relationship("Student", back_populates="user", uselist=False)
    teacher_profile = relationship("Teacher", back_populates="user", uselist=False)
    parent_profile = relationship("Parent", back_populates="user", uselist=False)
    notifications = relationship("Notification", back_populates="user")
    reports = relationship("Report", back_populates="user")
    sent_messages = relationship("ChatMessage", foreign_keys='ChatMessage.sender_id', back_populates="sender")
    received_messages = relationship("ChatMessage", foreign_keys='ChatMessage.receiver_id', back_populates="receiver")

def create_default_subjects(session):
    default_subjects = [
        {"id": 1, "name": "Time Management"},
        {"id": 2, "name": "Communication"},
        {"id": 3, "name": "Health"},
        {"id": 4, "name": "Decision Making"},
        {"id": 5, "name": "Financial Literacy"},
        {"id": 6, "name": "Problem Solving"},
        {"id": 7, "name": "Emotion Theory"},
    ]

    for subj in default_subjects:
        existing = session.query(Subject).filter_by(name=subj["name"]).first()
        if not existing:
            new_subject = Subject(id=subj["id"], name=subj["name"], description=subj["name"])
            session.add(new_subject)

    session.commit()
    print("Default subjects created")

def create_admin_user(session):
    """Create admin user with password '123'"""
    # Check if admin already exists
    from auth import pwd_context
    existing_admin = session.query(User).filter_by(username="admin").first()
    if not existing_admin:
        admin_user = User(
            email="admin@example.com",
            full_name="Administrator",
            username="admin",
            password=pwd_context.hash("123"),  # Use hashed password
            role_name=RoleEnum.admin,
            created_at=datetime.now())
        session.add(admin_user)
        session.commit()
        print("hurray we did it")
        print('passwrod is 123')

class School(SQLBaseModel):
    __tablename__ = 'schools'
    id = Column(Integer, primary_key=True)
    name = Column(String, unique=True, nullable=False)
    address = Column(String)

    classes = relationship("Class", back_populates="school")

class Class(SQLBaseModel):
    __tablename__ = 'class'
    id = Column(Integer, primary_key=True)
    school_id = Column(Integer, ForeignKey('schools.id'))
    standard = Column(Integer)
    division = Column(String)

    school = relationship("School", back_populates="classes")
    students = relationship("Student", back_populates="classroom")
    teachers = relationship("Teacher", back_populates="classroom") 
    assignments = relationship("Assignment", back_populates="classroom")

class Subject(SQLBaseModel):
    __tablename__ = 'subjects'
    id = Column(Integer, primary_key=True)
    name = Column(String, unique=True, nullable=False)
    description = Column(Text)

    teachers = relationship("Teacher", back_populates="subject")
    students = relationship("Student", secondary=student_subject, back_populates="subjects")

class Student(SQLBaseModel):
    __tablename__ = 'students'
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'))
    class_id = Column(Integer, ForeignKey('class.id'))
    user = relationship("User", back_populates="student_profile")
    classroom = relationship("Class", back_populates="students")
    subjects = relationship("Subject", secondary=student_subject, back_populates="students")
    subject_id = Column(Integer, ForeignKey('subjects.id'))
    parent = relationship("Parent", back_populates="student", uselist=False)
    rewards = relationship("Reward", back_populates="student")
    tasks = relationship("Task", back_populates="student")
    focus_modes = relationship("FocusMode", back_populates="student")
    direct_assignments = relationship("Assignment", back_populates="assigned_student")
    submissions = relationship("Submission", back_populates="student")
    scores = relationship("Score", back_populates="student")
    chosen_teachers = relationship("Teacher",secondary=student_teacher_subject,back_populates="assigned_students")

class Teacher(SQLBaseModel):
    __tablename__ = 'teachers'
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'))
    class_id = Column(Integer, ForeignKey('class.id'))
    subject_id = Column(Integer, ForeignKey('subjects.id'))
    experience = Column(String, primary_key=False)
    number = Column(String, nullable=True)
    assigned_students = relationship("Student",secondary=student_teacher_subject,back_populates="chosen_teachers")
    user = relationship("User", back_populates="teacher_profile")
    classroom = relationship("Class", back_populates="teachers")
    subject = relationship("Subject", back_populates="teachers")
    assignments = relationship("Assignment", back_populates="teacher")
    rewards = relationship("Reward", back_populates="teacher")
    resources = relationship("Resource", back_populates="instructor")
    

class Parent(SQLBaseModel):
    __tablename__ = 'parents'
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'))
    student_id = Column(Integer, ForeignKey('students.id'))
    number = Column(String, nullable=True)

    user = relationship("User", back_populates="parent_profile")
    student = relationship("Student", back_populates="parent")
    rewards = relationship("Reward", back_populates="parent")

class Assignment(SQLBaseModel):
    __tablename__ = 'assignments'
    id = Column(Integer, primary_key=True)
    title = Column(String)
    feedback = Column(Text)
    teacher_id = Column(Integer, ForeignKey('teachers.id'))
    class_id = Column(Integer, ForeignKey('class.id'), nullable=True)
    student_id = Column(Integer, ForeignKey('students.id'), nullable=True)  # Make nullable for class-wide assignments
    subject_id = Column(Integer, ForeignKey('subjects.id'))  # Add if assignments belong to subjects
    assignment_created = Column(DateTime)
    assignment_deadline = Column(DateTime)
    question_type = Column(Enum(QuestionType), nullable=False)
    status = Column(Enum(AssignmentStatus), default=AssignmentStatus.pending)
    teacher = relationship("Teacher", back_populates="assignments")
    questions = relationship("Question", back_populates="assignment")
    classroom = relationship("Class", back_populates="assignments") 
    assigned_student = relationship("Student", back_populates="direct_assignments")
    max_score = Column(Integer, default=100)
    scores = relationship("Score", back_populates="assignment")

class Question(SQLBaseModel):
    __tablename__ = 'questions'
    id = Column(Integer, primary_key=True)
    assignment_id = Column(Integer, ForeignKey('assignments.id'))
    question = Column(Text)
    option_1 = Column(String)
    option_2 = Column(String)
    option_3 = Column(String)
    option_4 = Column(String)
    descriptive_answer = Column(Text)
    correct_answer = Column(String)
    points = Column(Integer, default=1)
    assignment = relationship("Assignment", back_populates="questions")

class Score(SQLBaseModel):
    __tablename__ = 'scores'
    id = Column(Integer, primary_key=True)
    student_id = Column(Integer, ForeignKey('students.id'), nullable=False)
    assignment_id = Column(Integer, ForeignKey('assignments.id'), nullable=False)
    score = Column(Float, nullable=False) 
    max_score = Column(Integer, nullable=False)  
    percentage = Column(Float) 
    attempt_number = Column(Integer, default=1) 
    status = Column(Enum(ScoreStatus), default=ScoreStatus.pending)
    graded_by = Column(Integer, ForeignKey('teachers.id'), nullable=True)  
    graded_at = Column(DateTime)
    feedback = Column(Text)  
    submitted_at = Column(DateTime, default=datetime.utcnow)
    student = relationship("Student", back_populates="scores")
    assignment = relationship("Assignment", back_populates="scores")
    grader = relationship("Teacher", foreign_keys=[graded_by])

class Reward(SQLBaseModel):
    __tablename__ = 'rewards'
    id = Column(Integer, primary_key=True)
    student_id = Column(Integer, ForeignKey('students.id'))
    teacher_id = Column(Integer, ForeignKey('teachers.id'))
    parent_id = Column(Integer, ForeignKey('parents.id'))
    reward_points = Column(Integer)
    badge_id = Column(Integer, ForeignKey('badges.id'))

    student = relationship("Student", back_populates="rewards")
    teacher = relationship("Teacher", back_populates="rewards")
    parent = relationship("Parent", back_populates="rewards")
    badge = relationship("Badge", back_populates="rewards")

class Badge(SQLBaseModel):
    __tablename__ = 'badges'
    id = Column(Integer, primary_key=True)
    badge_type = Column(String)
    badge_points = Column(Integer)
    rewards = relationship("Reward", back_populates="badge")

class Task(SQLBaseModel):
    __tablename__ = 'tasks'
    id = Column(Integer, primary_key=True)
    title = Column(String)
    description = Column(Text)
    student_id = Column(Integer, ForeignKey('students.id'))
    status = Column(Enum(TaskStatusEnum))
    created_at = Column(DateTime)
    due_date = Column(DateTime, nullable=False)

    student = relationship("Student", back_populates="tasks")

class Notification(SQLBaseModel):
    __tablename__ = 'notifications'
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'))
    message = Column(Text)
    timestamp = Column(DateTime)
    message_type = Column(Enum(NotificationType))
    report_filename = Column(String, nullable=True)  # For reports

    user = relationship("User", back_populates="notifications")

class Report(SQLBaseModel):
    __tablename__ = "reports"
    id = Column(Integer, primary_key=True)
    screenshot = Column(String, nullable=True)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    title = Column(String, nullable=False)
    content = Column(Text, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    status = Column(String, default='open')  
    priority = Column(String, default='medium')
    category = Column(String, default='general')  
    admin_notes = Column(Text, nullable=True)
    admin_reply = Column(Text, nullable=True)
    reply_at = Column(DateTime, nullable=True)
    resolved_at = Column(DateTime, nullable=True)
    user = relationship("User", foreign_keys=[user_id], back_populates="reports")

class Resource(SQLBaseModel):
    __tablename__ = "resources"
    id = Column(Integer, primary_key=True)
    title = Column(String, nullable=False)
    description = Column(Text, nullable=False)
    url = Column(String, nullable=False)
    category = Column(String, nullable=False)
    instructor_id = Column(Integer, ForeignKey('teachers.id'), nullable=False)

    instructor = relationship("Teacher", back_populates="resources")

class FocusMode(SQLBaseModel):
    __tablename__ = 'focus_modes'
    id = Column(Integer, primary_key=True)
    student_id = Column(Integer, ForeignKey('students.id'))
    start_time = Column(DateTime, nullable=False)
    end_time = Column(DateTime, nullable=False)
    duration_minutes = Column(Integer, nullable=False)
    tab_switch_count = Column(Integer, default=0)

    student = relationship("Student", back_populates="focus_modes")

class ChatMessage(SQLBaseModel):
    __tablename__ = 'chat_messages'
    id = Column(Integer, primary_key=True)
    sender_id = Column(Integer, ForeignKey('users.id'))
    receiver_id = Column(Integer, ForeignKey('users.id'))
    content = Column(Text, nullable=False)
    timestamp = Column(DateTime, default=datetime.utcnow)

    sender = relationship("User", foreign_keys=[sender_id], back_populates="sent_messages")
    receiver = relationship("User", foreign_keys=[receiver_id], back_populates="received_messages")

class Announcement(SQLBaseModel):
    __tablename__ = "announcements"
    id = Column(Integer, primary_key=True)
    subject = Column(String, nullable=False)
    body = Column(Text, nullable=False)
    file_url = Column(String, nullable=True)
    recipient_role = Column(String, nullable=True)  # "all", "teacher", "student", "parent", or None
    specific_user_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    user = relationship("User")

class Submission(SQLBaseModel):
    __tablename__ = 'submissions'
    
    id = Column(Integer, primary_key=True)
    student_id = Column(Integer, ForeignKey('students.id'), nullable=False)
    assignment_id = Column(Integer, ForeignKey('assignments.id'), nullable=False)
    question_id = Column(Integer, ForeignKey('questions.id'), nullable=False)
    answer = Column(Text)  # Can store multiple choice answer or descriptive text
    is_correct = Column(Boolean, default=None)  # Will be calculated after submission
    submitted_at = Column(DateTime, default=datetime.utcnow)
    status = Column(String, default="pending")
    
    # Relationships
    student = relationship("Student")
    assignment = relationship("Assignment")
    question = relationship("Question")
    
def calculate_score(session, student_id, assignment_id):
    """Calculate and save score for a student's assignment submission."""
    from sqlalchemy import func
    
    # Get all submissions for this student and assignment
    submissions = session.query(Submission).filter_by(
        student_id=student_id, 
        assignment_id=assignment_id
    ).all()
    
    if not submissions:
        return None
    
    # Calculate total score
    total_points = 0
    max_points = 0
    
    for submission in submissions:
        question = submission.question
        max_points += question.points
        
        if submission.is_correct:
            total_points += question.points
    
    # Create or update score record
    existing_score = session.query(Score).filter_by(
        student_id=student_id,
        assignment_id=assignment_id
    ).first()
    
    percentage = (total_points / max_points * 100) if max_points > 0 else 0
    
    if existing_score:
        existing_score.score = total_points
        existing_score.max_score = max_points
        existing_score.percentage = percentage
        existing_score.status = ScoreStatus.graded
        existing_score.graded_at = datetime.utcnow()
    else:
        new_score = Score(
            student_id=student_id,
            assignment_id=assignment_id,
            score=total_points,
            max_score=max_points,
            percentage=percentage,
            status=ScoreStatus.graded,
            graded_at=datetime.utcnow()
        )
        session.add(new_score)
    
    session.commit()
    return existing_score or new_score

def get_student_scores(session, student_id):
    """Get all scores for a student."""
    return session.query(Score).filter_by(student_id=student_id).all()

def get_assignment_scores(session, assignment_id):
    """Get all scores for an assignment."""
    return session.query(Score).filter_by(assignment_id=assignment_id).all()


# class MailServerSetting(BaseModel):
#     __tablename__ = 'mail_server_settings'
#     id = Column(Integer, primary_key=True)
#     smtp_server = Column(String, nullable=False)
#     smtp_port = Column(Integer, nullable=False)
#     username = Column(String, nullable=False)
#     password = Column(String, nullable=False)
#     use_ssl = Column(Integer, default=1)  # 1 for True, 0 for False

#     def __repr__(self):
#         return f"<MailServerSetting(smtp_server={self.smtp_server}, smtp_port={self.smtp_port})>"
